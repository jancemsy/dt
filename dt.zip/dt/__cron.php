<?php

include("common.php");
set_time_limit(0);
ini_set('memory_limit', '154M');
header('Content-type: text/json');
header('Content-type: application/json');


process_filecleanup();
echo "File cleanup done";

process_s3_pending();
echo "Process s3 done";


#########################################################################################################################################
# FUNCTIONS 
#########################################################################################################################################

function generate_rss_feed() {
    $path = "content/rss/";
    $file = $path . "feeds.txt";
    $file2 = $path . "feeds.rss";
    $handle = @fopen($file, "r");
    $str = @fread($handle, filesize($file));


    $result = mysql_query("SELECT *FROM articles WHERE feed = 0 AND is_published = 1 ORDER BY id ASC  ");
    if (mysql_num_rows($result)) {
        $row = mysql_fetch_array($result);
        $categories = strip_tags(CategoryArticle::getCategoryNamesByIds($row["categories"]));
        $description = close_open_tags(word_cut(convert_to_original($row["text"]), 200));


        $permalink = Article::getPermalink($row);
        $thumb = PATH . Article::medthumb($row["thumb"]);
        $title = $row["title"];
        $date = date("r", strtotime($row["created_at"]));
        $description = '<p><img src="' . $thumb . '" alt="DietTools.com Image" width="150" style="margin-right:10px;border:1px solid #666666;" align="left" /><a href="' . $permalink . '"><font color="#006699" face="Arial, Helvetica, sans-serif" style="font-size:12px;font-weight:bold;">' . $title . '</font></a></p>
                                <p><font color="#666666" face="Arial, Helvetica, sans-serif" style="font-size:12px;">' . $description . '</font></p>';




        $str .= "<item> 
                <title>" . $title . "</title> 
                <link>" . $permalink . "</link> 
                <pubDate>" . $date . "</pubDate>
                <category>
                <![CDATA[ " . $categories . "
                    ]]>
                </category>
                <description>
                <![CDATA[ 
                " . $description . "
                ]]>
                </description>
                </item>
                ";

        $result = mysql_query("UPDATE articles SET feed = '1' WHERE id = '" . $row["id"] . "' ");
    }



    //////////////////////////////////////////////////////////////////////////////////////

    $result = mysql_query("SELECT *FROM recipes WHERE feed = 0 AND is_published = 1 ORDER BY id ASC  ");
    if (mysql_num_rows($result)) {
        $row = mysql_fetch_array($result);
        $categories = strip_tags(CategoryRecipe::getCategoryNamesByIds($row["categories"]));
        $description = close_open_tags(word_cut(convert_to_original($row["text"]), 200));


        $permalink = Recipe::getPermalink($row);
        $thumb = PATH . Recipe::medthumb($row["thumb"]);
        $title = $row["title"];
        $date = date("r", strtotime($row["created_at"]));
        $description = '<p><img src="' . $thumb . '" alt="DietTools.com Image" width="150" style="margin-right:10px;border:1px solid #666666;" align="left" /><a href="' . $permalink . '"><font color="#006699" face="Arial, Helvetica, sans-serif" style="font-size:12px;font-weight:bold;">' . $title . '</font></a></p>
                                <p><font color="#666666" face="Arial, Helvetica, sans-serif" style="font-size:12px;">' . $description . '</font></p>';


        $str .= "<item> 
                <title>" . $title . "</title> 
                <link>" . $permalink . "</link> 
                <pubDate>" . $date . "</pubDate>
                <category>
                <![CDATA[ " . $categories . "
                    ]]>
                </category>
                <description>
                <![CDATA[ 
                " . $description . "
                ]]>
                </description>
                </item>
                ";

        $result = mysql_query("UPDATE recipes SET feed = '1' WHERE id = '" . $row["id"] . "' ");
    }

    //////////////////////////////////////////////////////////////////////////////////////

    $result = mysql_query("SELECT *FROM fitness WHERE feed = 0 AND is_published = 1 ORDER BY id ASC  ");

    if (mysql_num_rows($result)) {
        $row = mysql_fetch_array($result);
        $categories = strip_tags(CategoryFitness::getCategoryNamesByIds($row["categories"]));
        $description = close_open_tags(word_cut(convert_to_original($row["description"]), 200));


        $permalink = Fitness::getPermalink($row);
        $thumb = fitness::getFeaturedThumb($row["params"]);
        $title = $row["name"];
        $date = date("r", strtotime($row["created_at"]));
        $description = '<p><img src="' . $thumb . '" alt="DietTools.com Image" width="150" style="margin-right:10px;border:1px solid #666666;" align="left" /><a href="' . $permalink . '"><font color="#006699" face="Arial, Helvetica, sans-serif" style="font-size:12px;font-weight:bold;">' . $title . '</font></a></p>
                                    <p><font color="#666666" face="Arial, Helvetica, sans-serif" style="font-size:12px;">' . $description . '</font></p>';


        $str .= "<item> 
                    <title>" . $title . "</title> 
                    <link>" . $permalink . "</link> 
                    <pubDate>" . $date . "</pubDate>
                    <category>
                    <![CDATA[ " . $categories . "
                        ]]>
                    </category>
                    <description>
                    <![CDATA[ 
                    " . $description . "
                    ]]>
                    </description>
                    </item>
                    ";

        $result = mysql_query("UPDATE fitness SET feed = '1' WHERE id = '" . $row["id"] . "' ");
    }

    update_file($file, $str); //partial

    $str = '
            <rss xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:wfw="http://wellformedweb.org/CommentAPI/" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:sy="http://purl.org/rss/1.0/modules/syndication/" xmlns:slash="http://purl.org/rss/1.0/modules/slash/" version="2.0">
            <channel> 
            <title>DietTools.com Newsletter RSS Feed</title> 
            <atom:link href="http://diettools.com/blog/feed/" rel="self" type="application/rss+xml"/> 
            <link>http://diettools.com</link> 
            <description>DietTools.com dieting news, tips, and support</description> 
            <lastBuildDate>Wed, 01 Jun 2011 16:18:22 +0000</lastBuildDate> 
            <language>en</language> 
            <sy:updatePeriod>hourly</sy:updatePeriod> 
            <sy:updateFrequency>1</sy:updateFrequency> 
            <generator>http://diettools.com</generator> 
               ' . $str . '
            </channel>
            </rss>';

    update_file($file2, $str); //actual feed
}

#########################################################################################################################################





$setting = Config::get("rss_setting");
$ampm = date("a");
$hour = date("g");
$day = date("N");


if ($setting["day$day"] == 1) {
    if ($setting["ampm$day"] == $ampm) {
        if ($setting["hour$day"] == $hour) {
            generate_rss_feed();
        }
    }
}


//delete older temporary files
$result = mysql_query("SELECT *FROM _temp WHERE type = 'video' AND created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)  ");
while ($row = mysql_fetch_array($result)) {
    $vid = $row["vid"];
    @unlink("content/video_recording/" . $vid . ".flv");
    Temp::deleteByVid($vid);
}
?> 