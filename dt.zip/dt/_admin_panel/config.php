<?php
 include("common.php"); 
 include("_header.php"); ?>
  
<div id="main">
               config
</div>		
                                
                                 
<?php include("_footer.php"); ?>  