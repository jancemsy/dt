<?php
 include("common.php"); 
 
 
 $menu_class[4] = 'class="current"' ;
 
 include("_header.php");
 
     
 
 if( isset($_POST["save_tools"]) ){
      
     for($i = 1; $i < 9; $i ++){
      if(isset($_FILES["upload$i"]) && $_FILES["upload$i"]["name"] != ""){
        $name = $_FILES["upload$i"]["name"];
        $ext   = end(explode(".",$name));    
        
        @unlink("../content/featured_tools/".$post["thumb$i"]);        
        
        $filename = "thumb$i.$ext";
        $thumb_dest = "../content/featured_tools/$filename";
        move_uploaded_file($_FILES["upload$i"]["tmp_name"], $thumb_dest );                 
        $_POST["thumb$i"] = $filename; 
      }          
     }
         
     Config::update("featured_tools",$_POST);  
          
 } 
 
   $_POST =  Config::get("featured_tools");
   
 
 ?>
  
<div class="box"> 
            <div class="title"> 
                    <h2>Featured Tools</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms">
               
   <form action="" method="post"    enctype="multipart/form-data"   >
       <?php for($i = 1; $i < 9; $i ++){ ?>
        <h2>Tool <?php echo $i; ?>:</h2>    
                <div style="padding-left:50px;">   
                    Tool Name: <br/>
                    <input type="text" class="text-input"  name="name<?php echo $i; ?>" size="70" value="<?php echo $_POST["name$i"]; ?>" /> <br/>
                    Description: <br/>
                    <textarea rows="5" class="text-input editor"  name="description<?php echo $i; ?>" cols="66"><?php echo $_POST["description$i"]; ?></textarea> <br/> 
                    Short Description: <br/>
                    <textarea rows="5" class="text-input"  name="short_description<?php echo $i; ?>" cols="72"><?php echo $_POST["short_description$i"]; ?></textarea> <br/> 
                   
                    <!--
                    More Link:<br/>
                    <input type="text" class="text-input"  name="link<?php echo $i; ?>" size="70" value="<?php echo $_POST["link$i"]; ?>" /> <br/>
                    Picture: (224px × 154px) <br/>
                   
                    <?php
                        $file = $_POST["thumb$i"];
                        if(!empty($file)){
                            echo "<input type='hidden' name='thumb$i' value='$file' /> <img src='../content/featured_tools/$file' width='100' />  ";
                        } 
                    ?> 
                    
                    <div class='row'>
                      <input type="file" name="upload<?php echo $i; ?>" />
                    </div>
                    -->
                  <br/> <br/>  
           </div>              
        <?php } ?>  
       
       
       
        <div class="row buttons">           
           <button type="submit" name="save_tools"><span>Save</span></button>                                                
        </div>
       
     </form>        

</div>		
</div>		
                
<script>
      initMCE();
</script>     
                                 
<?php include("_footer.php"); ?>  