<?php
 include("common.php"); 
 
 $menu_class[0] = 'class="current"' ;
 include("_header.php"); ?>
 
 
            <div class="box"> 
				<div class="title"> 
					<h2>Dashboard</h2> 
					<?php echo $_dahide; ?>
				</div> 
				<div class="content pages"> 
				
				 			                                                               
    <pre style="font-size: 12px; ">
    ****<b>To test Checkout Express, login to https://sandbox.paypal.com/ 
    as  jancemsy@yahoo.com and password is password (my main sandbox account).  </b>
    Once logged in, you can use this account to purchase a product:
     e: jancem_1311834081_per@yahoo.com 
     pw: 311834170 
  
    ****<b>To test Direct Payment use this info</b>
    address:    24285 Elm  
    zip code: 50000
    cvv2:  300 
    expiry: 2013

    American Express: 371449635398431
    American Express Corporate: 378734493671000
    Diners Club: 30569309025904
    Diners Club: 38520000023237
    Discover: 6011111111111117
    Discover: 6011000990139424
    JCB: 3530111333300000
    JCB: 3566002020360505
    MasterCard: 5555555555554444
               </pre>
                
			
    </div> 
</div> 
                                
                                 
<?php include("_footer.php"); ?>  