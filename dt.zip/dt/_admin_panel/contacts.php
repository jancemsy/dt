<?php
 include("common.php");  
 include("../library/contactus.php");
 
 
 if(isset($_GET["delete"])){
     $id = $_GET["delete"];
     Contactus::delete($id);         
 }
 
     
 $menu_class[9] = 'class="current"' ; 
 include("_header.php");       
?>
<style>
    .cms-home input{ width: 200px; }
    .cms-home textarea{ width: 470px; }
    hr{ color: #eee; }
</style>

 <div class="box"> 
        <div class="title"> 
                <h2>Contacts</h2> 
                <?php echo $_dahide; ?>
        </div> 
     <div class="content  pages">         
         <table >
             <tr>
                 <td>Date</td>
                 <td>Name</td>
                 <td>Email</td>
                 <td>Username</td>
                 <td>Subject</td>
                 <td>Message</td>                 
                 <td>Action</td> 
             </tr>
         <?php            
            $span = 2;
            $rows_per_page = 20;           
            $page = $_GET["page"]; 
            $url = PATH."_admin_panel/contacts.php?page=";                       
            $result = mysql_query("SELECT COUNT(*) FROM contactus WHERE 1 "); 
            $row2 = mysql_fetch_array($result);
            $numrows = $row2[0];
            $order = "created_at DESC";
            
            $tmp = GeneratePaginationAdmin(array(
                             "numrows" => $numrows,
                             "url" => $url,
                             "page" => $page,
                             "rows_per_page" => $rows_per_page,
                             "span" => $span 
                             ));
                      extract($tmp);                        
                                            
                      
           $result = mysql_query("SELECT *FROM contactus  ORDER BY $order  $limit "); 
                      
           while($row = mysql_fetch_array($result)){                              
               $button = "<a href='?delete={$row["id"]}' class='delete'>[Delete]</a>";               
               echo "<tr>
                 <td>{$row["created_at"]}</td>  
                 <td>{$row["name"]}</td>
                 <td>{$row["email"]}</td>
                 <td>{$row["username"]}</td>
                 <td>{$row["subject"]}</td>
                 <td>{$row["message"]}</td>               
                 <td>$button</td>               
             </tr>";               
           }
         ?>
         </table>    
         <div style="padding:10px;">
         <?php echo $pagination; ?>
          </div>
     </div>
 </div>     
   
<?php include("_footer.php"); ?>  