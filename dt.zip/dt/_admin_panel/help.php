<?php
 include("common.php");  
 include("modules/help/process.php");
 
 /*
 if(isset($_POST["save_cms"])){ 
     Config::update("footer_cms", $_POST );   
 }
      
 
 $_POST =  Config::get("footer_cms");  
  * 
  */
 
 
 $menu_class[9] = 'class="current"' ; 
 include("_header.php");   
 
 
 if($_GET["new"] || $_GET["edit"] ){
     $include = "modules/help/form.php";
 }else{
     $include = "modules/help/list.php";
 }
  
?>
<style>
    .cms-home input{ width: 200px; }
    .cms-home textarea{ width: 470px; }
    hr{ color: #eee; }
</style>

 <div class="box"> 
        <div class="title"> 
                <h2>Help</h2> 
                <?php echo $_dahide; ?>
        </div> 
     <div class="content forms">                                   
         <?php include($include); ?>                  
     </div>
 </div>     

<script> 
</script>
    

   


<?php include("_footer.php"); ?>  