<?php
 include("common.php"); 
 $path = "../content/splash/";     
 if(!file_exists($path)){  mkdir($path); }

 
 if(isset($_POST["save_cms"])){ 
     Config::update("homepage_cms", $_POST );   
 }
  
     
 $height = 399; 
 $width = 465; 
  

 $quality = 100; 
 
 if( isset($_GET["delete_splash"]) ){ 
    $id = $_GET["delete_splash"];
    $splash = new Splash($id);    
    @unlink("../".$splash->thumb);     
    Splash::delete($id);
    jumpto("?");
}

       
 if( isset($_POST['crop_images'] ) ){  //ajax call   
        $_SESSION["pending_crop"] = ""; 
        $size = count($_POST['h']);

        for($i = 0; $i< $size; $i++){
          $des_h = $_POST['h'][$i];
          $des_w = $_POST['w'][$i];
          $source_x = $_POST['x'][$i];
          $source_y = $_POST['y'][$i];
          $src = $_POST['thumb'][$i];    
          
           if( !empty($des_h) && !empty($src) ){
                    $filename = end(explode("/",$src));
                    $filename = str_replace("-orig","",$filename);                        
                    $destination = $path.$filename;                   
                    
                    $ext = strtolower(end(explode(".",$src)));

                    switch ($ext){
                        case "gif":
                          $img_r = imagecreatefromgif($src);
                          break;
                        case "png":
                          $img_r = imagecreatefrompng($src);
                          break;
                        default:
                          $img_r = imagecreatefromjpeg($src);
                          break;
                      }

                    $dst_r = ImageCreateTrueColor( $width , $height );
                    imagecopyresampled($dst_r,$img_r,0,0,$source_x,$source_y ,$width ,$height ,$des_w ,$des_h);

                    @unlink($destination);  //delete the old one
                    switch($ext){
                        case "gif":
                           imagegif($dst_r, $destination);
                          break;
                        case "png":
                           imagepng($dst_r, $destination);
                          break;
                        default:
                           imagejpeg($dst_r, $destination,$quality);
                          break;
                      }
                      
                  @unlink($src);//unlink original  
                  //@createThumb($destination,$thumb_dest,$width,$height); 
          }
        }
        die("1");
}



if(isset($_POST["add_splash"])){   
        $name = $_FILES['upload']["name"];
        
        if(!empty($name)){
            @unlink("../".$_POST["thumb"]);            
            $ext   = end(explode(".",$name));
            $time = time();                 
            $filename = "$time.$ext";
            $thumb_dest = $path.$filename;
            $thumb_orig = $path."$time-orig.$ext"; 
            $_POST["thumb"] = str_replace("../","",$path).$filename;

            move_uploaded_file($_FILES["upload"]["tmp_name"], $thumb_orig);                     
            @createThumb($thumb_orig, $thumb_dest, $width, $height);
            $pending_crop[] = $thumb_orig;  
        }
        
        $params = array("thumb" => $_POST["thumb"],
                        "type" => $_POST["type"],
                        "tab" => $_POST["tab"],
                        "num" => $_POST["num"] );
        
        
        if($_POST["id"] != ""){
           $params["id"] = $_POST["id"];
           Splash::update($params); 
        }else{
           Splash::add($params); 
        }
     
     if(count($pending_crop) > 0 ){
         $_SESSION["pending_crop"] = serialize($pending_crop);
         jumpto("?crop=1"); 
     }else{
           jumpto("?"); 
     }
 }
 


 
 $_POST =  Config::get("homepage_cms");  
 $menu_class[11] = 'class="current"' ; 
 include("_header.php");   
 
 
 
 if($_GET["crop"] == 1){ 
?> 







<script src="<?php echo PATH; ?>js/jcrop/js/jquery.Jcrop.js"></script>
<link rel="stylesheet" href="<?php echo PATH; ?>js/jcrop/css/jquery.Jcrop.css" type="text/css" />
<style type="text/css">
    #crop-container{ background: none;  }
    #crop-container h2{ font-size: 20px; margin: 5px auto 5px auto; background: #fff; padding:10px; }
    #images-holder{ margin-top: 20px; position: absolute; }
    #images-holder h2{ margin: 20px 0 10px 0; color: #fff; }

     #images-holder hr{ color:#fff; }

    #preview_holder{ display:none; width:<?php echo $width; ?>px; height:<?php echo $height; ?>px; z-index:999999; border:5px solid red; position:fixed; bottom:0px; right:0px;  overflow:hidden; }
    #bottom-container{ padding:10px;  background:#fff; margin-top:40px;
     bottom:0px; left:0px;
     border-top:2px solid #333;
     width:100%;
     position:fixed;
     padding-left:200px;
     z-index:999998;
    }
    #bottom-container input{ font-size:15px; font-weight:bold;}
</style>
<form id="form-crop" action="" method="post"> 
<input type="hidden" name="crop_images" value="1" />
<div style="padding:10px;">
<h1>Crop Images</h1>

<?php

     $crop = unserialize( $_SESSION["pending_crop"]) ;
     //= unserialize($pending_crop);


     $i = 0;
     foreach($crop as $thumb){
         $i++;
         $id = "t$i";               
         ?>
         <img  src="<?php echo $thumb; ?>" class="crop" tid="<?php echo $id ;?>" />
         <input type="hidden" name="thumb[]" value="<?php echo $thumb; ?>" />
         <input type="hidden" name="h[]" value="" class="h<?php echo $id ;?>" />
         <input type="hidden" name="w[]" value="" class="w<?php echo $id ;?>" />
         <input type="hidden" name="x[]" value="" class="x<?php echo $id ;?>" />
         <input type="hidden" name="y[]" value="" class="y<?php echo $id ;?>" />
       <?php

     }

?>

</div>    
<script type="text/javascript">
  $("#form-crop").submit(function(){
        $("#submit-btn").val("Please wait, this could take a while...").attr("disabled","true");
      $.post("", $("#form-crop").serialize(),function(data){          
          location.href="?";
        });
       return false;
    }); 
    
     var $selected_image  = "";
     var $selected_h = "";
     var $selected_w = "";

    var api = $('.crop').Jcrop({
                onChange: showPreview,
                onSelect: showPreview,
                aspectRatio:  <?php echo ($width/ $height); ?>
         }) ;
                 
   function showPreview(coords){

        $("#preview_holder").show();

        if( $selected_image != "" ){
          var url = $selected_image.attr("src");
          
           if($('#preview').attr("src") !=  url || $selected_h == "" || $selected_h == 0 ){     
               $('#preview').attr("src",url);
               var newImg = new Image();
               newImg.src = url;
               $selected_h = newImg.height;
               $selected_w = newImg.width;
          }
        }


        if (parseInt(coords.w) > 0)
        {

                //var reduce_size = $selected_w - $selected_image.width();


                var h = $selected_h;
                var w = $selected_w;                
                <?php
                  echo " var rx = $width / coords.w; ";
                  echo " var ry = $height / coords.h; ";
                ?>
    
                //var rx = 100 / coords.w;
                //var ry = 100 / coords.h;
                //$width = 372;
                //$height = 248;

                 var final_w = Math.round(rx * w);
                 var final_h = Math.round(ry * h) ;
                 var final_x = Math.round(rx * coords.x);
                 var final_y = Math.round(ry * coords.y);

                 var tid = $selected_image.attr("tid");
                 $(".h"+tid).val(coords.h);
                 $(".w"+tid).val(coords.w);
                 $(".x"+tid).val(coords.x);
                 $(".y"+tid).val(coords.y);

                $("#dummy").html("w: "+coords.w+"<br/>h: "+coords.h+"<br/>x: "+ coords.x+" <br/>y: "+ coords.y );

                $('#preview').css({
                        width: final_w + 'px',
                        height: final_h + 'px',
                        marginLeft: '-' +  final_x + 'px',
                        marginTop: '-' +  final_y  + 'px'
                });
        }
}                 

</script>    


<div id="preview_holder">
  <div id="dummy" style="position:absolute; background: #fff;"></div>
  <img src="" id="preview" />
 </div>

<div id="bottom-container">
  <input type="submit" id="submit-btn" name="crop" value="save"  />
  Note: Please wait to load all images completely to start cropping...
</div> 
</form>






<?php
 
 }else{ 

      if(isset($_GET["edit"])){
            $id = $_GET["edit"];
            $splash = new Splash($id);
            if( !empty($splash->id) ){        
                $_POST = $splash->array; 
                $_thumb = "<img src='".PATH.$splash->thumb."' width='50' />";
            } 
      }
?>
<style>
    .cms-home input,
    .cms-home textarea{ width: 400px; }
</style>

 <div class="box"> 
        <div class="title"> 
                <h2>Home Page CMS</h2> 
                <?php echo $_dahide; ?>
        </div> 
     <div class="content forms" style="display:none;">
         <form action="" method="post">
              <table class="cms-home">
                    <tr>
                        <td>Title:</td><td><input type="text" name="title" value="<?php echo $_POST['title']; ?>"   size="97" /></td>                        
                    </tr>
                    <tr>
                        <td>Description:</td>
                        <td><textarea name="description" class="mceEditor" cols="72"><?php echo $_POST['description']; ?></textarea></td>                        
                    </tr> 
                    <tr>
                        <td>Bullets (separated by |):</td>
                        <td><textarea name="bullets" cols="72"><?php echo $_POST['bullets']; ?></textarea></td>                        
                    </tr>  

                    <tr>
                        <td>Testimonial Title:</td>
                        <td> <input type="text" name="text_1" value="<?php echo $_POST["text_1"]; ?>" /> </td>
                      </tr>
                    <tr>
                        <td>Testimonial Desc:</td>
                        <td>
                            <textarea name="text_2"><?php echo $_POST["text_2"]; ?></textarea> 
                        </td>
                      </tr>  
                    <tr>
                        <td>Diet Title:</td>
                        <td> <input type="text" name="text_3" value="<?php echo $_POST["text_3"]; ?>" /> </td>
                      </tr>
                    <tr>
                        <td>Diet Desc:</td>
                        <td> <textarea name="text_4"><?php echo $_POST["text_4"]; ?></textarea>  </td>
                      </tr>  
                      
                      <tr>
                        <td>Recent Article Title:</td>
                        <td> <input type="text" name="text_5" value="<?php echo $_POST["text_5"]; ?>" /> </td>
                      </tr>
                    <tr>
                        <td>Recent Article Desc:</td>
                        <td> <textarea name="text_6"><?php echo $_POST["text_6"]; ?></textarea> </td>
                      </tr>  
                    <tr>
                        <td>Recent Video  Title:</td>
                        <td> <input type="text" name="text_7" value="<?php echo $_POST["text_7"]; ?>" /> </td>
                      </tr>
                    <tr>
                        <td>Recent Video  Desc:</td>
                        <td>  <textarea name="text_8"><?php echo $_POST["text_8"]; ?></textarea>  </td>
                      </tr>   
                     
                      
                      <tr>
                        <td>Diet Category Title:</td>
                        <td>  <input name="text_9" value="<?php echo $_POST["text_9"]; ?>" />  </td>
                      </tr>  
                      
                      <tr>
                        <td>Facebook  Title:</td>
                        <td>  <input name="text_11" value="<?php echo $_POST["text_11"]; ?>" />  </td>
                      </tr> 
                      
                      <tr>
                        <td>Facebook  code:</td>
                        <td>  <textarea name="text_111"><?php echo $_POST["text_111"]; ?></textarea></td>
                      </tr> 
                      
                      <tr>
                        <td>Twitter Title:</td>
                        <td>  <input name="text_10" value="<?php echo $_POST["text_10"]; ?>" />  </td>
                      </tr>  
                      
                      <tr>
                        <td>Twitter  code:</td>
                        <td>  <textarea name="text_101"><?php echo $_POST["text_101"]; ?></textarea></td>
                      </tr> 
                      
              </table>   
             <div class="row buttons">                                        
                    <button type="submit" name="save_cms"><span>Save</span></button>                                                
             </div>
         </form>
         
     </div>
 </div>     
  

 <div class="box"> 
        <div class="title"> 
                <h2>Home Page Images</h2> 
                <?php echo $_dahide; ?>
        </div> 
        <div class="content forms">   
                         <form action="" method="post"  enctype="multipart/form-data" id="splash_form" >
                             <input type="hidden" name="id" value="<?php echo $_POST["id"]; ?>" /> 
                             <input type="hidden" name="thumb" value="<?php echo $_POST["thumb"]; ?>" /> 
                             <input type="hidden" name="type" value="home" /> 
                             
                             <table>
                                 <tr>
                             <td>Num:</td><td> <input type="text" name="num" value="<?php echo $_POST["num"]; ?>" /> </td>
                                 </tr>
                               <tr>
                                   <!-- 
                             <td>Page:</td><td> <select name="type">
                                 <option <?php echo $_POST["type"] == 'home' ? 'selected' : ''; ?> >home</option>
                                 <option <?php echo $_POST["type"] == 'landing' ? 'selected' : ''; ?> >landing</option>
                                 <option <?php echo $_POST["type"] == 'all' ? 'selected' : ''; ?> >all</option>                                 
                             </select></td>
                                 </tr>     -->
                             <tr> 
                                   
                             <td>Tab:</td><td> <select name="tab">
                                 <option <?php echo $_POST["tab"] == 'tools' ? 'selected' : ''; ?> >tools</option>
                                 <option <?php echo $_POST["tab"] == 'community' ? 'selected' : ''; ?> >community</option>
                                 <option <?php echo $_POST["tab"] == 'experts' ? 'selected' : ''; ?> >experts</option>
                                 <option <?php echo $_POST["tab"] == 'news' ? 'selected' : ''; ?> >news</option>
                             </select></td>
                                 </tr>
                                 <tr>
                                     <td>Image (463px397px) : </td><td><div class="row"  >
                                          <input type="file" id="upload" name="upload" value="" />  <br/>
                                          <?php echo $_thumb; ?>
                                          <br/>
                                          
                                        </div> </td>       
                                 </tr>
                             </table>
                               
                                 <div class="row buttons"> 
                                       <button type="button" onclick="location.href='?'" ><span>Cancel</span></button>                                                
                                       <button type="submit" name="add_splash"><span>Save</span></button>                                                
                                    </div>
                         </form>                         
         <br/>
     
       <div class="content pages">  
       <table cellspacing="0" class="table">
            <thead>  
            <tr class="tr-header">
                <td>ID</td>            
                <td>Thumb</td> 
                <td>Tab</td> 
                <td>Order</td> 
                <td width="70">Action</td>         
            </tr>
            </thead> 
            <?php
               $output = "";
               $list = Splash::getList(99999,'home' );
               $i = 0;
               foreach($list as $item){
                   $array = unserialize($item["params"]);

                   
                   $button = "<a href='?delete_splash={$item['id']}' class='delete-btn'>$_dadelete</a> <a href='?edit={$item['id']}'>$_daedit</a>";
                   $i++;                  
                   $tr_class = $i%2 == 0 ? "tr-odd" : "tr-even";                   
                   $img  = "<img src='".PATH.$item["thumb"]."'  width='150'  /> ";
                   $text =  string_cut(strip_tags($array['description']),250);

                   $output .= "<tr class='$tr_class' >
                        <td>{$item['id']}</td>   
                        <td>$img</td>
                        <td>{$item['tab']}</td>
                        <td>{$item['num']}</td> 
                        <td>$button</td>
                    </tr>";

               }
               echo $output;

            ?>    
        </table>
       </div>
     </div>
     
     
</div>      



 



<?php

 } 
?>




<?php include("_footer.php"); ?>  