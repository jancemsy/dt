<?php
 include("common.php");  
 session_destroy(); 
 jumpto('login.php');
?>  