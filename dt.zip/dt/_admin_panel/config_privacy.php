<?php
 include("common.php"); 
 
if(isset($_POST["save_cms"])){ 
     Config::update("privacy_cms", $_POST );   
 }
 
 
 $_POST =  Config::get("privacy_cms");   
 $menu_class[11] = 'class="current"' ;
 
 include("_header.php"); 

  

?> 

 <div class="box"> 
        <div class="title"> 
                <h2>Privacy CMS</h2> 
                <?php echo $_dahide; ?>
        </div> 
        <div class="content forms">  
            
<form action="" method="post" enctype="multipart/form-data"    >  
    <table style="width:100%;"> 
        <tr>
            <td>Title:</td><td><input type="text" style="width:600px;" name="title" value="<?php echo $_POST['title']; ?>" size="105" /></td>                        
        </tr>
        <tr>
            <td>Text:</td>
            <td>
                <textarea name="text" class="mceEditor"  ><?php echo $_POST['text']; ?></textarea>
            </td>                        
        </tr> 
    </table>
     
       
    <div class="row buttons">                  
           <button type="submit" name="save_cms"><span>Save</span></button>                                                
     </div> 
</form>



<script type="text/javascript">  initMCE(); </script>  

        </div>
</div>     
                                
                                 
<?php include("_footer.php"); ?>  