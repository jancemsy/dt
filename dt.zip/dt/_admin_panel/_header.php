<?php
$_dapath = PATH . "_admin_panel/dreamadmin/";
$_daedit = '<img src="' . $_dapath . 'gfx/icon-edit.png" alt="Edit this item" />';
$_dadelete = '<img src="' . $_dapath . 'gfx/icon-delete.png" alt="Delete this item" />';
$_dahide = '<img src="' . $_dapath . 'gfx/title-hide.gif" class="toggle" alt="" />';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"> 

    <head>	
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="robots" content="noindex,nofollow" />
        <title>DietTools.com</title>

        <link rel="stylesheet" href="<?php echo PATH; ?>css/admin.css" type="text/css" media="screen" />


        <style type="text/css">  
            @import url("<?php echo $_dapath; ?>css/style.css"); 
            @import url('<?php echo $_dapath; ?>css/style_text.css');
            @import url('<?php echo $_dapath; ?>css/c-grey.css'); 
            @import url('<?php echo $_dapath; ?>css/datepicker.css');
            @import url('<?php echo $_dapath; ?>css/form.css');
            @import url('<?php echo $_dapath; ?>css/menu.css');
            @import url('<?php echo $_dapath; ?>css/messages.css');
            @import url('<?php echo $_dapath; ?>css/statics.css');
            @import url('<?php echo $_dapath; ?>css/tabs.css');


            @import url('<?php echo $_dapath; ?>css/wysiwyg.css');
            @import url('<?php echo $_dapath; ?>css/wysiwyg.modal.css');
            @import url('<?php echo $_dapath; ?>css/wysiwyg-editor.css');         
            /*input[type=file]{ border:none; background:none; }*/
        </style> 

        <style type="text/css">
            .clear{ clear: both; }
            .clickthis{ text-decoration: underline!important; font-weight: bold; } 

            div.wysiwyg iframe, div.wysiwyg {   width: 700px!important;  }
            div.wysiwyg iframe{ border: none;  }


            .mceEditor,.mceEditor_target, ._editor{ width: 745px!important; height: 200px; }

            .clean-row{ border:none; }
            .clean-row-small{ border:none; }
            .clean-row-small input{ width: 150px; }
            .clean-row input , .clean-row textarea{ width: 590px; } 
            tr.draft *{ color: #ccc!important;}
            tr.draft a{ text-decoration: underline!important;}
            tr.draft img{ opacity:0.4; filter:alpha(opacity=50); /* For IE8 and earlier */}            
            .mce-menubtn{ height: 24px!important; }
        </style>         


        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
        <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css" />
        <script src="http://code.jquery.com/ui/1.10.2/jquery-ui.js"></script> 


        <script type="text/javascript" src="<?php echo PATH; ?>js/common.js"></script>	
        <script type="text/javascript" src="<?php echo PATH; ?>js/admin.js?23"></script>


        <script type="text/javascript" src="<?php echo $_dapath; ?>js/jquery-ui.js"></script>
        <script type="text/javascript" src="<?php echo $_dapath; ?>js/jquery.pngFix.js"></script>
        <script type="text/javascript" src="<?php echo $_dapath; ?>js/hoverIntent.js"></script>
        <script type="text/javascript" src="<?php echo $_dapath; ?>js/superfish.js"></script>
        <script type="text/javascript" src="<?php echo $_dapath; ?>js/supersubs.js"></script>
        <script type="text/javascript" src="<?php echo $_dapath; ?>js/date.js"></script>
        <script type="text/javascript" src="<?php echo $_dapath; ?>js/jquery.sparkbox-select.js"></script>
        <script type="text/javascript" src="<?php echo $_dapath; ?>js/jquery.datepicker.js"></script>
        
        <?php 
         if(!defined("NO_FILE_TWEAK") || isset($_GET["crop"]) ){ 
        ?>
        <script type="text/javascript" src="<?php echo $_dapath; ?>js/jquery.filestyle.mini.js"></script>
         <?php } ?>
        <!--this will mess up some form so better not use it--->
        
        <script type="text/javascript" src="<?php echo $_dapath; ?>js/jquery.flot.js"></script>
        <script type="text/javascript" src="<?php echo $_dapath; ?>js/jquery.graphtable-0.2.js"></script>  
        <script type="text/javascript" src="<?php echo $_dapath; ?>js/inline.js"></script> 


        <script type="text/javascript" src="<?php echo PATH; ?>js/tinymce/tinymce.min.js"></script> 

        <link rel="stylesheet" type="text/css" href="<?php echo PATH; ?>js/datetimepicker/jquery.datetimepicker.css"/>
        <script type="text/javascript" src="<?php echo PATH; ?>js/datetimepicker/jquery.datetimepicker.js"></script>



        <!--
        this editor is not working with higher jquery version 
        <script type="text/javascript" src="<?php echo PATH; ?>js/editors/nicEdit.js"></script>
        -->

    </head> 
    <body>

        <div class="wrapper"> 
            <div class="container"> 

                <!--[if !IE]> START TOP <![endif]-->  
                <div class="top"> 
                    <div class="split"><h1><a href="../"><?php echo SITE_NAME; ?></a></h1></div> 
                    <div class="split"> 
                        <div class="logout"><img src="<?php echo $_dapath; ?>gfx/icon-logout.gif" align="left" alt="Logout" />  <a href="logout.php">Log out</a></div> 
                        <div><img src="<?php echo $_dapath; ?>gfx/icon-welcome.gif" align="left" alt="Welcome" /> Welcome <?php echo $Admin->name; ?>
                            [<a href="users.php?cpassword=1">Change Password</a>]
                        </div> 
                    </div> 
                </div> 
                <!--[if !IE]> END TOP <![endif]-->  

                <!--[if !IE]> START MENU <![endif]-->  
                <div class="menu"> 
                    <ul> 

                        <li <?php echo $menu_class[0]; ?> ><a href="./">Dashboard</a></li> 
                        <li class="break"></li>
                        <li  <?php echo $menu_class[4]; ?> ><a href="featured_tools.php">Tools</a>
                            <ul> 
                                <li><a href="featured_tools.php">List</a></li>
                                <!-- 
                                <li><a href="resources.php?become_member=1">Become a member</a></li>
                                <li><a href="resources.php?heading=1">Heading</a></li>
                                <li><a href="featured_tools.php">Tools</a></li>
                                <li><a href="resources.php?ebook=1">Ebook</a></li> 
                                <li><a href="resources.php?discount=1">Exclusive Discounts</a></li> 
                                <li><a href="resources.php?membership=1">Membership</a></li> 
                                -->
                                <li><a href="resources.php?community=1">Community</a></li> 
                                <li><a href="resources.php?experts=1">Experts</a></li> 
                                <li><a href="resources.php?news=1">News, Recipes & Tips</a></li>                                                             
                                <li><a href="resources.php?testimonials=1">Testimonials</a></li> 
                                <li><a href="resources.php?tdesc=1">[Settings]</a></li> 
                            </ul> 
                        </li>    
                        <!-- <li class="break"></li>
                        <li  <?php echo $menu_class[1]; ?> ><a href="splash.php">Splash</a></li>
                        -->

<!--  <li class="break"></li> <li  <?php echo $menu_class[2]; ?> ><a href="category.php">Category</a></li> -->
                        <li class="break"></li> 
                        <li  <?php echo $menu_class[3]; ?> >
                            <a href="diets.php">Diets</a>    
                            <ul>    
                                <li><a href="diets.php">Diet List</a></li> 
                                <li><a href="diets.php?featured=1">Featured Slots</a></li> 
                                <li><a href="diets.php?cat=1">Categories</a></li>
                                <li><a href="diets.php?user_reviews=1">User Reviews</a></li>                                                            
                                <!-- <li><a href="diets.php?gallery=1">Galleries</a></li> -->
                                <li class="break"></li> 
                                <li> <a href="diets.php?new=1" >[New Diet]</a></li>     
                                <li class="break"></li>                                                             
                                <li><a href="diets.php?ads=1">[Ads]</a></li>
                                <li><a href="diets.php?tdesc=1">[Settings]</a></li>                                                            
                            </ul> 
                        </li> 

                        <li class="break"></li>
                        <li  <?php echo $menu_class[10]; ?>  ><a href="fitness.php">Workouts</a>
                            <ul> 
                                <li><a href="fitness.php">List</a></li>
                                <li><a href="fitness.php?featured=1">Featured Slots</a></li> 
                                <li><a href="fitness.php?cat=1">Categories</a></li> 
                                <li><a href="fitness.php?ads=1">[Ads]</a></li>
                                <li><a href="fitness.php?tdesc=1">[Settings]</a></li>
                            </ul>       
                        </li>                                                                      
                        <li class="break"></li> 
                        <li  <?php echo $menu_class[5]; ?>  ><a href="articles.php">Articles</a>
                            <ul> 
                                <li><a href="articles.php">List</a></li>
                                <li><a href="articles.php?featured=1">Featured Slots</a></li> 
                                <li><a href="articles.php?cat=1">Categories</a></li> 
                                <li><a href="articles.php?ads=1">[Ads]</a></li>
                                <li><a href="articles.php?tdesc=1">[Settings]</a></li>
                            </ul>       
                        </li>                                                                      
                        <li class="break"></li> 
                        <li  <?php echo $menu_class[6]; ?>  ><a href="videos.php">Videos</a>
                            <ul> 
                                <li><a href="videos.php">List</a></li>
                                <li><a href="videos.php?featured=1">Featured Slots</a></li> 
                                <li><a href="videos.php?cat=1">Categories</a></li>                                                              
                                <li><a href="videos.php?ads=1">[Ads]</a></li>
                                <li><a href="videos.php?tdesc=1">[Settings]</a></li>
                            </ul>       
                        </li> 
                        <li class="break"></li> 
                        <li  <?php echo $menu_class[7]; ?>  ><a href="recipes.php">Recipes</a>
                            <ul> 
                                <li><a href="recipes.php">List</a></li>                                                            
                                <li><a href="recipes.php?cat=1">Categories</a></li>
                                <li><a href="recipes.php?featured=1">Featured Slots</a></li>                                                            
                                <li><a href="recipes.php?ads=1">[Ads]</a></li>
                                <li><a href="recipes.php?tdesc=1">[Settings]</a></li>
                            </ul>       
                        </li>   
                        <li class="break"></li> 
                        <li  <?php echo $menu_class[8]; ?>  >  
                            <a href="products.php">Products</a>
                            <ul> 
                                <li><a href="products.php?update_qty=1">Update Products by CSV</a></li>
                                <li><a href="products.php">Supplements/Equipment/Books/etc..</a></li>
                                <li><a href="podcasts.php">Podcasts </a></li>                                                             
                                <li><a href="subscriptions.php">Premium Subscriptions</a></li>
                                <!-- <li><a href="subscriber_payments.php">Subscriber Payments</a></li>-->
                                <li><a href="transactions.php">Transactions</a></li>                                                             

                                <li><a href="config_products.php">Products/Services Configuration</a></li>

                            </ul>                                                   
                        </li>   
                        <li class="break"></li> 
                        <li  <?php echo $menu_class[11]; ?>  >
                            <a href="#">CMS</a>
                            <ul> 
                                <li><a href="config_jumpstarterkit.php">Jumpstarter Kit</a></li> 
                                <li><a href="config_social.php">Social Media Buttons</a></li> 
                                <li><a href="config_started.php">Lets Get Started Video & Thumbnail</a></li> 
                                <li><a href="config_about.php">About Us</a></li> 
                                <li><a href="config_privacy.php">Privacy</a></li> 
                                <li><a href="challenges.php">Challenges</a></li>
                                <li><a href="premium.php">Premium Page</a></li>
                                <!--<li><a href="config_products.php">Checkout Products/Services</a></li> -->
                                <li><a href="interview_samples.php">Premium Interview Samples</a></li>                                                              
                                <li><a href="config_pointsystem.php">Point System</a></li> 
                                <li><a href="config_footer.php">Footer</a></li> 
                                <li><a href="config_home.php">Home Page</a></li>  
                                <li><a href="config_landing.php">Landing Page</a></li> 
                                <li><a href="config_register.php">Register CMS</a></li>

                                <li><a href="join_block.php">Join Box</a></li>        
                                <li><a href="config_weight_loss_gain.php">User Goal Settings</a></li> 

                            </ul> 
                        </li>    

                        <li class="break"></li> 
                        <li  <?php echo $menu_class[15]; ?>  > 
                            <a href="user_list.php">Users</a>                                          
                            <ul> 
                                <li><a href="user_list.php?joined=1">Challenge Participants</a></li>
                            </ul>    

                        </li>    



                        <li class="break"></li> 
                        <li  <?php echo $menu_class[9]; ?>  > 
                            <a href="#">More..</a>
                            <ul>

                                <li><a href="rss_feed.php">RSS Feed</a></li>
                                <li><a href="contacts.php">Contacts</a></li> 
                                <li><a href="newsletter.php">Newsletter Generator</a></li> 
                                <li><a href="foods.php">Foods</a></li>                                                              
                                <li><a href="help.php">Help</a></li> 



                                <li><a href="exercise.php">Exercises/MET</a>  
                                    <li><a href="seo_meta.php">SEO Meta</a></li>   
                                    <li><a href="register_email_template.php">Register Welcome Email Template</a></li>
                                    <li><a href="templates.php">Email Notification Templates</a></li>
                                    <li><a href="announcement.php">Announcement</a></li>                                                             
                                    <li><a href="users.php">User Admins</a></li>




                            </ul>

                        </li>


                    </ul> 

                </div> 
                <!--[if !IE]> END MENU <![endif]-->  


                <!--[if !IE]> START HOLDER <![endif]--> 
                <div class="holder"> 
                    <div id="popup-content-box"><div class="content"></div></div><div id="popup-overlay" ></div>





