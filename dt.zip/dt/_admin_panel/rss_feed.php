<?php
 include("common.php");  

 if( $_GET["clear_rss"] != "" ){
     $result = mysql_query("UPDATE articles SET feed = 0 WHERE 1");
     $result = mysql_query("UPDATE recipes SET feed = 0 WHERE 1");
     $result = mysql_query("UPDATE fitness SET feed = 0 WHERE 1");
     update_file("../content/rss/feeds.txt",""); 
     update_file("../content/rss/feeds.rss",' <rss xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:wfw="http://wellformedweb.org/CommentAPI/" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:sy="http://purl.org/rss/1.0/modules/syndication/" xmlns:slash="http://purl.org/rss/1.0/modules/slash/" version="2.0">
            <channel> 
            <title>DietTools.com Newsletter RSS Feed</title> 
            <atom:link href="http://diettools.com/blog/feed/" rel="self" type="application/rss+xml"/> 
            <link>http://diettools.com</link> 
            <description>DietTools.com dieting news, tips, and support</description> 
            <lastBuildDate>Wed, 01 Jun 2011 16:18:22 +0000</lastBuildDate> 
            <language>en</language> 
            <sy:updatePeriod>hourly</sy:updatePeriod> 
            <sy:updateFrequency>1</sy:updateFrequency> 
            <generator>http://diettools.com</generator>                
            </channel>
            </rss>'); 
     jumpto("?");
}

 if( isset($_POST["save_rss"]) ){ 
     Config::update("rss_setting", $_POST); 
     jumpto("?");
}

 $_POST =  Config::get("rss_setting");   
  
 
$menu_class[9] = 'class="current"' ; 
include("_header.php"); ?>

<div class="box"> 
            <div class="title"> 
                    <h2>RSS FEED</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
<div class="content  forms" > 
    
Current Time: <?php echo date("r");    ?> 
<a href="?clear_rss=1">Clear RSS</a> |  
<a href="../newsletter/feed" target="_blank">View RSS</a> <br/><br/>
 
Run RSS Cron job at:
<form action="" method="post"    >
<table> 
    <?php
    $days = array("","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"); 
    for($i = 1; $i < 8; $i ++){ ?>
       <tr>
        <td> <label><input type="checkbox" name="day<?php echo $i; ?>" <?php echo $_POST["day$i"] == "1" ? "checked" : ""; ?> value="1" /> <?php echo $days[$i]; ?> </label> </td>
        <td><select name="hour<?php echo $i; ?>"><?php for($j = 1; $j <=  12; $j++){ 
                          echo "<option ".($_POST["hour$i"] == $j ? "selected" : "").">$j</option>";
                      }?>                                    
            </select></td>
            <td><select name="ampm<?php echo $i; ?>"><option value="am" >am</option><option value="pm"  <?php echo $_POST["ampm$i"] == "pm" ? "selected" : ""; ?>  >pm</option></select></td>
        </tr>
     <?php } ?>  
        <tr><td colspan="3"> 
                  <div class="row buttons">                                                                 
                     <button type="submit"  name="save_rss"><span>Save</span></button>                                                
                  </div>
        </td></tr>
</table>
</form>  


</div>
</div>    


<?php include("_footer.php"); ?>  