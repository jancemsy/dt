<?php
 include("common.php");  
 include("modules/fitness/process.php");  
 
 if($_GET["ads"] == 1 ){    
    $title = "Ads";
    $include = "modules/fitness/ads.php";    
 }else if($_GET["cat"] == 1){     
    $include = "modules/fitness/categories.php";
    $title = "Fitness Categories";
 }else if($_GET["catedit"]  != ""){    
    $include = "modules/fitness/cat_form.php";
 }else if($_GET["new_cat"] == 1){     
    $include = "modules/fitness/cat_form.php";
    $title = "New Fitness Category";
 }else if($_GET["new"] == 1 || $_GET["edit"] != ""){      
    $include = "modules/fitness/form.php";    
 }else if($_GET["crop"] == 1 ){      
    $include = "modules/fitness/crop.php";        
 }else  if($_GET["tdesc"] == 1){    
    $include = "modules/fitness/desc_form.php";
 }else  if($_GET["featured"] == 1){   
     $title = "Featured Slots";
    $include = "modules/fitness/featured.php";
 }else{  
     
     $catID = $_GET["catID"];
     $include = "modules/fitness/list.php"; 
 }
 
 
 $menu_class[10] = 'class="current"' ;
 
 include("_header.php");     
 include($include);
 include("_footer.php"); ?>  