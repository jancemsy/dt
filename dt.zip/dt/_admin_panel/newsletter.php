<?php
include("common.php");
include("modules/newsletter/process.php");




if (isset($_GET["preview"])) {
    ?>
    <html><head>

            <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script> 
            <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css" />
            <script src="http://code.jquery.com/ui/1.10.2/jquery-ui.js"></script>
            <script>
                function hidegencode() {
                    $(".gencode").hide();
                    $(".gencodetop").removeClass("open");
                }
                function showgencode() {
                    $(".gencode").show();
                    $(".gencodetop").addClass("open");
                }
            </script>
            <style>
                .gencodetop{ border-bottom: 2px solid #555;  background:#ccc; height: 20px;padding:10px;  }
                .gencodetop.open{ height: 380px; }
                .gencode{ clear:both; float:right;   }        
                a{ color: #333; }
                html,body{ margin: 0px; padding: 0px; overflow: hidden; }
            </style></head><body>
            <div class="gencodetop"  > 

                <input style="float:right" type="button" value="Close" onclick="location.href = '?'"/>
                <input style="float:right" type="button" value="Generate Code" onclick="showgencode()"/>
                <input style="float:right" type="button" value="Update Content" onclick="location.href = '?edit=<?php echo $_GET["preview"]; ?>'"/>


                <div class="gencode" style="display:none;">
                    <b>Generated Code: (<a href="javascript:;" onclick="hidegencode()">hide</a>)</b> <br/>
                    <textarea cols="100%" onclick="this.select()" rows="20"><?php
    $tid = $_GET["preview"];
    include("modules/newsletter/_preview.php");
    ?></textarea> 
                </div>


            </div>
            <iframe  frameborder="0" width="100%" height="100%" src="modules/newsletter/_preview.php?preview=<?php echo $_GET["preview"]; ?>"></iframe>
        </body>
    </html>
    <?php
    exit();
}


$id = "";
$menu_class[9] = 'class="current"';
include("_header.php");
?>
<div class="container">         
    <?php
    if ($_GET["crop"] == 1) {
        include("modules/newsletter/crop.php");
    } else if ($_GET["new"] == 1 || isset($_GET["edit"])) {
        include("modules/newsletter/form.php");
    } else {
        include("modules/newsletter/list.php");
    }
    ?>                                                 
</div> 

<?php include("_footer.php"); ?>  