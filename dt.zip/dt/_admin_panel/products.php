<?php

include("common.php");
$catID = $_GET["cat"];
set_time_limit(0);
ini_set('max_execution_time', 0);
include("modules/products/process.php");


$menu_class[8] = 'class="current"';

include("_header.php");

if ($_GET["cat"] != "") {
    $cat = new Category($catID);
    $title = $cat->name;
} else if ($_GET["settings"] == 1) {
    $title = "Product Settings";
} else {
    if ($_GET["featured"]) {
        $title = "Featured Products";
    } else {
        $title = ( empty($cat->name) ) ? "Products" : "Category: " . $cat->name;
    }
}

if (isset($_GET["update_qty"])) {
    include("modules/products/update_qty.php");
} else if (isset($_GET["new"]) || isset($_GET["edit"])) {
    include("modules/products/form.php");
} else if ($_GET["settings"] == 1) {
    include("modules/products/settings.php");
} else {
    include("modules/products/list.php");
}

include("_footer.php");
?>  