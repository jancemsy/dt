<?php

include("../common.php"); 
set_time_limit(0);
//error_reporting(E_ALL);
require_once '../library/PHPExcel/IOFactory.php';
$objPHPExcel = PHPExcel_IOFactory::load("../_import.xls");
$objWorksheet = $objPHPExcel->getActiveSheet();

//delete all diet that was previously imported
$result = mysql_query("DELETE FROM  diets WHERE dummy != '' ");

 
$_cat = array(      "Calorie Shifting Diets" => 3,
                    "Calorie Shifting" => 3,
                    "Asian Diets" =>  4,
                    "Low Carb Diets" => 5,
                    "High Carb Diets"  => 6,
                    "Meal Replacement" => 17,
                    "Celebrity Diets" => 22, 
                    "High Fiber Diets" => 25,
                    "Low Calorie Diets" => 26,
                    "Meal Delivery Diets" => 27,
                    "Fitness Programs"  => 28,
                    "Pills & Supplements"  => 29,
                    "Detox & Cleanse Diets"  => 30,
                    "Calorie Counting Diets"  => 31,
                    "Acai Diets" => 32
                ); 

echo '<table border=1>' . "\n";
$table_index = 0;
$data_count = 0;
foreach ($objWorksheet->getRowIterator() as $row) {
    $table_index ++;
    $cellIterator = $row->getCellIterator();
    $cellIterator->setIterateOnlyExistingCells(false);
        
    if($table_index > 3){
        echo '<tr>' . "\n"; 
   
 
        $values = array();
        foreach ($cellIterator as $cell) {
          $values[] = $cell->getValue();
        }

        $id             = $values[0];
        $name           = $values[1];
        $meta_title     = $name;
        $meta_desc      = $values[3]; 
        $meta_keywords  = $values[4];
        $sub_heading    = $values[6]; 
        $short_desc     = $values[7]; 
        $description    = $values[8]; 
        
        $features = $values[12]; 

        $editor_header1 = $values[13]; //quiz1
        $overview1 = $values[14]; //quiz text
        $overview2 = $values[15]; //text
        $overview3 = $values[16]; //text
        $overview4 = $values[17]; //text
        
        if(!empty($name)){
                        $data_count++;
                        $examples = array();
                        $i = 0;

                        $ex1       = $values[18];
                        $ex_tmp    = explode("|",$ex1);
                        foreach($ex_tmp as $item){
                         $t = explode(":",$item);    
                         $e = @trim($t[0]);
                         $n = @trim($t[1]);
                         $i++;
                         $examples["example_$i"] = urlencode($n);
                         $examples["example_name_$i"] = urlencode($e);      
                        }


                        $ex2       = $values[19];
                        $ex_tmp    = explode("|",$ex2);
                        $i = 8;
                        foreach($ex_tmp as $item){
                         $t = explode(":",$item);    
                         $e = @trim($t[0]);
                         $n = @trim($t[1]);
                         $i++;
                         $examples["example_$i"] = urlencode($n);
                         $examples["example_name_$i"] = urlencode($e);      
                        }

                        $examples = serialize( $examples );  


                        $rating_1       = $values[20];
                        $rating_text_1  = $values[21];
                        $rating_2       = $values[22];
                        $rating_text_2  = $values[23];
                        $rating_3       = $values[24];
                        $rating_text_3  = $values[25];
                        $rating_4       = $values[26];
                        $rating_text_4  = $values[27];

                        $rating = serialize( array( "rating_1" => $rating_1,
                                            "rating_2" => $rating_2,
                                            "rating_3" => $rating_3,
                                            "rating_4" => $rating_4, 
                                            "rating_text_1" => urlencode(diet::removeformats($rating_text_1)),
                                            "rating_text_2" => urlencode(diet::removeformats($rating_text_2)),
                                            "rating_text_3" => urlencode(diet::removeformats($rating_text_3)),
                                            "rating_text_4" => urlencode(diet::removeformats($rating_text_4)) ) );

                        $our_rating =  @( ( $rating_1 +  $rating_2 +  $rating_3 +  $rating_4 ) / 4);


                        $proscons_text1  = $values[28];
                        $pros1           = $values[29];
                        $cons1           = $values[30];
                        $proscons_text2  = diet::removeformats($values[31]); 
                        $proscons1 = serialize(array("pros" => urlencode($pros1),
                                                    "cons" => urlencode($cons1),  
                                                    "proscons_text" => urlencode( diet::removeformats($proscons_text1)) )); 

                        $proscons2 = serialize(array("pros" => urlencode($pros2),
                                                        "cons" => urlencode($cons2),  
                                                        "proscons_text" => urlencode( diet::removeformats($proscons_text2)) )); 


                        $categories       = @$_cat[trim($values[2])];   

                        $official_link  = $values[5];   


                        $standard_price = $values[9]; //not supported at diet table 
                        

                        $large_logo = $values[10]; 
                        $small_logo = $values[11]; 

                        $image1 = $values[32]; 
                        $image2 = $values[33];


                        $dummy = serialize(array("large_logo" => $large_logo,
                                                "small_logo" => $small_logo, 
                                                "gallery_image1" => $image1, 
                                                "gallery_image2" => $image2));


                                                               
    
                        
                        $params = array(   
                                    "plan_text"     => addslashes( diet::removeformats($values[43]) ),
                            
                                    "dummy"   => $dummy,
                                    "official_link" => $official_link,
                                    "meta_title"    => addslashes($meta_title),         
                                    "meta_desc"     => addslashes($meta_desc),
                                    "meta_keywords" => addslashes($meta_keywords),
                                    "categories"    => "-$categories-",
                                    "rating_text"   => $rating, 
                                    "proscons1"      => $proscons1, 
                                    "proscons2"      => $proscons2, 


                                    /**********Editorial fields**********/
                                    "editor_header1" => addslashes(diet::removeformats($editor_header1)),
                                    "overview1"      => addslashes(diet::removeformats($overview1) ), 
                                    //"editor_header2" => addslashes($_POST["editor_header2"]),
                                    "overview2"      => addslashes(diet::removeformats($overview2) ), 
                                    //"editor_header3" => addslashes($_POST["editor_header3"]),
                                    "overview3"      => addslashes(diet::removeformats($overview3) ), 
                                    //"editor_header4" => addslashes($_POST["editor_header4"]),
                                    "overview4"      => addslashes(diet::removeformats($overview4) ), 
                                    //"editor_header5" => addslashes($_POST["editor_header5"]),
                                    //"overview5"      => addslashes($overview5), 
                                    /**********Editorial fields**********/

                                    "examples"          => $examples,
                                    "name"              => addslashes(diet::removeformats($name)),                     
                                    "description"       => addslashes(diet::removeformats($description)),
                                    "short_desc"        => addslashes(diet::removeformats($short_desc)),

                                    /*no supported 
                                    "coupon_code"       => $_POST["coupon_code"], 
                                    "affiliate_link"    => $_POST["affiliate_link"],
                                    "duration"          =>  intval($_POST["duration"]),
                                    "standard_price"    => addslashes($_POST["standard_price"]),
                                    "discount"          => addslashes($_POST["discount"]),
                                    "price"             => addslashes($_POST["price"]),                      
                                    */

                                    "our_rating"        => $our_rating, 
                                    /*"category"          => $_POST["category"],*/
                                    "features"          => addslashes(diet::removeformats($features)),

                                    //"special"           => intval($_POST["special"]),
                                    //"featured"          => intval($_POST["featured"]),

                                    "sub_heading"       => addslashes($sub_heading),
                                    //"nutritional_facts" => addslashes($_POST["nutritional_facts"]),
                                    "is_published"      => 1
                        );


                        $id = 0;
                        $id = Diet::add($params); 



                        ######################################################################
                        #            Different Tables Here                                   #
                        ###################################################################### 
                        $videoid1        = str_replace("n\a","",$values[34]); 
                        $videoid2        = str_replace("n\a","",$values[35]); 
                        
                        if( !empty($videoid1) ){
                           $params1 = array(              
                                "dietID" => $id,
                                "type"  => "video",
                                "thumb" => "",
                                "file"  => "",             
                                "embed" => urlencode(youtubePlayer($videoid1)),
                                "caption" => "" );
                            Gallery::add($params1);
                        }
                        
                       if( !empty($videoid1) ){
                        $params2 = array(              
                                "dietID" => $id,
                                "type"  => "video",
                                "thumb" => "",
                                "file"  => "",             
                                "embed" => urlencode(youtubePlayer($videoid2)),
                                "caption" => ""
                                );
                      
                        Gallery::add($params2);   
                       }


                        //8DIET PLANS88888888888888888888888888888888888888

                        $diet_plan_cost1 = $values[36];
                        $str = $diet_plan_cost1;
                        if( !empty($str) && trim(strtolower($str)) != "n/a"){
                            $tmp  = explode("|",$str);                        
                            $pdesc = "";            
                            foreach($tmp as $pd){ 
                                if( search("feature1",$pd) || search("feature 1",$pd) ){
                                  $pdesc .= "<li>".str_replace(array("feature1:","feature 1:"),"", $pd)."</li>";
                                }else if( search("feature2",$pd ) || search("feature 2",$pd ) ){ 
                                  $pdesc .= "<li>".str_replace(array("feature2:","feature 2:"),"",$pd)."</li>";
                                }else if( search("feature3",$pd ) || search("feature 3",$pd ) ){ 
                                  $pdesc .= "<li>".str_replace(array("feature3:","feature 3:"),"",$pd)."</li>";
                                }else if( search("feature4",$pd) || search("feature 4",$pd) ){
                                  $pdesc .= "<li>".str_replace(array("feature4:","feature 4:"),"", $pd)."</li>";
                                }
                            }                          
                            $pdesc = !empty($pdesc) ? "<ul>$pdesc</ul>" : "";

                            $params3 = array("dietID" => $id, 
                            "name"        => trim(str_replace("Diet Plan:","",$tmp[1])),
                            "standard_price" => trim(str_replace("Standard Price:","",$tmp[0])),
                            "discount"    => "",
                            "code"        => "",
                            "total_price" => "",
                            "link"        => "",
                            "description" => $pdesc); 
                            
                            if(!empty($params3))   DietPlans::add($params3);
                        }

                        $diet_plan_cost2 = $values[37];
                        $str = $diet_plan_cost2;
                        if( !empty($str) && trim(strtolower($str)) != "n/a"){
                            $tmp  = explode("|",$str);                                    
                            $pdesc = "";
                             foreach($tmp as $pd){ 
                                if( search("feature1",$pd) || search("feature 1",$pd) ){
                                  $pdesc .= "<li>".str_replace(array("feature1:","feature 1:"),"", $pd)."</li>";
                                }else if( search("feature2",$pd ) || search("feature 2",$pd ) ){ 
                                  $pdesc .= "<li>".str_replace(array("feature2:","feature 2:"),"",$pd)."</li>";
                                }else if( search("feature3",$pd ) || search("feature 3",$pd ) ){ 
                                  $pdesc .= "<li>".str_replace(array("feature3:","feature 3:"),"",$pd)."</li>";
                                }else if( search("feature4",$pd) || search("feature 4",$pd) ){
                                  $pdesc .= "<li>".str_replace(array("feature4:","feature 4:"),"", $pd)."</li>";
                                }
                            }
                             $pdesc = !empty($pdesc) ? "<ul>$pdesc</ul>" : "";
                            

                            $params4 = array("dietID" => $id, 
                            "name"        => trim(str_replace("Diet Plan:","",$tmp[1])),
                            "standard_price" => trim(str_replace("Standard Price:","",$tmp[0])),
                            "discount"    => "",
                            "code"        => "",
                            "total_price" => "",
                            "link"        => "",
                            "description" => $pdesc );           
                                
                            if(!empty($params4))   DietPlans::add($params4);
                        }

                        $diet_plan_cost3 = $values[38];
                        $str = $diet_plan_cost3;
                        if( !empty($str) && trim(strtolower($str)) != "n/a"){
                            $tmp  = explode("|",$str);                        
                            $pdesc = "";
                            foreach($tmp as $pd){ 
                                if( search("feature1",$pd) || search("feature 1",$pd) ){
                                  $pdesc .= "<li>".str_replace(array("feature1:","feature 1:"),"", $pd)."</li>";
                                }else if( search("feature2",$pd ) || search("feature 2",$pd ) ){ 
                                  $pdesc .= "<li>".str_replace(array("feature2:","feature 2:"),"",$pd)."</li>";
                                }else if( search("feature3",$pd ) || search("feature 3",$pd ) ){ 
                                  $pdesc .= "<li>".str_replace(array("feature3:","feature 3:"),"",$pd)."</li>";
                                }else if( search("feature4",$pd) || search("feature 4",$pd) ){
                                  $pdesc .= "<li>".str_replace(array("feature4:","feature 4:"),"", $pd)."</li>";
                                }
                            }
                            $pdesc = !empty($pdesc) ? "<ul>$pdesc</ul>" : "";

                            $params5 = array("dietID" => $id, 
                            "name"        => trim(str_replace("Diet Plan:","",$tmp[1])),
                            "standard_price" => trim(str_replace("Standard Price:","",$tmp[0])),
                            "discount"    => "",
                            "code"        => "",
                            "total_price" => "",
                            "link"        => "",
                            "description" => $pdesc );          
                            
                            if(!empty($params5))   DietPlans::add($params5);
                        }

                  
                        
                      
                        //8888888888888888888888888888888888888888888888888


                        //8STORIES88888888888888888888888888888888888888888
                        $story1          = $values[39];
                        $story_image1    = $values[40];
                        $str = $story1;
                        if( !empty($str) &&  trim(strtolower($str)) != "n/a"){
                            //Name:|Age: |Height: |Before Weight: |After Weight: |Location: |Story

                            $sname = "";
                            $sage = "";
                            $sheight = "";
                            $sbw = "";
                            $saw = "";
                            $slocation = "";
                            $sstory = "";
                            $tmp = explode("|",$str);
                            foreach($tmp as $d){
                                if(search("Name:",$d)){ $sname = str_replace("Name:","",$d); }
                                if(search("Age:",$d)){ $sage = str_replace("Age:","",$d); }
                                if(search("Height:",$d)){ $sheight = str_replace("Height:","",$d); }
                                if(search("Before Weight:",$d)){ $sbw = str_replace("Before Weight:","",$d); }
                                if(search("After Weight:",$d)){ $saw = str_replace("After Weight:","",$d); }
                                if(search("Location:",$d)){ $slocation = str_replace("Location:","",$d); }
                                if(search("Story:",$d)){ $sstory = str_replace("Story:","",$d); }
                            }

                            $params6 = array(
                            "dietID" =>  $id,
                            "name"   => addslashes($sname),
                            "location" => addslashes($slocation),
                            "thumb" =>    $story_image1,
                            "thumb2" =>   "",
                            "comment" =>  addslashes($sstory),
                            "age" =>   $sage,
                            "height" => $sheight,
                            "was"    => addslashes($sbw),
                            "lost"   => "",
                            "now"    => addslashes($saw),
                            "goal"   => "");
                            
                            if(!empty($params6) && !empty($sname) )  Story::add($params6);         
                        }

                        $story2          = $values[41];
                        $story_image2    = $values[42];
                        $str = $story2;
                        if( !empty($str) &&  trim(strtolower($str)) != "n/a"){
                            //Name:|Age: |Height: |Before Weight: |After Weight: |Location: |Story

                            $sname = "";
                            $sage = "";
                            $sheight = "";
                            $sbw = "";
                            $saw = "";
                            $slocation = "";
                            $sstory = "";
                            $tmp = explode("|",$str);
                            foreach($tmp as $d){
                                if(search("Name:",$d)){ $sname = str_replace("Name:","",$d); }
                                if(search("Age:",$d)){ $sage = str_replace("Age:","",$d); }
                                if(search("Height:",$d)){ $sheight = str_replace("Height:","",$d); }
                                if(search("Before Weight:",$d)){ $sbw = str_replace("Before Weight:","",$d); }
                                if(search("After Weight:",$d)){ $saw = str_replace("After Weight:","",$d); }
                                if(search("Location:",$d)){ $slocation = str_replace("Location:","",$d); }
                                if(search("Story:",$d)){ $sstory = str_replace("Story:","",$d); }
                            }

                            $params7 = array(
                            "dietID" =>  $id,
                            "name"   => addslashes($sname),
                            "location" => addslashes($slocation),
                            "thumb" =>    $story_image2,
                            "thumb2" =>   "",
                            "comment" =>  addslashes($sstory),
                            "age" =>   $sage,
                            "height" => $sheight,
                            "was"    => addslashes($sbw),
                            "lost"   => "",
                            "now"    => addslashes($saw),
                            "goal"   => ""); 
                          
                           if(!empty($params7)  && !empty($sname)  )  Story::add($params7);       
                        }

                      
                        //8STORIES88888888888888888888888888888888888888888


                       


                        echo "<td>$data_count -  ".$name. " ::: $id </td>";

                        echo '</tr>' . "\n";
                        
                         sleep(1);
        
         }
        
    }
}


echo '</table>' . "\n";


$result = mysql_query("SELECT *FROM categories WHERE type = 'diet' ");
while($row = mysql_fetch_array($result)){    
   $catID = $row["id"];
   $q = mysql_query("SELECT COUNT(*) FROM diets WHERE categories LIKE  '%-$catID-%'   ");   
   $r = mysql_fetch_array($q);
   $count = $r[0];           
   $q = mysql_query("UPDATE categories SET count = '$count' WHERE id = '$catID' ");          
   echo "UPDATE categories SET count = '$count' WHERE id = '$catID' <br/>";
}
 








?> 