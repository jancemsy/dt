<?php
@set_time_limit(0); 
ini_set("post_max_size", "228M");
ini_set("upload_max_filesize", "228M");
ini_set("memory_limit", "228M" );

include("common.php");  
include("modules/videos/process.php"); 
$title = "Videos"; 


if($_GET["get_ytc"] == 1){   //not in used      
            $title = $_POST["title"];
            $desc = $_POST["description"];
            $nextUrl = "http://dt.liquidapogeedev.com/_admin_panel/videos.php"; 
            
            require_once 'Zend/Loader.php'; // the Zend dir must be in your include_path
            Zend_Loader::loadClass('Zend_Gdata_YouTube'); 
            Zend_Loader::loadClass('Zend_Gdata_ClientLogin');  

            $authenticationURL= 'https://www.google.com/accounts/ClientLogin';
            $httpClient = Zend_Gdata_ClientLogin::getHttpClient(
                      $username = YT_USERNAME,
                      $password = YT_PASSWORD,
                      $service = 'youtube',
                      $client = null,
                      $source = 'MySource', // a short string identifying your application
                      $loginToken = null,
                      $loginCaptcha = null,
                      $authenticationURL);

            //https://developers.google.com/youtube/2.0/developers_guide_protocol
            //GET THE DEVELOPER KEY AT http://code.google.com/apis/youtube/dashboard/ 
            $yt = new Zend_Gdata_YouTube($httpClient, YT_APPID, YT_CLIENTID, YT_DEVKEY); 
            $yt->setMajorProtocolVersion(2); 
            $myVideoEntry = new Zend_Gdata_YouTube_VideoEntry();

            $myVideoEntry->setVideoTitle($title);
            $myVideoEntry->setVideoDescription($desc);
            // The category must be a valid YouTube category!
            $myVideoEntry->setVideoCategory('Education');

            // Set keywords. Please note that this must be a comma-separated string
            // and that individual keywords cannot contain whitespace
            $myVideoEntry->SetVideoTags('diet','tools','video');

            $tokenHandlerUrl = 'http://gdata.youtube.com/action/GetUploadToken';
            $tokenArray = $yt->getFormUploadToken($myVideoEntry, $tokenHandlerUrl);
            $tokenValue = $tokenArray['token'];
            $postUrl = $tokenArray['url'];
            // place to redirect user after upload
            

            // build the form
            $form = '<form action="'. $postUrl .'?nexturl='. $nextUrl .
                '" method="post" enctype="multipart/form-data">'. 
                '<input name="file" type="file"/>'. 
                '<input name="token" type="hidden" value="'. $tokenValue .'"/>'.
                '<input value="Upload Video File" type="submit" />'. 
                '</form>'; 
            
            die($form);

}else if($_GET["crop"] == 1){     
    $include = "modules/videos/crop.php";
    $title = "Crop Images";
}else if($_GET["ads"] == 1){      
  $title = "Ads";
  $include = "modules/videos/ads.php";
}else if($_GET["cat"] == 1){     
  $include = "modules/videos/categories.php";
  $title = "Video Categories";
}else if($_GET["catedit"]  != ""){    
  $include = "modules/videos/cat_form.php";
}else if($_GET["new_cat"] == 1){     
  $include = "modules/videos/cat_form.php";
  $title = "New Video Category";
}else if($_GET["new"] == 1 || $_GET["edit"] != ""){      
  $include = "modules/videos/form.php";
}else if($_GET["tdesc"] == 1){    
  $include = "modules/videos/desc_form.php";
}else  if($_GET["featured"] == 1){   
     $title = "Featured Slots";
    $include = "modules/videos/featured.php";
 }else{  
    
     
     $catID = $_GET["catID"];  
     $include = "modules/videos/list.php";
     
     
      
}

              
              

 $menu_class[6] = 'class="current"' ;
 
include("_header.php"); 


include($include);

              
include("_footer.php"); ?>  