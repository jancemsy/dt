<?php
 include("common.php");  
 include("modules/articles/process.php");  
 
 if($_GET["ads"] == 1 ){      
    $title = "Ads";
    $include = "modules/articles/ads.php";    
 }else if($_GET["cat"] == 1){     
    $include = "modules/articles/categories.php";
    $title = "Article Categories";
 }else if($_GET["catedit"]  != ""){    
    $include = "modules/articles/cat_form.php";
 }else if($_GET["new_cat"] == 1){     
    $include = "modules/articles/cat_form.php";
    $title = "New Article Category";
 }else if($_GET["new"] == 1 || $_GET["edit"] != ""){      
    $include = "modules/articles/form.php";    
 }else if($_GET["crop"] == 1 ){      
    $include = "modules/articles/crop.php";    
 }else if($_GET["tdesc"] == 1){    
    $include = "modules/articles/desc_form.php";
 }else  if($_GET["featured"] == 1){   
     $title = "Featured Slots";
    $include = "modules/articles/featured.php";
 }else{  
     
     $catID = $_GET["catID"];
     $include = "modules/articles/list.php"; 
 }
 
 
 $menu_class[5] = 'class="current"' ;
 
 include("_header.php");     
             include($include);
                               
    include("_footer.php"); ?>  