<?php

@set_time_limit(0);
ini_set("post_max_size", "228M");
ini_set("upload_max_filesize", "228M");
ini_set("memory_limit", "228M");

include("common.php");
$menu_class[9] = 'class="current"' ;
include("modules/users/process.php");
include("_header.php");








if ($_GET["new"] == 1 || !empty($_GET["edit"])) {
    include("modules/users/form.php");
} else if ($_GET["cpassword"] == 1) {
    include("modules/users/cpassword.php");
} else {
    include("modules/users/list.php");
}

include("_footer.php");
?>  