<?php
 include("common.php"); 
  $menu_class[9] = 'class="current"' ;
 include("modules/templates/process.php");
 include("_header.php");
?> 
<div id="main"> 
<?php

   if(isset($_GET["new"]) || isset($_GET["edit"]) ){         
         include("modules/templates/form.php");
     }else{
         include("modules/templates/list.php"); 
     }
     
?>     
</div>		                       
<?php include("_footer.php"); ?>  