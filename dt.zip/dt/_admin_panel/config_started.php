<?php
include("common.php");
$_w = "150";
$_h = "80";

if (isset($_POST["save_cms"])) {
    
    
    if (isset($_FILES["upload_flv"]) && $_FILES['upload_flv']["name"] != "") {        
        $name = $_FILES['upload_flv']["name"];          
        $ext = end(explode(".", $name));
        $time = time();
        $filename = "$time-video.$ext";                
        $thumb_dest = "../content/videos/$filename";
        move_uploaded_file($_FILES["upload_flv"]["tmp_name"], $thumb_dest);        
        $_POST["flv"] = upload_s3($thumb_dest);                                        
    }    
    
    if (isset($_FILES["upload_thumb"]) && $_FILES['upload_thumb']["name"] != "") {        
        $name = $_FILES['upload_thumb']["name"];          
        $ext = end(explode(".", $name));
        $time = time();
        $filename = "$time-thumb.$ext";                
        $thumb_dest = "../content/videos/$filename";
        move_uploaded_file($_FILES["upload_thumb"]["tmp_name"], $thumb_dest);        
        createThumb($thumb_dest, $thumb_dest, $_w, $_h);                        
        $_POST["thumb"] = upload_s3($thumb_dest);                                        
    }    
    
    
    Config::update("regstarted_cms", $_POST);
}


$_POST = Config::get("regstarted_cms");
$menu_class[11] = 'class="current"';

include("_header.php");
?> 

<div class="box"> 
    <div class="title"> 
        <h2>Lets Get Started  CMS</h2> 
        <?php echo $_dahide; ?>
    </div> 
    <div class="content forms">  
        <form action="" method="post" enctype="multipart/form-data"   >  
            <table> 
                <tr><td>Thumbnail (<?php echo "$_w x $_h"; ?> PNG ONLY):            
                        <?php
                        if (!empty($_POST['thumb'])) {
                            echo "<br/><img src='" . cpath($_POST['thumb']). "' height='50' />";
                        }
                        ?></td>
                    <td>

                        <div class="row"  >                  
                            <input type="hidden" name="thumb" value="<?php echo $_POST['thumb']; ?>"   />
                            <input type="file" name="upload_thumb"   />
                        </div>
                    </td>                        
                </tr>

                <tr><td>Video (flv or mp4)                    
                        <?php 
                        echo ($_POST['flv']!="") ? "<a href='{$_POST['flv']}'>attached</a>" : ""; 
                        ?>
                    </td>
                    <td>
                        <div class="row"  >                                                                          
                            <input type="hidden" name="flv" value="<?php echo $_POST['flv']; ?>"   />
                            <input type="file" name="upload_flv"   />
                        </div>
                    </td>                        
                </tr>


                
                
            </table>


            <div class="row buttons">                  
                <button type="submit" name="save_cms"><span>Save</span></button>                                                
            </div> 
        </form>



        <script type="text/javascript">  initMCE(); </script>  

    </div>
</div>     


<?php include("_footer.php"); ?>  