<?php
 include("common.php");  
 include("modules/recipes/process.php");  
 
 $title = "Recipes";
 
  if($_GET["ads"] == 1){     
    $include = "modules/recipes/ads.php";
    $title = "Ads";
 }else if($_GET["new"] == 1 || $_GET["edit"] != ""){      
    $include = "modules/recipes/form.php";
 }else if($_GET["catedit"]  != ""){    
    $include = "modules/recipes/cat_form.php";
 }else if($_GET["tdesc"] == 1){ 
    $title = "Recipe Settings";
    $include = "modules/recipes/desc_form.php";
 }else if($_GET["cat"] == 1){     
    $include = "modules/recipes/categories.php";
    $title = "Recipe Categories";
 }else if($_GET["new_cat"] == 1){     
    $include = "modules/recipes/cat_form.php";
    $title = "New Recipe Category";
 }else if($_GET["crop"] == 1){     
    $include = "modules/recipes/crop.php";
    $title = "Crop images";
 }else if($_GET["featured"] == 1){     
    $include = "modules/recipes/featured.php";
    $title = "Featured Slots";
 }else{  
    $catID = $_GET["catID"];
    $include = "modules/recipes/list.php";
 }
 
 
 
 $menu_class[7] = 'class="current"' ;
 
 include("_header.php");   
 include($include);
 include("_footer.php"); ?>  