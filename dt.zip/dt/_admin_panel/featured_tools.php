<?php
 include("common.php");  
 $menu_class[4] = 'class="current"' ; 
 include("_header.php"); 
     
 
 if( isset($_POST["save_tools"]) ){ 
         $count =  count($_POST["id"]); 
         for($i = 0; $i < $count;  $i++){
              $id = $_POST["id"][$i];
              $name = clean_quote($_POST["name"][$i]);
              $link = clean_quote($_POST["link"][$i]);
              $order = $_POST["order"][$i];
              $description = clean_quote($_POST["description"][$i]);
              $short_desc = clean_quote($_POST["short_desc"][$i]);
               
              Tools::update(array(
                  "link" => $link,
                  "name" => $name, 
                                  "num" => $order,
                                  "description" => $description , 
                                  "short_desc" => $short_desc, 
                                  "id" => $id  ) );              
              
         }                 
 }  
    
   $list = Tools::getList();
 
 ?>
  
<div class="box"> 
            <div class="title"> 
                    <h2>Featured Tools</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms">
               
   <form action="" method="post"    enctype="multipart/form-data"   >
       <?php $i = 0 ;  foreach($list as $item){ $i ++; ?>        
                <div style="padding-left:50px; border-bottom:5px solid #ccc; padding: 20px 0 20px 0; ">  
                    <h1 style="font-size:26px!important;">Tool <?php echo $i; ?>:</h1>
                    
                    <input type="hidden" name="id[]" value="<?php echo $item['id']; ?>" /> 
                    
                    <p>ID: <?php echo $item["id"]; ?></p>
                    <p>Order: <input type="text" class="text-input" name="order[]" value="<?php echo $item["num"];?>" /> </p>
                    <p>Name: <input type="text" class="text-input"  name="name[]" size="70" value="<?php echo convert_to_original($item["name"]); ?>" /> </p>
                    Description: <br/>
                    <textarea rows="5" class="text-input editor"  name="description[]" cols="66"><?php echo  convert_to_original($item["description"]); ?></textarea> <br/> 
                    Short Description: <br/>
                    <textarea rows="5" class="text-input"  name="short_desc[]" cols="72"><?php echo convert_to_original($item["short_desc"]); ?></textarea> <br/> 
                    Tool Link:
                    <input type="text" name="link[]" size="70" value="<?php echo $item['link']; ?>" /> <br/>
                   
                   
                    <?php
                        $file = $_POST["thumb$i"];
                        if(!empty($file)){
                            echo "<input type='hidden' name='thumb$i' value='$file' /> <img src='../content/featured_tools/$file' width='100' />  ";
                        } 
                    ?> 
                    
                    <!-- <div class='row'>
                      <input type="file" name="upload<?php echo $i; ?>" />
                    </div> -->
                    
                  
                  
           </div>              
        <?php } ?>  
       
       
       
        <div class="row buttons">           
           <button type="submit" name="save_tools"><span>Save</span></button>                                                
        </div>
       
     </form>        

</div>		
</div>		
                
<script>
      initMCE();
</script>     
                                 
<?php include("_footer.php"); ?>  