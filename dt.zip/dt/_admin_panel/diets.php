<?php

include("common.php");
include("modules/diets/process.php");

$menu_class[3] = 'class="current"';
$title = "Diets";

if ($_GET["user_reviews"] == 1) {
    $title = "User Reviews";
    $include = "modules/diets/user_reviews.php";
} else if ($_GET["plans"] == 1) {
    $title = "Diet Plans";
    $include = "modules/diets/diet_plans.php";
} else if ($_GET["gallery"] == 1) {
    $title = "Diet Gallery";
    $include = "modules/diets/gallery.php";
} else if ($_GET["crop"] == 1) {
    $title = "Crop Images";
    $include = "modules/diets/crop.php";
} else if ($_GET["crop_stories"] == 1) {
    $title = "Crop Images";
    $include = "modules/diets/crop_stories.php";
} else if ($_GET["ads"] == 1) {
    $title = "Ads";
    $include = "modules/diets/ads.php";
} else if ($_GET["story"] == 1) {
    $title = "Diets/Story";
    $include = "modules/diets/stories.php";
} else if ($_GET["catedit"] != "") {
    $include = "modules/diets/cat_form.php";
} else if ($_GET["cat"] == 1) {
    $include = "modules/diets/categories.php";
    $title = "Diet Categories";
} else if ($_GET["new_cat"] == 1) {
    $include = "modules/diets/cat_form.php";
    $title = "New Diet Category";
} else if ($_GET["become_member"] == 1) {
    $title = "Diets/Become a member";
    $include = "modules/diets/become_a_member.php";
} else if ($_GET["new"] == 1 || $_GET["edit"] != "") {
    $include = "modules/diets/form.php";
} else if ($_GET["tdesc"] == 1) {
    $include = "modules/diets/desc_form.php";
} else if ($_GET["featured"] == 1) {
    $title = "Featured Slots";
    $include = "modules/diets/featured.php";
} else {
    $catID = $_GET["catID"];
    $include = "modules/diets/list.php";
}


include("_header.php");

include($include);

include("_footer.php");
?>  