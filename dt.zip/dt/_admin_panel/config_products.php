<?php
include("common.php");


if (isset($_POST["save_cms"])) {
    Config::update("product_cms", $_POST);
}


$_POST = Config::get("product_cms");
$menu_class[8] = 'class="current"';
include("_header.php");
?>
<style>
    .cms-home input{ width: 200px; }
    .cms-home textarea{ width: 470px; }
    hr{ color: #eee; }
</style>

<div class="box"> 
    <div class="title"> 
        <h2>Products/Services Configuration</h2> 
<?php echo $_dahide; ?>
    </div> 
    <div class="content forms">


        <form action="" method="post">                     
            <b>Product</b> <br/>
            <table>
                <tr>
                    <td>Popular Count:</td><td><input type="text" name="popular_count" value="<?php echo $_POST['popular_count']; ?>" size="55" /></td>                        
                </tr>  

            </table> 
            <hr size="1" />
            
            <br/><br/>

            <div style="border:1px solid #ccc; padding: 10px;">
            <b>Service #1</b> <br/>
            
            Upgrade page Heading: <input type="text" size="70" name="title1" value="<?php echo $_POST["title1"]; ?>" /> <br/>             
            Upgrade page Description: <br/>
            <textarea name="desc1" class="editor"><?php echo $_POST["desc1"]; ?></textarea>     <br/>             
            Product Name: <input type="text" size="70" name="product_name1" value="<?php echo $_POST["product_name1"]; ?>" />  <br/>
            Monthly Price: $<input type="text" size="10" name="plan_monthly_price" value="<?php echo $_POST["plan_monthly_price"]; ?>" /> <br/>
            <label><input type="checkbox" name="doesnt_shipped1" value="1" <?php echo $_POST["doesnt_shipped1"] == 1 ? "checked='checked'" : ""; ?> /> Item doesn’t get shipped</label>
            
            </div>
            
            <br/><br/>
            <div style="border:1px solid #ccc; padding: 10px;">
            <b>Service #2</b> <br/>                        
            Product Name: <input type="text" size="70" name="product_name2" value="<?php echo $_POST["product_name2"]; ?>" />  <br/>
            Price: $<input type="text" size="10" name="product_price2" value="<?php echo $_POST["product_price2"]; ?>" /> <br/>
            <label><input type="checkbox" name="doesnt_shipped2" value="1" <?php echo $_POST["doesnt_shipped2"] == 1 ? "checked='checked'" : ""; ?> /> Item doesn’t get shipped</label>
            
            </div>


            <div class="row buttons">                                        
                <button type="submit" name="save_cms"><span>Save</span></button>                                                
            </div>

        </form>

    </div>
</div>     

<script>
    $(function(){
        initMCET(".editor");
    });
</script>





<?php include("_footer.php"); ?>  