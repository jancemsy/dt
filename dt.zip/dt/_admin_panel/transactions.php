<?php
 include("common.php"); 
 
 
 if($_GET["close"] != ""){
     $id = $_GET["close"];     
     Transaction::update(array("transactionID" => $id , "status" => 1));
     jumpto("?");
 }
 
 
 
 
 $menu_class[8] = 'class="current"' ;
 include("_header.php"); 
 
 
 
 if(!empty($_GET["detail"])){
      include("modules/transaction/detail.php");
 }else{
      include("modules/transaction/list.php");
 }
 
 
 
 include("_footer.php"); ?>  