<?php
include("common.php");
include("modules/interview_samples/process.php");
$menu_class[11] = 'class="current"';
include("_header.php");
?>
<style>
    .cms-home input{ width: 200px; }
    .cms-home textarea{ width: 470px; }
    hr{ color: #eee; }
</style>

<div class="box"> 

    <?php
    if (!isset($_GET["edit"]) && !isset($_GET["new"])) {
        $arr = Config::get("interview_samples_cms");
        ?>

        <div class="title"> 
            <h2>Premium Interview Description and PDF Download </h2> 
            <?php echo $_dahide; ?>
        </div> 

        <div class="content form">

            <form action="" method="post"  enctype="multipart/form-data">                        

                <b>Popup description:</b> <br/>
                <textarea name="desc" style="width:600px; height: 100px;"><?php echo $arr["desc"]; ?></textarea>
                <input type="hidden" name="save_desc" value="1" /><br/>


                <b>PDF Sample download:</b> <br/>

                Filename: <input type="text" name="download_name" value="<?php echo empty($arr["download_name"]) ? "download" : $arr["download_name"]; ?>" />.pdf <br/>



                <div id="add_pdf_by_upload">
                    <div class="row" >
                        <input type="file" name="pdf_upload" class="pdf_upload"   />
                    </div>
                    or
                    browse from podcasts list <input type="button" value="browse" onclick="
                            $('#add_pdf_by_list').show();
                            $('#add_pdf_by_upload').hide(); 
                            $('.pdf_upload').val('');
                                                     " />
                </div>

                <input type="hidden" name="pdf" value="<?php echo $arr["pdf"]; ?>" />

                <div id="add_pdf_by_list" style="display:none;">
                                                                               Select Podcast PDF to be used as our sample download or <input type="button" value="upload" onclick="$('#add_pdf_by_list').hide();$('#add_pdf_by_upload').show();
                                                                                       $('[name=select_pdf]').attr('checked',false);" />
                    <table cellspacing="0" class="table">
                        <thead>  
                            <tr class="tr-header">
                                <td>Select</td>
                                <td>Title</td>                                
                                <td>With/casts</td> 
                                <td>mp3</td> 
                                <td>pdf</td>                                
                            </tr>
                        </thead>                 
                        <?php
                        extract(Podcast::getList($_GET["s"], 999999, "_admin_panel/podcasts.php?page="));

                        foreach ($list as $item) {
                            if (!empty($item["pdf"])) {
                                ?>
                                <tr >
                                    <td><input type="radio" name="select_pdf" value="<?php echo $item["pdf"]; ?>" onclick="$('[name=download_name]').val('<?php echo slug($item["title"]); ?>');"  /></td>
                                    <td><?php
                    echo $item["title"];
                    if ($item["isFeatured"])
                        echo "<div style='color:blue; font-weight:bold;'>[Featured]</div>";
                                ?></td>
                                    <td><?php echo $item["casts"]; ?></td> 
                                    <td>
                                        <?php
                                        if (empty($item["mp3"])) {
                                            echo "<a href='javascript:;' class='premium_mp3 disabled'></a>";
                                        } else {
                                            echo "<a href='" . cpath($item["mp3"]) . "'  target='_blank' class='premium_mp3'></a>";
                                        }
                                        ?>
                                    </td> 
                                    <td><?php
                            if (empty($item["pdf"])) {
                                echo "<a href='javascript:;' class='premium_pdf disabled'></a>";
                            } else {
                                echo "<a href='" . cpath($item["pdf"]) . "' target='_blank' class='premium_pdf '></a>";
                            }
                                        ?></td>                              
                                </tr>
                                <?php
                            }
                        }
                        ?>
                    </table>
                </div>

                <?php
                if (isset($arr["pdf"])) {
                    echo "<table><tr><td><a href='" . cpath($arr["pdf"]) . "' class='premium_pdf' target='_blank'></a></td><td> PDF Attached</td></tr></table>";
                }
                ?>
                <br/><br/>


                <div class="row buttons" >             
                    <button type="submit"  ><span>Save</span></button>                                                
                    <img src="../images/loading-small.gif" class="loader" style="display:none"  />
                    <span class="status"></span>
                </div>


            </form> 
        </div>
        <br/><br/>


        <?php
    }
    ?>


    <div class="title"> 
        <h2>Premium Interview Mp3 Samples</h2> 
        <?php echo $_dahide; ?>
    </div> 





    <?php
    if (isset($_GET["edit"])) {
        $result = mysql_query("SELECT *FROM interview_samples WHERE id = '{$_GET["edit"]}' ");
        $row = mysql_fetch_array($result);
        $_POST = $row;
        include("modules/interview_samples/form.php");
    } else if ($_GET["new"] == 1) {
        include("modules/interview_samples/form.php");
    } else {
        include("modules/interview_samples/list.php");
    }
    ?>
</div>     



<?php include("_footer.php"); ?>  