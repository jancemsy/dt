<?php
 include("common.php"); 
 include("_header.php"); ?>
  
<div id="main">
               members
</div>		
                                
                                 
<?php include("_footer.php"); ?>  