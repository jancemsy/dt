<?php
 include("common.php"); 
 include("modules/podcasts/process.php");
  
 $menu_class[8] = 'class="current"' ;
 
 include("_header.php");
   
 
   if(isset($_GET["crop"])){                 
       include("modules/podcasts/crop.php");       
   }else if(isset($_GET["new"]) || isset($_GET["edit"]) ){                 
       include("modules/podcasts/form.php");       
   }else{       
       include("modules/podcasts/list.php"); 
   }

include("_footer.php"); ?>  