<?php
$_POST = Config::get("register_email_cms");
$menu_class[9] = 'class="current"';

include("_header.php");
?> 

<div class="box"> 
    <div class="title"> 
        <h2>Register  Welcome Email</h2> 
        <?php echo $_dahide; ?>
    </div> 
    <div class="content forms">  

        <form action="" method="post" enctype="multipart/form-data"   >  
            <table>   
                <tr>
                    <td>EMAIL SUBJECT:</td><td><input type="text" name="subject" value="<?php echo $_POST['subject']; ?>" size="105" />  </td>                        
                </tr> 

                <tr>
                    <td>Hello:</td><td><input type="text" name="hello" value="<?php echo $_POST['hello']; ?>" size="105" />   </td>                        
                </tr> 



                <tr>
                    <td>Body:</td>
                    <td><textarea name="body" class="mceEditor" cols="52"><?php echo $_POST['body']; ?></textarea></td>                        
                </tr> 

                <?php for ($i = 1; $i < 5; $i++) { ?>
                    <tr>
                        <td valign="top" style="padding-top:5px;">Step <?php echo $i; ?>:</td>
                        <td>

                            <input type="text" name="step<?php echo $i; ?>_title" value="<?php echo $_POST["step{$i}_title"]; ?>" size="119" />  <br/> 
                            <textarea name="step<?php echo $i; ?>_text" class="mceEditor" cols="52"><?php echo $_POST["step{$i}_text"]; ?></textarea> <br/>
							
							<table><tr><td>
                         <div class="row" style="margin:0px 0px 15px 0px; border:none; height: 20px; padding: 0px; display:block; position:static; ">
                                <input type="file" size="46"  name="upload_<?php echo $i; ?>"   class="input upload file"  /> 
                                <input type="hidden" size="46"  name="thumb_<?php echo $i; ?>"   value="<?php echo $_POST["thumb_{$i}"]; ?>"  />   
                              
                            </div></td><td>  <?php
                                if ($_POST["thumb_{$i}"] != "") {
                                    echo " <img src=\"".PATH."{$_POST["thumb_{$i}"]}\" height='30' /> <br/> ";
                                }
                                ?>   260x189px JPG  </td></tr></table>
                        </td>  
                    </tr> 
                <?php } ?>



                <tr>
                    <td>Footer Text1:</td>
                    <td><textarea name="footer_text1" class="mceEditor" cols="52"><?php echo $_POST['footer_text1']; ?></textarea></td>                        
                </tr> 
                <tr>
                    <td>Footer Bullets:</td>
                    <td><textarea name="footer_bullets"    cols="90" ><?php echo $_POST['footer_bullets']; ?></textarea></td>                        
                </tr> 
                <tr>
                    <td>Footer Text2:</td>
                    <td><textarea name="footer_text2" class="mceEditor" cols="52"><?php echo $_POST['footer_text2']; ?></textarea></td>                        
                </tr> 
            </table>


            <div class="row buttons">                  
                <button type="submit" name="save_cms"><span>Save</span></button>                                                

                <button type="submit"  name="save_preview_cms"><span>Preview</span></button>                                                
            </div> 
        </form>



        <script type="text/javascript">  initMCET('.mceEditor');</script>  

    </div>
</div>     


<?php include("_footer.php"); ?>  