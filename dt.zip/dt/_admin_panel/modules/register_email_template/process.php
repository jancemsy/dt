<?php
unset($_SESSION["pending_crop"]);
$path = "../content/register_template/";
if (!file_exists($path)) {
    mkdir($path);
}

if (isset($_POST["save_cms"]) || isset($_POST["save_preview_cms"])) {

    for ($i = 1; $i < 5; $i++) {
        if ($_FILES["upload_$i"]["name"] != "") {
            if (!empty($_POST["thumb$x"][$j])) {
                @unlink("../" . $_POST["thumb_$i"]);
            }
            $name = $_FILES["upload_$i"]["name"];
            $ext = end(explode(".", $name));
            $time = time() . $i . $j;
            $filename = "$time.$ext";
            $orig_dest = $path . $filename;
            move_uploaded_file($_FILES["upload_$i"]["tmp_name"], $orig_dest);
            $_POST["thumb_$i"] = str_replace("../","",$orig_dest);
            list($width, $height, $type, $attr) = getimagesize($orig_dest);
            $pending_crop[] = array("image" => $orig_dest, "width" => "260", "height" => "189", "caption" => "Step $i");
        }
    }

    Config::update("register_email_cms", $_POST);


    //global cropper 
    if (count($pending_crop) > 0) {
        $_SESSION["pending_crop"] = serialize($pending_crop);

        if (isset($_POST["save_preview_cms"]))
            $_SESSION["goback"] = "register_email_template.php?save_preview_cms=1";
        else
            $_SESSION["goback"] = "register_email_template.php";
        jumpto("cropper.php");
    }
}
?>