<div class="box"> 
        <div class="title"> 
                <h2>Transactions</h2> 
                <?php echo $_dahide; ?>
        </div> 
        <div class="content pages"> 
            <style> a.aa{ text-decoration:underline!important; color: blue!important; }
                a.aa:hover{ text-decoration:none!important; color: blue!important; }
            </style> 
   <table class="purchase_history_table" cellpadding="2" cellspacing="0">
                                    <tr class="hd"><td>#</td>
                                        <td>Details (click to view the full details)</td>
                                        <td>Customer</td>
                                        <td>Amount</td>                                        
                                        
                                        <td>Status</td>
                                    </tr>
                                    <?php  
                                    $list = Transaction::getList();
                                    foreach($list as $item){ 
                                                                               
                                         $array = unserialize(urldecode($item["params"]));
                                         $p = $array["purchase"];
                                         $details = "";
                                         foreach($p as $pd){
                                             $details .= $pd["qty"]."pc/s ".$pd["name"]."  ".$pd["price"]."<br/>";
                                         }
                                         
                                         $user = new User($item["userID"]);
                                        
                                         
                                         if($item["status"] == 1) $button = "closed";
                                         else  $button = "<input type='button' onclick=\"location.href='?close={$item["transactionID"]}';\" value='close transaction' />";
                                         
                                       echo "<tr><td>{$item["transactionID"]}</td>       
                                           <td><a href='?detail={$item['transactionID']}' class='aa'>$details</a></td>
                                       <td><a href='{$user->profile_link}' target='_blank'>{$user->username}</a></td> 
                                        <td>$"."{$item["amount"]}</td>                                        
                                        
                                           <td>$button</td>
                                        </tr>";
                                    }
                                    ?>
                                </table>    
 	
        </div>
</div>                                         