<style>                
    .table-list .td3{ width: 100px; text-align: center;  color: red;  }                
    .table-list{ padding: 5px ; width: 100%; border: 1px solid #eee; border-bottom: 3px solid #ccc; border-right: 3px solid #ccc; }
    .table-list tr.head td{ color:#fff!important; background: #ccc; font-weight:bold; }                
    .table-list tr.head td.td3{ background: #348a00!important; }                
    .table-list tr.even td{ background: #fff; }
    .table-list tr.odd td{ background: #eee; }
    .table-list td{ padding: 10px;}
    .table-list td ul{padding-left: 17px; margin: 0px;  }
    .table-list td li{ margin: 0px;  padding: 0px; list-style:circle;  }
    .table-list .td1{ width: 400px!important; text-align: left; }
    .table-list .td2{ width: 100px!important; text-align: left; }


    .table-detail td{ padding: 10px;}
    .table-detail .td1{ width: 100px; color:#fff!important; background: #ccc; font-weight:bold; }                
    .table-detail .td2{ text-align: left!important; color:#333!important; background: #eee; font-weight:bold; }                
</style>
<div class="box"> 
    <div class="title"> 
        <h2 class="cms_title">Transaction History</h2>             
        <?php echo $_dahide; ?>
    </div> 
    <div class="content pages">             
        <?php
        $tran_id = $_GET["detail"];
        $_transaction = new Transaction($tran_id);
        ?>



        <div style="padding-bottom:10px">
            TRANSACTION ID: <?php echo $_transaction->id; ?> <br/>
            Date: <?php echo date("m/d/y", strtotime($_transaction->created_at)); ?> 
        </div>

        <?php
        $array = unserialize(urldecode($_transaction->params));
 
        $p = $array["purchase"];
        $details = "";
        $i = 0;
        foreach ($p as $pd) {
            $class = $i % 2 == 0 ? "even" : "odd";
            $i ++;
            $details .=
                    "<tr class='$class'><td class='td1'>" . $pd["name"] . "</td>" .
                    "<td class='td2'>" . $pd["qty"] . "pc/s </td>" .
                    "<td class='td3'>$" . $pd["price"] . "</td></tr>";
        }



        echo "<table border='0' width='100%' class='table-list' >
                 <tr class='head'><td class='td1'>Product Name</td>
                 <td class='td2'>Pcs</td>
                 <td class='td3'>Amount</td></tr>
             $details
                 <tr>
                 <td></td>
                 <td  align='right'><b>Total:</b></td>
                 <td class='td3'>$$_transaction->amount</td>
                 </tr>                 
</table>";


        $user = new User($_transaction->userID);

        echo "<br/>
            User Details:                  
            <table border='0' width='100%' class='table-detail' >
                             <tr><td class='td1'>Username</td><td class='td2'>  <a href='" . $user->profile_link($user->username) . "' target='_blank' style='text-decoration:underline;'>$user->username</a> </td></tr>                       
                             <tr><td class='td1'>User First and Last Name</td><td class='td2'>  $user->first_name $user->last_name </td></tr>                       
                             <tr><td class='td1'>Sex</td><td class='td2'> $user->sex </td></tr>                                              
                             <tr><td class='td1'>Birth date and age</td><td class='td2'>$user->birth_date</td></tr>                 
                             <tr><td class='td1'>Current weight</td><td class='td2'>$user->weight lbs</td></tr>                 
                             <tr><td class='td1'>Height</td><td class='td2'> $user->height inches</td></tr>                 
                             <tr><td class='td1'>Goal </td><td class='td2'> $user->goal </td></tr>
                             <tr><td class='td1'>Goal weight</td><td class='td2'>$user->goal_weight lbs</td></tr>                 
                             <tr><td class='td1'>Goal Date</td><td class='td2'>$user->goal_date</td></tr>    
                             <tr><td class='td1'>Daily Allowance</td><td class='td2'>$user->goal_daily_cal lbs</td></tr>                  
            </table>";




        echo "<br/>
            Shipping/Billing Details:                  
            <table border='0' width='100%' class='table-detail' >
                             <tr><td class='td1'>Name</td><td class='td2'>{$array["fname"]} {$array["lname"]}</td></tr>                       
                             <tr><td class='td1'>Country</td><td class='td2'>{$array["country"]}</td></tr>                                              
                             <tr><td class='td1'>City</td><td class='td2'>{$array["city"]}</td></tr>                 
                             <tr><td class='td1'>State</td><td class='td2'>{$array["state"]}</td></tr>                 
                             <tr><td class='td1'>Zip</td><td class='td2'>{$array["zip"]}</td></tr>                 
                             <tr><td class='td1'>Address</td><td class='td2'>{$array["address"]}</td></tr>
                             <tr><td class='td1'>Phone</td><td class='td2'>{$array["phone"]}</td></tr>                 
                             <tr><td class='td1'>Email</td><td class='td2'>{$array["email"]}</td></tr>                 
            </table>";





        //find the questions and answers 
        foreach ($array["purchase"] as $i) {

            if (isset($i["aa"])) {
                echo "<table border='0' width='100%' class='table-list' >";
                echo "<br/><br/>Jumpstarter kit questions and answers: <br/> ";

                $a = explode("|", $i["aa"]);
                $q = explode("|", $i["qq"]);

                for ($j = 1; $j < count($q); $j++) {
                    echo "<tr><td align='left' style='text-align:left!important; padding:10px!important;'>"
                    . "<b>" . ($j ) . "." . urldecode($q[$j]) . "</b>:"
                            . "<p>&nbsp;&nbsp;&nbsp;&nbsp;" . urldecode($a[$j]) . "</p></td></tr>";
                }


                echo "</table>";

                break;
            }
        }
        ?><br/>





    </div>
</div>                                         