<?php 

if( isset($_POST['crop_images'] ) ){  //ajax call   
       $_SESSION["pending_crop"] = "";
       $width = 381;
       $height = 227;  
       $quality = 100;  

        $size = count($_POST['h']);

        for($i = 0; $i< $size; $i++){
          $des_h = $_POST['h'][$i];
          $des_w = $_POST['w'][$i];
          $source_x = $_POST['x'][$i];
          $source_y = $_POST['y'][$i];
          $src = $_POST['thumb'][$i];    
          
           if( !empty($des_h) && !empty($src) ){
                    $filename = end(explode("/",$src)); 
                    $thumb_dest = "../content/articles/".str_replace("-orig","",$filename);    
                    $med_dest = "../content/articles/".str_replace("-orig","-med",$filename);                                                           
                    $filename = str_replace("-orig","-large",$filename);      
                    $destination = "../content/articles/$filename";                    
                     
                    
                    $ext = strtolower(end(explode(".",$src)));

                    switch ($ext){
                        case "gif":
                          $img_r = imagecreatefromgif($src);
                          break;
                        case "png":
                          $img_r = imagecreatefrompng($src);
                          break;
                        default:
                          $img_r = imagecreatefromjpeg($src);
                          break;
                      }

                    $dst_r = ImageCreateTrueColor( $width , $height );
                    imagecopyresampled($dst_r,$img_r,0,0,$source_x,$source_y ,$width ,$height ,$des_w ,$des_h);

                    @unlink($destination);  //delete the old one
                    switch($ext){
                        case "gif":
                           imagegif($dst_r, $destination);
                          break;
                        case "png":
                           imagepng($dst_r, $destination);
                          break;
                        default:
                           imagejpeg($dst_r, $destination,$quality);
                          break;
                      } 
                       
                    @createThumb($destination,$thumb_dest,162,97);          
                    @createThumb($destination,$med_dest,295,176);          
                    //@createThumb($destination,$large_dest,381,227);   
                    //@createThumb($destination,$thumb_dest,177,102);   
                    @unlink($src);//unlink original 

          }
        }
        die("1");
}


   
if( isset($_GET["delete"]) ){ 
    $id = $_GET["delete"];
    $article = new Article($id); 
    @unlink("../".$article->thumb);     
    $article->delete($id);
    jumpto("articles.php");
}

if( isset($_GET["catdelete"]) ){ 
    $id = $_GET["catdelete"];
    CategoryArticle::delete($id);
    jumpto("articles.php?cat=1"); 
}

if( isset($_POST["save_category"]) ){
   $name = clean_quote($_POST["name"]);
   $type = clean_quote($_POST["type"]);
   $description = clean_quote($_POST["description"]);
   $short_desc =  clean_quote($_POST["short_desc"]);
   $params = array(
       "headline" => addslashes($_POST["headline"]),
       "num" => $_POST["num"],
       "short_desc" => $short_desc,
       "description" => $description, "name" => $name, 
       "type" => $type,
       "meta_title" => addslashes($_POST["meta_title"]),         
       "meta_desc" => addslashes($_POST["meta_desc"]),
       "meta_keywords" => addslashes($_POST["meta_keywords"]),
       "short_desc" => clean_quote($_POST["short_desc"]) );
   
   if($_POST["id"] != ""){ 
       $params["id"] = $_POST["id"];
       CategoryArticle::update($params);   
   }else{
       CategoryArticle::add($params);     
   }  
   jumpto("articles.php?cat=1"); 
}


if( isset($_POST["save"]) ){     
    $pending_crop = array();    
    if(isset($_FILES["upload"]) && $_FILES['upload']["name"] != ""){
        if( !empty($_POST["thumb"]) ){
            $thumb = $_POST["thumb"];
            @unlink("../".$thumb);
            $med = Article::medthumb($thumb);
            $large = Article::largethumb($thumb);
            @unlink("../".$med);
            @unlink("../".$large);            
        }
        $name = $_FILES['upload']["name"];
        $ext   = end(explode(".",$name));
        $time = time();                 
        $filename = "$time.$ext";
        $thumb_dest = "../content/articles/$filename";
        $orig_dest = "../content/articles/$time-orig.$ext";  
        $med_dest = "../content/articles/$time-med.$ext";  
        $large_dest = "../content/articles/$time-large.$ext";          
        
        move_uploaded_file($_FILES["upload"]["tmp_name"], $orig_dest );         
                
        @createThumb($orig_dest,$thumb_dest,162,97);          
        @createThumb($orig_dest,$med_dest,295,176);          
        @createThumb($orig_dest,$large_dest,381,227);          
        
        $pending_crop[] = $orig_dest;
        
        //@unlink($orig_dest);                
        $_POST["thumb"] = "content/articles/$filename";
     }
     
      $csize = count($_POST["category"]);
      $categories = "";
      for($i = 0; $i <= $csize; $i++){
         if($_POST["category"][$i] != ""){
           $categories .= "-".$_POST["category"][$i]."-";
         }
      }
       
     $params = array(
                     "publish_date_time" => clean_data($_POST["publish_date_time"]),
                     "caption"    => addslashes($_POST["caption"]),
                     "created_at" => addslashes($_POST["created_at"]),
                     "featured"   => addslashes($_POST["featured"]),
                     "meta_title" => addslashes($_POST["meta_title"]),         
                     "meta_desc" => addslashes($_POST["meta_desc"]),
                     "meta_keywords" => addslashes($_POST["meta_keywords"]),
                     "categories" => addslashes($categories),
                     "title" => clean_quote($_POST["title"]),
                     "text" => clean_quote($_POST["text"]),  
                     "thumb" => $_POST["thumb"],
                     "is_published" => addslashes($_POST["is_published"])  );
     
    
     if($_POST["id"] != ""){
         $id = $_POST["id"];
        $params["id"] = $_POST["id"];
        Article::update($params); 
     }else{
        $id = Article::add($params); 
     }
     
      if(count($pending_crop) > 0 ){
         $_SESSION["pending_crop"] = serialize($pending_crop); 
         jumpto("articles.php?crop=1"); 
     }
     
     jumpto("articles.php"); 
}
 

?> 