<?php
$type = "Add";
if (isset($_GET["edit"])) {
    $id = $_GET["edit"];

    $article = new Article($id);
    $_POST = $article->array;
    $type = "Edit";

    $time = strtotime($_POST['created_at']);
    $date = date("Y-m-d", $time);
}
?>

<div class="box"> 
    <div class="title"> 
        <h2><?php echo $type; ?> Article</h2> 
<?php echo $_dahide; ?>
    </div> 
    <div class="content  forms" > 

        <form action="" method="post" enctype="multipart/form-data" onSubmit="return checkArticle()"   >
            <input type="hidden" name="id" value="<?php echo $_POST['id']; ?>" />
            <input type="hidden" name="thumb" value="<?php echo $_POST['thumb']; ?>" />

            <table>
                <tr><td>Status:</td>
                    <td>
                        <select name="is_published" onchange=" $(this).val() == '1' ? $('.publish_box').show() : $('.publish_box').hide();
                                " >
                            <option value="1">Publish</option>
                            <option value="0" <?php if ($_POST["is_published"] == 0) echo "selected"; ?> >Draft</option></select>


                        <span class="publish_box" <?php if ($_POST["is_published"] == 0) {
            echo "style='display:none;'";
        } ?>  >
                            <input type="text" id="datetimepicker" name="publish_date_time" placeholder="Enter publish time"   value="<?php echo $_POST['publish_date_time']; ?>" />  
                        </span> 

                    </td></tr> 
                <tr><td>Meta Title <counter style="display:none" max="70" required="1" target="input[name=meta_title]'"></counter>:</td><td>  <input type="text" name="meta_title" class="text-input" value="<?php echo $_POST['meta_title']; ?>" /></td></tr> 
                <tr><td>Meta Desc <counter style="display:none" max="155" required="1" target="input[name=meta_desc]'"></counter>:</td><td>  <input type="text" name="meta_desc" class="text-input" value="<?php echo $_POST['meta_desc']; ?>" /></td></tr> 
                <tr><td>Meta Keywords:</td><td>  <input type="text" name="meta_keywords" class="text-input" value="<?php echo $_POST['meta_keywords']; ?>" /></td></tr> 

                <tr>
                    <td>Date:</td><td><input type="text" name="created_at" class="datepicker"  value="<?php echo $date; ?>" size="55" /></td>                        
                </tr>

                <tr><td>Featured?</td><td>                                  
                        <label><input type="radio" name="featured"  <?php echo $_POST['featured'] == 1 ? "checked" : ""; ?>  value="1" /> yes</label>
                        <label><input type="radio" name="featured"  <?php echo $_POST['featured'] == 0 ? "checked" : ""; ?>  value="0" /> no </label>

                    </td></tr> 

                <tr>
                    <td>Title:</td><td><input type="text" name="title" value="<?php echo $_POST['title']; ?>" size="55" /></td>                        
                </tr>
                <tr>
                    <td>Description:</td><td><textarea name="text" class="mceEditor" cols="52"><?php echo $_POST['text']; ?></textarea></td>                        
                </tr>

                <tr><td>Thumbnail: <br/>
                        381px x 227px JPG only:</td><td>

                        <div class="row" >
                            <input type="file" size="46"  name="upload"  />             
                        </div>

<?php
if (!empty($_POST["thumb"])) {
    echo ' <br/> <img src="' . PATH . $_POST["thumb"] . '"  /> ';
}
?>             
                    </td></tr> 
                <tr>
                    <td>Caption:</td>
                    <td><input type="text" name="caption" value="<?php echo $_POST['caption']; ?>" size="55" /></td>                        
                </tr>
                <tr>
                    <td>Category: </td><td>
<?php
$list = CategoryArticle::getList();

foreach ($list as $item) {
    if (search("-{$item["id"]}-", $_POST["categories"])) {
        echo "<label><input type='checkbox' checked=checked name='category[]' value='" . $item["id"] . "' /> " . $item["name"] . " </label> <br/>";
    } else {
        echo "<label><input type='checkbox' name='category[]' value='" . $item["id"] . "' /> " . $item["name"] . " </label> <br/>";
    }
}
?> 
                    </td></tr>    
                <tr>
                    <td colspan="2" >

                        <div class="row buttons">           
                            <button type="button" onclick="location.href = '?';" ><span>Back</span></button>                                                
                            <button type="submit"  name="save"><span>Save</span></button>                                                
                        </div>

                    </td>                        
                </tr>

            </table>
        </form>



        <script type="text/javascript">

            function checkArticle() {
                var errors = "";
                tinyMCE.triggerSave();
                if ($("input[name='title']").val() == "") {
                    errors += "Invalid title \n";
                }

                if ($("textarea[name='text']").val() == "") {
                    errors += "Invalid text content!";
                }

                if (errors != "") {
                    alert(errors);
                    return false;
                }

                return true;
            }


            $('#datetimepicker').datetimepicker();

            initMCE();
            // $( ".datepicker2" ).datepicker( "option", "dateFormat", 'yy-mm-dd' );
            //$(".datepicker2").datepicker({ "appendText" : '(yyyy-mm-dd)', "dateFormat" : 'yy-mm-dd'    }); 

        </script>    
    </div>
</div>    
