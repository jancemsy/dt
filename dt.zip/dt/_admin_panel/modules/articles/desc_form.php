<?php

 $meta =  Config::get("seo_meta");  
  
if(isset($_POST["save_desc"])){ 
     Config::update("article_cms", $_POST ); 
     
     
     $meta["title4"] = $_POST["meta_title"];
     $meta["desc4"] = $_POST["meta_desc"];
     $meta["keywords4"] = $_POST["meta_keywords"];
     Config::update("seo_meta", $meta ); 
 }
 
 
 $_POST =  Config::get("article_cms");   

?> 

<div class="box"> 
            <div class="title"> 
                    <h2>Settings</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms" > 
<form action="" method="post" enctype="multipart/form-data"   >  
    <table  >
        <tr><td>Meta Title <counter style="display:none" max="70" required="1" target="input[name=meta_title]'"></counter>:</td><td>  <input type="text" name="meta_title" class="text-input" value="<?php echo $meta["title4"]; ?>" /></td></tr> 
        <tr><td>Meta Desc <counter style="display:none" max="155" required="1" target="input[name=meta_desc]'"></counter>:</td><td>  <input type="text" name="meta_desc" class="text-input" value="<?php echo $meta["desc4"]; ?>" /></td></tr> 
        <tr><td>Meta Keywords:</td><td>  <input type="text" name="meta_keywords" class="text-input" value="<?php echo $meta["keywords4"]; ?>" /></td></tr> 
 
        
        <tr>
            <td>Headline:</td><td><input type="text" name="title" value="<?php echo $_POST['title']; ?>" size="55" /></td>                        
        </tr>
        <tr>
            <td>Description:</td><td><textarea name="text" class="mceEditor" cols="52"><?php echo $_POST['text']; ?></textarea></td>                        
        </tr> 
        
        <tr>
            <td>Listing Headline:</td><td><input type="text" name="list_headline" value="<?php echo $_POST['list_headline']; ?>" size="55" /></td>                        
        </tr>
        <tr>
            <td>Listing Description:</td><td><textarea name="list_desc" class="mceEditor" cols="52"><?php echo $_POST['list_desc']; ?></textarea></td>                        
        </tr> 
        
        
        
    </table>
    
       <div class="row buttons">                      
           <button type="submit"  name="save_desc"><span>Save</span></button>                                                
        </div>
    
</form>



<script type="text/javascript"> 
      initMCE();
</script>    

</div>
</div>    
    