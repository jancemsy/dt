 <?php
   
     if( !empty($_GET["edit"]) ){
          $help = new Helps($_GET["edit"]);
          $_POST = $help->array;
     }
 
 
     $_POST["video_type"] = $_POST["video_type"] == ''  ? 'upload' :  $_POST["video_type"];
 
 ?>

<form action="" method="post" enctype="multipart/form-data" >
    * Required Fields 
    <input type="hidden" name="video" value="<?php echo $_POST["video"]; ?>" />
    <input type="hidden" name="thumb1" value="<?php echo $_POST["thumb1"]; ?>" />
    <input type="hidden" name="thumb2" value="<?php echo $_POST["thumb2"]; ?>" />
    <input type="hidden" name="thumb3" value="<?php echo $_POST["thumb3"]; ?>" />
    <input type="hidden" name="id" value="<?php echo $_POST["id"]; ?>" />
    
    <table>
          <tr><td>Name <span style="color:red">*</span></td><td><input type="text" size="60" name="name" value="<?php echo $_POST["name"]; ?>" /></td></tr>
          <tr><td>Description</td><td><textarea name="description" cols="72"><?php echo $_POST["description"]; ?></textarea></td></tr>
          <tr><td>Text/HTML<span style="color:red">*</span></td><td><textarea name="content" class="mceEditor"><?php echo $_POST["content"]; ?></textarea></td></tr>
          <tr><td>Video:</td><td>               
                  <label><input type="radio" <?php echo $_POST["video_type"] == 'upload'  ? 'checked="checked"' : ''; ?> name="video_type" value="upload" /> Upload</label> 
                  <label><input type="radio" <?php echo $_POST["video_type"] == 'embed' ? 'checked="checked"' : ''; ?> name="video_type" value="embed" /> Embed</label>                    
                  &nbsp;&nbsp;&nbsp;
                  <?php                                       
                       if( !empty($_POST["video"]) ){
                           echo "<a href='".cpath($_POST["video"])."' target='_blank'>attached video</a> (<a href='?edit=".$_POST["id"]."&del=4'>delete</a>)";
                       }                   
                  ?>
                  <div  class="vtype row upload" <?php echo $_POST["video_type"] == "upload" ? '' : 'style="display:none;"'; ?> ><input type="file" name="video_upload"  /> </div>
                  <div  class="vtype embed" <?php echo $_POST["video_type"] == "embed" ? '' : 'style="display:none;"'; ?> ><textarea name="embed" cols="70" ><?php echo $_POST["embed"]; ?></textarea> </div>
              
              </td></tr>          
          <tr><td>Thumbnail 1:</td><td>
                    <?php 
                       if( !empty($_POST["thumb1"]) ){
                           echo "<a href='".cpath($_POST["thumb1"])."' target='_blank'>attached image 1</a> (<a href='?edit=".$_POST["id"]."&del=1'>delete</a>)";
                       }
                   
                  ?>
                  <div  class="row"><input type="file" name="thumbnail1_upload"   /></div> </td></tr>    
          <tr><td>Thumbnail 2:</td><td>
                     <?php 
                       if( !empty($_POST["thumb2"]) ){
                           echo "<a href='".cpath($_POST["thumb2"])."' target='_blank'>attached image 2</a> (<a href='?edit=".$_POST["id"]."&del=2'>delete</a>)";
                       }
                   
                  ?>
                  <div  class="row"><input type="file" name="thumbnail2_upload"  /></div> </td></tr>    
          <tr><td>Thumbnail 3:</td><td>   <?php 
                       if( !empty($_POST["thumb3"]) ){
                           echo "<a href='".cpath($_POST["thumb3"])."' target='_blank'>attached image 3</a> (<a href='?edit=".$_POST["id"]."&del=3'>delete</a>)";
                       }
                   
                  ?><div  class="row"><input type="file" name="thumbnail3_upload"  /></div> </td></tr>    
    </table>          
    
    
    <input type="hidden" name="update_help" value="Save" />
    
    
    
    
    <div class="row buttons" > 
           <button type="button" onclick="location.href='?'" ><span>Back</span></button>                                                
           <button type="submit"  ><span>Save</span></button>                                                
           <img src="../images/loading-small.gif" class="loader" style="display:none"  />
           <span class="status"></span>
        </div>
    
    
</form>


<script type="text/javascript">
   $(function(){
       $("input[name=video_type]").click(function(){
           $(".vtype").hide();
           $("." + $(this).val() ).show();           
       });
   });
   initMCET(".mceEditor");
</script>     