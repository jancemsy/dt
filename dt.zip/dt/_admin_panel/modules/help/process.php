<?php

if (!empty($_GET["edit"]) && !empty($_GET["del"])) {
    $del = $_GET["del"];
    $id = $_GET["edit"];
    $help = new helps($id);

    if ($del == 1) {
        @unlink("../" . $help->thumb1);
        Helps::update(array("id" => $id, "thumb1" => ""));
    } else if ($del == 2) {
        @unlink("../" . $help->thumb2);
        Helps::update(array("id" => $id, "thumb2" => ""));
    } else if ($del == 3) {
        @unlink("../" . $help->thumb3);
        Helps::update(array("id" => $id, "thumb3" => ""));
    } else if ($del == 4) {
        @unlink("../" . $help->video);
        Helps::update(array("id" => $id, "video" => ""));
    }

    jumpto("?edit=" . $id);
}

if (isset($_POST["update_help"])) {
    $path = "../content/helps";

    if (!file_exists($path)) {
        mkdir($path, 0777);
    }

    $vid_1 = false;
    $thumb_1 = false;
    $thumb_2 = false;
    $thumb_3 = false;


    if (isset($_FILES["video_upload"]) && $_FILES["video_upload"]["name"] != "") {
        if (!empty($_POST["video"]))
            @unlink("../" . $_POST["video"]);
        $name = $_FILES["video_upload"]["name"];
        $ext = end(explode(".", $name));
        $time = time();
        $filename = "$time-video.$ext";
        $thumb_orig = $path . "/" . $filename;
        move_uploaded_file($_FILES["video_upload"]["tmp_name"], $thumb_orig);                
        $_POST["video"] = "content/helps/$filename";        
        $_POST["video"] = upload_s3($_POST["video"]);                  
        $vid_1 = true;
    }

    if (isset($_FILES["thumbnail1_upload"]) && $_FILES["thumbnail1_upload"]["name"] != "") {
        if (!empty($_POST["thumb1"]))
            @unlink("../" . $_POST["thumb1"]);
        $name = $_FILES['thumbnail1_upload']["name"];
        $ext = end(explode(".", $name));
        $time = time();
        $filename = "$time-orig1.$ext";
        $thumb_orig = $path . "/" . $filename;
        move_uploaded_file($_FILES["thumbnail1_upload"]["tmp_name"], $thumb_orig);
        $_POST["thumb1"] = "content/helps/$filename";
        $_POST["thumb1"] = upload_s3($_POST["thumb1"]);                  
        $thumb_1 = true;
    }

    if (isset($_FILES["thumbnail2_upload"]) && $_FILES["thumbnail2_upload"]["name"] != "") {
        if (!empty($_POST["thumb2"]))
            @unlink("../" . $_POST["thumb2"]);
        $name = $_FILES['thumbnail2_upload']["name"];
        $ext = end(explode(".", $name));
        $time = time();
        $filename = "$time-orig2.$ext";
        $thumb_orig = $path . "/" . $filename;
        move_uploaded_file($_FILES["thumbnail2_upload"]["tmp_name"], $thumb_orig);
        $_POST["thumb2"] = "content/helps/$filename";
        $_POST["thumb2"] = upload_s3($_POST["thumb2"]);                  
        $thumb_2 = true;
    }

    if (isset($_FILES["thumbnail3_upload"]) && $_FILES["thumbnail3_upload"]["name"] != "") {
        if (!empty($_POST["thumb3"]))
            @unlink("../" . $_POST["thumb3"]);
        $name = $_FILES['thumbnail3_upload']["name"];
        $ext = end(explode(".", $name));
        $time = time();
        $filename = "$time-orig3.$ext";
        $thumb_orig = $path . "/" . $filename;
        move_uploaded_file($_FILES["thumbnail3_upload"]["tmp_name"], $thumb_orig);
        $_POST["thumb3"] = "content/helps/$filename";       
        $_POST["thumb3"] = upload_s3($_POST["thumb3"]);                  
        $thumb_3 = true;
    }

    $params = array("name" => $_POST["name"],
        "description" => $_POST["description"],
        "video_type" => $_POST["video_type"],
        "content" => clean_data($_POST["content"]),
        "video" => $_POST["video"],
        "embed" => serializeEncode($_POST["embed"]),
        "thumb1" => $_POST["thumb1"],
        "thumb2" => $_POST["thumb2"],
        "thumb3" => $_POST["thumb3"]
    );
    
    

    if (!empty($_POST["id"])) {
        $params["id"] = $_POST["id"];
        $id = $params["id"];
        Helps::update($params);
    } else {
        $id = Helps::add($params);
    }

    
    
    

    /* old
    if($vid_1) {
        init_s3_uploads("helps", "video", $_POST["video"], $id);
    }

    if($thumb_1) {
        init_s3_uploads("helps", "thumb1", $_POST["thumb1"], $id);
    }
    
    if($thumb_2) {
        init_s3_uploads("helps", "thumb2", $_POST["thumb2"], $id);
    }
    
    if($thumb_3) {
        init_s3_uploads("helps", "thumb3", $_POST["thumb3"], $id);
    }
     * 
     */


    jumpto("?");
}
?>