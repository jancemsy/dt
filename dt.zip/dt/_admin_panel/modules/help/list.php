<?php
  $list  = Helps::getList();
?>

<br/>
<p><a href="?new=1" class="button">New Help</a></p>

<table cellspacing="0" class="table">
    <thead>  
    <tr class="tr-header">
        <td>ID</td> 
        <td width="300">Name</td>
        <td width="300">Description</td>               
        <td width="200">Text/Html</td>     
        <td width="70">Action</td> 
    </tr>
    <?php
    
    foreach($list as $row){
       $button = "<a href='?edit=".$row["id"]."'>[Edit]</a>";
       $content = string_cut(strip_tags($row["content"]),100);
       
       echo '<tr>
        <td>'.$row["id"].'</td> 
        <td>'.$row["name"].'</td>
        <td>'.$row["description"].'</td> 
        <td>'.$content.'</td>
        <td>'.$button.'</td> 
       </tr>';
    }
    
    ?>
    
    </thead> 
    
    <tr></tr>
</table>