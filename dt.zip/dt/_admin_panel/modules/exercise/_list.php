<?php
if (!defined("PATH"))
    include_once("../../common.php");

 
extract(Exercise::getList(100, $_GET["search"]));



?>
<div class="clear"></div> <br/>

<form id="form-list" method="post" >
<table><tr><td>#</td>
        <td>met</td>
        <td>categoryID</td>
        <td>exercise</td>
        <td>Search Keywords/order
            <img class="food-result-loader"  style="display:none;    "  src="<?php echo PATH; ?>images/loading-small.gif" />                                        
        </td>
        <td>Action</td>
    </tr>
<?php
foreach ($list as $item) {
    $edit_btn = "<a href='?edit=" . $item["id"] . "&page=" . $_GET["page"] . "'>Edit</a>";
    $delete_btn = "<a href=''>delete</a>";


    $order = $item["search_order"] == "0" ? "" : $item["search_order"];
    $tags = $item["search_keywords"];
    $tags = str_replace(array("[", "]"), ",", $tags);
    $tags = str_replace(",,", ",", $tags);
    if ($tags[0] == ",")
        $tags = substr($tags, 1);
    if ($tags[strlen($tags) - 1] == ",")
        $tags = substr($tags, 0, -1);


    echo " <tr><td>{$item['id']}</td>
                                <td>{$item['met']}</td>
                                <td>{$item['categoryID']}</td>
                                <td width=500 >{$item['exercise']}</td>
                                <td>
                                 <input type='text' placeholder='search keywords' name='search_keywords[]' value='$tags'  />
                                 <input type='text' placeholder='order' name='search_order[]' value='$order'/>
                                 <input type='hidden' name='ids[]' value='{$item["id"]}' />
                                </td>
                                <td> $edit_btn</td>
                            </tr>  ";
}
?>
</table>
    <input type="hidden" name="update_search" value="1" />
    </form>

<div style="padding:10px;"> 
<?php
echo $pagination;
?>
</div>