<div class="box"> 
    <div class="title"> 
        <h2>Exercises</h2> 
        <?php echo $_dahide; ?>
    </div> 
    <div class="content  pages">

        <form action="" method="get" style="padding-bottom:20px;">
          Search Exercise: 
          <input type="text" name="search" />        
          <input type="submit" value="go" />
           <img class="food-loader" style="display:none;" src="<?php echo PATH; ?>images/loading-small.gif" />         
            <?php
            if ($_GET["search"] != "") {
                echo "<div style='border:1px solid #ccc; padding:10px; margin-top:10px; margin-bottom:10px;font-size:14px; '>                
                Search Result: <b>{$_GET["search"]}</b> &nbsp;&nbsp;&nbsp;
                    <a href='?'>&laquo; Go Back</a>                                             
                 </div>";
            }
            ?>
       </form>


        <div id="search-result">            
            <input  style="float:right;" type="button" name="save_search" value="Save Search Keywords" onclick="save_search_keywords()" />                         
            <?php
            include("_list.php");
            ?>
        </div>

    </div>
</div>    

<script type="text/javascript">
    function save_search_keywords(){
        $(".food-result-loader").show();        
        $.post("<?php echo PATH; ?>_admin_panel/modules/exercise/process.php",$("#form-list").serialize(),function(result){
            $(".food-result-loader").hide();            
        });        
    }
    
    
    $(function(){
        /*
            $("input[name=search]").keypress(function(){
                $(".loader").show();
              var s = $(this).val();
              $.get("modules/exercise/_list.php?s="+s,function(output){                  
                 $("#search-result").html(output);              
                 $(".loader").hide();
              });
            });
         */ 
    });
</script>
