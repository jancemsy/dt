<?php
   
   $exercise =   new Exercise($_GET["edit"]);   

?>
 <div class="box"> 
            <div class="title"> 
                    <h2>Edit Exercise</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms" > 
                <form action="" method="post">
                    <input type="hidden" name="id" value="<?php echo $exercise->id; ?>" />    
                    <table><tr><td>Exercise</td>
                            <td><input type="text" size="50" name="exercise" value="<?php echo $exercise->exercise; ?>" /></td></tr>
                        <tr><td>Met</td>
                            <td><input type="text" size="50"  name="met" value="<?php echo $exercise->met; ?>" /></td></tr>
                        <tr><td colspan="2">

                            <div class="row buttons"> 
                               <button type="button"  onclick="location.href='?page=<?php echo $_GET["page"];?>'" /><span>Cancel</span></button>                                                
                               <button type="submit" name="save_exercise" ><span>Save</span></button>                                                
                            </div>
                                
                                
    
                            </td></tr>
                    </table>
                </form>
    </div>        
</div>