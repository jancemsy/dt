<?php
$category_table = "fitness_categories";
$target_table = "fitness"; 
if (isset($_POST["save_featured_slots"])) {
    $list = CategoryFitness::getList();
    foreach ($list as $item) {
        $ids = $_POST["id_" . $item["id"]];
        $old_ids = $_POST["old_id_" . $item["id"]];

        if ($ids != $old_ids) { //if ids has changed lets update otherwise leave it be 
            $featured_ids = prepare_ids($ids); 
            mysql_query("UPDATE $target_table SET featured = 0 WHERE id IN (" . prepare_ids($old_ids) . ") ");
            mysql_query("UPDATE $target_table SET featured = 1 WHERE id IN (" . $featured_ids . ") ");
            CategoryFitness::update(array("id" => $item["id"], "featured_ids" => $ids ));
        }
    }
    $success_message = "Category slots have been saved!";
}

function prepare_ids($ids) {
    $ids_tmp = explode("-", $ids);
    $new_ids = "";
    foreach ($ids_tmp as $item) {
        if (!empty($item)) {
            $new_ids .=!empty($new_ids) ? "," : "";
            $new_ids .= $item;
        }
    }
    return $new_ids;
}

//////////////////////UPDATE CATEGORIES IF FEATURED SLOT ISNT SET YET////////////////////////////////


if ($_GET["init"] == 1) { 
    $result = mysql_query("SELECT id FROM $category_table WHERE featured_ids = '' ");

    while ($row = mysql_fetch_array($result)) {
        $catid = $row["id"];
        $result2 = mysql_query("SELECT id FROM $target_table WHERE featured = '1' AND categories LIKE '%-$catid-%' ");
        $ids = "";
        while ($row2 = mysql_fetch_array($result2)) {
            $id = $row2["id"];
            $ids .= "-$id-";
        }
        if ($ids != "") {
            mysql_query("UPDATE $category_table  SET featured_ids = '$ids'  WHERE id = $catid ");
        }
    }
}
?>
<script type="text/javascript">

    function checkthis(target) {
        var ids = "";

        $("." + target).each(function() {
            if ($(this).attr("checked")) {
                ids += "-" + $(this).val() + "-";
            }
        });

        $("#" + target).val(ids);
    }

    function opencat() {
        $(".tabdiv").hide();
        $($("#catmenu").val()).show();
    }
</script>
<style type="text/css">
    .featured_slots{   width: 900px; }
    .featured_slots .checkbox{ }
    .featured_slots .item{ margin: 5px; margin-left:10px; width: 100px; height: 110px; border: 1px solid #ccc; padding: 5px; float: left;}
    #catmenu { padding: 2px 10px 2px 10px!important; background:#eee; border: 2px solid #ccc;  font-size: 15px!important; }
</style>

<div class="box"> 
    <div class="title"> 
        <h2><?php echo $title; ?></h2> 
        <?php echo $_dahide; ?>
    </div> 
    <div class="content tabs" style="width:100%">                  
        <form action="" method="post">     
            <input type="hidden" name="selectedcat" />

            <?php
            if (!empty($success_message))
                echo "<div class=\"message blue\" style=\"margin:10px;\">$success_message</div>";

            $list = CategoryFitness::getList();

            $output = "";
            $tab_menu = "";
            $i = 0;
            foreach ($list as $item) {

                $i ++;

                if ($_POST["selectedcat"] == "")
                    $_POST["selectedcat"] = "#tab$i";
                $tab_menu .= ' <li><a href="#tab' . $i . '">' . $item["name"] . '</a></li> ';
                $tab_option .= '<option value="#tab' . $i . '" ' . ( $_POST["selectedcat"] == "#tab$i" ? "selected" : "") . ' >' . $item["name"] . '</option>';


                $output .= '<div id="tab' . $i . '" ' . ( $_POST["selectedcat"] == "#tab$i" ? "" : "style='display:none;'") . ' class="tabdiv"> 
               <input type="hidden" name="id_' . $item["id"] . '" value="' . $item["featured_ids"] . '" id="cat_' . $item["id"] . '" />                 
               <input type="hidden" name="old_id_' . $item["id"] . '" value="' . $item["featured_ids"] . '"   />                 
                       
                
             <div class="featured_slots"  >';

                $result = Fitness::getListByCatId($item["id"], 9999999);
                $inner_list = $result["list"];

                foreach ($inner_list as $inner_item) {
                    $output .= '
                 <div class="item">
                     <label><input type="checkbox" ' . (search("-" . $inner_item["id"] . "-", $item["featured_ids"]) ? "checked=checked" : "") . '  class="checkbox cat_' . $item["id"] . '" value="' . $inner_item["id"] . '"  onclick="checkthis(\'cat_' . $item["id"] . '\')" />' .
                            $inner_item["title"] . $inner_item["name"] . '</label>  
                    </div>';
                }

                $output .= ' <div class="clear"></div> </div> 
                </div>';
            }



            echo "<div style='text-align:right; padding:10px;'>Select Category: <select id='catmenu' name='selectedcat' onchange='opencat()'>$tab_option</select>"
            . "</div> $output";
//  echo "<ul class=\"tabnav\"> $tab_menu</ul> $output"; 
            ?>


            <div class="row buttons" style="padding:10px; border: none;">                     
                <button type="submit" name="save_featured_slots"><span>Save</span></button>                                                
            </div>

        </form>   

    </div>
</div>    
