<?php

if (isset($_POST['crop_images'])) {  //ajax call   
    $_SESSION["pending_crop"] = "";
    $quality = 100;

    $count = count($_POST['h']);

    for ($i = 0; $i < $count; $i++) {
        $des_h = $_POST['h'][$i];
        $des_w = $_POST['w'][$i];
        $width = $_POST['_w'][$i];
        $height = $_POST['_h'][$i];
        $source_x = $_POST['x'][$i];
        $source_y = $_POST['y'][$i];
        $size = empty($_POST['size'][$i]) ? "" : "-" . $_POST['size'][$i];
        $src = $_POST['thumb'][$i];




        if (!empty($des_h) && !empty($src)) {
            $filename = end(explode("/", $src));
            $destination = "../content/fitness/$filename";
            $ext = strtolower(end(explode(".", $src)));
            switch ($ext) {
                case "gif":
                    $img_r = imagecreatefromgif($src);
                    break;
                case "png":
                    $img_r = imagecreatefrompng($src);
                    break;
                default:
                    $img_r = imagecreatefromjpeg($src);
                    break;
            }

            $dst_r = ImageCreateTrueColor($width, $height);
            imagecopyresampled($dst_r, $img_r, 0, 0, $source_x, $source_y, $width, $height, $des_w, $des_h);


            switch ($ext) {
                case "gif":
                    imagegif($dst_r, $destination);
                    break;
                case "png":
                    imagepng($dst_r, $destination);
                    break;
                default:
                    imagejpeg($dst_r, $destination, $quality);
                    break;
            }

            if ($width == 600 && $height == 400) {
                $small = str_replace(".jpg", "-small.jpg", $destination);
                $med = str_replace(".jpg", "-med.jpg", $destination);
                createThumb($destination, $med, 300, 200);
                createThumb($destination, $small, 180, 120);
            }
        }//if 
    }//for






    die("1");
}


if (isset($_GET["delete"])) {
    $id = $_GET["delete"];
    $fitness = new Fitness($id);
    @unlink("../" . $fitness->thumb);
    $fitness->delete($id);
    jumpto("fitness.php");
}

if (isset($_GET["catdelete"])) {
    $id = $_GET["catdelete"];
    CategoryFitness::delete($id);
    jumpto("fitness.php?cat=1");
}

if (isset($_POST["save_category"])) {
    $name = clean_quote($_POST["name"]);
    $type = clean_quote($_POST["type"]);
    $description = clean_quote($_POST["description"]);
    $short_desc = clean_quote($_POST["short_desc"]);
    $params = array(
        "headline" => $_POST["headline"],
        "num" => $_POST["num"], "short_desc" => $short_desc,
        "description" => $description, "name" => $name,
        "type" => $type,
        "meta_title" => $_POST["meta_title"],
        "meta_desc" => $_POST["meta_desc"],
        "meta_keywords" => $_POST["meta_keywords"],
        "short_desc" => clean_quote($_POST["short_desc"]));

    if ($_POST["id"] != "") {
        $params["id"] = $_POST["id"];
        CategoryFitness::update($params);
    } else {
        CategoryFitness::add($params);
    }
    jumpto("fitness.php?cat=1");
}


if (isset($_POST["save"])) {

    $csize = count($_POST["category"]);
    $categories = "";
    $featured_categories = "";
    for ($i = 0; $i <= $csize; $i++) {
        if ($_POST["category"][$i] != "") {
            $categories .= "-" . $_POST["category"][$i] . "-";
        }
    }

    $array = array();
    $pending_crop = array();

    //thumb
    if (isset($_FILES["upload"]) && $_FILES['upload']["name"] != "") {
        if (!empty($_POST["thumb"])) {
            @unlink("../" . $_POST["thumb"]);
            $small = str_replace(".jpg", "-small.jpg", $_POST["thumb"]);
            $med = str_replace(".jpg", "-med.jpg", $_POST["thumb"]);
            @unlink("../" . $small);
            @unlink("../" . $med);
        }
        $name = $_FILES['upload']["name"];
        $ext = end(explode(".", $name));
        $time = time();
        $filename = "$time.$ext";
        $thumb_dest = "../content/fitness/$filename";
        move_uploaded_file($_FILES["upload"]["tmp_name"], $thumb_dest);

        list($width, $height, $type, $attr) = getimagesize($thumb_dest);
        if ($width == 600 && $height == 400) {
            $small = str_replace(".jpg", "-small.jpg", $thumb_dest);
            $med = str_replace(".jpg", "-med.jpg", $thumb_dest);
            createThumb($thumb_dest, $med, 300, 200);
            createThumb($thumb_dest, $small, 180, 120);
        } else {
            $pending_crop[] = array("image" => $thumb_dest, "width" => "600", "height" => "400", "caption" => "Workout Image");
        }
        $_POST["thumb"] = "content/fitness/$filename";
    }



    $count = count($_POST["routine"]);
    for ($i = 0; $i < $count; $i++) {
        $x = $i + 1;



        $steps = array();
        $steps_count = count($_POST["instruction$x"]);


        for ($j = 0; $j < $steps_count; $j ++) {
            if ($_FILES["upload$x"]["name"][$j] != "") {

                if (!empty($_POST["thumb$x"][$j])) {
                    @unlink("../" . $_POST["thumb$x"][$j]);
                    $small = str_replace(".jpg", "-small.jpg", $_POST["thumb$x"][$j]);
                    $med = str_replace(".jpg", "-med.jpg", $_POST["thumb$x"][$j]);
                    @unlink("../" . $small);
                    @unlink("../" . $med);
                }
                $name = $_FILES["upload$x"]["name"][$j];
                $ext = end(explode(".", $name));
                $time = time() . $i . $j;
                $filename = "$time.$ext";
                $orig_dest = "../content/fitness/$filename";
                move_uploaded_file($_FILES["upload$x"]["tmp_name"][$j], $orig_dest);

                list($width, $height, $type, $attr) = getimagesize($orig_dest);
                if ($width == 600 && $height == 400) {
                    $small = str_replace(".jpg", "-small.jpg", $orig_dest);
                    $med = str_replace(".jpg", "-med.jpg", $orig_dest);
                    createThumb($orig_dest, $med, 300, 200);
                    createThumb($orig_dest, $small, 180, 120);
                } else {
                    $pending_crop[] = array("image" => $orig_dest, "width" => "600", "height" => "400", "caption" => "Routine Image");
                }


                $_POST["thumb$x"][$j] = "content/fitness/$filename";
            }


            $thumb = $_POST["thumb$x"][$j];
            $steps[] = array(
                "name" => serializeEncode($_POST["name$x"][$j]),
                "instruction" => serializeEncode($_POST["instruction$x"][$j]),
                "thumb" => $thumb);
        }

        $routine = serializeEncode($_POST["routine"][$i]);
        $routine_desc = serializeEncode($_POST["routine_desc"][$i]);

        $array[] = array("steps" => $steps,
            "routine" => $routine,
            "desc" => $routine_desc);
    }//for


    $params = array(
        "publish_date_time" => clean_data($_POST["publish_date_time"]),
        "created_at" => addslashes($_POST["created_at"]),
        "thumb" => $_POST["thumb"],
        "featured" => $_POST["featured"],
        "userID" => $User->id,
        "meta_title" => clean_quote($_POST["meta_title"]),
        "meta_desc" => clean_quote($_POST["meta_desc"]),
        "meta_keywords" => clean_quote($_POST["meta_keywords"]),
        "categories" => $categories,
        "name" => clean_quote($_POST["name"]),
        "description" => clean_quote($_POST["description"]),
        "is_published" => $_POST["is_published"],
        "params" => serialize($array));



    if ($_POST["id"] != "") {
        $params["id"] = $_POST["id"];
        Fitness::update($params);   //   die("x {$params["id"]} xxx");
        $id = $_POST["id"];
    } else {
        $id = Fitness::add($params);
    }


    if (count($pending_crop) > 0) {
        $_SESSION["pending_crop"] = serialize($pending_crop);
        $_SESSION["goback"] = "fitness.php?edit=" . $id;
        jumpto("fitness.php?crop=1");
    }

    jumpto("fitness.php");
}
?> 
