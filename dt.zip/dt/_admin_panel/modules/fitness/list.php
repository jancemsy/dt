<?php
if (empty($catID)) {
    extract(Fitness::getAdminList(1, 20));
    $title = "Fitness Workouts ";
} else {
    extract(Fitness::getAdminList("categories LIKE '%-$catID-%'", 20));
    $cat = new CategoryFitness($catID);
    $catName = $cat->name;
    $title = "Fitness  / $catName";
}
?> 
<div class="box"> 
    <div class="title"> 
        <h2><?php echo $title; ?></h2> 
        <?php echo $_dahide; ?>
    </div> 
    <div class="content  pages">


        <p><a href="?new=1" class="button">New Workout</a></p>   

        <div class="row" style="position: absolute;width: 320px; border: none;display: block; margin: -40px 10px 10px 580px;  padding: 0 0 15px 0;">      

            <span>Display by:</span>
            <select id="jumper">
                <option value=""  >All</option> 
                <?php
                $cat = CategoryFitness::getList();
                foreach ($cat as $item) {
                    $selected = $item["id"] == $catID ? "selected" : "";
                    echo '<option value="' . $item['id'] . '" ' . $selected . ' >' . $item['name'] . '</option>';
                }
                ?>                                                                                     
            </select>                  

            <script>$(function() {
                    $("#jumper").change(function() {
                        location.href = '?catID=' + $(this).val();
                    });
                });</script>
        </div> 


        <div> 
            <?php echo $pagination; ?>                    
            <div class="clear"></div><br/> 
        </div>



        <table cellspacing="0" class="table">
            <thead>  
                <tr class="tr-header">
                    <td>ID</td>
                    <td>Published</td>  
                    <td>Date</td>
                    <td width="200">Workout</td>         
                    <td>Category</td> 
                    <td>Status</td> 
                    <td width="60">Action</td> 
                </tr>
            </thead> 
            <?php
            $output = "";
            $i = 0;
            foreach ($list as $item) {
                $button = "<a href='?delete={$item['id']}' class='delete-btn'>$_dadelete</a>
           <a href='?edit={$item['id']}'>$_daedit</a>";
                $i++;
                $tr_class = $i % 2 == 0 ? "tr-odd" : "tr-even";

                $thumb = "<img src='" . PATH . "{$item["thumb"]}' width='80' /> ";
                $text = string_cut(strip_tags($item["description"]), 250);
                $categories = CategoryFitness::getCategoryNamesByIds($item["categories"]);
                $featured = $item["featured"] == 1 ? "<br/><b>**featured**</b>" : "";
                $date = date("m/j/y", strtotime($item["created_at"]));
                $status = $item["is_published"] ? "published" : "draft";
                $published = $status == "draft" ? "n/a" : $item["publish_date_time"] == "0000-00-00 00:00:00" || $item["publish_date_time"] == "" ? "no data" : $item["publish_date_time"];

                $output .= "<tr class='$status'>
                <td>{$item["id"]}</td>
                <td>$published</td>
                <td>$date</td>
                <td>{$item["name"]}</td>                                 
                <td>$categories</td>
                <td>$status</td>     
                <td>$button</td></tr>";
            }

            echo $output;
            ?>
        </table>

    </div>
</div>    

