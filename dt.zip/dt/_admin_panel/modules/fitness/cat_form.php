<?php
$type = "Add";
if( isset($_GET["catedit"]) ){
    $id = $_GET["catedit"];     
    $cat = new CategoryFitness($id);
    $_POST = $cat->array;    
    $type = "Edit";
}

?>


<div class="box"> 
            <div class="title"> 
                    <h2><?php echo $type; ?> Category</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms">  

<form action="" method="post">
    <input type="hidden" name="id" value="<?php echo $_POST["id"]; ?>" />
    <input type="hidden" name="type" value="na" />
    <table>
         <tr><td>Meta Title <counter style="display:none" max="70" required="1" target="input[name=meta_title]'"></counter>:</td><td>  <input type="text" name="meta_title" class="text-input" value="<?php echo $_POST['meta_title']; ?>" /></td></tr> 
        <tr><td>Meta Desc <counter style="display:none" max="155" required="1" target="input[name=meta_desc]'"></counter>:</td><td>  <input type="text" name="meta_desc" class="text-input" value="<?php echo $_POST['meta_desc']; ?>" /></td></tr> 
        <tr><td>Meta Keywords:</td><td>  <input type="text" name="meta_keywords" class="text-input" value="<?php echo $_POST['meta_keywords']; ?>" /></td></tr> 
        
        
        <tr>
            <td>Order:</td>     
            <td><input type="input" name="num" value="<?php echo $_POST["num"]; ?>" /></td>
        </tr>
        
        
        <tr>
            <td>Headline:</td>     
            <td><input type="input" name="headline" size="96" value="<?php echo $_POST["headline"]; ?>" /></td>
        </tr>
        
        <tr>
            <td>Name:</td>     
            <td><input type="input" name="name" size="96" value="<?php echo $_POST["name"]; ?>" /></td>
        </tr>
        
        <!--
        <tr>
            <td>Type:</td>     
            <td>
                <select name="type">
                    <option <?php echo $_POST["type"] == "by meal" ? "selected" : ""; ?> >by meal</option>
                    <option  <?php echo $_POST["type"] == "by diet" ? "selected" : ""; ?> >by diet</option>
                </select>
            </td>
        </tr>
        -->
        <tr>
            <td>Description:</td>     
            <td><textarea name="description" cols="40" rows="5"><?php echo $_POST["description"]; ?></textarea></td>
        </tr>
        
         <tr>
            <td>Short Description:</td>     
            <td><textarea name="short_desc" cols="40" rows="5"><?php echo $_POST["short_desc"]; ?></textarea></td>
        </tr>
        <tr>
            <td colspan="2">                 
               <div class="row buttons"> 
                <button type="button" onclick="location.href='?cat=1'" ><span>Cancel</span></button>                                                
                <button type="submit" name="save_category"><span>Save</span></button>                                                
              </div> 
            </td>                
        </tr>
        
    </table>          
</form> 

    </div>
</div> 

<script>
      initMCE();
</script>