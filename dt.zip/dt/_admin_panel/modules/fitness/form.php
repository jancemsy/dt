<?php
$type = "Add";
if (isset($_GET["edit"])) {
    $id = $_GET["edit"];

    $fitness = new Fitness($id);
    $_POST = $fitness->array;
    $time = strtotime($_POST['created_at']);
    $date = date("Y-m-d", $time);
    $_POST["params"] = $fitness->params_unserialized;
    $type = "Edit";

    $time = strtotime($_POST['created_at']);
    $date = date("Y-m-d", $time);
}
?>
<script type="text/javascript">

    $(function() {
        $('#datetimepicker').datetimepicker();
        initMCET(".texteditor");

        if ($("div.routine").length > 0) {
            $("a.remove-row").show();
        }

    });

    function checkArticle() {
        var errors = "";
        tinyMCE.triggerSave();
        if ($("input[name='title']").val() == "") {
            errors += "Invalid title \n";
        }

        if ($("textarea[name='text']").val() == "") {
            errors += "Invalid text content!";
        }

        if (errors != "") {
            alert(errors);
            return false;
        }

        return true;
    }


    function add_routine_row() {
        var copy = $(".routine-dummy").html();
        var i = $(".routine").length + 1;

        if (i == 1) {
            $("<div class='routine'>" + copy + "</div>").insertAfter(".start-routine:last");
        } else {
            $("<div class='routine'>" + copy + "</div>").insertAfter(".routine:last");
        }
        $(".routine:last").find(".head").html("Routine " + i + ":");
        $(".routine:last").find(".input").val("");
        $(".routine:last").find("img").remove();

        //lets make have one step here      
        $(".routine:last .step").not($(".routine:last .step").eq(0)).remove();
        $(".routine:last .remove-step").hide();
        $(".remove-row").show();
        $(".routine:last .file").attr("name", "upload" + i + "[]");
        $(".routine:last .instruction").attr("name", "instruction" + i + "[]");
        $(".routine:last .name").attr("name", "name" + i + "[]");
    }

    function remove_routine_row() {
        //if($(".routine").length != 1){
        $(".routine:last").fadeOut(function() {
            $(this).remove();
            var i = $(".routine").length;
            if (i == 0)
                $(".remove-row").hide();
        });
        //}
    }

    function add_step(me) {
        var $me = $(me);
        var $parent = $me.parent();

        var copy = $parent.find(".step").html();
        var i = $parent.find(".step").length + 1;
        $("<div class='step'>" + copy + "</div>").insertAfter($parent.find(".step:last"));

        $parent.find(".head-step:last").html("Step " + i + ":");
        $parent.find(".step:last .input").val("");
        $(".step:last").find("img").remove();
        $parent.find(".remove-step").show();
    }

    function remove_step(me) {
        var $me = $(me);
        var $parent = $me.parent();

        if ($parent.find(".step").length != 1) {
            $parent.find(".step:last").fadeOut(function() {
                $(this).remove();
                if ($parent.find(".step").length == 1)
                    $parent.find(".remove-step").hide();

            });
        }
    }
</script>
<style>
    .routine{ margin-top: 25px; border:2px solid #333; padding: 10px; margin-bottom: 10px; width: 580px; height: auto; }
    .routine .head{ padding:0 10px 0 10px; font-weight: bold; background:#333; color:#fff; position: absolute; margin: -29px 0 0 -12px; }
    .step{ margin-top: 25px; border:1px solid #ccc; padding: 10px; margin-bottom: 10px; width: 560px; height: auto; }
    .head-step{ padding:0 10px 0 10px; background:#ccc; color:#fff; position: absolute; margin: -29px 0 0 -11px; }
    .routine-text1{ width: 575px!important; }
    .step-text1{ width: 475px!important; }
</style>

<div class="box"> 
    <div class="title"> 
        <h2><?php echo $type; ?> Fitness Workout</h2> 
        <?php echo $_dahide; ?>
    </div> 
    <div class="content  forms" > 

        <form action="" method="post" enctype="multipart/form-data"     >
            <input type="hidden" name="id" value="<?php echo $_POST['id']; ?>" /> 

            <table>
                <tr><td>Status:</td>
                    <td>
                        <select name="is_published" onchange=" $(this).val() == '1' ? $('.publish_box').show() : $('.publish_box').hide();
                                " >
                            <option value="1">Publish</option>
                            <option value="0" <?php if ($_POST["is_published"] == 0) echo "selected"; ?> >Draft</option></select>


                        <span class="publish_box" <?php if ($_POST["is_published"] == 0) {
            echo "style='display:none;'";
        } ?>  >
                            <input type="text" id="datetimepicker" name="publish_date_time" placeholder="Enter publish time"   value="<?php echo $_POST['publish_date_time']; ?>" />  
                        </span> 

                    </td></tr> 
                <tr><td>Meta Title <counter style="display:none" max="70" required="1" target="input[name=meta_title]'"></counter>:</td><td>  <input type="text" name="meta_title" class="text-input" value="<?php echo $_POST['meta_title']; ?>" /></td></tr> 
                <tr><td>Meta Desc <counter style="display:none" max="155" required="1" target="input[name=meta_desc]'"></counter>:</td><td>  <input type="text" name="meta_desc" class="text-input" value="<?php echo $_POST['meta_desc']; ?>" /></td></tr> 
                <tr><td>Meta Keywords:</td><td>  <input type="text" name="meta_keywords" class="text-input" value="<?php echo $_POST['meta_keywords']; ?>" /></td></tr> 

                <tr>
                    <td>Date:</td><td><input type="text" name="created_at" class="datepicker text-input"  value="<?php echo $date; ?>"   /></td>                        
                </tr>

                <?php /*
                  <tr><td>Featured?</td><td>
                  <label><input type="radio" name="featured"  <?php echo $_POST['featured'] == 1 ? "checked" : ""; ?>  value="1" /> yes</label>
                  <label><input type="radio" name="featured"  <?php echo $_POST['featured'] == 0 ? "checked" : ""; ?>  value="0" /> no </label>
                  </td></tr>
                 */
                ?>

                <tr>
                    <td>Name:</td><td><input type="text" name="name" value="<?php echo $_POST['name']; ?>" size="55" /></td>                        
                </tr>
                <tr>
                    <td>Description:</td><td><textarea name="description" class="texteditor" cols="52"><?php echo $_POST['description']; ?></textarea></td>                        
                </tr>

                <tr>
                    <td>Thumb (600 x 400 px) jpg only:</td><td>
                        <div class="row" style=" border:none; height: 20px; padding: 0px; ">
                            <input type="file" name="upload" />
                            <input type="hidden" name="thumb" value="<?php echo $_POST["thumb"]; ?>" />
                        </div>
                        <?php
                        if (!empty($_POST["thumb"])) {
                            echo " &nbsp; <img src='../" . toThumbMed($_POST["thumb"]) . "' style='margin-top:4px; '  /> <br/>  ";
                        }
                        ?>
                </tr> 

                <tr>
                    <td valign="top">Workouts:</td>
                    <td>    

                        <div class='start-routine'></div>
                        <?php
                        $i = 0;
                        if (isset($_POST["params"])) {
                            $array = $_POST["params"];
                            $i = 0;
                            if (is_array($array)) {
                                foreach ($array as $item) {
                                    $i++;
                                    ?>    
                                    <div class="routine" > 
                                        <div class="head" >Routine <?php echo $i; ?>:</div>
                                        Routine Name: <br/> <input name="routine[]" type="text"  value="<?php echo $item["routine"]; ?>"  class="input routine-text1" /> <br/>
                                        Desc: <br/>
                                        <textarea name="routine_desc[]"   class="input routine-text1" ><?php echo $item["desc"]; ?></textarea>   <br/> 


                                        <?php
                                        $steps = $item["steps"];
                                        $j = 0;
                                        foreach ($steps as $s) {
                                            $j++;
                                            ?>
                                            <div class="step">
                                                <div class="head-step" >Step <?php echo $j; ?>:</div>

                                                Step Name: <input type="text" name="name<?php echo $i; ?>[]" value="<?php echo $s["name"]; ?>" class="name input step-text1" /> <br/>
                                                Thumbnail:  (600 x 400 px) jpg only:                                        

                                                <div class="row" style=" border:none; height: 20px; padding: 0px; ">
                                                    <input type="file" size="46"  name="upload<?php echo $i; ?>[]"   class="input upload file"  /> 
                                                    <input type="hidden" name="thumb<?php echo $i; ?>[]" value="<?php echo $s["thumb"]; ?>"  class="input" />
                                                </div>
                                                <?php
                                                if (!empty($s["thumb"])) {
                                                    echo " &nbsp; <img src='../" . toThumbMed($s["thumb"]) . "' style='margin-top:4px;'  /> <br/>  ";
                                                }
                                                ?>

                                                Instructions (separated by | ) <br/>
                                                <textarea name="instruction<?php echo $i; ?>[]" cols="60"  class="input instruction"><?php echo $s["instruction"]; ?></textarea>                                 
                                            </div>
            <?php } ?>


                                        <a href="javascript:;" onclick="add_step(this)">[add step]</a>
                                        <a href="javascript:;" onclick="remove_step(this)" class="remove-step"   >[remove step]</a>
                                    </div>

                                    <?php
                                }
                            }
                        }
                        ?>


                        <a href="javascript:;" onclick="add_routine_row()" class="small" >[add routine]</a>
                        <a href="javascript:;" onclick="remove_routine_row()"  class="small remove-row" style="display:none" >[remove routine]</a>



                    </td>                        
                </tr>


                <tr>
                    <td>Category: </td><td>

                        <table>
                            <tr style = 'background:#eee;' ><td>Categories</td><!--<td> Featured? </td>--></tr>
                            <?php
                            $list = CategoryFitness::getList();
                            $i = 0;
                            foreach ($list as $item) {
                                $i++;
                                //$checked_featured =  (search("-{$item["id"]}-", $_POST["featured_categories"]))  ? " checked=checked " : "";  
                                $checked = (search("-{$item["id"]}-", $_POST["categories"])) ? " checked=checked " : "";
                                $style = $i % 2 == 0 ? " style = 'background:#eee;' " : "";
                                echo "<tr $style  ><td><label><input type='checkbox' name='category[]' $checked value='" . $item["id"] . "' /> " . $item["name"] . " </label> </td>";
                                echo "</tr>";

                                //. "<td> <label><input $checked_featured type='checkbox' name='featured_category[]'  value='" . $item["id"] . "' />   </label> </td></tr> "; 
                            }
                            ?> 
                        </table>
                    </td></tr>    
                <tr>
                    <td colspan="2" >

                        <div id="button_container" class="row buttons">           
                            <button type="button" onclick="location.href = '?';" ><span>Back</span></button>                                                
                            <button type="submit"  name="save" onclick="$('#button_container').hide();
                                    $('#please_wait').show();"><span>Save</span></button>                                                
                        </div>

                        <div id="please_wait" style="display:none;padding:10px; font-size:20px; font-weight:bold;">
                            Please wait...
                        </div>

                    </td>                        
                </tr>

            </table>
        </form>

        <div class="routine-dummy"  style="display:none">  
            <div class="head" >Routine 1:</div>
            Routine Name: <br/> <input name="routine[]" type="text"  class="input routine-text1" /> <br/>
            Desc: <br/> 
            <textarea name="routine_desc[]" class="input routine-text1" ></textarea>



            <div class="step">
                <div class="head-step" >Step 1:</div>
                Step Name: <input type="text" name="name1[]" value="" class="name input step-text1" /> <br/>

                Thumbnail: 295x212 .jpg only:                                        

                <div class="row" style=" border:none; height: 20px; padding: 0px; ">
                    <input type="file" size="46"  name="upload1[]"   class="input upload file"  />             
                </div>

                Instructions (separated by | ) <br/>
                <textarea name="instruction1[]" cols="60"  class="input instruction"></textarea>                                                        
            </div>
            <a href="javascript:;" onclick="add_step(this)">[add step]</a>
            <a href="javascript:;" onclick="remove_step(this)" class="remove-step" style="display:none">[remove step]</a>
        </div>

    </div>
</div>    

