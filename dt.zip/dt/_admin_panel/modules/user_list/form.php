<?php 
 
$id = $_GET["edit"];
$user = new User($id);
$_POST = $user->array;
?> 

<div class="box"> 
            <div class="title"> 
                    <h2>Edit User</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms"> 
<form action="" method="post"   enctype="multipart/form-data" onsubmit="return checkuserUpdate2()"   >
    <input type="hidden" name="id" value="<?php echo $id; ?>" />
    
    <table><tr>
            <td>Name:</td>
            <td><input type="input" size="50" name="name" value="<?php echo $_POST["name"]; ?>" /></td>                        
        </tr>
        <tr>
            <td>Email:</td>
            <td><input type="input" size="50" name="email"  value="<?php echo $_POST["email"]; ?>" /></td>                        
        </tr>
        <tr>
            <td>Location:</td>
            <td><input type="input" size="50" name="address"   value="<?php echo $_POST["address"]; ?>" /></td>                        
        </tr>
        <tr>
            <td>Password:</td>
            <td><input type="password" size="50" name="password"   value="" /></td>                        
        </tr>
        <tr>
            <td>Confirm Password:</td>
            <td><input type="password" size="50" name="password2"   value="" /></td>                        
        </tr>
    </table>
             
    <div class="row buttons"> 
                   <button type="button" onclick="location.href='user_list.php'" ><span>Cancel</span></button>                                                
                   <button type="submit" name="save_user"><span>Save</span></button>                                                
    </div>
     
    
</form>    
    </div>        
</div>    


<script>
 function checkuserUpdate2(){
    
     if(  $("input[name=password]").val() != $("input[name=password2]").val() ){
         alert("Password didn't match!");
         return false;
     }
     return true;
 }
</script>