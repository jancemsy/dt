<script>
function ResendActivation(id){
    $(".loader-"+id).show();
    $(".rlink-"+id).hide();
    $.post("",{'id' : id, resendactivation_admin:1},function(result){
         if(result == "1"){
            $(".loader-"+id).hide();
            $(".rlink-"+id).show();   
         }
    });
}
</script>

<?php

  if( $_GET["orderby"] == "created_at" ){
      if($_GET["order"] == 1) $created_at_class = "order_up";
      else $created_at_class = "order_down";
  }
  
  
  if( $_GET["orderby"] == "email" ){
      if($_GET["order"] == 1) $email_class = "order_up";
      else $email_class = "order_down";
  }
  
  if( $_GET["orderby"] == "sourceid" ){
      if($_GET["order"] == 1) $sourceid_class = "order_up";
      else $sourceid_class = "order_down";
  }
  
  if( $_GET["orderby"] == "keywordid" ){
      if($_GET["order"] == 1) $keywordid_class = "order_up";
      else $keywordid_class = "order_down";
  }
  

?>
<style type="text/css">
    a.order_down{  background: url(../images/arrow-up-down.gif) no-repeat bottom right;  padding-right: 10px;   text-decoration: underline!important;  }
    a.order_up{ background: url(../images/arrow-up-down.gif) no-repeat  top right; padding-right: 10px;     text-decoration:  underline!important;  }
    .tr-header td a{ color: blue!important; }

    /* display:none; */
    tr.tr-disable *{ font-style:italic; color: #ccc!important;   }
    #user-list-popup{ z-index:99999; position:absolute; background:#fff;   top: 205px; width: 600px; height:auto; margin-left:170px; border:5px solid #eee; padding:10px; z-index:99999; }
    #user-list-overlay{ margin: 0px!important; top:0px!important;background: url(../images/dashboard/overlay.png); position:fixed!important; display:block;  z-index: 5; left:0px; top:0px;  width: 100%!important;height: 100%!important; }
</style>

<div id="user-list-popup" style="display:none;" >
 <div style="padding:20px;">
       <input type="hidden" class="target_user_id" value="" />
      Select the reason for disabling this user: 
      <p>
        <label><input type="radio" value="-1" name="status" checked="checked" /> Account Abuse</label>
        <label><input type="radio" value="-2" name="status" /> Inactivity</label>
        <label><input type="radio" value="-3" name="status" /> Security</label>   
      </p>
      
      <input type="button" value="Disable User" class="save_ban_btn" />
      <input type="button" value="Cancel" class="cancel_ban_btn" />
  </div>
</div>

<div id="user-list-overlay"  style="display:none;" > 
</div>



<div class="box"> 
        <div class="title"> 
                <h2><?php echo $title; ?></h2> 
                <?php echo $_dahide; ?>
        </div> 
        <div class="content pages"> 

            <form action="" method="post" onsubmit="return confirm('Warning! This action will delete all content associated with the users selected. Are you sure?')" >
            
                <input type="submit" name="delete_all_selected" value="Delete All Selected" /> <br/><br/>
                <!-- <input type="submit" name="disabled_all_selected" value="Disabled All Selected" /> <br/><br/> -->
            
<table cellspacing="0" class="table">
             <thead> 
             <tr class="tr-header"> 
                   <td></td>   
                   <td>ID</td>   
                   <td><a href="<?php echo "?orderby=created_at&order=".($_GET["order"] == 1 ?  0 : 1 );?>" class="<?php echo $created_at_class; ?>" >Join&nbsp;Date</a></td>
                   <td><a href="<?php echo "?orderby=email&order=".($_GET["order"] == 1 ?  0 : 1 );?>" class="<?php echo $email_class; ?>" >User Info</a></td>
                   <td align='center'><a href="<?php echo "?orderby=sourceid&order=".($_GET["order"] == 1 ?  0 : 1 );?>" class="<?php echo $sourceid_class; ?>" >souceID</a></td>
                   <td align='center'><a href="<?php echo "?orderby=keywordid&order=".($_GET["order"] == 1 ?  0 : 1 );?>" class="<?php echo $keywordid_class; ?>" >keywordID</a></td>
                   
                   <td>Last Logged</td>
                   <td align='center'>Status</td>
                   <td width="100">Action</td>                   
               </tr>
               </thead> 
               
<?php 
      $output =  "<tr>";            
      extract(User::getListAdmin(100,$_GET["orderby"],$_GET["order"]));      
            
      foreach($list as $item){          
          $button = "<a href='?delete={$item["id"]}' onclick='return confirm_user_delete(\"{$item["username"]}\",\"{$item["email"]}\")' class='delete-btn2'>$_dadelete</a>&nbsp;<a href='?edit={$item["id"]}'>$_daedit</a>";          
          
          
          $user_link = User::profile_link($item["id"]);          
          $date = date("m/d/y",strtotime($item["created_at"]));          
          
          if($item["status"] == 1){
              $status = "active";
          }else{
              if($item["status"] == -1){
                  $status = "Disabled: account abuse";
              }else if($item["status"] == -2){
                  $status = "Disabled: inactivity";
              }else if($item["status"] == -3){
                  $status = "Disabled: security";
              }else if($item["status"] == 0){
                  $status = "Not yet activated";
              }
          }
                               
          
          
          if($item["status"] == 1){
            $class = "";
            $button = "<a href='javascript:;' onclick='disable_user({$item['id']})' title='Disable User'><img src='".PATH."images/control_pause.png'/></a>".$button;
          }else{
            $class = "tr-disable";
            $button = "<a href='javascript:;' onclick='enable_user({$item['id']})' title='Enable User'><img src='".PATH."images/control_play.png'/></a>".$button;  
          }
          
          
          if($item["status"] != "1"){
              $button .= "
                  <a  class='rlink-{$item["id"]}' href='javascript:;' onclick='ResendActivation({$item["id"]})' title='Resend Email Activation'><img src='".PATH."images/arrow_refresh.png'/></a>
                  <img class='loader-{$item["id"]}' style='display:none' src='".PATH."images/loading-small.gif' /> ";
          }
          
          
          
          $date  = $item["last_login"] == "0000-00-00 00:00:00" ? $item["created_at"]  : $item["last_login"];
          $lastlogged = date("n/j/Y g:i A",strtotime($date));
          
          
          $output .= "<tr class='$class' >
                       <td><input type='checkbox' name='selected_user[]' value='{$item["id"]}' /></td> 
                       <td>{$item["id"]}</td>                                               
                       <td>$date</td>    
                       <td>{$item["email"]} <br/>
                       <a href='$user_link'>{$item["username"]}</a></td>                                                                      
                       <td align='center'>{$item["sourceID"]}</td> 
                       <td align='center'>{$item["keywordID"]}</td> 
                           <td  >$lastlogged</td>
                       <td align='center'>$status</td>
                       <td>$button</td>
          </tr>";
      }
           
      echo $output; 
?>  
</table>
            
        </form>
            
            <br/><br/>
            <?php
             echo $pagination;
            ?>
            <br/><br/>
        </div>
</div>               

<script>
    
    function enable_user(id){
        location.href = "?enable_user=" + id;                        
    }
    
    function hide_popup(){
        $("#user-list-popup").hide();
        $("#user-list-overlay").hide(); 
    }
    
    function disable_user(id){ 
        $(".target_user_id").val(id);
        $("#user-list-popup").show();
        $("#user-list-overlay").show().click(hide_popup);
    }    
     
    
    $(".save_ban_btn").click(function(){
        var id = $(".target_user_id").val();
        var status  = $("input[name=status]:checked").val();                
        location.href = "?disable_user="+status+"&userID=" + id;                        
    });
    
    $(".cancel_ban_btn").click(hide_popup);
     
          
    
    function confirm_user_delete(username,email){       
        if( confirm("Warning! This action will delete all content associated\n with the user "+username+", "+email+". Are you sure?") ){            
          return true;    
        }        
        return false;        
    }
</script>