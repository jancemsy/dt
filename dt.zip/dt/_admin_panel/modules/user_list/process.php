<?php

if (isset($_POST["resendactivation_admin"])) {
    $id = $_POST["id"];
    $u = new User($id);
    if (!empty($u->id) && $u->status != 1) {
        $u->SendActivateEmail();
    }
    die("1");
}


if (isset($_GET["enable_user"])) {
    $id = $_GET["enable_user"];
    $user = new User($id);
    $user->update(array("status" => 1));
    jumpto("?");
}


if (isset($_GET["disable_user"])) {
    $status = $_GET["disable_user"];
    $id = $_GET["userID"];
    $user = new User($id);
    $user->update(array("status" => $status));

    ////////////////// EMAIL USER  //////////////    
    if ($status == -1)
        $reason = "Account Abuse";
    else if ($status == -2)
        $reason = "Inactivity";
    else if ($status == -3)
        $reason = "Security";

    $template = new StaticPages();
    extract($template->getNotifyBanTemplate(array("username" => $user->username, "reason" => $reason)));
    $mail = new ZFmail($user->email, EMAIL_FROM, $subject, $body);
    $mail_result = @$mail->send();


    jumpto("?");
}


if (isset($_POST["delete_all_selected"])) {
    $count = count($_POST["selected_user"]);
    $selected_user = $_POST["selected_user"]; 
    for($i = 0; $i < $count; $i++){ 
       $userID = $_POST["selected_user"][$i];
       User::delete($userID); 
    }
    jumpto("?");
}
/*
if (isset($_POST["disabled_all_selected"])) {
    $count = count($_POST["selected_user"]);
    $selected_user = $_POST["selected_user"]; 
    for($i = 0; $i < $count; $i++){ 
       $userID = $_POST["selected_user"][$i];
       User::delete($userID); 
    }
    jumpto("?");
}*/

if (isset($_GET["delete"])) {
    $id = $_GET["delete"];
    User::delete($id);
    jumpto("?");
}


if (isset($_POST["save_user"])) {
    $user = new User($_POST["id"]);
    $array = array(
        "address" => addslashes($_POST["address"]),
        "name" => $_POST["name"],
        "email" => $_POST["email"]
    );

    if (!empty($_POST["password"])) {
        $array["password"] = $_POST["password"];
    }

    $user->update($array);
    jumpto("?");
}
?>
