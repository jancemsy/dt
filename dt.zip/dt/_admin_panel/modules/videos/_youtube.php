<?php 

$file =  "../content/videos/$filename";

require_once 'Zend/Loader.php'; // the Zend dir must be in your include_path
Zend_Loader::loadClass('Zend_Gdata_YouTube'); 
Zend_Loader::loadClass('Zend_Gdata_ClientLogin');  
 
$authenticationURL= 'https://www.google.com/accounts/ClientLogin';
$httpClient = Zend_Gdata_ClientLogin::getHttpClient(
              $username = YT_USERNAME,
              $password = YT_PASSWORD,
              $service = 'youtube',
              $client = null,
              $source = 'MySource', // a short string identifying your application
              $loginToken = null,
              $loginCaptcha = null,
              $authenticationURL);


// Note that this example creates an unversioned service object.
// You do not need to specify a version number to upload content
// since the upload behavior is the same for all API versions.
$yt = new Zend_Gdata_YouTube($httpClient, YT_APPID, YT_CLIENTID, YT_DEVKEY); 

// create a new VideoEntry object
$myVideoEntry = new Zend_Gdata_YouTube_VideoEntry();

// create a new Zend_Gdata_App_MediaFileSource object
$filesource = $yt->newMediaFileSource($file);
//$filesource->setContentType('video/flv');
// set slug header
$filesource->setSlug($filename);
 
// add the filesource to the video entry
$myVideoEntry->setMediaSource($filesource);         
$myVideoEntry->setVideoTitle($_POST["meta_title"]);
$myVideoEntry->setVideoDescription($_POST["meta_desc"]);
// The category must be a valid YouTube category!
$myVideoEntry->setVideoCategory('Education');

// Set keywords. Please note that this must be a comma-separated string
// and that individual keywords cannot contain whitespace
$myVideoEntry->SetVideoTags(array('diet','tools','video'));

// set some developer tags -- this is optional
// (see Searching by Developer Tags for more details)
//$myVideoEntry->setVideoDeveloperTags(array('mydevtag', 'anotherdevtag'));

// set the video's location -- this is also optional
/*
$yt->registerPackage('Zend_Gdata_Geo'); 
$yt->registerPackage('Zend_Gdata_Geo_Extension');
$where = $yt->newGeoRssWhere();
$position = $yt->newGmlPos('37.0 -122.0');
$where->point = $yt->newGmlPoint($position);
$myVideoEntry->setWhere($where); 
*/

// upload URI for the currently authenticated user
$uploadUrl = 'http://uploads.gdata.youtube.com/feeds/api/users/default/uploads';

// try to upload the video, catching a Zend_Gdata_App_HttpException, 
// if available, or just a regular Zend_Gdata_App_Exception otherwise
try {
    $newEntry = $yt->insertEntry($myVideoEntry, $uploadUrl, 'Zend_Gdata_YouTube_VideoEntry');
    // Assuming that $videoEntry is the object that was returned during the upload
    $state = $newEntry->getVideoState();

    if ($state) { 
        $_POST["flv"] = "http://youtu.be/".$newEntry->getVideoId(); 
         @unlink("../content/videos/$filename"); 
        /*
      echo 'Upload status for video ID ' . $videoEntry->getVideoId() . ' is ' .
        $state->getName() . ' - ' . $state->getText() . "\n";
      } else {
        echo "Not able to retrieve the video status information yet. " . 
          "Please try again later.\n";
       }
       */

    }
} catch (Zend_Gdata_App_HttpException $httpException) {
   $viderror = $httpException->getRawResponseBody()."..";
} catch (Zend_Gdata_App_Exception $e) {
   $viderror = $e->getMessage()."...";
} 







?>