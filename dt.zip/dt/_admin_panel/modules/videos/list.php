<?php 
    $path = "../content/videos/"; 
    if( empty($catID) ){ 
         extract(Video::getListAdmin(1,20));   
         $title = "Videos";
                          
    }else{
        $cat = new CategoryVideo($catID);                
        $title = "Videos  / $cat->name";        
        extract(Video::getListAdmin("categories LIKE '%-$catID-%'",20));
    }
?> 

<div class="box"> 
            <div class="title"> 
                     <h2><?php echo $title; ?></h2>
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  pages" > 
        
<p><a href="?new=1" class="button">New Video</a></p>


<div class="row" style="position: absolute;width: 320px; border: none;display: block; margin: -40px 10px 10px 580px;  padding: 0 0 15px 0;">      
        
             <span>Display by:</span>
             <select id="jumper">
                        <option value=""  >All</option> 
                         <?php
                              $cat = CategoryVideo::getList();                             
                              foreach($cat as $item){  
                                  $selected = $item["id"] == $catID ? "selected" : "";
                                  echo '<option value="'.$item['id'].'" '.$selected.' >'.$item['name'].'</option>';
                              }
                             ?>                                                                                     
                </select>                  
        
<script>$(function(){ $("#jumper").change(function(){ location.href='?catID='+$(this).val(); }); });</script>
</div> 


 <div> 
        <?php echo $pagination; ?>                    
     <div class="clear"></div><br/> 
</div>
 <table cellspacing="0" class="table">
    <thead>  
    <tr class="tr-header">
        <td>ID</td> 
        <td>Published</td>  
        <td>Date</td>
        <td width="300">Title</td>
        <!--<td width="300">Description</td>-->
        <td width="200">Thumb</td>        
     
        <td>Category</td>
        <td>Status</td> 
        <td width="70">Action</td> 
    </tr>
    </thead> 
    <?php
       $output = ""; 
       $i = 0;
       foreach($list as $item){
           $array = unserialize($item["params"]);
            
           $img  = "<img src='$path{$array['thumb']}'  width='50'  /> ";
           $button = "<a href='?delete_video={$item['id']}' class='delete-btn'>$_dadelete</a>
           <a href='?edit={$item['id']}'>$_daedit</a>";
           $i++;
           
           $tr_class = $i%2 == 0 ? "tr-odd" : "tr-even";
           
           $featured = $item["featured"] == 1 ? " <br/> <span style='color:red;'>featured</span> " : "";
           $text =  string_cut(strip_tags($item["description"]),250);
           $categories = CategoryVideo::getCategoryNamesByIds($item["categories"]);
             
           
           $status = $item["is_published"] ? "published" : "draft";
           $date = date("m/j/y",  strtotime($item["created_at"]));
           $published = $status == "draft" ? "n/a" : $item["publish_date_time"] == "0000-00-00 00:00:00" || $item["publish_date_time"] == "" ? "no data" : $item["publish_date_time"];
           
           
           $output .= "<tr class='$tr_class $status' >
                <td>{$item['id']}</td> 
                <td>$published</td>
                <td>$date</td>    
                <td><a href='{$item["permalink"]}' target='_blank'>{$item['title']}</a> $featured</td>   
                <td>$img</td>                   
                <td>$categories</td>
                <td>$status</td>
                <td>$button</td>
            </tr>";
           
       }
       echo $output;
    
    ?>    
</table>  

    </div>
</div>    