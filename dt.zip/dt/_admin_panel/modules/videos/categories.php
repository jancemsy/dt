 <div class="box"> 
        <div class="title"> 
                <h2><?php echo $title; ?></h2> 
                <?php echo $_dahide; ?>
        </div> 
        <div class="content pages">  
<p><a href="?new_cat=1" class="button">New Category</a></p>      
 <table cellspacing="0" class="table">
    <tr class="tr-header">
        <td>ID</td>
        <td width="200">Category</td>  
        <td width="300">Short Desc</td>  
        <!--<td>Type</td> -->
        <td>Order</td>     
        <td>Action</td> 
    </tr>
<?php 
      $list = CategoryVideo::getList();   
       $output = "";
       $i = 0;
       foreach($list as $item){  
         $button = "<a href='?catdelete={$item['id']}' class='delete-btn'>$_dadelete</a>
          <a href='?catedit={$item['id']}'>$_daedit</a>";
         $i++;
         $tr_class = $i%2 == 0 ? "tr-odd" : "tr-even"; 
         $thumb = "<img src='".PATH."{$item["thumb"]}' width='80' /> ";  
         $text =  string_cut($item["text"],250); 
         $output .= "<tr>
                <td>{$item["id"]}</td>
                <td>{$item["name"]}</td>       
                <td>{$item["short_desc"]}</td>       
                <!-- <td>{$item["type"]}</td> -->
                <td>{$item["num"]}</td>     
                <td>$button</td></tr>"; 
       } 
       echo $output; 
?>
</table>
        </div>
</div>     