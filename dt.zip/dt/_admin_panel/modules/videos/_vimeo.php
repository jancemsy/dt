<?php 

$file =  "../content/videos/$filename";  
include ABSPATH.'vimeo/vimeo.php'; 

$title  = $_POST["meta_title"];
$desc   = $_POST["meta_desc"];
$vimeo = new phpVimeo(VIMEO_KEY, VIMEO_SECRET , VIMEO_ACCESS_TOKEN, VIMEO_ACCESS_SECRET);


try {
    $video_id = $vimeo->upload($file);

    if ($video_id) {        
         $_POST["flv"] = "http://vimeo.com/$video_id"; 
         @unlink("../content/videos/$filename"); 
         
         //$vimeo->call('vimeo.videos.setPrivacy', array('privacy' => 'nobody', 'video_id' => $video_id));
         $vimeo->call('vimeo.videos.setTitle', array('title' => $title, 'video_id' => $video_id));
         $vimeo->call('vimeo.videos.setDescription', array('description' => $desc, 'video_id' => $video_id));
    }
    else {
        $viderror =  "Video file did not exist!";
    }
}
catch (VimeoAPIException $e) {
    $viderror = "Encountered an API error -- code {$e->getCode()} - {$e->getMessage()}";
}

?>