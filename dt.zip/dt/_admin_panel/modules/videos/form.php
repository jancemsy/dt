<?php
$id = "";
$type = "Add";
if (isset($_GET["edit"])) {
    $id = $_GET["edit"];
    $video = new Video($id);
    if (!empty($video->id)) {
        $arr1 = $video->array;
        $arr2 = unserialize($video->params);
        $_POST = array_merge($arr1, $arr2);
        $_POST["video_embed"] = convert_to_original(serializeDecode($_POST["video_embed"]));
        $_POST["video_type"] = $arr2["video_type"];
        $time = strtotime($_POST['created_at']);
        $date = date("Y-m-d", $time);
    }
    $type = "Edit";
}
?>
<div class="box"> 
    <div class="title"> 
        <h2><?php echo $type; ?> Videos</h2> 
        <?php echo $_dahide; ?>
    </div> 
    <div class="content  forms" >     
        <?php
        if (!empty($viderror)) {
            echo $viderror;
        }
        ?>

        <form action="" method="post" onsubmit="return checkVideoForm()"   enctype="multipart/form-data"  >
            <input type="hidden" name="thumb" id="thumb" value="<?php echo $_POST['thumb']; ?>" />
            <input type="hidden" name="flv" id="flv"  value="<?php echo $_POST['flv']; ?>" />
            <input type="hidden" name="old_video_type"   value="<?php echo $_POST['video_type']; ?>" />

            <input type="hidden" name="id" value="<?php echo $id; ?>" />
            <table>
                <tr><td>Status:</td>
                     <td>
                        <select name="is_published" onchange=" $(this).val() == '1' ? $('.publish_box').show() : $('.publish_box').hide();
                                " >
                            <option value="1">Publish</option>
                            <option value="0" <?php if ($_POST["is_published"] == 0) echo "selected"; ?> >Draft</option></select>


                        <span class="publish_box" <?php if ($_POST["is_published"] == 0) {
            echo "style='display:none;'";
        } ?>  >
                            <input type="text" id="datetimepicker" name="publish_date_time" placeholder="Enter publish time"   value="<?php echo $_POST['publish_date_time']; ?>" />  
                        </span> 

                    </td></tr> 
                <tr><td>Meta Title <counter style="display:none" max="70" required="1" target="input[name=meta_title]'"></counter>:</td><td>  <input type="text" name="meta_title" class="text-input" value="<?php echo $_POST['meta_title']; ?>" /></td></tr> 
                <tr><td>Meta Desc <counter style="display:none" max="155" required="1" target="input[name=meta_desc]'"></counter>:</td><td>  <input type="text" name="meta_desc" class="text-input" value="<?php echo $_POST['meta_desc']; ?>" /></td></tr> 
                <tr><td>Meta Keywords:</td><td>  <input type="text" name="meta_keywords" class="text-input" value="<?php echo $_POST['meta_keywords']; ?>" /></td></tr> 

                <tr>
                    <td>Date:</td><td><input type="text" name="created_at" class="datepicker text-input"  value="<?php echo $date; ?>"   /></td>                        
                </tr>

                <tr><td>Title:</td><td>  <input type="text" id="title" name="title" size="68" class="text-input" value="<?php echo $_POST['title']; ?>" /></td></tr>         
                <tr><td>Description:</td><td>  <textarea id="description" name="description" cols="50" class="editor text-input" ><?php echo $_POST['description']; ?></textarea></td></tr>         
                <tr><td>Thumbnail: <br/> 641px × 387px (jpg only) </td><td>         

                        <img src="<?php echo $thumb_dest = "../content/videos/" . $_POST['thumb']; ?>" width="50" />
                        <div class="row">
                            <input type="file" size="46" id="upload_thumb" name="upload_thumb"  /> 
                        </div>

                    </td></tr>  


                <tr><td valign="top">Video: <br/> 
                    </td><td>
                        <label><input type="radio" <?php echo $_POST["video_type"] == '' || $_POST["video_type"] == 'amazon' ? 'checked="checked"' : '' ?>  name="video_type" value="amazon" /> Upload to Amazon </label> 
                        <label><input type="radio" <?php echo $_POST["video_type"] == 'youtube' ? 'checked="checked"' : '' ?> name="video_type" value="youtube"  /> Upload to Youtube </label> 
                        <label><input type="radio" <?php echo $_POST["video_type"] == 'vimeo' ? 'checked="checked"' : '' ?> name="video_type" value="vimeo" /> Upload to Vimeo </label> 
                        <label><input type="radio" <?php echo $_POST["video_type"] == 'embed' ? 'checked="checked"' : '' ?> name="video_type" value="embed"  /> Embed </label>
                        <div class="row upload_vid"  <?php echo $_POST["video_type"] == 'embed' ? "style='display:none'" : ""; ?> >
                            <?php
                            if (!empty($_POST['flv']))
                                echo "&nbsp;&nbsp;" . $_POST['flv'];
                            ?>
                            <input type="file" size="46" id="upload_flv" name="upload_flv" /> 
                        </div>                      
                        <textarea id="video_embed" name="video_embed" cols="55" rows="6"   <?php echo $_POST["video_type"] != 'embed' ? "style='display:none'" : ""; ?>   ><?php echo $_POST['video_embed']; ?></textarea>
                    </td></tr>   

                <tr><td>Featured?</td><td>
                        <label><input name="featured" type="radio" value="1" <?php echo $_POST['featured'] == '1' ? 'checked' : ''; ?>  />Yes</label>  
                        <label><input type="radio" name="featured" value="0"   <?php echo $_POST['featured'] == '0' ? 'checked' : ''; ?> />No</label> </td></tr>
                <tr>
                    <td>Category: </td><td>
                        <?php
                        $list = CategoryVideo::getList();

                        foreach ($list as $item) {
                            if (search("-{$item["id"]}-", $_POST["categories"])) {
                                echo "<label><input type='checkbox' checked=checked name='category[]' value='" . $item["id"] . "' /> " . $item["name"] . " </label> <br/>";
                            } else {
                                echo "<label><input type='checkbox' name='category[]' value='" . $item["id"] . "' /> " . $item["name"] . " </label> <br/>";
                            }
                        }
                        ?> 
                    </td></tr> 


            </table>


            <div class="row buttons">                      
                <button type="button"onclick="location.href = '?'"><span>Back</span></button>                                                
                <button type="submit"  name="add_video"><span>Save</span></button>                                                
            </div>



        </form>

        <script>
            $(function() {
                $('#datetimepicker').datetimepicker();
                $('input[name=video_type]').click(function() {
                    if ($(this).val() == 'embed') {
                        $(".upload_vid").hide();
                        $("#video_embed").show();
                    } else {
                        $(".upload_vid").show();
                        $("#video_embed").hide();
                    }
                });
            });
            initMCET('.editor');
            function checkVideoForm() {
                var errors = "";
                var thumb = $("#upload_thumb").val();

                if (thumb == "") {
                    thumb = $("#thumb").val();
                }

                if ($("#title").val() == "") {
                    errors += "Invalid title \n";
                }

                if (thumb == "") {
                    errors += "Invalid Thumbnail \n";
                } else if (thumb.lastIndexOf(".jpg") < 1) {
                    $("#upload_thumb").val("");
                    errors += "Invalid Thumbnail Format \n";
                }

                if ($("#upload_flv").val() == "" && $("#flv").val() == "" && $("#video_embed").val() == "") {
                    errors += "Invalid Video \n";
                }

                if ($("#upload_flv").val() != "") {
                    var flv = $("#upload_flv").val();
                    if (flv.lastIndexOf(".flv") < 1) {
                        errors += "Make sure to upload FLV video. \n";
                        $("#upload_flv").val("");
                    }
                }




                if (errors != "") {
                    alert(errors);
                    return false;
                } else {
                    return true;
                }
            }

        </script>
    </div>
</div>    
