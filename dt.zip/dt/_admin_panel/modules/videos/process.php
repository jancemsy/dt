<?php

if (isset($_POST['crop_images'])) {  //ajax call   
    $_SESSION["pending_crop"] = "";
    $width = 641;
    $height = 387;
    $quality = 100;

    $size = count($_POST['h']);

    for ($i = 0; $i < $size; $i++) {
        $des_h = $_POST['h'][$i];
        $des_w = $_POST['w'][$i];
        $source_x = $_POST['x'][$i];
        $source_y = $_POST['y'][$i];
        $src = $_POST['thumb'][$i];

        if (!empty($des_h) && !empty($src)) {
            $filename = end(explode("/", $src));
            $filename = str_replace("-orig", "-med", $filename);
            $destination = "../content/videos/$filename";
            $thumb_dest = "../content/videos/" . str_replace("-med", "", $filename);

            $ext = strtolower(end(explode(".", $src)));

            switch ($ext) {
                case "gif":
                    $img_r = imagecreatefromgif($src);
                    break;
                case "png":
                    $img_r = imagecreatefrompng($src);
                    break;
                default:
                    $img_r = imagecreatefromjpeg($src);
                    break;
            }

            $dst_r = ImageCreateTrueColor($width, $height);
            imagecopyresampled($dst_r, $img_r, 0, 0, $source_x, $source_y, $width, $height, $des_w, $des_h);

            @unlink($destination);  //delete the old one
            switch ($ext) {
                case "gif":
                    imagegif($dst_r, $destination);
                    break;
                case "png":
                    imagepng($dst_r, $destination);
                    break;
                default:
                    imagejpeg($dst_r, $destination, $quality);
                    break;
            }

            @unlink($src); //unlink original                      
            @createThumb($destination, $thumb_dest, 162, 94);
        }
    }
    die("1");
}


if (isset($_GET["delete_video"])) {
    $id = $_GET["delete_video"];
    $video = new Video($id);
    $post = unserialize($video->params);
    @unlink("../content/videos/" . $post["thumb"]);
    @unlink("../content/videos/" . $post["flv"]);
    Video::delete($id);
    jumpto("videos.php");
}

if (isset($_GET["catdelete"])) {
    $id = $_GET["catdelete"];
    CategoryVideo::delete($id);
    jumpto("videos.php?cat=1");
}

if (isset($_POST["save_category"])) {
    $name = clean_quote($_POST["name"]);
    $type = clean_quote($_POST["type"]);
    $description = clean_quote($_POST["description"]);
    $short_desc = clean_quote($_POST["short_desc"]);

    $params = array("num" => $_POST["num"], "description" => $description,
        "headline" => $_POST["headline"],
        "meta_title" => $_POST["meta_title"],
        "meta_desc" => $_POST["meta_desc"],
        "meta_keywords" => $_POST["meta_keywords"],
        "short_desc" => $short_desc,
        "name" => $name, "type" => $type);


    if ($_POST["id"] != "") {
        $params["id"] = $_POST["id"];
        CategoryVideo::update($params);
    } else {
        CategoryVideo::add($params);
    }
    jumpto("videos.php?cat=1");
}


if (isset($_POST["add_video"])) {

    $pending_crop = array();
    if (isset($_FILES["upload_thumb"]) && $_FILES['upload_thumb']["name"] != "") {
        if (!empty($_POST["thumb"]))
            @unlink("../content/videos/" . $_POST["thumb"]);
        $name = $_FILES['upload_thumb']["name"];
        $ext = end(explode(".", $name));
        $time = time();
        $filename = "$time.$ext";
        $thumb_dest = "../content/videos/$filename";
        $orig_dest = "../content/videos/$time-orig.$ext";
        $med_dest = "../content/videos/$time-med.$ext";


        move_uploaded_file($_FILES["upload_thumb"]["tmp_name"], $orig_dest);
        @createThumb($orig_dest, $thumb_dest, 162, 94);
        @createThumb($orig_dest, $med_dest, 641, 387);
        $pending_crop[] = $orig_dest;
        $_POST["thumb"] = $filename;
    }

    if (isset($_FILES["upload_flv"]) && $_FILES['upload_flv']["name"] != "") {
        if (!empty($_POST["flv"]))
            @unlink("../content/videos/" . $_POST["flv"]);
        $name = $_FILES['upload_flv']["name"];
        $ext = end(explode(".", $name));
        $time = time();
        $filename = "flv$time.$ext";
        $thumb_dest = "../content/videos/$filename";
        move_uploaded_file($_FILES["upload_flv"]["tmp_name"], $thumb_dest);
        $_POST["flv"] = $filename;


        if ($_POST["video_type"] == "amazon") {             
            $_POST["flv"] = upload_s3($thumb_dest);
        } else if ($_POST["video_type"] == "youtube") {
            include("_youtube.php");
        } else if ($_POST["video_type"] == "vimeo") {
            include("_vimeo.php");
        }
    } else if (( $_POST["old_video_type"] != $_POST["video_type"] && !empty($_POST["flv"]) ) || ( $_POST["video_type"] == "embed" && empty($_POST["video_embed"]) && !empty($_POST["flv"]) )) { //if nothing is uploaded lets use the old video path
        $_POST["video_type"] = $_POST["old_video_type"];
    }

    $video_embed = serializeEncode($_POST["video_embed"]);
    $featured = intval($_POST["featured"]);


    $csize = count($_POST["category"]);
    $categories = "";
    for ($i = 0; $i <= $csize; $i++) {
        if ($_POST["category"][$i] != "") {
            $categories .= "-" . $_POST["category"][$i] . "-";
        }
    }


    $params = array("params" =>
        addslashes(serialize(array("video_embed" => $video_embed,
                    "flv" => $_POST["flv"],
                    "featured" => $featured,
                    "thumb" => $_POST["thumb"],
                    "video_type" => $_POST["video_type"])))
        ,
          "publish_date_time" => clean_data($_POST["publish_date_time"]),
        "created_at" => addslashes($_POST["created_at"]),
        "categories" => $categories,
        "featured" => $featured,
        "title" => addslashes($_POST["title"]),
        "description" => clean_quote(addslashes($_POST["description"])),
        "id" => $_POST["id"],
        "meta_title" => addslashes($_POST["meta_title"]),
        "meta_desc" => addslashes($_POST["meta_desc"]),
        "meta_keywords" => addslashes($_POST["meta_keywords"]),
        "is_published" => $_POST["is_published"]
    );


    
    
    if ($_POST["id"] != "") {
        $id = $_POST["id"];
        Video::update($params);
    } else {
        $id = Video::add($params);
    }
    

    if (count($pending_crop) > 0) {
        $_SESSION["pending_crop"] = serialize($pending_crop);
        jumpto("videos.php?crop=1");
    }

    jumpto("videos.php");
}
?> 