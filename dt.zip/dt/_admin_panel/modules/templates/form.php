
<style type="text/css">
    .inputtxt{ 
          width: 597px;
    }
</style>


 
<?php

if( isset($_GET["edit"]) ){ 
      $id = $_GET["edit"];    
      $sp = new StaticPages($id); 
?>
           <div class="box"> 
            <div class="title"> 
                    <h2>Edit Email Template</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms"> 
<form action="" method="post">  
    
            <input type="hidden" name="id" value="<?php echo $sp->id;  ?>" />
            <table>
                <tr><td>Name: </td><td> <input class="inputtxt" type="text" name="name" value="<?php echo $sp->name; ?>" />  </td></tr>
                <tr><td>Subject: </td><td>  <input class="inputtxt" type="text" name="subject" value="<?php echo $sp->subject; ?>" />  </td></tr>
                <tr><td>Body:  </td><td> <textarea class="inputtxt" rows="25" name="description"><?php echo $sp->description; ?></textarea> </td></tr>
                <tr><td></td><td colspan="2">
                        <input type="button" onclick="location.href='?'" value="Cancel" />
                        <input type="submit" name="save_template" value="Save" />  </td></tr>
            </table> 
<?php }else{ ?> 
           <div class="box"> 
            <div class="title"> 
                    <h2>Add Template</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms"> 
<form action="" method="post">  
            <table>
                <tr><td>Name: </td><td> <input class="inputtxt" type="text" name="name" />  </td></tr>
                <tr><td>Subject: </td><td>  <input class="inputtxt" type="text" name="subject" />  </td></tr>
                <tr><td>Body:  </td><td> <textarea class="inputtxt" rows="25"  name="description"></textarea> </td></tr>
                <tr><td></td><td colspan="2">
                        
                        
                 <div class="row buttons"> 
                   <button type="button" onclick="location.href='?'" ><span>Cancel</span></button>                                                
                   <button type="submit" name="save_template"><span>Save</span></button>                                                
                </div>
     
                     </td></tr>
            </table>
<?php } ?>

  </form>


<script>
  initMCE();
</script>  
             

  </div>        
</div>    
    