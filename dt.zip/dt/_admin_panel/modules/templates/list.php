 


<div class="box"> 
        <div class="title"> 
                <h2>Email Notification Templates</h2> 
                <?php echo $_dahide; ?>
        </div> 
        <div class="content pages"> 
            
<a href="?new=1" class="button">New Template</a></p>   
 <table cellspacing="0" class="table" width="100%">
    <thead>  
    <tr class="tr-header">
        <td>ID</td>
        <td width="200">Name</td> 
        <td  width="200">Subject</td>
        <td>Body</td>     
        <td width="70">Action</td> 
    </tr>
    </thead> 
    <?php
        $list = StaticPages::getList("email"); 
        foreach($list as $item){
            $button = "<a href='?delete={$item["id"]}'  class='delete-btn' >$_dadelete</a> 
            <a href='?edit={$item["id"]}'>$_daedit</a> ";
             
            
             $text =  string_cut(strip_tags($item["description"]),250);
            echo "<tr> 
                      <td>{$item["id"]}</td>
                      <td>{$item["name"]}</td>
                      <td>{$item["subject"]}</td>
                      <td>$text</td>     
                      <td>$button</td> 
                  </tr>";
        }   
    ?>
 </table>
        </div>
</div>    