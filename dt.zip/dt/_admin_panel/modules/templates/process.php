<?php



if( isset($_POST["save_template"]) ){    
    if($_POST["id"] != ""){
         StaticPages::update(array("id" => $_POST["id"], 
                           "name" => addslashes($_POST["name"] ), 
                           "subject" =>  addslashes($_POST["subject"] ), 
                           "description" => addslashes($_POST["description"]) ),"email");     
    }else{
         StaticPages::add(array("name" => addslashes($_POST["name"]),
                           "subject" => addslashes($_POST["subject"]),
                           "description" => addslashes($_POST["description"]) ) ,"email");    
    }    
    jumpto("?");
}


if( isset($_GET["delete"]) ){
    $id =  $_GET["delete"];
    StaticPages::delete($id);    
    jumpto("?");
}




?>