<?php
$id = "";
if(isset($_GET["edit"])){
    $id = $_GET["edit"];
    $admin = new Admin($id);
    if( !empty($admin->adminID) ){     
        $_POST = $admin->array;
    }
}  
?>
<div class="box"> 
            <div class="title"> 
                    <h2>Create Admin</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms"> 
        
        <?php
        if($_GET["error"]) echo '<div class="message red">'.$_GET["error"].'</div>'; 
        ?>
<form action="" method="post" onsubmit=""  > 
    <input type="hidden" name="id" value="<?php echo $_POST["adminID"]; ?>" />
    <table>
      <tr><td>Username:</td><td><input type="text" name="username" class="text-input" value="<?php echo $_POST['username']; ?>" /></td></tr> 
      <tr><td>Password:</td><td><input type="text" name="password" class="text-input" value="" />
            <?php if(isset($_GET["edit"])) echo "Leave this blank if not to change"; ?>
          </td></tr>       
      <tr><td>Name:</td><td><input type="text" name="name" class="text-input" value="<?php echo $_POST['name']; ?>" /></td></tr> 
      <tr><td>Email:</td><td><input type="text" name="email" class="text-input" value="<?php echo $_POST['email']; ?>" /></td></tr> 
    </table>       
    
        <div class="row buttons"> 
                   <button type="button" onclick="location.href='?'" ><span>Cancel</span></button>                                                
                   <button type="submit" name="add"><span>Save</span></button>                                                
                </div>
     
</form> 
    </div>
</div>        