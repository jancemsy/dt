<?php 
$list = Admin::getList(); 



?> 

<div class="box"> 
        <div class="title"> 
                <h2>User Admins</h2> 
                <?php echo $_dahide; ?>
        </div> 
        <div class="content pages"> 

<p><a href="?new=1" class="button">New Admin</a></p>  

 <table cellspacing="0" class="table">
    <thead>  
    <tr class="tr-header">
        <td>ID</td>
        <td>Username</td> 
        <td>Name</td>
        <td>Email</td>        
        <td>Action</td> 
    </tr>
    </thead> 
<?php 

       
       $output = "";
       $i = 0;
       foreach($list as $item){
         $i++;
         $category = $_category[$item["category"]];
         $specials = $item["special"] == 1 ? "special" : "";
         
         $button = "";
         if($item["username"] == "admin"){             
         }else if($Admin->is_super_user ) {                      
               $button = " <a href='?delete={$item["adminID"]}' class='delete-btn'>$_dadelete</a>
                    <a href='?edit={$item["adminID"]}'>$_daedit</a>";
          
         }
         
         $tr_class = $i%2 == 0 ? "tr-odd" : "tr-even";                  
         $output .= "<tr>
                <td>{$item["adminID"]}</td>
                <td>{$item["username"]}</td>  
                <td>{$item["name"]}</td>
                <td>{$item["email"]}</td>                
                <td>$button</td></tr>"; 
       }
       
       echo $output; 
?>
</table>        </div>
</div>          