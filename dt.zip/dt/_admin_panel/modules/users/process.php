<?php
  
if( isset($_GET["delete"]) ){ 
    $id = $_GET["delete"];
    Admin::delete($id);      
    jumpto("users.php");
}



if( isset($_POST["change_password"]) ){               
      if( !Admin::checkValidPassword($_POST["current_password"])  ){
         jumpto("users.php?cpassword=1&error=".urlencode("Current Password is invalid!!!"));    
      }else if( empty($_POST["password"]) ){
         jumpto("users.php?cpassword=1&error=".urlencode("Password cannot be empty!"));   
      }else if($_POST["password"] != $_POST["password2"] ){
         jumpto("users.php?cpassword=1&error=".urlencode("Confirm Password did not match!!!"));  
      }   
      
      
      $params = array();           
      $params["password"] = md5($_POST["password"]);         
      $params["adminID"] = $Admin->adminID;
      Admin::update($params);       
      
      jumpto("users.php?cpassword=1&success=".urlencode("Password changed!!!"));  
              
}

if( isset($_POST["add"]) ){ 
    
      if( trim($_POST["username"]) == 'admin'  ){          
          jumpto("users.php?error=".urlencode("Invalid Username!!!")); 
      }
      
      $params = array(
                     "username" => trim($_POST["username"]),
                     "name" => addslashes($_POST["name"]), 
                     "email" => addslashes($_POST["email"])
         );
     
     if(!empty($_POST["password"])){
         $params["password"] = md5($_POST["password"]);
     }
    
     if($_POST["id"] != ""){
        $params["adminID"] = $_POST["id"];
        Admin::update($params); 
     }else{
        Admin::add($params); 
     }
     
     jumpto("users.php"); 
}
 


if( isset($_GET["delete_story"]) ){ 
    $id = $_GET["ID"];
    $mainurl = "users.php?story=1&ID=$id";
    $id = $_GET["delete_story"];
    $story = new Story($id); 
    @unlink("../".$diet->thumb);     
    $story->delete($id);
    jumpto($mainurl);
}

  
if(  isset($_POST["save_story"])){ 
    $id = $_GET["ID"];
    $mainurl = "users.php?story=1&ID=$id";
     if(isset($_FILES["upload"]) && $_FILES['upload']["name"] != ""){
        if( !empty($_POST["thumb"]) ) @unlink("../".$_POST["thumb"]);
        $name = $_FILES['upload']["name"];
        $ext   = end(explode(".",$name));
        $time = time();                 
        $filename = "$time.$ext";
        $thumb_dest = "../content/stories/$filename";
        move_uploaded_file($_FILES["upload"]["tmp_name"], $thumb_dest );         
        createThumb($thumb_dest,$thumb_dest,126,103);          
        $_POST["thumb"] = "content/stories/$filename";
     }
     
     $array = array();
     foreach($_POST as $field => $value){
          $array[$field] = addslashes($value);     
     }
      
    $params = $array;
    $params["dietID"] = $id;  
    if( isset($_GET["edit"]) ){           
       Story::update($params);    
    }else{
       Story::add($params);    
    }               
    jumpto($mainurl);
 }


 
  if($_GET["dt"] != ""){  
      $id = $_GET["ID"]; 
      Gallery::delete($_GET["dt"]);
      jumpto("users.php?gallery=1&ID=$id");
  }
  
  if( isset($_POST["save_picture"])  ){ 
       $id = $_GET["ID"]; 
       $caption = addslashes($_POST["caption"]);      
       $name = $_FILES['upload']["name"];
       $file = "";
       
       if(!empty($name)){
          $ext   = end(explode(".",$name));
          $time = time();                 
          $filename = "$time.$ext";
          $thumb_dest = "../content/gallery/$filename";
          move_uploaded_file($_FILES["upload"]["tmp_name"], $thumb_dest );         
          createThumb($thumb_dest,$thumb_dest,600,400);          
          $file = "content/gallery/$filename";
          
          if($_POST["old_pic"] != "" && $_GET["gid"] != ""){ //edit and we should delete the old pic here
              @unlink(ABSPATH.$_POST["old_pic"]);
          }
       }
       
       
       if($_GET["gid"] != ""){ //edit           
          Gallery::update(array(
           "id" => $_GET["gid"],
           "file" => $file,
           "caption" => $caption           
          ));  
       }else{ //add
          Gallery::add(array(
           "dietID" => $id,
           "file" => $file,
           "caption" => $caption           
          )); 
       }
       
       jumpto("users.php?gallery=1&ID=$id");
  } 
  
?>