<div class="box"> 
            <div class="title"> 
                    <h2>Change Password</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms"> 
  <?php
        if($_GET["error"]) echo '<div class="message red">'.$_GET["error"].'</div>'; 
        
        if($_GET["success"]) echo '<div class="message blue">'.$_GET["success"].'</div>'; 
        ?>
<form action="users.php?cpassword=1" method="post"  > 
    <input type="hidden" name="id" value="<?php echo $_POST["adminID"]; ?>" />
    <table>
      <tr><td>Current Password:</td><td><input type="password" name="current_password" class="text-input" value="" /></td></tr> 
      <tr><td>Password:</td><td><input type="password" name="password" class="text-input" value="" /></td></tr>       
      <tr><td>Confirm Password:</td><td><input type="password" name="password2" class="text-input" value="" /></td></tr>             
    </table>       
     
     
                <div class="row buttons"> 
                   <button type="button" onclick="location.href='?'" ><span>Cancel</span></button>                                                
                   <button type="submit" name="change_password"><span>Save</span></button>                                                
                </div>
              
</form> 

    </div>
</div>            