<?php
 

$id = $_GET["ID"];
$mainurl = "diets.php?story=1&ID=$id";

if( empty($id) ){
    die("invalid Diet ID!!");
}

 
 
 if(isset($_GET["edit"])){
     $story =  new Story($_GET["edit"]);
     $_POST = $story->array; 
 } 
 
 
?>
 <div class="box"> 
        <div class="title"> 
                <h2><?php echo $title; ?></h2> 
                <?php echo $_dahide; ?>
        </div> 
         <div class="content  forms"> 
                <form action="" method="post"  enctype="multipart/form-data">
                    <input type="hidden" name="storyID" value="<?php echo $_POST["id"]?>" />
                    <input type="hidden" name="thumb" value="<?php echo $_POST["thumb"]?>" />
                    <input type="hidden" name="thumb2" value="<?php echo $_POST["thumb2"]?>" />

                 <table class="table2" > 
                       <tr ><td> Name:</td>
                        <td>  
                            <input size="55" type="text" name="name" value="<?php echo $_POST["name"];?>" />      
                        </td>       
                    </tr>        

                    <tr ><td> Location:</td>
                        <td>  
                            <input size="55" type="text" name="location" value="<?php echo $_POST["location"];?>" />      
                        </td>       
                    </tr>        

                    <tr><td>Story Summary: <br/> 1-2 paragraphs</td>
                        <td>  
                            <textarea name="comment" cols="37"><?php echo $_POST["comment"];?></textarea>
                        </td>       
                    </tr>        



                       <tr ><td> Age:</td>
                        <td>  
                            <input size="55" type="text" name="age" value="<?php echo $_POST["age"];?>" />      
                        </td>       
                    </tr>    

                      <tr ><td> Height:</td>
                        <td>  
                            <input size="55" type="text" name="height" value="<?php echo $_POST["height"];?>" />      
                        </td>       
                    </tr>  

                    <tr ><td> Was:</td>
                        <td>  
                            <input size="55" type="text" name="was" value="<?php echo $_POST["was"];?>" />      
                        </td>       
                    </tr>  


                    <tr ><td> Lost:</td>
                        <td>  
                            <input size="55" type="text" name="lost" value="<?php echo $_POST["lost"];?>" />      
                        </td>       
                    </tr>  


                    <tr ><td> Now:</td>
                        <td>  
                            <input size="55" type="text" name="now" value="<?php echo $_POST["now"];?>" />      
                        </td>       
                    </tr>  


                    <tr ><td> Goal:</td>
                        <td>  
                            <input size="55" type="text" name="goal" value="<?php echo $_POST["goal"];?>" />      
                        </td>       
                    </tr>   

                    <tr><td>Thumbnail (before): <br/>  85px × 129px JPG only:</td>
                            <td>
                                 <div  class="row">    
                                    <input type="file"    name="upload"  />                            
                                    <?php if( isset($_GET["edit"]) ){                                            
                                        echo " <br/> <img src='".PATH."{$_POST["thumb"]}'   width='85' />";                    
                                    }
                                ?></div> 
                                
                            </td></tr> 
                    <tr><td>Thumbnail (after): <br/>  85px × 129px JPG only:</td>
                            <td>
                                 <div  class="row">    
                                    <input type="file"    name="upload2"  />                            
                                    <?php if( isset($_GET["edit"]) ){                                            
                                        echo " <br/> <img src='".PATH."{$_POST["thumb2"]}'   width='85' />";                    
                                    }
                                ?></div>
                                
                                
                            </td></tr>

                </table>

                   <?php if( isset($_GET["edit"]) ) { ?><input type="button"   onClick=" window.location.href='<?php echo $mainurl; ?>'; " value="Cancel" />  <?php } ?>  
                <input type="submit" name="save_story" value="Save"/>
                </form>

                <br/><br/>

                <h2>Stories</h2>

                <table cellspacing="0" class="table">
                    <tr class="tr-header">
                        <td width="200">Name</td><td width="200">Location</td><td width="200">Story</td><td></td><td></td></tr>
                <?php 
                   $list = Story::getList($id); 
                   $output = "";

                   foreach($list as $item){

                       $thumb = "<img src='".PATH."{$item["thumb"]}'   width='100' />";
                       $info = "Age: {$item['age']}, Height: {$item['height']}, 
                                Was: {$item['was']}, Lost: {$item['lost']},
                                Now: {$item['now']}, Goal: {$item['goal']} ";

                       $buttons = "<a href='diets.php?story=1&ID=$id&delete_story={$item["id"]}' class='delete-btn'>delete</a> /
                       <a href='diets.php?story=1&ID=$id&edit={$item["id"]}'>edit</a>"; 

                       
                       $item["comment"] = string_cut(strip_tags($item["comment"]),200);
                       $output .= "<tr><td>{$item["name"]}<br/>  $thumb </td>
                                       <td>{$item["location"]}</td>
                                       <td>{$item["comment"]}</td>
                                       <td>$info</td>
                                       <td>$buttons</td></tr>";
                   }

                   echo $output;
                ?>
                </table>
        </div>
</div>     

<script> initMCE();
</script>