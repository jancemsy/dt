<?php

$category = "diet sidebar";

/*
 *  <tr><td>Display At:</td><td> 
 * <select name="category">
 * <option>diet sidebar</option>
 * <option>fitness sidebar</option>
 * <option>article sidebar</option>
 * <option>video sidebar</option>
 * <option>recipe sidebar</option></select> </td></tr>
 */

if( isset($_GET["delete_ad"])) {     
    $id = $_GET["delete_ad"];
    $ad = new Ads($id);
    if( !empty($ad->id ) ){
      
      $thumb = $ad->thumb;
      
      if(!empty($thumb)){
        $path = "../";
        $ext = end(explode(".",$thumb));
        $orig = $path.str_replace(".".$ext , "-orig.".$ext,$thumb);
        $thumb = $path.$thumb;
        @unlink($thumb);
        @unlink($orig);
      }
      
      $ad->delete($id);    
      jumpto("?ads=1",1);
    }
    
}

if( isset($_POST["save_ads"])) {     
     $path = "../content/ads/";     
     if(!file_exists($path)){  mkdir($path); }
     
     $w = 0; $h = 0;
     switch($_POST["size"]){
            case "120x600":  $w = 120; $h = 600; break;
            case "160x600":  $w = 160; $h = 600; break;
            case "200x200":  $w = 200; $h = 200; break;
            case "250x250":  $w = 250; $h = 250; break;            
     }
         
        
     if(isset($_FILES["upload"]) && $_FILES['upload']["name"] != ""){
        if( !empty($_POST["thumb"]) ){            
            $thumb = $_POST["thumb"];
            $ext = end(explode(".",$thumb));
            $orig = str_replace(".".$ext , "-orig.".$ext,$thumb);
            @unlink("../".$thumb);
            @unlink("../".$orig);
        }
        $name = $_FILES['upload']["name"];
        $ext   = end(explode(".",$name));
        $time = time();                 
        $filename = "$time.$ext";
        
        $thumb_orig = $path."$time-orig.$ext";
        $thumb_dest = $path.$filename;
               
        move_uploaded_file($_FILES["upload"]["tmp_name"], $thumb_orig );         
        
        @createThumb($thumb_orig,$thumb_dest,$w,$h);                          
        $_POST["thumb"] = "content/ads/$filename";
     }else if( $_POST["id"] != "" ){
         $ad = new Ads($_POST["id"]);
         if($ad->size != $_POST["size"] && $_POST["type"] == "image"){
             $thumb = $ad->thumb;
             $dest = "../".$thumb;
             $ext = end(explode(".",$thumb));
             $orig = "../".str_replace(".".$ext , "-orig.".$ext,$thumb);                              
             @createThumb($orig,$dest,$w,$h);                                                    
         }
     }
     
     
     
     
     $params = array("name" => $_POST["name"],"type" => $_POST["type"],
                     "category" => $category,"code" => $_POST["code"],
                     "thumb" => $_POST["thumb"],"size" => $_POST["size"],
                     "text_title" => $_POST["text_title"], 
                     "text_desc1" => $_POST["text_desc1"],
                     "text_desc2" => $_POST["text_desc2"],
                     "text_display_url" => $_POST["text_display_url"], 
                     "destination" => $_POST["destination"] );     
          
     
     if( !empty($_POST["id"]) ){
         $params["id"] = $_POST["id"];
         Ads::update($params);
     }else{
         Ads::add($params);    
     }
     
     jumpto("?ads=1",1);
               
 }
              
              


?>
<div class="box"> 
        <div class="title"> 
                <h2><?php echo $title; ?></h2> 
                <?php echo $_dahide; ?>
        </div> 
    
       
        <?php if($_GET["new"] == 1 || isset($_GET["edit_ad"])){
            
            if(isset($_GET["edit_ad"]) ){
                $ad = new Ads($_GET["edit_ad"]);
                $_POST = $ad->array;                
            }
             
            ?>
          <div class="content forms">               
           <form action="" method="post"  enctype="multipart/form-data"   >  
               <input type="hidden" name="thumb" value="<?PHP echo $_POST["thumb"]; ?>" />
               <input type="hidden" name="id" value="<?PHP echo $_POST["id"]; ?>" />
               
               <table>
                <tr><td>Name:</td><td> <input type="text" name="name" value="<?PHP echo $_POST["name"]; ?>"  /></td></tr>
                <tr><td>Type:</td><td> <select name="type"><option>code</option><option>text</option><option>image</option></select> </td></tr>              
                <tr class="code-tr tr-hide"><td>Code:</td><td> <textarea name="code"><?PHP echo $_POST["code"]; ?></textarea></td></tr>
                <tr class="image-tr tr-hide" ><td>Thumbnail: (jpg only)</td><td><div  class="row"><input type="file" size="46"  name="upload"  /></div></td></tr>
                <tr class="image-tr tr-hide"><td>Ad Size:</td><td><select name="size"><option>120x600</option><option>160x600</option><option>200x200</option><option>250x250</option></select>    </td></tr>
                <tr class="text-tr tr-hide"><td>Title:</td><td> <input  name="text_title" type="text" value="<?PHP echo $_POST["text_title"]; ?>" maxlength="25" /> 25 max chars</td></tr>
                <tr class="text-tr tr-hide"><td>Line 1:</td><td> <input  name="text_desc1" type="text" value="<?PHP echo $_POST["text_desc1"]; ?>" maxlength="35" /> 35 max chars</td></tr>
                <tr class="text-tr tr-hide"><td>Line 2:</td><td> <input  name="text_desc2" type="text" value="<?PHP echo $_POST["text_desc2"]; ?>" maxlength="35" /> 35 max chars</td></tr>
                <tr class="text-tr tr-hide"><td>Display URL:</td><td> <input  name="text_display_url" type="text" maxlength="35" value="<?PHP echo $_POST["text_display_url"]; ?>" /> 35 max chars</td></tr>
                <tr class="text-image-tr tr-hide"><td>Destination:</td><td> <input  name="destination" type="text" value="<?PHP echo $_POST["destination"]; ?>" /> 255 max chars</td></tr>                                                                              
                
                <tr><td colspan="2"><div class="row buttons"> 
                      <button type="button" onclick="location.href='?ads=1'" ><span>Cancel</span></button>                                                
                      <button type="submit" name="save_ads"><span>Save</span></button>                                                
                    </div> 
                </td></tr>
               </table>                                                                                  
           </form>
           </div>    
    
    
          <script type="text/javascript">
              $(".tr-hide").hide();              
              $("select[name=type]").change(function(){                  
                  var c = $(this).val()+"-tr";
                  $(".tr-hide").hide();
                  $("."+c).show();
                  
                  if($(this).val() != "code") $(".text-image-tr").show();
                  else $(".text-image-tr").hide();
              });              
              
              <?php 
                 if(isset($_GET["edit_ad"])){ 
                     echo '$("select[name=type]").val("'.$_POST["type"].'");';
                     echo '$("select[name=size]").val("'.$_POST["size"].'");';
                 }              
              ?>
               $("select[name=type]").change();
          </script>

        <?php }else{ ?>   
           <div class="content pages">  
            <p><a href="?ads=1&new=1" class="button">New Ad</a></p>      
             <table cellspacing="0" class="table">
                <tr class="tr-header">
                    <td>ID</td>
                    <td width="200">Name</td>  
                    <td width="300">Type</td>                              
                    <td>Action</td> 
                </tr>            
                <?php 
                   $list = Ads::getList($category);                   
                   foreach($list as $item){           
                       $size = ($item["type"] == "image") ? " [".$item["size"]."]" : ""; 
                ?>                  
                <tr>
                    <td><?php echo $item["id"]; ?></td>
                    <td><?php echo $item["name"]; ?></td>
                    <td><?php echo $item["type"].$size; ?></td>                             
                    <td> 
                        <a href="?ads=1&delete_ad=<?php echo $item["id"];?>"><?php echo $_dadelete; ?></a>                    
                         <a href="?ads=1&edit_ad=<?php echo $item["id"];?>"><?php echo $_daedit; ?></a> 
                    </td> 
                </tr>            
                <?php } ?>
            </table>        
            </div>    
            <?php } ?>            
        
</div>     

