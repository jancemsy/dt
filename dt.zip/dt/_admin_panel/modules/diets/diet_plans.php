<?php 
  $id = $_GET["ID"];  
  
  if( !empty($_GET["edit_plan"]) ){ 
      $dp = new DietPlans($_GET["edit_plan"]); 
      $_POST = $dp->array;  
  }
  
  
  $diet  = new Diet($_GET["ID"]);
  $dietTitle = $diet->name;
  
?> 
<div class="box"> 
            <div class="title"> 
                    <h2>Diet Plans for <?php echo $dietTitle; ?> :</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms">
        
        <h2>Add/Update Diet</h2>
        <form action="" method="post">
            <input type="hidden" name="dpi" value="<?php echo $_POST["id"]; ?>" />
            <table><tr><td>Diet Plan:</td><td> <input type="text" size="50" name="name" value="<?php echo $_POST["name"]; ?>" /> </td></tr>
              <tr><td>Standard Price: </td><td> <input type="text" size="50" name="standard_price" value="<?php echo $_POST["standard_price"]; ?>" /> </td></tr>	 
              <tr><td>Promotional Discount:</td><td> <input type="text" size="50" name="discount" value="<?php echo $_POST["discount"]; ?>" /> </td></tr>
              <tr><td>Coupon Code:</td><td> <input type="text" size="50" name="code"  value="<?php echo $_POST["code"]; ?>"/> </td></tr>
              <tr><td>Total Price: </td><td> <input type="text"  size="50" name="total_price" value="<?php echo $_POST["total_price"]; ?>"/> </td></tr>
              <tr><td>Description: </td><td> <textarea name="description"><?php echo $_POST["description"]; ?></textarea> </td></tr>
              <tr><td>Affiliate Link: </td><td> <input type="text" size="50" name="link"  value="<?php echo $_POST["link"]; ?>"/> </td></tr>
            </table> 
            
            <input type="submit" name="save_diet_plan" value="save diet plan" />
        </form>  
        
        <br/><br/> <br/><br/><br/>
        
          <table cellspacing="0" cellpadding="10" class="table">
                <tr class="tr-header">
                <td width="20">#</td>
                <td width="300">Diet Plan</td>
                <td>Standard Price</td>
                <td>Discount</td>
                <td>Coupon</td>
                <td>Total Price</td>
                <td>Action</td></tr>
            <?php
                $list = DietPlans::getList($_GET["ID"]);
                foreach($list as $item){                    
                    
                    $edit_btn = "<a href='diets.php?plans=1&ID={$_GET["ID"]}&edit_plan={$item['id']}'>edit</a>";
                    $delete_btn = "<a href='diets.php?plans=1&ID={$_GET["ID"]}&delete_plan={$item['id']}'>delete</a>";
                     echo "<tr>
                            <td>{$item['id']}</td>
                            <td>{$item['name']}</td> 
                            <td>{$item['standard_price']}</td>
                            <td>{$item['discount']}</td>
                            <td>{$item['code']}</td>
                            <td>{$item['total_price']}</td>
                            <td>$delete_btn / $edit_btn</td>
                         </tr>";
                }             
            ?>
            </table>
        
   </div>
    
 
    
    <div class="row buttons fixed-buttons"   > <button type="button" onclick="location.href='?edit=<?php echo $id; ?>'" ><span>&laquo; Go To Diet Form</span></button> </div>
    
    
</div>


<script>initMCE();</script>