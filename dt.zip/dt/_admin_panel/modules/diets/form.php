<?php
$id = "";
$type = "Add";
if (isset($_GET["edit"])) {
    $id = $_GET["edit"];
    $diet = new Diet($id);
    $_POST = $diet->array;
    $type = "Edit";
    $examples = unserialize($diet->examples);
    $proscons1 = unserialize($diet->proscons1);
    $proscons2 = unserialize($diet->proscons2);
    $gallery = unserialize($diet->gallery_text);
    $rating = unserialize($diet->rating_text);

    if (is_array($examples)) {
        foreach ($examples as $field => $value) {
            $examples[$field] = diet::removeformats(serializeDecode($value));
        }
        $_POST = array_merge($_POST, $examples);
    }
    if (is_array($proscons1)) {
        $_proscons1 = array();
        foreach ($proscons1 as $field => $value) {
            $_proscons1[$field] = diet::removeformats(serializeDecode($value));
        }
        //$_POST = array_merge($_POST,$proscons); 
    }

    if (is_array($proscons2)) {
        $_proscons2 = array();
        foreach ($proscons2 as $field => $value) {
            $_proscons2[$field] = diet::removeformats(serializeDecode($value));
        }
        //$_POST = array_merge($_POST,$proscons); 
    }

    if (is_array($gallery)) {
        foreach ($gallery as $field => $value) {
            $gallery[$field] = diet::removeformats(serializeDecode($value));
        }

        $_POST = array_merge($_POST, $gallery);
    }



    if (is_array($rating)) {
        foreach ($rating as $field => $value) {
            $rating[$field] = diet::removeformats(serializeDecode($value));
        }

        $_POST = array_merge($_POST, $rating);
    }
}


if (empty($_POST["overview"]))
    $_POST["overview"] = "%example_meals_include%  <br/>

%rating_include%";


$_POST['editor_header1'] = empty($_POST['editor_header1']) ? "Is the <diet name> diet right for you?" : $_POST['editor_header1'];
$_POST['editor_header2'] = empty($_POST['editor_header2']) ? "The <diet name> promise to you?" : $_POST['editor_header2'];
$_POST['editor_header3'] = empty($_POST['editor_header3']) ? "The Theory and Details Behind the <diet name> diet" : $_POST['editor_header3'];
$_POST['editor_header4'] = empty($_POST['editor_header4']) ? "What Health Care Professionals Say About the <diet name> diet" : $_POST['editor_header4'];
$_POST['editor_header5'] = empty($_POST['editor_header5']) ? "Examples of <diet name> Meals:" : $_POST['editor_header5'];
$_POST['proscons_header1'] = empty($_POST['proscons_header1']) ? "<diet name> Pros & Cons" : $_POST['proscons_header1'];
$_POST['proscons_header2'] = empty($_POST['proscons_header2']) ? "Who Should Not Use this Diet" : $_POST['proscons_header2'];
$_POST['pran_header'] = empty($_POST['pran_header']) ? "<diet name> Plan Options" : $_POST['pran_header'];

$t1 = strip_tags($_POST['gallery_text1']);
$t2 = strip_tags($_POST['gallery_text2']);
$_POST['gallery_text1'] = empty($t1) ? "<h2>Images</h2> Check out these images of the [diet name]" : $_POST['gallery_text1'];
$_POST['gallery_text2'] = empty($t2) ? "<h2>Video</h2> Some videos about the [diet name]" : $_POST['gallery_text2'];
?>


<div class="box"> 
    <div class="title"> 
        <h2><?php echo $type; ?> Diet</h2> 
        <?php echo $_dahide; ?>
    </div> 
    <div class="content  forms">
        <form action="" method="post" onsubmit="return saveThisForm()"   enctype="multipart/form-data" class="diet-form" id="category_form" >
            <input type="hidden" name="id" value="<?php echo $id; ?>" />
            <input type="hidden" name="logo_med" value="<?php echo $_POST["logo_med"]; ?>" />
            <input type="hidden" name="logo_large" value="<?php echo $_POST["logo_large"]; ?>" />
            <input type="hidden" name="logo_small" value="<?php echo $_POST["logo_small"]; ?>" />

            <table>
                <tr><td>Status:</td>
                    <td>
                        <select name="is_published" onchange=" $(this).val() == '1' ? $('.publish_box').show() : $('.publish_box').hide();
                                " >
                            <option value="1">Publish</option>
                            <option value="0" <?php if ($_POST["is_published"] == 0) echo "selected"; ?> >Draft</option></select>


                        <span class="publish_box" <?php if ($_POST["is_published"] == 0) {
            echo "style='display:none;'";
        } ?>  >
                            <input type="text" id="datetimepicker" name="publish_date_time" placeholder="Enter publish time"   value="<?php echo $_POST['publish_date_time']; ?>" />  
                        </span> 

                    </td></tr> 




                <tr><td>Meta Title <counter style="display:none" max="70" required="1" target="input[name=meta_title]'"></counter>:</td><td>  <input type="text" name="meta_title" class="text-input" value="<?php echo $_POST['meta_title']; ?>" /></td></tr> 
                <tr><td>Meta Desc  <counter style="display:none" max="155" required="1" target="input[name=meta_desc]'"></counter>:</td><td>  <input type="text" name="meta_desc" class="text-input" value="<?php echo $_POST['meta_desc']; ?>" /></td></tr> 
                <tr><td>Meta Keywords:</td><td>  <input type="text" name="meta_keywords" class="text-input" value="<?php echo $_POST['meta_keywords']; ?>" /></td></tr> 


                <tr><td>Diet Name/Title:</td><td>  <input type="text" name="name" class="text-input" value="<?php echo $_POST['name']; ?>" /></td></tr>         
                <tr><td>Sub Heading:</td>
                    <td>  <input type="text" name="sub_heading" class="text-input" value="<?php echo $_POST['sub_heading']; ?>" />
                        <br/> (can be used at home page featured diet)
                    </td></tr> 


                <tr><td>Short Description:</td><td><textarea name="short_desc"  class="text-input mceEditor" ><?php echo $_POST['short_desc']; ?></textarea></td></tr>             
                <tr><td>Description:</td><td><textarea name="description"  class="text-input mceEditor" ><?php echo $_POST['description']; ?></textarea></td></tr>             
                <!-- <tr><td>Diet Duration:</td><td>
                         
                <?php
                $list = Category::getList(99999, "num", "duration");
                $i = 0;
                $output = "<select name='duration' >";
                foreach ($list as $item) {
                    if ($_POST["duration"] == $item["id"])
                        $output .= "<option value='{$item["id"]}' selected >{$item["name"]}</option>";
                    else
                        $output .= "<option value='{$item["id"]}'>{$item["name"]}</option>";
                }
                echo $output . "</select>";
                ?>  
                        
                    
                    </td></tr>   -->






                <tr>
                    <td>Category:</td>                  
                    <td>  
                        <?php
                        $list = Category::getList(99999, "num", "diet");

                        foreach ($list as $item) {
                            if (search("-{$item["id"]}-", $_POST["categories"])) {
                                echo "<label><input type='checkbox' checked=checked name='category[]' value='" . $item["id"] . "' /> " . $item["name"] . " </label> <br/>";
                            } else {
                                echo "<label><input type='checkbox' name='category[]' value='" . $item["id"] . "' /> " . $item["name"] . " </label> <br/>";
                            }
                        }
                        ?> 
                    </td></tr> 


                <tr><td>Large Logo: <br/>
                        200px × 128px JPG :</td><td>
                        <div  class="row">    
                            <input type="file" size="46"  name="upload" class="upload"  />             
                        </div>
                        <?php
                        if (!empty($_POST["logo_large"])) {
                            echo ' <br/> <img src="' . PATH . $_POST["logo_large"] . '" width="100" /> ';
                        }
                        ?>             
                    </td></tr> 

                <!-- 
                <tr><td>Medium Logo: <br/>
                        148px × 163px JPG :</td><td>
                   <div  class="row">    
                     <input type="file" size="46"  name="upload2"  class="upload"  />             
                  </div>
                <?php
                if (!empty($_POST["logo_med"])) {
                    echo ' <br/> <img src="' . PATH . $_POST["logo_med"] . '" width="100" /> ';
                }
                ?>             
              </td></tr> 
                -->


                <tr><td>Small Logo: <br/>
                        70px × 70px JPG:</td><td>
                        <div  class="row">          
                            <input type="file" size="46"  name="upload3"  class="upload"  />             
                        </div>

                        <?php
                        if (!empty($_POST["logo_small"])) {
                            echo ' <br/> <img src="' . PATH . $_POST["logo_small"] . '" width="49" /> ';
                        }
                        ?>             
                    </td></tr> 


                <tr><td>Bullet Highlights:</td><td>  
                        <textarea name="features"  class="text-input" rows="5" cols="72" ><?php echo $_POST['features']; ?></textarea>  <i>separated by <b>|</b> </i>
                    </td></tr>    

                <!-- 
                 <tr><td>Nutritional Facts:</td><td>  
                <textarea name="nutritional_facts"  class="text-input" rows="5" cols="72" ><?php echo $_POST['nutritional_facts']; ?></textarea>  <i>separated by <b>|</b> </i>
                </td></tr>  
                -->


                <!-- 
                   <tr><td>Is Featured Diet?</td>
                       <td><label><input type="radio" name="featured"  value="1"  <?php echo $_POST['featured'] == "1" ? "checked='checked'" : ""; ?> />Yes</label> 
                           <label><input type="radio" name="featured" value="0"   <?php echo $_POST['featured'] == "1" ? "" : "checked='checked'"; ?> />No</label>
                           (can be used at home page featured diet)
                       </td></tr> 
   
                -->

                <tr><td>Special</td><td><label><input type="radio" name="special" value="1" <?php echo $_POST['special'] == "1" ? "checked='checked'" : ""; ?> />Yes</label>
                        <label><input type="radio" name="special" value="0" <?php echo $_POST['special'] == "1" ? "" : "checked='checked'"; ?>  />No</label>
                    </td></tr> 

                <tr><td colspan="2">
                        <hr size="1" />
                        <h1>Editorial Reviews Tab</h1> 
                    </td></tr>


<?php for ($i = 1; $i <= 4; $i++) { ?>          
                    <tr><td>header <?php echo $i; ?>: </td><td>
                            <input type="text" name="editor_header<?php echo $i; ?>" size="97" value="<?php echo $_POST['editor_header' . $i]; ?>" /></td></tr>                                   
                    <tr><td>text <?php echo $i; ?>: </td><td>
                            <textarea name="overview<?php echo $i; ?>" class="editor mceEditor"   cols="100" rows="5" ><?php echo $_POST['overview' . $i]; ?></textarea>                                 
                        </td></tr>
<?php } ?>   

                <tr><td>header 5: </td>
                    <td><input type="text" name="editor_header5" size="97" value="<?php echo $_POST['editor_header5']; ?>" /></td></tr>                                      
                <tr><td >Examples: </td><td>         
                        <br/><b>Meal Examples #1</b><br/><table><tr><td>Name</td><td>Description</td></tr> 
                            <?php
                            for ($i = 1; $i < 9; $i++) {
                                echo '<tr><td><input type="text" name="example_name_' . $i . '" value="' . serializeDecode($_POST["example_name_" . $i]) . '" /></td> ';
                                echo '<td><input type="text" size="70" name="example_' . $i . '" value="' . serializeDecode($_POST["example_" . $i]) . '" /> </td></tr> ';
                            }
                            ?> 
                        </table>
                        <b>Meal Examples #2</b> <br/>
                        <table><tr><td>Name</td><td>Description</td></tr> 
                            <?php
                            for ($i = 9; $i < 19; $i++) {
                                echo '<tr><td><input type="text" name="example_name_' . $i . '" value="' . serializeDecode($_POST["example_name_" . $i]) . '" /></td> ';
                                echo '<td><input type="text" size="70" name="example_' . $i . '" value="' . serializeDecode($_POST["example_" . $i]) . '" /> </td></tr> ';
                            }
                            ?> </table> 
                    </td></tr> 
                <tr><td colspan="2">
                        <hr size="1" />
                        <h1>Our Rating Tab
                            (<i>%rating_include%</i>)
                        </h1> 
                    </td></tr>
                <tr><td></td>
                    <td>        
                        <?php
                        /*
                          for($i = 1; $i <6; $i ++){
                          if($_POST["our_rating"]  == $i)  echo "<option selected>$i</option> ";
                          else echo "<option>$i</option> ";
                          }
                         */


                        $_rating = array("", "Plan Support", "Diet Effectiveness", "Diet Food", "Diet Cost");

                        $option1 = "<option selected='selected'>1</option><option>2</option><option>3</option><option>4</option><option>5</option>";
                        $option2 = "<option>1</option><option selected='selected'>2</option><option>3</option><option>4</option><option>5</option>";
                        $option3 = "<option>1</option><option>2</option><option selected='selected'>3</option><option>4</option><option>5</option>";
                        $option4 = "<option>1</option><option>2</option><option>3</option><option selected='selected'>4</option><option>5</option>";
                        $option5 = "<option>1</option><option>2</option><option>3</option><option>4</option><option selected='selected'>5</option>";


                        for ($i = 1; $i < 5; $i++) {

                            if (!isset($_POST["rating_$i"]))
                                $option = "<option>1</option><option>2</option><option>3</option><option>4</option><option selected='selected'>5</option>";
                            else
                                eval('$option  = $option' . $_POST["rating_$i"] . ';');

                            echo $_rating[$i] . ' rating: <select name="rating_' . $i . '">' . $option . '</select> <br/>
                        <textarea name="rating_text_' . $i . '" class="editor mceEditor"   cols="80" rows="7" >' . $_POST['rating_text_' . $i] . '</textarea> <br/>';
                        }
                        ?>                                        
                    </td></tr> 

                <tr><td colspan="2">
                        <hr size="1" /><h1>Pros & Cons Tab</h1>
                    </td></tr>

                <tr><td>Header 1:</td>
                    <td><input name="proscons_header1" style="width:595px!important;" value="<?php echo $_POST['proscons_header1']; ?>" /></td></tr>     

                <tr><td>Text 1:</td>
                    <td><textarea name="proscons_text1"  class="editor mceEditor"   cols="100" rows="3" ><?php echo $_proscons1['proscons_text']; ?></textarea></td></tr>     

                <tr><td>Pros 1: <br/>
                        <i>separated by <b>|</b> </i>
                    </td><td>
                        <textarea name="pros1"  class="text-input" rows="5" style="width:595px!important;"><?php echo $_proscons1['pros']; ?></textarea>  
                    </td></tr>  

                <tr><td>Cons 1: <br/>
                        <i>separated by <b>|</b> </i>
                    </td><td>
                        <textarea name="cons1"  class="text-input" rows="5"  style="width:595px!important;"><?php echo $_proscons1['cons']; ?></textarea>   
                    </td></tr>   


                <tr><td>Header 2:</td>
                    <td><input name="proscons_header2" style="width:595px!important;" value="<?php echo $_POST['proscons_header2']; ?>" /></td></tr>     

                <tr><td>Text 2:
                        <i>separated by <b>|</b> </i>
                    </td>
                    <td><textarea name="proscons_text2"  class="text-input"  rows="5"  style="width:595px!important;" ><?php echo $_proscons2['proscons_text']; ?></textarea></td></tr>     


                <!-- 
                    <tr><td>Pros 2: <br/>
                            <i>separated by <b>|</b> </i>
                        </td><td>
                          <textarea name="pros2"  class="text-input" rows="5" style="width:595px!important;"><?php echo $_proscons2['pros']; ?></textarea>  
                    </td></tr>  
        
                    <tr><td>Cons 2: <br/>
                            <i>separated by <b>|</b> </i>
                        </td><td>
                          <textarea name="cons2"  class="text-input" rows="5"  style="width:595px!important;"><?php echo $_proscons2['cons']; ?></textarea>   
                    </td></tr>   
                -->


                <tr><td colspan="2">
                        <hr size="1" /><h1>Gallery Tab</h1>
                    </td></tr>

                <tr><td>Image text:</td>
                    <td><textarea name="gallery_text1"  class="editor mceEditor"   cols="100" rows="3" ><?php echo $_POST['gallery_text1']; ?></textarea></td></tr>     

                <tr><td>Video text:</td>
                    <td><textarea name="gallery_text2"  class="editor mceEditor"   cols="100" rows="3" ><?php echo $_POST['gallery_text2']; ?></textarea></td></tr>     


                <tr><td></td><td>
                        <?php
                        if ($type == "Edit") {
                            echo "<a href='diets.php?gallery=1&ID=$id'  title='click to edit/update gallery' class='clickthis'>[click to update galleries]</a>";
                        }
                        ?> 
                    </td></tr>

                <tr><td colspan="2">
                        <hr size="1" /><h1>Diet Plan Tab</h1>
                    </td></tr>

                <tr><td>Header:</td>
                    <td><input name="plan_header" style="width:595px!important;" value="<?php echo $_POST['plan_header']; ?>" /></td></tr>     

                <tr><td>text:</td>
                    <td><textarea name="plan_text"  class="editor mceEditor"   cols="100" rows="3" ><?php echo $_POST['plan_text']; ?></textarea></td></tr>     




                <tr><td colspan="2">
                        <hr size="1" /><h1>Editorial Review /Dietplan</h1>
                    </td></tr>

                <tr><td colspan="2">
                        Select dietplan to show in editorial review
                        <table cellspacing="0" cellpadding="10" class="table">
                            <tr class="tr-header">
                                <td width="20">#</td>
                                <td width="300">Diet Plan</td>
                                <td>Standard Price</td>
                                <td>Discount</td>
                                <td>Coupon</td>
                                <td>Total Price</td>
                                <td>Select</td></tr>
                            <?php
                            $list = DietPlans::getList($id);
                            foreach ($list as $item) {
                                $selected = $_POST['dietplans'] == $item["id"] ? "checked" : "";
                                echo "<tr>
                                        <td>{$item['id']}</td>
                                        <td>{$item['name']}</td> 
                                        <td>{$item['standard_price']}</td>
                                        <td>{$item['discount']}</td>
                                        <td>{$item['code']}</td>
                                        <td>{$item['total_price']}</td>
                                        <td><input type=\"radio\" name=\"dietplans\" $selected value=\"{$item["id"]}\"  /></td>
                                     </tr>";
                            }
                            ?>
                        </table>
                        <?php
                        if ($type == "Edit") {
                            echo "<a href='diets.php?plans=1&ID=$id'  title='click to edit/update diet plans' class='clickthis'>[click to update dietplans]</a>";
                        }
                        ?> 

                    </td></tr>     

                <tr><td colspan="2">
                        <hr size="1" />
                    </td></tr> 

            </table>

            <input type="hidden" name="add" value="1" />

            <br/>


            <div class="row buttons fixed-buttons" style="position:fixed!important; top:85%; padding: 32px 10px;  border: none; height: 200px; background: #fff; width: 870px;   "> 
                <button type="button" onclick="location.href = '?'" ><span>&laquo; Back</span></button>                                                
                <button type="submit" class="save-btn" ><span>Save</span></button>     
                <img src="../images/loading-small.gif" class="loader" style="display:none"/>
                <span class="status"></span>
            </div>

            <div class="row buttons" > 
                <button type="button" onclick="location.href = '?'" ><span>Back</span></button>                                                
                <button type="submit" class="save-btn" ><span>Save</span></button>                                                
                <img src="../images/loading-small.gif" class="loader" style="display:none"  />
                <span class="status"></span>
            </div>

        </form>

        <br/><br/><br/><br/><br/><br/>


        <script>
            $(function() { // run this code on page load (AKA DOM load) 
                $('#datetimepicker').datetimepicker();

                var $window = $(window);
                var top = $(document.body).children(0).position().top;

                /* react to scroll event on window */
                $window.scroll(function() {
                    //$window.scrollTop()  
                    if ($window.scrollTop() >= 4400) {
                        $(".fixed-buttons").hide();
                    } else {
                        $(".fixed-buttons").show();
                    }
                });


            });


            function saveThisForm() {
                if (checkCategoryForm()) {

                    var upload_count = 0;

                    $(".upload").each(function() {
                        if ($(this).val() != "") {
                            upload_count++;
                        }
                    });

                    if (upload_count > 0) { //we need to submit this form normally if we have an image upload...
                        return true;
                    } else {
                        $(".loader").show();
                        $(".save-btn").hide();
                        $.post(location.href + "&ajax=1", $(".diet-form").serialize(), function() {
                            $(".loader").hide();
<?php
if ($_GET["new"] == 1) {
    echo "location.href='?'; return false;";
}
?>
                            $(".save-btn").show();
                            $(".status").html("Successfully saved!");
                            setTimeout("$('.status').hide()", 2000);
                        });
                    }
                }

                return false;
            }

            function checkCategoryForm() {
                var errors = "";

                if ($("input[name='name']").val() == "") {
                    errors += "Invalid Category Name\n";
                }

                if ($("textarea[name='description']").val() == "") {
                    errors += "Invalid Category Description\n";
                }


                if (errors != "") {
                    alert(errors);
                    return false;
                } else {
                    return true;
                }
            }


            initMCET(".mceEditor");
        </script>         

    </div>
</div>    