<?php
 
  $id = $_GET["ID"]; 
 if($_GET["gid"] != ""){ //edit       
      $gallery = new Gallery($_GET["gid"]);      
      if( empty($gallery->id) ) die("Invalid gid!"); 
      $caption  = $gallery->caption;      
      $default_thumb = "<img src='".PATH."$gallery->file' width='100' /> <br/>";
      $old_picture = $gallery->file; 
         
      if($gallery->type == 'video'){
          $video = $gallery->file;    
          $thumb = $gallery->thumb;
          $embed = convert_to_original(serializeDecode($gallery->embed));
          echo "<script>$(function(){ $('#video-select').click(); } );</script>";
          $default_thumb =  "<img src='".PATH.$gallery->thumb."' width='100' /> <br/>";           
      }   
      
  }
?>
  
<div class="box"> 
            <div class="title"> 
                    <h2>Diet Gallery/Media</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms">
        
            Add/Edit: <label><input type="radio" name="form-type" checked="checked" onclick="$('#image-form').show();$('#video-form').hide();" value="picture" />Picture</label>
            <label><input type="radio" name="form-type" id="video-select" value="video" onclick="$('#image-form').hide();$('#video-form').show();" />Video</label>
            
            <form id="image-form" action="" method="post"   enctype="multipart/form-data"   > 
               <input type="hidden" name="old_pic" value="<?php echo $old_picture; ?>" /> 
               <p>Caption: <input type="text" name="caption" size="50" value="<?php echo $caption; ?>" /></p> 
               <p>Browse Picture: (600x400px jpg only)<?php echo $default_thumb ; ?> 
                   <div  class="row">    
                        <input type="file" size="46"  name="upload"  />             
                    </div> 
               </p> 
               <input type="submit" name="save_picture" value="Save Image"/>
            </form> 
            
             <form id="video-form" action="" method="post"   enctype="multipart/form-data" style="display:none"   > 
               
                
               <input type="hidden" name="video" value="<?php echo $video; ?>" /> 
               <input type="hidden" name="thumb" value="<?php echo $thumb; ?>" /> 
                
               
               <p>Title: <input type="text" name="caption" size="50" value="<?php echo $caption; ?>" /></p> 
               <p>Browse Video (FLV only) :  
                   <div  class="row">    
                        <input type="file" size="46"  name="upload"  />             
                        <?php
                  if( !empty($video) ){
                      echo " &nbsp;&nbsp; <a href='".PATH.$video."' style='text-decoration:none;' >[Attached File] </a>
                                <small>(<a href='?gallery=1&ID=$id&gid=".$_GET["gid"]."&delete_file=1'>delete</a>)</small>";
                  }
               ?>
                    </div> 
               
                  or Embed: <br/>
                   <textarea cols="50" name="embed"><?php echo $embed; ?></textarea> <br/>
               
                  Thumbnail (136px × 88px): <?php echo $default_thumb ; ?> 
                   <div  class="row">    
                        <input type="file" size="46"  name="upload2"  />             
                    </div> 
                 
               </p> 
               
               <input type="submit" name="save_video" value="Save Video"/>
            </form>
            
            <br/><br/> 

            <table cellspacing="0" cellpadding="10" class="table">
                <tr class="tr-header">
                <td width="20">#</td><td width="300">Caption</td><td>Thumb</td><td>Type</td><td></td></tr>
            <?php
             //list here
             $list  = Gallery::getList($id);
             foreach($list as $item){
                 
                 $embed = convert_to_original(serializeDecode($item["embed"])); 
                 
                 
                 if($item["type"] == 'image')
                   $thumb = PATH.$item["file"];
                 else if( search("youtu",$embed) && empty($item["thumb"]) )  
                   $thumb = getYoutubeImage($embed); 
                 else 
                   $thumb = PATH.$item["thumb"];
                 
                 
                 $button = "<a href='diets.php?gallery=1&ID=$id&dt={$item["id"]}' class='delete-btn'>delete</a> / 
                 <a  href='diets.php?gallery=1&ID=$id&gid={$item["id"]}' href=''>edit</a>";
                 $thumb = "<img src='".$thumb."'  width='100' />";     

                 echo "<tr><td>{$item["id"]}</td>
                 <td>{$item["caption"]}</td>
                 <td>$thumb</td>
                 <td>{$item["type"]}</td>
                 <td>$button</td></tr>"; 
             }

            ?>
            </table>
            
            
      
                        
</div>      
    
    <div class="row buttons fixed-buttons"   > <button type="button" onclick="location.href='?edit=<?php echo $id; ?>'" ><span>&laquo; Go To Diet Form</span></button> </div>


</div>
