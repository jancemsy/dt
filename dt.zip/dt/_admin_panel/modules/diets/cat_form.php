<?php
$type = "Add";
if( isset($_GET["catedit"]) ){
    $id = $_GET["catedit"];     
    $cat = new Category($id);
    $_POST = $cat->array;    
    $type = "Edit"; 
    $ex = unserialize($cat->example_diets); 
    $_POST["example_diets"] = $ex["examples"];
    $tmp = unserialize($cat->params);
    @extract($tmp);
}

?>


<div class="box"> 
            <div class="title"> 
                    <h2><?php echo $type; ?> Category</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms">  

<form action="" method="post" enctype="multipart/form-data"   >
    <input type="hidden" name="id" value="<?php echo $_POST["id"]; ?>" />
    <table>
         <tr><td>Meta Title <counter style="display:none" max="70" required="1" target="input[name=meta_title]'"></counter>:</td>
    <td>  <input type="text" name="meta_title" class="text-input" value="<?php echo $_POST['meta_title']; ?>" /></td></tr> 
        <tr><td>Meta Desc <counter style="display:none" max="155" required="1" target="input[name=meta_desc]'"></counter>:</td><td>  <input type="text" name="meta_desc" class="text-input" value="<?php echo $_POST['meta_desc']; ?>" /></td></tr> 
        <tr><td>Meta Keywords:</td><td>  <input type="text" name="meta_keywords" class="text-input" value="<?php echo $_POST['meta_keywords']; ?>" /></td></tr> 
        
        
        <tr>
            <td>Order:</td>     
            <td><input type="input" name="num" value="<?php echo $_POST["num"]; ?>" /></td>
        </tr>
        
        <tr>
            <td>Headline:</td>     
            <td><input type="input" name="headline" size="96" value="<?php echo $_POST["headline"]; ?>" /></td>
        </tr>
        
        <tr>
            <td>Name:</td>     
            <td><input type="input" name="name" value="<?php echo $_POST["name"]; ?>" /></td>
        </tr>        
        <tr>
            <td>Description:</td>     
            <td><textarea name="description"  class="editor" cols="40" rows="5"><?php echo $_POST["description"]; ?></textarea></td>
        </tr>
        
          
         <tr>
            <td>Short Description:</td>     
            <td><textarea name="short_desc"  class="editor" cols="40" rows="5"><?php echo $_POST["short_desc"]; ?></textarea></td>
        </tr>
        
         <tr><td>Category Icon (37px × 37px) jpg only:  </td><td>
            <div class="row">
             <input type="file" size="46"  name="upload2"  />             
            </div>
             <?php
             echo "<input type='hidden' name='icon' value='".$_POST["icon"]."' /> ";
             if( !empty($_POST["icon"]) ){
                 echo ' <br/> <img src="'.PATH.$_POST["icon"].'" width="37" /> ';                                  
             }
             ?>             
        </td></tr> 
         
         <tr><td>Thumbnail:  </td><td>
            <div class="row">
             <input type="file" size="46"  name="upload"  />             
            </div>
             <?php
             echo "<input type='hidden' name='thumb' value='".$_POST["thumb"]."' /> ";
             if( !empty($_POST["thumb"]) ){
                 echo ' <br/> <img src="'.PATH.$_POST["thumb"].'" width="100" /> ';                                  
             }
             ?>             
        </td></tr> 
         
         <tr><td>Thumbnail Caption:  </td>  
             <td><input type="input" name="caption"  size="90" value="<?php echo $_POST["caption"]; ?>" /></td>
         </tr> 
         
         
         
         <tr><td>Pros: <br/> separated by |  </td>  
             <td>
                 <textarea name="pros" cols="71" rows="5"><?php echo $_POST["pros"]; ?></textarea>
             </td>
         </tr> 
         
         <tr><td>Cons: <br/> separated by |  </td>  
             <td>
                 <textarea name="cons" cols="71" rows="5"><?php echo $_POST["cons"]; ?></textarea>
             </td>
         </tr> 
         
         <tr><td>Other Diets : <br/> separated by |  </td>  
             <td>
                 <textarea name="example_diets" cols="71" rows="5"><?php echo $_POST["example_diets"]; ?></textarea>
             </td>
         </tr> 
         
         
         <tr>
            <td>Heading 1:</td>
            <td><input type="text" name="list_headline1" value="<?php echo $list_headline1; ?>" size="55" /></td>                        
        </tr>
        <tr>
            <td>Description 1:</td>
            <td><textarea name="list_desc1"  class="editor mceEditor" cols="52"><?php echo $list_desc1; ?></textarea></td>                        
        </tr>
        
         <tr>
            <td>Heading 2:</td>
            <td><input type="text" name="list_headline2" value="<?php echo $list_headline2; ?>" size="55" /></td>                        
        </tr>
        <tr>
            <td>Description 2:</td>
            <td><textarea name="list_desc2"   class="editor mceEditor" cols="52"><?php echo $list_desc2; ?></textarea></td>                        
        </tr> 
        
        <tr>
            <td>Heading 3:</td>
            <td><input type="text" name="list_headline3" value="<?php echo $list_headline3; ?>" size="55" /></td>                        
        </tr>
        <tr>
            <td>Description 3:</td>
            <td><textarea name="list_desc3"  class="mceEditor editor"  cols="52"><?php echo $list_desc3; ?></textarea></td>                        
        </tr> 
        
        <tr>
            <td>Heading 4:</td>
            <td><input type="text" name="list_headline4" value="<?php echo $list_headline4; ?>" size="55" /></td>                        
        </tr>
        <tr>
            <td>Description 4:</td>
            <td><textarea name="list_desc4" class="mceEditor editor"  cols="52"><?php echo $list_desc4; ?></textarea></td>                        
        </tr> 
         
        
        <tr>
            <td>Select the diets to feature <br/>
                on category pages:</td>
            <td>
                <?php
                   $list = Diet::getDietsByCategory($_POST["id"]);
                   
                   foreach($list as $item){
                       $check = search("-".$item["id"]."-",$features) ? "checked = checked" : "";
                       echo "<label> <input type='checkbox' name='features[]' $check value='{$item['id']}'  /> {$item['name']} </label> <br/> ";                       
                   }
                                           
                ?>                               
            </td>                        
        </tr> 
         
         
        <tr>
            <td colspan="2">                 
               <div class="row buttons"> 
                <button type="button" onclick="location.href='?cat=1'" ><span>Cancel</span></button>                                                
                <button type="submit" name="save_category"><span>Save</span></button>                                                
              </div> 
            </td>                
        </tr>
        
    </table>          
</form> 

    </div>
</div> 

<script>
      initMCET('.editor')
</script>