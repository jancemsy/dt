<?php

if (isset($_POST['crop_images2'])) {  //ajax call   
    $_SESSION["pending_crop"] = "";
    $width = 85;
    $height = 129;
    $quality = 100;

    $size = count($_POST['h']);

    for ($i = 0; $i < $size; $i++) {
        $des_h = $_POST['h'][$i];
        $des_w = $_POST['w'][$i];
        $source_x = $_POST['x'][$i];
        $source_y = $_POST['y'][$i];
        $src = $_POST['thumb'][$i];

        if (!empty($des_h) && !empty($src)) {
            $filename = end(explode("/", $src));
            $filename = str_replace("-orig", "", $filename);
            $destination = "../content/stories/$filename";
            //$thumb_dest = "../content/stories/".str_replace("-med","",$filename);    

            $ext = strtolower(end(explode(".", $src)));

            switch ($ext) {
                case "gif":
                    $img_r = imagecreatefromgif($src);
                    break;
                case "png":
                    $img_r = imagecreatefrompng($src);
                    break;
                default:
                    $img_r = imagecreatefromjpeg($src);
                    break;
            }

            $dst_r = ImageCreateTrueColor($width, $height);
            imagecopyresampled($dst_r, $img_r, 0, 0, $source_x, $source_y, $width, $height, $des_w, $des_h);

            @unlink($destination);  //delete the old one
            switch ($ext) {
                case "gif":
                    imagegif($dst_r, $destination);
                    break;
                case "png":
                    imagepng($dst_r, $destination);
                    break;
                default:
                    imagejpeg($dst_r, $destination, $quality);
                    break;
            }

            @unlink($src); //unlink original  
            //@createThumb($destination,$thumb_dest,$width,$height); 
        }
    }
    die("1");
}

if (isset($_POST['crop_images'])) {  //ajax call   
    $_SESSION["pending_crop"] = "";
    $quality = 100;

    $count = count($_POST['h']);

    for ($i = 0; $i < $count; $i++) {
        $des_h = $_POST['h'][$i];
        $des_w = $_POST['w'][$i];
        $width = $_POST['_w'][$i];
        $height = $_POST['_h'][$i];
        $source_x = $_POST['x'][$i];
        $source_y = $_POST['y'][$i];
        $size = empty($_POST['size'][$i]) ? "" : "-" . $_POST['size'][$i];
        $src = $_POST['thumb'][$i];

        if (!empty($des_h) && !empty($src)) {
            $filename = end(explode("/", $src));
            $destination = "../content/diets/$filename";
            $ext = strtolower(end(explode(".", $src)));
            switch ($ext) {
                case "gif":
                    $img_r = imagecreatefromgif($src);
                    break;
                case "png":
                    $img_r = imagecreatefrompng($src);
                    break;
                default:
                    $img_r = imagecreatefromjpeg($src);
                    break;
            }

            $dst_r = ImageCreateTrueColor($width, $height);
            imagecopyresampled($dst_r, $img_r, 0, 0, $source_x, $source_y, $width, $height, $des_w, $des_h);


            switch ($ext) {
                case "gif":
                    imagegif($dst_r, $destination);
                    break;
                case "png":
                    imagepng($dst_r, $destination);
                    break;
                default:
                    imagejpeg($dst_r, $destination, $quality);
                    break;
            }

            if ($width == 148 && $height == 163) {
                $destination2 = str_replace(".jpg", "-small.jpg", $destination);
                createThumb($destination, $destination2, 101, 110);
            }
        }//if 
    }//for






    die("1");
}





if (isset($_GET["catdelete"])) {
    $id = $_GET["catdelete"];
    Category::delete($id);
    jumpto("diets.php?cat=1");
}



if (isset($_POST["save_category"])) {
    $description = clean_data($_POST["description"]);


    if (isset($_FILES["upload2"]) && $_FILES['upload2']["name"] != "") {
        if (!empty($_POST["icon"]))
            @unlink("../" . $_POST["icon"]);
        $name = $_FILES['upload2']["name"];
        $ext = end(explode(".", $name));
        $time = time();
        $filename = "$time.$ext";
        $thumb_dest = "../content/category_icon/$filename";
        move_uploaded_file($_FILES["upload2"]["tmp_name"], $thumb_dest);
        createThumb($thumb_dest, $thumb_dest, 37, 37);
        $_POST["icon"] = "content/category_icon/$filename";
    }


    if (isset($_FILES["upload"]) && $_FILES['upload']["name"] != "") {
        if (!empty($_POST["thumb"]))
            @unlink("../" . $_POST["thumb"]);
        $name = $_FILES['upload']["name"];
        $ext = end(explode(".", $name));
        $time = time();
        $filename = "$time.$ext";
        $thumb_orig = "../content/category/$time-orig.$ext";
        $thumb_dest = "../content/category/$filename";
        move_uploaded_file($_FILES["upload"]["tmp_name"], $thumb_orig);
        @createThumb($thumb_orig, $thumb_dest, 325, 181);
        @unlink($thumb_orig);
        $_POST["thumb"] = "content/category/$filename";
    }

    $example_diets = "";


    if (!empty($_POST["example_diets"])) {
        $tmp = explode("|", $_POST["example_diets"]);
        $array = array();

        /*
          $ids =  "";
          $not = "";
          foreach($tmp as $item){
          if(!empty($item)){
          $r = Diet::getSearchResult($item);

          if(count($r) >0){  }
          else{
          $not .= "|$item";
          }
          foreach($r as $row){
          if( !search("-".$row["id"]."-",$ids) ){
          $ids .= "-".$row["id"]."-";
          }
          }
          }
          }
         */

        $final = array("examples" => $_POST["example_diets"]
                /* ,
                  "result" => $ids,
                  "nomatch" => $not */
        );

        $example_diets = serialize($final);
    }//if


    $fcount = count($_POST["features"]);
    $features = "";
    $features_con = "";
    for ($i = 0; $i < $fcount; $i ++) {
        $id = $_POST["features"][$i];
        if (!empty($id)) {
            $features_con .= empty($features_con) ? "" : " OR ";
            $features_con .= " id = $id ";
            $features .= "-$id-";
        }
    }


    $params = array(
        "features" => $features,
        "features_condition" => $features_con,
        "list_headline1" => $_POST['list_headline1'],
        "list_desc1" => $_POST['list_desc1'],
        "list_headline2" => $_POST['list_headline2'],
        "list_desc2" => $_POST['list_desc2'],
        "list_headline3" => $_POST['list_headline3'],
        "list_desc3" => $_POST['list_desc3'],
        "list_headline4" => $_POST['list_headline4'],
        "list_desc4" => $_POST['list_desc4']
    );

    $params = serialize($params);

    $name = clean_data($_POST["name"]);
    $params = array(
        "icon" => mysql_real_escape_string($_POST["icon"]),
        "headline" => mysql_real_escape_string($_POST["headline"]),
        "params" => $params,
        "example_diets" => $example_diets,
        "pros" => clean_data($_POST["pros"]),
        "cons" => clean_data($_POST["cons"]),
        "num" => $_POST["num"],
        "thumb" => $_POST["thumb"],
        "caption" => clean_data($_POST["caption"]),
        "description" => mysql_real_escape_string($description),
        "name" => mysql_real_escape_string($name),
        "meta_title" => mysql_real_escape_string($_POST["meta_title"]),
        "meta_desc" => mysql_real_escape_string($_POST["meta_desc"]),
        "meta_keywords" => mysql_real_escape_string($_POST["meta_keywords"]),
        "short_desc" => clean_data($_POST["short_desc"]),
        "type" => "diet"
    );


    if ($_POST["id"] != "") {
        $params["id"] = $_POST["id"];
        Category::update($params);
    } else {
        Category::add($params);
    }
    jumpto("diets.php?cat=1");
}



if (isset($_GET["delete"])) {
    $id = $_GET["delete"];
    $diet = new Diet($id);
    @unlink("../" . $diet->thumb);
    $diet->delete($id);
    jumpto("diets.php");
}

if (isset($_POST["add"])) {
    if (isset($_FILES["upload"]) && $_FILES['upload']["name"] != "") {
        if (!empty($_POST["logo_large"]))
            @unlink("../" . $_POST["logo_large"]);
        $name = $_FILES['upload']["name"];
        $ext = end(explode(".", $name));
        $time = "l" . time();
        $filename = "$time.$ext";
        $_POST["logo_large"] = "content/diets/$filename";
        $thumb_orig = "../content/diets/$filename";
        move_uploaded_file($_FILES["upload"]["tmp_name"], $thumb_orig);
        $pending_crop[] = array("image" => $thumb_orig, "width" => "200", "height" => "129", "caption" => "Large Logo");
    }



    if (isset($_FILES["upload3"]) && $_FILES['upload3']["name"] != "") {
        if (!empty($_POST["logo_small"]))
            @unlink("../" . $_POST["logo_small"]);
        $name = $_FILES['upload3']["name"];
        $ext = end(explode(".", $name));
        $time = "s" . time();
        $filename = "$time.$ext";
        $_POST["logo_small"] = "content/diets/$filename";
        $thumb_orig = "../content/diets/$filename";
        move_uploaded_file($_FILES["upload3"]["tmp_name"], $thumb_orig);
        $pending_crop[] = array("image" => $thumb_orig, "width" => "70", "height" => "70", "caption" => "Small logo");
    }



    $csize = count($_POST["category"]);
    $categories = "";
    for ($i = 0; $i <= $csize; $i++) {
        if ($_POST["category"][$i] != "") {
            $categories .= "-" . $_POST["category"][$i] . "-";
        }
    }
    $examples = array();
    for ($i = 1; $i < 19; $i++) {
        $examples["example_$i"] = serializeEncode($_POST["example_$i"]);
        $examples["example_name_$i"] = serializeEncode($_POST["example_name_$i"]);
    }

    $examples = serialize($examples);

    $proscons1 = serialize(array("pros" => serializeEncode($_POST["pros1"]),
        "cons" => serializeEncode($_POST["cons1"]),
        "proscons_text" => serializeEncode($_POST["proscons_text1"])));

    $proscons2 = serialize(array("pros" => serializeEncode($_POST["pros2"]),
        "cons" => serializeEncode($_POST["cons2"]),
        "proscons_text" => serializeEncode($_POST["proscons_text2"])));



    $gallery_text = serialize(array("gallery_text1" => serializeEncode($_POST["gallery_text1"]),
        "gallery_text2" => serializeEncode($_POST["gallery_text2"])));

    $our_rating = 0;

    $rating = serialize(array("rating_1" => $_POST["rating_1"],
        "rating_2" => $_POST["rating_2"],
        "rating_3" => $_POST["rating_3"],
        "rating_4" => $_POST["rating_4"],
        "rating_text_1" => serializeEncode($_POST["rating_text_1"]),
        "rating_text_2" => serializeEncode($_POST["rating_text_2"]),
        "rating_text_3" => serializeEncode($_POST["rating_text_3"]),
        "rating_text_4" => serializeEncode($_POST["rating_text_4"])));

    $our_rating = @( ( $_POST["rating_1"] + $_POST["rating_2"] + $_POST["rating_3"] + $_POST["rating_4"] ) / 4);


    $plan_text = clean_data($_POST["plan_text"]);



    $params = array(
        "publish_date_time" => clean_data($_POST["publish_date_time"]),
        "plan_text" => $plan_text, //cleaned
        "plan_header" => clean_data($_POST["plan_header"]),
        "meta_title" => addslashes($_POST["meta_title"]),
        "meta_desc" => addslashes($_POST["meta_desc"]),
        "meta_keywords" => addslashes($_POST["meta_keywords"]),
        "categories" => $categories, //ids
        "rating_text" => $rating, //serialized
        "gallery_text" => $gallery_text, //serialized
        "proscons1" => $proscons1, //serialized
        "proscons_header1" => addslashes($_POST["proscons_header1"]),
        "proscons2" => $proscons2, //serialized
        "proscons_header2" => addslashes($_POST["proscons_header2"]),
        /*         * ********Editorial fields********* */
        "editor_header1" => addslashes($_POST["editor_header1"]),
        "overview1" => addslashes(diet::removeformats($_POST["overview1"])),
        "editor_header2" => addslashes($_POST["editor_header2"]),
        "overview2" => addslashes(diet::removeformats($_POST["overview2"])),
        "editor_header3" => addslashes($_POST["editor_header3"]),
        "overview3" => addslashes(diet::removeformats($_POST["overview3"])),
        "editor_header4" => addslashes($_POST["editor_header4"]),
        "overview4" => addslashes(diet::removeformats($_POST["overview4"])),
        "editor_header5" => addslashes($_POST["editor_header5"]),
        "overview5" => addslashes(diet::removeformats($_POST["overview5"])),
        /*         * ********Editorial fields********* */
        "examples" => $examples, //serialized
        "name" => addslashes($_POST["name"]),
        "logo_large" => $_POST["logo_large"], //link
        "logo_med" => $_POST["logo_med"], //link
        "logo_small" => $_POST["logo_small"], //link
        "description" => addslashes($_POST["description"]),
        "short_desc" => addslashes($_POST["short_desc"]),
        "dietplans" => $_POST["dietplans"],
        /*
          DEPRECATED
          //Editorial Reviews
          "coupon_code"       => addslashes($_POST["coupon_code"]),
          "affiliate_link"    => addslashes($_POST["affiliate_link"]),
          "standard_price"    => addslashes($_POST["standard_price"]),
          "discount"          => addslashes($_POST["discount"]),
          "price"             => addslashes($_POST["price"]),
         */
        "our_rating" => $our_rating, //int                     
        "features" => addslashes($_POST["features"]),
        "special" => intval($_POST["special"]),
        //"featured"          => intval($_POST["featured"]),
        "sub_heading" => addslashes($_POST["sub_heading"]),
        "nutritional_facts" => addslashes($_POST["nutritional_facts"]),
        "is_published" => $_POST["is_published"] //boolean
    );

    if ($_POST["id"] != "") {
        $params["id"] = $_POST["id"];
        Diet::update($params);
        $id = $_POST["id"];
    } else {
        $id = Diet::add($params);
    }

    if ($_GET["ajax"] == 1) {
        die("1");
    }


    if (count($pending_crop) > 0) {
        $_SESSION["pending_crop"] = serialize($pending_crop);
        $_SESSION["goback"] = "diets.php?edit=" . $id;
        jumpto("diets.php?crop=1");
    }

    jumpto("diets.php");
}



if (isset($_GET["delete_story"])) {
    $id = $_GET["ID"];
    $mainurl = "diets.php?story=1&ID=$id";
    $id = $_GET["delete_story"];
    $story = new Story($id);
    @unlink("../" . $diet->thumb);
    $story->delete($id);
    jumpto($mainurl);
}


if (isset($_POST["save_story"])) {
    $id = $_GET["ID"];
    $mainurl = "diets.php?story=1&ID=$id";
    if (isset($_FILES["upload"]) && $_FILES['upload']["name"] != "") {
        if (!empty($_POST["thumb"]))
            @unlink("../" . $_POST["thumb"]);
        $name = $_FILES['upload']["name"];
        $ext = end(explode(".", $name));
        $time = time();
        $filename = "$time.$ext";

        $thumb_orig = "../content/stories/$time-orig.$ext";
        $thumb_dest = "../content/stories/$filename";
        move_uploaded_file($_FILES["upload"]["tmp_name"], $thumb_orig);

        createThumb($thumb_orig, $thumb_dest, 85, 129);

        $pending_crop[] = $thumb_orig;
        $_POST["thumb"] = "content/stories/$filename";
    }


    if (isset($_FILES["upload2"]) && $_FILES['upload2']["name"] != "") {
        if (!empty($_POST["thumb2"]))
            @unlink("../" . $_POST["thumb"]);
        $name = $_FILES['upload2']["name"];
        $ext = end(explode(".", $name));
        $time = time() . "2";
        $filename = "$time.$ext";

        $thumb_orig = "../content/stories/$time-orig.$ext";
        $thumb_dest = "../content/stories/$filename";
        move_uploaded_file($_FILES["upload2"]["tmp_name"], $thumb_orig);

        createThumb($thumb_orig, $thumb_dest, 85, 129);

        $pending_crop[] = $thumb_orig;
        $_POST["thumb2"] = "content/stories/$filename";
    }


    $array = array();
    foreach ($_POST as $field => $value) {
        $array[$field] = addslashes($value);
    }

    $params = $array;
    $params["dietID"] = $id;
    if (isset($_GET["edit"])) {
        Story::update($params);
    } else {
        Story::add($params);
    }

    if (count($pending_crop) > 0) {
        $_SESSION["pending_crop"] = serialize($pending_crop);
        jumpto("diets.php?crop_stories=1&ID=" . $_GET["ID"]);
    }

    jumpto($mainurl);
}



if ($_GET["dt"] != "") {
    $id = $_GET["ID"];
    Gallery::delete($_GET["dt"]);
    jumpto("diets.php?gallery=1&ID=$id");
}


if (isset($_POST["save_video"])) {
    $id = $_GET["ID"];
    $caption = addslashes($_POST["caption"]);
    $file = "";
    $time = time();

    $name = $_FILES['upload']["name"];
    if (!empty($name)) {
        $ext = end(explode(".", $name));
        $filename = "$time.$ext";
        $thumb_dest = "../content/gallery/$filename";
        move_uploaded_file($_FILES["upload"]["tmp_name"], $thumb_dest);
        $file = "content/gallery/$filename";
        if ($_POST["video"] != "" && $_GET["gid"] != "") { //edit and we should delete the old pic here
            @unlink(ABSPATH . $_POST["video"]);
        }
        $_POST["video"] = $file;
    }

    $name = $_FILES['upload2']["name"];
    if (!empty($name)) {
        $ext = end(explode(".", $name));
        $filename = "$time-thumb.$ext";
        $thumb_dest = "../content/gallery/$filename";
        move_uploaded_file($_FILES["upload2"]["tmp_name"], $thumb_dest);
        createThumb($thumb_dest, $thumb_dest, 600, 400);
        $file = "content/gallery/$filename";

        if ($_POST["thumb"] != "" && $_GET["gid"] != "") { //edit and we should delete the old pic here
            @unlink(ABSPATH . $_POST["thumb"]);
        }
        $_POST["thumb"] = $file;
    }

    $params = array(
        "dietID" => $id,
        "type" => "video",
        "thumb" => $_POST["thumb"],
        "file" => $_POST["video"],
        "embed" => serializeEncode($_POST["embed"]),
        "caption" => $caption
    );

    if ($_GET["gid"] != "") { //edit           
        $params["id"] = $_GET["gid"];
        Gallery::update($params);
    } else { //add
        Gallery::add($params);
    }

    jumpto("diets.php?gallery=1&ID=$id");
}


if (isset($_POST["save_picture"])) {
    $id = $_GET["ID"];
    $caption = addslashes($_POST["caption"]);
    $name = $_FILES['upload']["name"];
    $file = "";

    if (!empty($name)) {
        $ext = end(explode(".", $name));
        $time = time();
        $filename = "$time.$ext";
        $filename_orig = "$time-orig.$ext";
        $thumb_dest = "../content/gallery/$filename";
        $thumb_dest_orig = "../content/gallery/$filename_orig";
        move_uploaded_file($_FILES["upload"]["tmp_name"], $thumb_dest_orig);
        //createThumb($thumb_dest_orig,$thumb_dest_orig,500,400);    
        createThumb($thumb_dest_orig, $thumb_dest, 136, 88);
        $file = "content/gallery/$filename";

        if ($_POST["old_pic"] != "" && $_GET["gid"] != "") { //edit and we should delete the old pic here              
            @unlink(ABSPATH . toThumbOrig($_POST["old_pic"]));
            @unlink(ABSPATH . $_POST["old_pic"]);
        }
    }

    $params = array(
        "dietID" => $id,
        "type" => "image",
        "file" => $file,
        "caption" => $caption
    );

    if ($_GET["gid"] != "") { //edit           
        $params["id"] = $_GET["gid"];
        Gallery::update($params);
    } else { //add
        Gallery::add($params);
    }


    jumpto("diets.php?gallery=1&ID=$id");
}


if ($_GET["delete_file"] != "") {
    $gallery = new Gallery($_GET["gid"]);
    @unlink("../" . $gallery->file);
    Gallery::update(array("file" => "", "id" => $_GET["gid"]));
    jumpto("diets.php?gallery=1&ID=" . $_GET["ID"] . "&gid=" . $_GET["gid"]);
}


if (isset($_POST["save_diet_plan"])) {
    $id = $_GET["ID"];
    $params = array("dietID" => $id,
        "name" => $_POST["name"],
        "standard_price" => $_POST["standard_price"],
        "discount" => $_POST["discount"],
        "code" => $_POST["code"],
        "total_price" => $_POST["total_price"],
        "link" => $_POST["link"],
        "description" => addslashes($_POST["description"])
    );

    if (empty($_POST["dpi"])) {
        DietPlans::add($params);
    } else {
        $params["id"] = $_POST["dpi"];
        DietPlans::update($params);
    }
    jumpto("diets.php?plans=1&ID=" . $_GET["ID"]);
}

if (isset($_GET["delete_plan"])) {
    DietPlans::delete($_GET["delete_plan"]);
    jumpto("diets.php?plans=1&ID=" . $_GET["ID"]);
}


if (isset($_POST["save_review"])) {
    $total = @(($_POST["rating_1"] + $_POST["rating_2"] + $_POST["rating_3"] + $_POST["rating_4"]) / 4);
    $params = array("comment" => clean_data($_POST["comment"]),
        "rating_1" => $_POST["rating_1"],
        "rating_2" => $_POST["rating_2"],
        "rating_3" => $_POST["rating_3"],
        "rating_4" => $_POST["rating_4"],
        "total_rating" => $total,
        "id" => $_POST["reviewID"]);

    DietReviews::update($params);

    if (!empty($_GET["dietID"]))
        jumpto("diets.php?user_reviews=1&dietID=" . $_GET["dietID"]);
    else
        jumpto("diets.php?user_reviews=1");
}

if (isset($_GET["delete_review"])) {
    DietReviews::delete($_GET["delete_review"]);

    if (!empty($_GET["dietID"]))
        jumpto("diets.php?user_reviews=1&dietID=" . $_GET["dietID"]);
    else
        jumpto("diets.php?user_reviews=1");
}
?>