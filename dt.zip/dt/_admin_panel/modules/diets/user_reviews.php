<?php


$reviewID = $_GET["reviewID"];
if(!empty($reviewID)){
    $reviews = new DietReviews($reviewID);    
}
 

   

?>
<div class="box"> 
    <div class="title"> 
            <h2>User Reviews</h2> 
            <?php echo $_dahide ; ?>
    </div> 
  
        
  <?php if( !empty($reviewID) ) { ?>
      <div class="content  forms"> 
          <h1>Update User Review</h1>
           <form id="review_form" action="" method="post"  >
                <input type="hidden" name="reviewID" value="<?php echo $reviewID; ?>" />
                <input type="hidden" name="add_review" value="1" />
                <table cellpadding="3">
                    <tr><td>Rate Plan Support: </td><td>
                            <select name="rating_1"><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option></select>
                        </td></tr>
                    <tr><td>Rate  Diet Effectiveness: </td><td>
                            <select name="rating_2"><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option></select>
                        </td></tr>    
                     <tr><td>Rate Diet Food: </td><td>
                            <select name="rating_3"><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option></select>
                        </td></tr>  
                      <tr><td>Rate Diet Cost: </td><td>
                            <select name="rating_4"><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option></select>
                        </td></tr>  
                      <tr><td>Your Review: </td><td>
                            <textarea name="comment" cols="50" rows="10"><?php echo $reviews->comment; ?></textarea>
                        </td></tr>        
                      <tr><td>  </td><td>
                              <input type="button" value="Cancel" onclick="location.href='?user_reviews=1'" />
                            <input type="submit" value="Save" name="save_review" />
                            
                        </td></tr>  
                </table>   
            </form>
        <script>
            $('select[name=rating_1]').val('<?php echo $reviews->rating_1; ?>');
            $('select[name=rating_2]').val('<?php echo $reviews->rating_2; ?>');
            $('select[name=rating_3]').val('<?php echo $reviews->rating_3; ?>');
            $('select[name=rating_4]').val('<?php echo $reviews->rating_4; ?>');
        </script>          
      </div>  
     <?php } ?>
    
    
      <div class="content pages">  
        <table width="100%"  class="table">
            <thead>  
               <tr class="tr-header">            
                <td>Username</td>
                <td>Diet</td>
                <td>Plan Support</td>
                <td>Diet Effectiveness</td>
                <td>Diet Food</td>
                <td>Diet Cost</td>
                <td>Review</td>
                <td>Action</td>
            </tr>
            </thead>  
        <?php          
           extract(DietReviews::getList("",9999999));
           
           foreach($list as $item){            
               $u        = new User($item["userID"]);
               $username = $u->username;
               $review   = string_cut(strip_tags($item["comment"]),100);
               
               $delete_btn =  "<a href='?user_reviews=1&delete_review={$item['id']}' class='delete-btn' >delete</a>";
               $edit_btn =  "<a href='?user_reviews=1&reviewID={$item['id']}'>edit</a>";
               $d = new Diet($item['dietID']);
               $diet = $d->name;
               
               echo "<tr>
               <td>$username</td>
               <td>$diet</td>
               <td>{$item['rating_1']}</td>
               <td>{$item['rating_2']}</td>
               <td>{$item['rating_3']}</td>
               <td>{$item['rating_4']}</td>
               <td>$review</td>
               <td>$delete_btn $edit_btn</td>
               </tr>";               
           }                
        ?>
        </table>
        
        

</div>    

