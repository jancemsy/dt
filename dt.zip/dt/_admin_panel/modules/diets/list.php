<?php
$list = Category::getList(99999, "num", "duration");
$_duration = array();
foreach ($list as $item) {
    $_duration[$item["id"]] = $item["name"];
}




if (empty($catID)) {
    extract(Diet::getAdminList("id DESC"));
    $title = "Diet ";
} else {
    extract(Diet::getAdminList("id DESC", "categories LIKE '%-$catID-%'"));
    $cat = new Category($catID);
    $catName = $cat->name;
    $title = "Diet  / $catName";
}
?> 

<div class="box"> 
    <div class="title"> 
        <h2><?php echo $title; ?></h2> 
<?php echo $_dahide; ?>
    </div> 
    <div class="content pages"> 

        <p><a href="?new=1" class="button">New Diet</a></p> 

        <div class="row" style="position: absolute;width: 320px; border: none;display: block; margin: -40px 10px 10px 580px;  padding: 0 0 15px 0;">      

            <span>Display by:</span>
            <select id="jumper">
                <option value=""  >All</option> 
<?php
$cat = Category::getList(99999, "num", "diet");
foreach ($cat as $item) {
    $selected = $item["id"] == $catID ? "selected" : "";
    echo '<option value="' . $item['id'] . '" ' . $selected . ' >' . $item['name'] . '</option>';
}
?>                                                                                     
            </select>                  

            <script>$(function() {
           $("#jumper").change(function() {
               location.href = '?catID=' + $(this).val();
           });
       });</script>
        </div> 


        <div> 
            <?php echo $pagination; ?>                    
            <div class="clear"></div><br/> 
        </div>




        <table cellspacing="0" class="table">
            <thead>  
                <tr class="tr-header">
                    <td>ID</td>
                    <td>Published</td>  
                    <td>Diet</td>  
                    <!--<td>Duration</td> 
                        <td>Price</td>
                        <td>Discount</td>
                    <td>Total Price</td>  -->
                    <td>Category</td>         
                    <td>Gallery</td>
                    <td>Success Stories</td> 
                    <td>Diet Plans</td> 
                    <td>Status</td> 
                    <td width="60" >Action</td> 
                </tr>
            </thead> 
<?php
$output = "";
$i = 0;
foreach ($list as $item) {

    $specials = $item["special"] == 1 ? "<span style='color:red'>*special*</span>" : "";
    $featured = $item["featured"] == 1 ? "<span style='color:blue'>++featured++</span>" : "";
    $button = "<a href='?delete={$item['id']}' class='delete-btn'>$_dadelete</a>
            <a href='?edit={$item['id']}'>$_daedit</a>";
    $i++;
    $tr_class = $i % 2 == 0 ? "tr-odd" : "tr-even";

    $thumb = ""; // "<img src='".PATH."{$item["thumb"]}' width='80' /> ";

    $gallery = "<a href='diets.php?gallery=1&ID={$item["id"]}' title='click to edit/update gallery' class='clickthis'>" . Gallery::count($item["id"]) . "</a>";
    $stories = "<a href='diets.php?story=1&ID={$item["id"]}' title='click to edit/update stories' class='clickthis'>" . Story::count($item["id"]) . "</a>";

    $categories = Category::getCategoryNamesByIds($item["categories"]);
    $diet_plans = "<a href='diets.php?plans=1&ID={$item["id"]}'  title='click to edit/update diet plans' class='clickthis'>" . DietPlans::count($item["id"]) . "</a>";

    $status = $item["is_published"] ? "published" : "draft";
    $published = $status == "draft" ? "n/a" : $item["publish_date_time"] == "0000-00-00 00:00:00" || $item["publish_date_time"] == "" ? "no data" : $item["publish_date_time"];


    $output .= "<tr class='$status'>
                <td>{$item["id"]}</td>
                <td>$published</td>
                <td><a href='{$item["permalink"]}' target='_blank' ><b>{$item["name"]}</b></a>
                 <br/><i/>{$item["sub_heading"]}</i>
                <br/> $thumb $specials $featured </td>   
                                
                 
                <td>$categories</td> 
                <td align='center'>$gallery</td>
                <td align='center'>$stories</td> 
                <td align='center'>$diet_plans</td> 
                <td>$status</td>
                <td>$button</td></tr>";
}

echo $output;
?>
        </table>

        <div > 
            <div class="clear"></div><br/> 
            <?php echo $pagination; ?>                    
            <div class="clear"></div><br/> 
        </div>

    </div>
</div>    