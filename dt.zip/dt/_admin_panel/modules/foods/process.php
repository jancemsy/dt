<?php

if (!defined("PATH"))
    include_once("../../common.php");

if (isset($_POST["update_search"])) {
    $count = count($_POST["ids"]);

    $id = $_POST["ids"][0];

    for ($i = 0; $i <= $count; $i++) {
        $id = $_POST["ids"][$i];
        $tags = $_POST["search_keywords"][$i];

        $tags = str_replace(array("[","]"),",",$tags);
        $tags = str_replace(",,",",",$tags);
        
        $t = explode(",", $tags);
        $rectags = "";
        foreach ($t as $item) {
            if (!empty($item)) {
                $rectags .= "[".trim($item)."]";
            }
        }

        
        $order = $_POST["search_order"][$i];


        if (!empty($id)) {
            $result = mysql_query("UPDATE food_db 
                  SET search_keywords = '$rectags',
                      search_order = '$order'
                  WHERE id = '$id'");
        }
    }
    die("1");
}
?>