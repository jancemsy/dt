<?php
if (!defined("PATH"))
    include_once("../../common.php");
$display_no = 20;

if (isset($_GET["setids"])) {
    $setids = $_GET["setids"];
    $type = $_GET["type"] == "1" ? "basic" : "non basic";            
    $result = mysql_query("UPDATE 
        food_db SET type = '$type' WHERE
            id IN ($setids) ");    
}



if (isset($_GET["display"])) {
    $display_no = intval($_GET["display"]) > 0 ? intval($_GET["display"]) : $display_no;
    $_SESSION["food_display"] = $display_no;
}

if (isset($_SESSION["food_display"])) {
    $display_no = intval($_SESSION["food_display"]) > 0 ? intval($_SESSION["food_display"]) : $display_no;
}

if (isset($_GET["set_type"])) {
    $_SESSION["food_type_order"] = $_GET["set_type"];
}


extract(FoodDB::getAdminList($display_no));
?>
<table cellspacing="0" class="table" width="100%">
    <thead>  
        <tr class="tr-header">
            <td><input type="checkbox" onclick="clickall(this)" /></td>
            <td><a href="?oid=<?php echo $_GET["oid"] == 2 ? 1 : 2; ?>" style="color:#000; text-decoration: underline;  padding-right:10px;  <?php echo $_id_css; ?> ">ID</a></td> 
            <td><a href="?of=<?php echo $_GET["of"] == 2 ? 1 : 2; ?>" style="color:#000; text-decoration: underline;  padding-right:10px; <?php echo $_food_css; ?>  ">Food</a></td>
            <!-- <td>Serving/size</td>     -->
            
            <td>Grams</td>         
            
            <td>Cal</td>   
            <td>Fat</td>   
            
            <td>Carbs</td> 
            <!--<td>Sugar</td> 
            <td>Protein</td> -->
            
            <td>Type</td> 
            
            <td width="193">
                Search Keywords/order
                <img class="food-result-loader"  style="display:none;    "  src="<?php echo PATH; ?>images/loading-small.gif" />                                        
                &nbsp;
            </td>
            <td width="60">Action</td> 
        </tr>
    </thead> 
<?php
$output = "";
$back = "&back=".urlencode(curPageURL());
foreach ($list as $item) {
    $button = "<a href='?edit={$item["id"]}$back'>edit</a>";    
    $info = unserialize($item["params"]);
    $company = empty($item["company"]) ? "" : htmlentities($item["company"], UTF - 8) . " - ";    
    $food = htmlentities($item["name"], UTF - 8) ;    
    $order = $item["search_order"] == "0" ? "" : $item["search_order"];    
    $tags = $item["search_keywords"];
    $tags = str_replace(array("[","]"),",",$tags);
    $tags = str_replace(",,",",",$tags);        
    if($tags[0] == ",") $tags = substr($tags, 1);
    if($tags[strlen($tags)-1] == ",") $tags = substr($tags, 0, -1);
    
    $output .= "<tr>
                        <td><input type='checkbox' class='ids' value='{$item['id']}' /></td>
                        <td>{$item["id"]}</td>
                        <td width='200'><b>$company</b> $food</td>
                        <!-- <td>{$item["serving"]}x {$item["size"]}</td> -->
                        <td>{$item["grams"]}</td>
                        <td>{$item["calories"]}</td>
                        <td>{$item["fat"]}</td>
                        <td>{$item["carbs"]}</td>
                        <!-- <td>{$item["sugars"]}</td>
                        <td>{$item["protein"]}</td>           -->
                        <td>{$item["type"]}</td> 
                        <td>
                        <input type='text' placeholder='search keywords' name='search_keywords[]' value='$tags'  />
                        <input type='text' placeholder='order' name='search_order[]' value='$order'/>
                        <input type='hidden' name='ids[]' value='{$item["id"]}' />
                        </td>
                        <td>$button</td></tr>";                        
}


echo $output;
?>
</table>