<?php
$display_no = 20;

if (!isset($_SESSION["food_type_order"])) {
    $_SESSION["food_type_order"] = -1;
}


$__up = " background:url(" . PATH . "images/arrow-up-down.gif) right 3px no-repeat  ;";
$__down = " background:url(" . PATH . "images/arrow-up-down.gif) right -15px no-repeat  ;";


$_id_css = "";
$_food_css = "";

if ($_GET["oid"] == 1)
    $_id_css = $__up;
if ($_GET["oid"] == 2)
    $_id_css = $__down;

if ($_GET["of"] == 1)
    $_food_css = $__up;
if ($_GET["of"] == 2)
    $_food_css = $__down;
?> 

<div class="box"> 
    <div class="title"> 
        <h2>Foods</h2> 
        <?php echo $_dahide; ?>

    </div> 
    <div class="content pages"> 

        <form action="" method="get" style="padding-bottom:20px;">
            Search Food: <input name="search-food" type="text"  />
            <input type="submit" value="go" />
            <img class="food-loader" style="display:none;" src="<?php echo PATH; ?>images/loading-small.gif" />         
            <?php
            if ($_GET["search-food"] != "") {
                echo "<div style='border:1px solid #ccc; padding:10px; margin-top:10px; margin-bottom:10px;font-size:14px; '>                
                Search Result: <b>{$_GET["search-food"]}</b> &nbsp;&nbsp;&nbsp;
                    <a href='?'>&laquo; Go Back</a>                                             
                 </div>";
            }
            ?>
        </form>


        <style>
            table.tb {   width:900px!important;  }
            table.tb td{ background:none!important;
                         border:none!important;
                         padding:0px!important;                         
            }
            
            
        </style>
        <table class="tb"  ><tr>
                <td width="50%">
                    Change Selected Items To:  
                    <input type="button" value="Basic" onclick="setSelectedFood(1)" /> 
                    <input type="button" value="Non Basic" onclick="setSelectedFood(0)" />                   
                </td>
                <td width="65%" >

                    
                        
                        Filter by food type:  
                        <label><input type="radio" name="food_type" value="-1" /> All</label> 
                        <label><input type="radio" name="food_type" value="1" /> Basic</label> 
                        <label><input type="radio" name="food_type" value="0" /> Non-basic </label>
                                

                        | 

                        
                        <input  style="position:absolute; "type="button" name="save_search" value="Save Search Keywords" onclick="save_search_keywords()" />                        
                        
                        
                        
                        

                    
                </td>
            </tr>
        </table> 


        <form id="form-list" method="post" >
            <div class="grid-container list-container">
                <?php include("_list.php"); ?>
            </div>
            <input type="hidden" name="update_search" value="1" />
        </form>   

        <div style="padding:10px;">              
            <?php echo $pagination; ?> 
            <div style=" display: block; margin-top: 10px; clear: both!important; float:right;">            
                Display: 
                <select name="display_no" onchange="location.href='?display='+this.value">
                    <option>20</option>
                    <option>50</option>
                    <option>100</option>
                    <option>250</option>
                    <option>500</option>
                    <option>1000</option>                     
                </select>

                or JUMP TO: <input type="text"   placeholder="page" name="jumpto" value="" size="5" style="text-align: center;"/> 
                <input type="button" value="go" onclick="location.href='?page='+$('input[name=jumpto]').val();" />
            </div>
            <div class="clear"></div>                                
        </div>   
    </div>
</div>     


<script>
    var xhr = null;    
<?php echo "$('[name=display_no]').val('$display_no');"; ?>
        
    $(function(){            
        $("input[name=food_type][value=<?php echo $_SESSION["food_type_order"]; ?>]").attr('checked', 'checked');
        $("input[name=food_type]").change(function(){
            var food_type = $("input[name=food_type]:checked").val();
            $.get("modules/foods/_list.php?set_type="+food_type+"<?php echo $_GET["search-food"] ? "&search-food=".$_GET["search-food"] : ""  ?>",function(data){
                $(".list-container").html(data);
            });
        });
    });
    
    function setSelectedFood(food_type){       
        var ids = "0";
        $(".ids:checked").each(function(){
            ids = ids + "," + $(this).val();
        });
        
        $.get("modules/foods/_list.php?setids="+ids+"&type="+food_type,function(data){
            $(".list-container").html(data);
        });
            
        
    }
         
    function clickall(me){
        if($(me).attr("checked")){
            $(".ids").attr("checked","checked");    
        }else{
            $(".ids").attr("checked","");
        }
        
    }
    
    function save_search_keywords(){
        $(".food-result-loader").show();        
        $.post("<?php echo PATH; ?>_admin_panel/modules/foods/process.php",$("#form-list").serialize(),function(result){
            $(".food-result-loader").hide();            
        });        
    }
     
                            

</script>



