<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


$fdb = new FoodDB($_GET["edit"]);


?>


 <div class="box"> 
        <div class="title"> 
                <h2>Foods</h2> 
                <?php echo $_dahide; ?>
        </div> 
     <div class="content form"> 
              <a href='<?php echo $_GET["back"];?>'>&laquo; Go Back</a> <br/><br/>
              
              
              
              <form action="" onsubmit="return checkfields()" method="post">
                  <input type="hidden" name="foodID" value="<?php echo $fdb->id;?>" /> 
              <table>
                  <tr>
                      <td>ID</td>
                      <td><?php echo $fdb->id; ?></td>                      
                  </tr>
                  <tr>
                      <td>Company/Restaurant/Brand</td>
                      <td><input type="text" name="company" value="<?php echo $fdb->company; ?>" /></td>                      
                  </tr>
                  <tr>
                      <td>Name</td>
                      <td><input type="text" name="name" value="<?php echo $fdb->name; ?>" /></td>                      
                  </tr>
                  <tr>
                      <td>Grams</td>
                      <td><input type="text" name="grams" value="<?php echo $fdb->grams; ?>" /></td>                      
                  </tr>
                  <tr>
                      <td>Size</td>
                      <td><input type="text" name="size" value="<?php echo $fdb->size; ?>" /></td>                      
                  </tr>
                  <tr>
                      <td>Calories</td>
                      <td><input type="text" name="calories" value="<?php echo $fdb->calories; ?>" /></td>                      
                  </tr>
                  <tr>
                      <td>Fat</td>
                      <td><input type="text" name="fat" value="<?php echo $fdb->fat; ?>" /></td>                      
                  </tr>
                  <tr>
                      <td>Saturated Fat</td>
                      <td><input type="text" name="saturated" value="<?php echo $fdb->saturated; ?>" /></td>                      
                  </tr>
                  <tr>
                      <td>Polyunsaturated Fat</td>
                      <td><input type="text" name="polyunsaturated" value="<?php echo $fdb->polyunsaturated; ?>" /></td>                      
                  </tr>
                  <tr>
                      <td>Monounsaturated Fat</td>
                      <td><input type="text" name="monounsaturated" value="<?php echo $fdb->monounsaturated; ?>" /></td>                      
                  </tr>
                  <tr>
                      <td>Trans Fat</td>
                      <td><input type="text" name="trans" value="<?php echo $fdb->trans; ?>" /></td>                      
                  </tr>
                  <tr>
                      <td>Cholesterol</td>
                      <td><input type="text" name="cholesterol" value="<?php echo $fdb->cholesterol; ?>" /></td>                      
                  </tr>
                  <tr>
                      <td>Sodium</td>
                      <td><input type="text" name="sodium" value="<?php echo $fdb->sodium; ?>" /></td>                      
                 </tr>
                  <tr>
                      <td>Potassium</td>
                      <td><input type="text" name="potassium" value="<?php echo $fdb->potassium; ?>" /></td>                      
                  </tr>
                  <tr>
                      <td>Carbs</td>
                      <td><input type="text" name="carbs" value="<?php echo $fdb->carbs; ?>" /></td>                      
                  </tr>                 
                  <tr>
                      <td>Fiber</td>
                      <td><input type="text" name="fiber" value="<?php echo $fdb->fiber; ?>" /></td>                      
                  </tr>
                  <tr>
                      <td>Sugars</td>
                      <td><input type="text" name="sugars" value="<?php echo $fdb->sugars; ?>" /></td>                      
                  </tr>
                  <tr>
                      <td>Protein</td>
                      <td><input type="text" name="protein" value="<?php echo $fdb->protein; ?>" /></td>                      
                  </tr>
                  <tr>
                      <td>Calcium</td>
                      <td><input type="text" name="calcium" value="<?php echo $fdb->calcium; ?>" /></td>                      
                  </tr>
                  <tr>
                      <td>Iron</td>
                      <td><input type="text" name="iron" value="<?php echo $fdb->iron; ?>" /></td>                      
                  </tr>
                   <tr>
                      <td>Type of Food</td>
                      <td>
                         <label><input type="radio" <?php if($fdb->type == "basic") echo "checked=true"; ?> name="type" value="basic" />Basic</label>
                         <label><input type="radio" <?php if($fdb->type == "non basic") echo "checked=true"; ?> name="type" value="non basic" />Non Basic</label>                         
                      </td>                      
                  </tr>
                  
              </table>    
                  <input type="submit" name="savefood" value="Save Food" />
                  <input type="button" value="Cancel" onclick="location.href='<?php echo $_GET["back"];?>';" />
              </form>
              
     </div>
 </div>

<script>
  function checkfields(){
      return true;
      var errors = "";
      if( $("input[name='name']").val() == ""){
          errors += "Invalid Name! \n";
      }
      
      var grams = parseInt($("input[name='grams']").val());
      var cal = parseInt($("input[name='calories']").val());
      var size = $("input[name='size']").val();
      
      if(   $("input[name='grams']").val() == "0"){
          errors += "Weight in grams must be higher than 0. \n";
      }else if( grams <= 0 ){
          errors += "Weight in grams should be a number. Must be higher than 0. \n";
      }
      if( cal <= 0 ){
          errors += "Invalid Calories! \n";
      }
      
      if( size == "" ){
          errors += "Invalid Serving Size! \n";
      }
      
      
      
      
      if(errors != ""){
          alert(errors);
          return false;
      }else{
          return true;
      }
  }
</script>    