<?php 
   

if( isset($_POST['crop_images'] ) ){  //ajax call   
       $_SESSION["pending_crop"] = "";
       $width = 295;
       $height = 171;
       $quality = 100;  
       

        $size = count($_POST['h']);

        for($i = 0; $i< $size; $i++){
          $des_h = $_POST['h'][$i];
          $des_w = $_POST['w'][$i];
          $source_x = $_POST['x'][$i];
          $source_y = $_POST['y'][$i];
          $src = $_POST['thumb'][$i];    
          
           if( !empty($des_h) && !empty($src) ){
                    $filename = end(explode("/",$src));
                    $filename = str_replace("-orig","-med",$filename);                        
                    $destination = "../content/recipes/$filename";                    
                    $thumb_dest = "../content/recipes/".str_replace("-med","",$filename);    
                    
                    $ext = strtolower(end(explode(".",$src)));

                    switch ($ext){
                        case "gif":
                          $img_r = imagecreatefromgif($src);
                          break;
                        case "png":
                          $img_r = imagecreatefrompng($src);
                          break;
                        default:
                          $img_r = imagecreatefromjpeg($src);
                          break;
                      }

                    $dst_r = ImageCreateTrueColor( $width , $height );
                    imagecopyresampled($dst_r,$img_r,0,0,$source_x,$source_y ,$width ,$height ,$des_w ,$des_h);

                    @unlink($destination);  //delete the old one
                    switch($ext){
                        case "gif":
                           imagegif($dst_r, $destination);
                          break;
                        case "png":
                           imagepng($dst_r, $destination);
                          break;
                        default:
                           imagejpeg($dst_r, $destination,$quality);
                          break;
                      }
                      
                  @unlink($src);//unlink original                                     
                  @createThumb($destination,$thumb_dest,162,94);          
          }
        }
        die("1");
}



if( !empty($_POST["extractNutrition"])  ){  
     die(recipe::extractNutrition2($_POST["extractNutrition"],$_POST["serving_size"])); 
 }
 
if( isset($_GET["delete"]) ){ 
    $id = $_GET["delete"];
    $recipe = new Recipe($id); 
    @unlink("../".$recipe->thumb);     
    $recipe->delete($id);
    jumpto("recipes.php");
}

if( isset($_GET["catdelete"]) ){ 
    $id = $_GET["catdelete"];
    CategoryRecipe::delete($id);
    jumpto("recipes.php?cat=1"); 
}


if( isset($_POST["save_featured_slots"]) ){
    $list = CategoryRecipe::getList();      
    foreach($list as $item){
       $ids = $_POST["id_".$item["id"]];
       CategoryRecipe::update( array("id" => $item["id"], "featured_ids" => $ids) ); 
    }  
    $success_message = "Category slots have been saved!";
}
 

if( isset($_POST["save_category"]) ){
   $name = addslashes($_POST["name"]);
   $type = addslashes($_POST["type"]);
   $description = addslashes($_POST["description"]);

   $params = array("num" => $_POST["num"], 
                   "featured" => $_POST["featured"],
                   "description" => $description, 
                   "name" => $name, 
                   "type" => $type,                   
                   "meta_title" => $_POST["meta_title"],         
                   "meta_desc" => $_POST["meta_desc"],
                   "meta_keywords" => $_POST["meta_keywords"],
                   "short_desc" => addslashes($_POST["short_desc"]) );
   
   if($_POST["id"] != ""){ 
      $params["id"] = $_POST["id"];
      CategoryRecipe::update($params);   
   }else{
      CategoryRecipe::add($params);     
   }  
   jumpto("recipes.php?cat=1"); 
}

if( isset($_POST["save"]) ){  
    
    $pending_crop = array();
    if(isset($_FILES["upload"]) && $_FILES['upload']["name"] != ""){
        if( !empty($_POST["thumb"]) ) @unlink("../".$_POST["thumb"]);
        $name = $_FILES['upload']["name"];
        $ext   = end(explode(".",$name));
        $time = time();                 
        $filename = "$time.$ext";
        $thumb_dest = "../content/recipes/$filename";
        $orig_dest = "../content/recipes/$time-orig.$ext"; 
        $med_dest = "../content/recipes/$time-med.$ext"; 
         
        move_uploaded_file($_FILES["upload"]["tmp_name"], $orig_dest );         
        @createThumb($orig_dest,$thumb_dest,162,94); 
        @createThumb($orig_dest,$med_dest,295,171);  
        $pending_crop[] = $orig_dest;        
        $_POST["thumb"] = "content/recipes/$filename";
     }
       
     
     $csize = count($_POST["category"]);
     $categories = "";
     for($i = 0; $i <= $csize; $i++){
         if($_POST["category"][$i] != ""){
           $categories .= "-".$_POST["category"][$i]."-";
         }
     }
     
      
     
     
     $da = count($_POST["directions_arr"]);          
     if( $da > 0 ){
         $output = "";
         for($i = 0; $i <= $da; $i++){
            if($_POST["directions_arr"][$i] != ""){
              $output .= $_POST["directions_arr"][$i]."\n";
            }            
        }
        $_POST["directions"] = $output;
     }
     
     $ia = count($_POST["ingredients_arr"]);                   
     if( $ia > 0 ){         
         $output = "";
         for($i = 0; $i <= $ia; $i++){
            if($_POST["ingredients_arr"][$i] != ""){
              $output .= $_POST["ingredients_arr"][$i]."\n";
            }
        }        
        $_POST["ingredients"] = $output;
        
     }
     
     $na = count($_POST["nutritions_arr"]);                   
     if($na > 0){
      $output = "";
      $output .= $_POST["nutritions_arr"][0]." fat\n";
      $output .= $_POST["nutritions_arr"][1]." saturated fat\n";
      $output .= $_POST["nutritions_arr"][2]." trans fat\n";
      $output .= $_POST["nutritions_arr"][3]." cholesterol\n";
      $output .= $_POST["nutritions_arr"][4]." sodium\n";
      $output .= $_POST["nutritions_arr"][5]." carbohydrate\n";
      $output .= $_POST["nutritions_arr"][6]." fiber\n";
      $output .= $_POST["nutritions_arr"][7]." sugar\n";
      $output .= $_POST["nutritions_arr"][8]." protein\n";
      $output .= $_POST["nutritions_arr"][9]." calories\n";      
      $_POST["nutritions"] = $output;
     }
      
      
     
     $nutritions = array();             
     
     $nutritions = serialize( array(
                    "serving_size" => $_POST["serving_size"],         
                    "content" => $_POST["nutritions"],
                    "number_of_servings" => $_POST["number_of_servings"]) );
     
     
     $params = array(
                     "publish_date_time" => clean_data($_POST["publish_date_time"]),
                     "meta_title" => addslashes($_POST["meta_title"]),         
                     "meta_desc" => addslashes($_POST["meta_desc"]),
                     "meta_keywords" => addslashes($_POST["meta_keywords"]),
         
         
                     "ingredients" => addslashes($_POST["ingredients"]),
                     "directions" => addslashes($_POST["directions"]),
                     "nutritions" =>  addslashes($nutritions),
                     "categories" => $categories,
                     "title" => addslashes($_POST["title"]),
                     "text" => addslashes($_POST["text"]),  
                     "short_desc" => addslashes($_POST["short_desc"]),
                     "thumb" => $_POST["thumb"],            
                     "preparation_time" => $_POST["preparation_time"],
                     "cooking_time" => $_POST["cooking_time"],
                     "total_time" => $_POST["total_time"],                     
                     "calorie" => $_POST["calorie"],
                     "protein" => $_POST["protein"], 
                     "carb" => $_POST["carb"],
                     "fat" => $_POST["fat"],
                     "is_published" => $_POST["is_published"]
             );
     
    
     if($_POST["id"] != ""){
        $params["id"] = $_POST["id"];
        recipe::update($params); 
        $id = $_POST["id"];
     }else{
        $id = recipe::add($params); 
     }
     
   if(count($pending_crop) > 0 ){
         $_SESSION["pending_crop"] = serialize($pending_crop);
         jumpto("recipes.php?crop=1"); 
     }
     
     jumpto("recipes.php"); 
}
 

?> 