<script type="text/javascript">

    function checkthis(target) {
        var ids = "";

        $("." + target).each(function() {
            if ($(this).attr("checked")) {
                ids += "-" + $(this).val() + "-";
            }
        });

        $("#" + target).val(ids);
    }

    function opencat() {
        $(".tabdiv").hide();
        $($("#catmenu").val()).show();
    }
</script>
<style type="text/css">
    .featured_slots{   width: 900px; }
    .featured_slots .checkbox{ }
    .featured_slots .item{ margin: 5px; margin-left:10px; width: 100px; height: 110px; border: 1px solid #ccc; padding: 5px; float: left;}
    #catmenu { padding: 2px 10px 2px 10px!important; background:#eee; border: 2px solid #ccc;  font-size: 15px!important; }
</style>

<div class="box"> 
    <div class="title"> 
        <h2><?php echo $title; ?></h2> 
        <?php echo $_dahide; ?>
    </div> 
    <div class="content tabs" style="width:100%">                  
        <form action="" method="post">     
            <input type="hidden" name="selectedcat" />

            <?php
            if (!empty($success_message))
                echo "<div class=\"message blue\" style=\"margin:10px;\">$success_message</div>";

            $list = CategoryRecipe::getList();

            $output = "";
            $tab_menu = "";
            $i = 0;
            foreach ($list as $item) {
                if ($item["recipe_count"] > 0) {
                    $i ++;

                    if ($_POST["selectedcat"] == "")
                        $_POST["selectedcat"] = "#tab$i";
                    $tab_menu .= ' <li><a href="#tab' . $i . '">' . $item["name"] . '</a></li> ';
                    $tab_option .= '<option value="#tab' . $i . '" ' . ( $_POST["selectedcat"] == "#tab$i" ? "selected" : "") . ' >' . $item["name"] . '</option>';


                    $output .= '<div id="tab' . $i . '" ' . ( $_POST["selectedcat"] == "#tab$i" ? "" : "style='display:none;'") . ' class="tabdiv"> 
               <input type="hidden" name="id_' . $item["id"] . '" value="' . $item["featured_ids"] . '" id="cat_' . $item["id"] . '" />                 
                
             <div class="featured_slots"  >';

                    $result = Recipe::getListByCatId($item["id"], 9999999);
                    $recipes_list = $result["list"];

                    foreach ($recipes_list as $recipe) {
                        $output .= '
                 <div class="item">
                     <label><input type="checkbox" ' . (search("-" . $recipe["id"] . "-", $item["featured_ids"]) ? "checked=checked" : "") . '  class="checkbox cat_' . $item["id"] . '" value="' . $recipe["id"] . '"  onclick="checkthis(\'cat_' . $item["id"] . '\')" />' .
                                $recipe["title"] . '</label>  <br/>
                     <img src="' . PATH . $recipe["thumb"] . '" width="100" />
                    </div>';
                    }

                    $output .= ' <div class="clear"></div> </div> 
                </div>';
                }
            }



            echo "<div style='text-align:right; padding:10px;'>Select Recipe Category: <select id='catmenu' name='selectedcat' onchange='opencat()'>$tab_option</select>"
            . "</div> $output";
            //  echo "<ul class=\"tabnav\"> $tab_menu</ul> $output"; 
            ?>


            <div class="row buttons" style="padding:10px; border: none;">                     
                <button type="submit" name="save_featured_slots"><span>Save</span></button>                                                
            </div>

        </form>   

    </div>
</div>    
