<?php
if (empty($catID)) {
    extract(Recipe::getAdminList(1, 20));
    $title = "Recipe ";
} else {
    extract(Recipe::getAdminList("categories LIKE '%-$catID-%'", 20));
    $cat = new Category($catID);
    $catName = $cat->name;
    $title = "Recipe  / $catName";
}
?>  
<div class="box"> 
    <div class="title"> 
        <h2><?php echo $title; ?></h2> 
<?php echo $_dahide; ?>
    </div> 
    <div class="content pages"> 

        <p><a href="?new=1" class="button">New Recipe</a></p>   
        <div class="row" style="position: absolute;width: 320px; border: none;display: block; margin: -40px 10px 10px 580px;  padding: 0 0 15px 0;">      

            <span>Display by:</span>
            <select id="jumper">
                <option value=""  >All</option> 
<?php
$cat = CategoryRecipe::getList();
foreach ($cat as $item) {
    $selected = $item["id"] == $catID ? "selected" : "";
    echo '<option value="' . $item['id'] . '" ' . $selected . ' >' . $item['name'] . '</option>';
}
?>                                                                                     
            </select>                  

            <script>$(function() {
           $("#jumper").change(function() {
               location.href = '?catID=' + $(this).val();
           });
       });</script>
        </div> 


        <div> 
<?php echo $pagination; ?>                    
            <div class="clear"></div><br/> 
        </div>
        <table cellspacing="0" class="table">
            <thead> 
                <tr class="tr-header">
                    <td>ID</td>
                    <td>Published</td>  
                    <td width="200">Title</td>     
                    <td width="160">Category</td>    
                    <td><a href="#" title="Popular Count">#</a></td>
                    <td>Status</td> 
                    <td width="70">Action</td> 
                </tr>
            </thead> 
<?php
$output = "";
$i = 0;
foreach ($list as $item) {
    $button = "<a href='?delete={$item['id']}' class='delete-btn'>$_dadelete</a>  
         <a href='?edit={$item['id']}'>$_daedit</a>";
    $i++;
    $tr_class = $i % 2 == 0 ? "tr-odd" : "tr-even";
    //$thumb = "<img src='".PATH."{$item["thumb"]}' width='80' /> ";  
    $text = string_cut(strip_tags($item["short_desc"]), 250);
    $categories = CategoryRecipe::getCategoryNamesByIds($item["categories"]);
    $count = intval($item["popular_count"]);
    $status = $item["is_published"] ? "published" : "draft";
    $published = $status == "draft" ? "n/a" : $item["publish_date_time"] == "0000-00-00 00:00:00" || $item["publish_date_time"] == "" ? "no data" : $item["publish_date_time"];

    $output .= "<tr class='$status'>
                <td>{$item["id"]}</td>
                <td>$published</td>
                <td><a href='{$item["permalink"]}' target='_blank'>{$item["title"]}</a></td>        
                
               <!--  <td>$text</td>  -->
                <td class='category'>$categories</td>
                <td>$count</td>
                <td>$status</td>
                <td>$button</td></tr>";
}
echo $output;
?>
        </table>
    </div>
</div>     