<?php

$type = "Add";
if( isset($_GET["edit"]) ){
    $id = $_GET["edit"]; 
    
    $recipe = new Recipe($id);
    $_POST = $recipe->array;     
              
    $tmp = unserialize($recipe->array["nutritions"]);     
    $_POST["serving_size"] = $tmp["serving_size"];
    $_POST["nutritions"] = $tmp["content"];
    $_POST["number_of_servings"] = $tmp["number_of_servings"];
    
    $type = "Edit";                                  
}

?>
<style>
    #ingredients-result ul{ padding:0px; }
    #ingredients-result ul li{ background: url(<?php echo PATH; ?>images/list-item-green.jpg) no-repeat 0px 10px; padding: 5px 5px 5px 15px; border-bottom: 1px solid #ccc; }      
    #direction-result{  }
    #direction-result ul{ padding:0px; }
    #direction-result ul li{ list-style:none; padding: 5px 5px 5px 0px; }    
    
    #nutrition-result li{ list-style:none!important; }
    #nutrition-result table.admin-table { font-size: 10px; border: 3px solid #000; }
    #nutrition-result table.admin-table  td{ width: 90px;  border-bottom: 1px solid #000; padding-left: 10px; }    
    #nutrition-result table.admin-table  .nutri-title{ width: 450px; }
    
   
    #nutrition-result table.admin-table  td.nutri-sub{ padding-left: 30px; }    
    #nutrition-result .nutri-head{  background: #000; color:#fff;}    
    #nutrition-result .nutri-bold{ font-weight: bold; color: #000; }
    
    
    
</style>
    

<div class="box"> 
            <div class="title"> 
                    <h2><?php echo $type; ?> Recipe</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms">

<form action="" method="post" enctype="multipart/form-data"   >
    <input type="hidden" name="id" value="<?php echo $_POST['id']; ?>" />
    <input type="hidden" name="thumb" value="<?php echo $_POST['thumb']; ?>" />
    
    <table   width="700">
         <tr><td>Status:</td>
        <td>
                        <select name="is_published" onchange=" $(this).val() == '1' ? $('.publish_box').show() : $('.publish_box').hide();
                                " >
                            <option value="1">Publish</option>
                            <option value="0" <?php if ($_POST["is_published"] == 0) echo "selected"; ?> >Draft</option></select>


                        <span class="publish_box" <?php if ($_POST["is_published"] == 0) {
            echo "style='display:none;'";
        } ?>  >
                            <input type="text" id="datetimepicker" name="publish_date_time" placeholder="Enter publish time"   value="<?php echo $_POST['publish_date_time']; ?>" />  
                        </span> 

                    </td></tr> 
        <tr><td>Meta Title <counter style="display:none" max="70" required="1" target="input[name=meta_title]'"></counter>:</td><td>  <input type="text" name="meta_title" class="text-input" value="<?php echo $_POST['meta_title']; ?>" /></td></tr> 
        <tr><td>Meta Desc <counter style="display:none" max="155" required="1" target="input[name=meta_desc]'"></counter>:</td><td>  <input type="text" name="meta_desc" class="text-input" value="<?php echo $_POST['meta_desc']; ?>" /></td></tr> 
        <tr><td>Meta Keywords:</td><td>  <input type="text" name="meta_keywords" class="text-input" value="<?php echo $_POST['meta_keywords']; ?>" /></td></tr> 
         <tr>
            <td  >Title:</td>
            <td class="row clean-row">
                <input type="text" name="title" value="<?php echo $_POST['title']; ?>"  /></td>                        
         </tr>
         <tr>
            <td>Description:</td><td><textarea   name="text"  cols="100" class="mceEditor"  ><?php echo $_POST['text']; ?></textarea></td>                        
          </tr>
          <tr>
            <td>Short Desc:</td><td><textarea   name="short_desc" cols="100"    class="mceEditor"  ><?php echo $_POST['short_desc']; ?></textarea></td>                        
          </tr> 
          <tr><td>Thumbnail: <br/>
                  182px × 107px JPG only:</td><td>
            <div class="row">
             <input type="file" size="46"  name="upload"  />             
            </div>
             <?php
             if( !empty($_POST["thumb"]) ){
                 echo ' <br/> <img src="'.PATH.$_POST["thumb"].'" width="100" /> ';                                  
             }
             ?>             
        </td></tr> 
        
          <tr>
              <td>Category:</td>                  
              <td>  
                    <?php
                       $list = CategoryRecipe::getList();    
                        
                       foreach($list as $item){                         
                           if( search("-{$item["id"]}-",$_POST["categories"]) ){
                             echo "<label><input type='checkbox' checked=checked name='category[]' value='".$item["id"]."' /> ".$item["name"]." </label> <br/>"; 
                           }else{
                             echo "<label><input type='checkbox' name='category[]' value='".$item["id"]."' /> ".$item["name"]." </label> <br/>"; 
                           }
                       }
                    ?> 
              </td></tr> 
          
          
          <tr><td colspan="2"><br/></td></tr>
          
          
          
         <tr><td colspan="2"><br/></td></tr>
          
          <tr>
              <td valign="top"><b>Ingredients</b>
                   (separated by new line)
              </td>
              <td >
                 
                  <div class="row" style="border:none; ">
                    <textarea  name="ingredients"  style="width:800px; height: 80px;"><?php echo $_POST["ingredients"]; ?></textarea> <br/>                    
                    <button type="button" onclick="process_ingredients()" style="margin-top:10px;" ><span>Process</span></button>                        
                  </div>
                   <div id="ingredients-result"></div> 
              </td>
          </tr> 
          
          <tr><td colspan="2"><br/></td></tr>
          
           <tr>
              <td valign="top"><b>Directions</b>
                  (separated by new line)
              </td>
              <td>
                  
                 
                 
                  <div class="row" style="border:none; ">
                    <textarea name="directions" style="width:800px; height: 80px;"><?php echo $_POST["directions"]; ?></textarea> <br/>
                    <button type="button" onclick="process_direction()" style="margin-top:10px;" ><span>Process</span></button>                     
                  </div>
                  <div id="direction-result"></div>
                    
         
              </td>
          </tr>   
         
                      
          <tr><td><br/></td><td></td></tr>
          
          <tr>
                 <td > Serving Size:</td>
                  <td><input name="serving_size" value="<?php echo !empty($_POST["serving_size"]) ? $_POST["serving_size"] : "250g" ; ?>" type="text" /></td>                          
           </tr>
           
           
            <tr>
              <td valign="top"><b>Nutritions</b>
                  
                  
                  
              </td>
              <td>  
                  
                  <div class="row" style="border:none; ">
                    <textarea name="nutritions" style="width:800px; height: 80px;"><?php echo $_POST["nutritions"]; ?></textarea> <br/>
                    <small>*Enter nutritions to be extracted like: <Br/>
                      10g fat <br/>
                  20 carbohydrate <br/>
                  and soon... <br/>
                    </small>
                    <button type="button" onclick="process_nutrition()" style="margin-top:10px;" ><span>Process</span></button>                     
                  </div>
                  <div id="nutrition-result"></div> 
                  
                  
              </td>
          </tr> 
          
          
          <tr><td><br/></td><td></td></tr>
          <tr><td><b>Recipe Overview</b></td>
              <td>
                  <table class="row clean-row-small">
                      <tr>
                          <td>Preparation time:</td>
                          <td ><input type="text" name="preparation_time" value="<?php echo $_POST["preparation_time"]; ?>" /> </td>                          
                      </tr>
                      <tr>
                          <td>Cooking time:</td>
                          <td><input type="text" name="cooking_time" value="<?php echo $_POST["cooking_time"]; ?>" /> </td>
                      </tr>
                      <tr>
                          <td>Total time:</td>
                          <td><input type="text" name="total_time" value="<?php echo $_POST["total_time"]; ?>"  /></td>
                      </tr>
                      
                      <tr>
                          <td>Number of Servings:</td>
                          <td><input type="text" name="number_of_servings" value="<?php echo $_POST["number_of_servings"]; ?>"  /></td>
                      </tr>
                      </table>                                                            
                   
              </td>              
          </tr>
            
          
          
        <tr>
            <td colspan="2"> 
              
               
                <div class="row buttons"> 
                   <button type="button" onclick="location.href='?'" ><span>Back</span></button>                                                
                   <button type="submit" name="save"><span>Save</span></button>                                                
                </div>
              
            </td>                        
        </tr>
        
    </table>
</form>


<script type="text/javascript">        
    $(function(){
         if($("textarea[name='directions']").val() != ""){
             process_direction();
         }
         
         if($("textarea[name='ingredients']").val() != ""){
             process_ingredients();
         }
         
         if($("textarea[name='nutritions']").val() != ""){
             process_nutrition();
         }                  
          $('#datetimepicker').datetimepicker();
    });
    
    
    function process_nutrition(){    
        if( jQuery.trim($("textarea[name='nutritions']").val()) == "") return false;    
        $.post("recipes.php",{"extractNutrition" :  $("textarea[name='nutritions']").val() ,"serving_size" : $("input[name='serving_size']").val()},function(output){
                     //output += " <!-- <a href='javascript:;' onclick='$(\"#nutrition-result\").html(\"\")'>[clear result]</a> -->";
                     $("#nutrition-result").html(output);
                     $("textarea[name='nutritions']").val("");
        });        
    } 
    
    function process_direction(){
        var strVal = $("textarea[name='directions']").val();
        if( jQuery.trim(strVal) == "") return false;
            
        $("textarea[name='directions']").val("");
        var splitArr = strVal.split("\n");
        var intCount = 0;
        var output = "<ul>";
        var str = "";
        while(intCount < splitArr.length)
        {
             str = splitArr[intCount]; 
             str = jQuery.trim(str);
             if( str != ""){
                 output += "<li><textarea cols='80' name='directions_arr[]'>"+str+"</textarea></li>";                
             }
              intCount += 1;
               
        }
        output += "</ul> <!-- <a href='javascript:;' onclick='$(\"#direction-result\").html(\"\")'>[clear result]</a> -->";
        $("#direction-result").html(output);
    }
    
    function process_ingredients(){
        var strVal = $("textarea[name='ingredients']").val();
        if( jQuery.trim(strVal) == "") return false;    
        $("textarea[name='ingredients']").val("");
        var splitArr = strVal.split("\n");
        var intCount = 0;
        var output = "<ul>";
        var str =  "";
        while(intCount < splitArr.length)
        {
             str = splitArr[intCount];   
             str = jQuery.trim(str);             
             if(str != ""){
                 output += "<li><input type='text' name='ingredients_arr[]' value=\""+str+"\" size='100' /></li>";                
             }
              intCount += 1;
        }
        output += "</ul> <!-- <a href='javascript:;' onclick='$(\"#ingredients-result\").html(\"\")'>[clear result]</a> -->";
        $("#ingredients-result").html(output);
    }
        
       
    initMCET('.mceEditor');      
</script>   

    </div>
</div>    