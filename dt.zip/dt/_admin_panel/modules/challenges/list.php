<?php
$list = Challenges::getList();
?>
<style>
    tr.inactive *{ color:#ccc!important; text-decoration: line-through; }
</style>

<div class="box"> 
    <div class="title"> 
        <h2>Challenges</h2> 
        <?php echo $_dahide; ?>
    </div> 
    <div class="content pages"> 

        <p align='right'>


            <a href="config_challenges_main.php">Configure Challenge Main</a> | 
            <a href="?icons=1">Icon List</a> |
            <a href="?newicon=1">Create New Icon</a> | <a href="?new=1">Create New Challenge</a> </p>

        <table>
            <tr>
                <td>id</td> 
                <td>Challenge Name</td>
                <td>Ending Date/Status</td>
                <td>Participants</td>
                <td>Action</td> 
            </tr>
            <?php
            foreach ($list as $item) {
                $class = $item["active"] == "0" ? "inactive" : "";
                ?>
                <tr class="<?php echo $class; ?>">
                    <td><?php echo $item["id"]; ?></td>
                    <td><?php echo $item["name"]; ?></td>
                    <td><?php
                        echo $item["ending_date"] == "0000-00-00" ? "ongoing" : $item["ending_date"];
                        ?></td>

                    <td align="center">
                        
                        
                            <?php
                            $result = mysql_query("SELECT COUNT(DISTINCT userID) as cnt FROM challenge_participants 
    WHERE challengeID = '{$item["id"]}'  ");
                            $row = mysql_fetch_array($result);
                            $countJoined = $row[0];

                            if($countJoined > 0){
                              echo '<a href="?participants='.$item["id"].'" style="color:blue; font-weight: bold; text-decoration: underline;" title="number of participants" >'.$countJoined.'</a>';
                            }else{
                                echo "0";
                            }
                            ?>  
                    </td>
                    <td>
                        <a href="?duplicate=<?php echo $item["id"]; ?>">duplicate challenge</a> | 

                        <a href="?edit=<?php echo $item["id"]; ?>">edit</a></td>
                </tr> 
            <?php } ?>  
        </table>
    </div>
</div>    

