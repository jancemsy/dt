<?php

$path = "../content/challenges/challenge1/";

$icon_path = "../content/challenges/challenge_icons/";

$top_splash_path = "../content/challenges/splash/";

if (!file_exists("../content/challenges/")) {
    mkdir("../content/challenges");
}

if (!file_exists($icon_path)) {
    mkdir($icon_path);
}

if (!file_exists($top_splash_path)) {
    mkdir($top_splash_path);
}

if (!file_exists($path)) {
    mkdir($path);
}

$resource_list = array("workouts", "recipes", "articles", "calendar",
    "events", "graphical", "prize");

$sizes = array("workouts" => "182|115",
    "recipes" => "182|115",
    "articles" => "182|115",
    "calendar" => "182|115",
    "events" => "105|78",
    "graphical" => "413|189",
    "prize" => "157|94");


if (isset($_POST["submit_icon"])) {
    if (isset($_FILES["upload"]) && $_FILES['upload']["name"] != "") {
        $filename = time() . ".png";
        move_uploaded_file($_FILES["upload"]["tmp_name"], $icon_path . $filename);
    } else {
        $filename = $_POST["filename"];
    }

    $params = array("filename" => $filename, "name" => $_POST["name"]);


    if ($_POST["id"] != "") {
        $params["id"] = $_POST["id"];
        ChallengeIcons::update($params);
    } else {
        ChallengeIcons::add($params);
    }


    jumpto("?icons=1");
}


if (isset($_GET["checkkey"])) {
    $key = $_GET["checkkey"];
    $id = $_GET["id"];
    if (Challenges::checkKeyAvailable($key, $id)) {
        die("1");
    } else {
        die("0");
    }
}

if (isset($_POST['crop_images'])) {  //ajax call   
    $_SESSION["pending_crop"] = "";
    $quality = 100;

    $count = count($_POST['h']);

    for ($i = 0; $i < $count; $i++) {
        $des_h = $_POST['h'][$i];
        $des_w = $_POST['w'][$i];
        $width = $_POST['_w'][$i];
        $height = $_POST['_h'][$i];
        $source_x = $_POST['x'][$i];
        $source_y = $_POST['y'][$i];
        $size = empty($_POST['size'][$i]) ? "" : "-" . $_POST['size'][$i];
        $src = $_POST['thumb'][$i];

        if (!empty($des_h) && !empty($src)) {
            $filename = end(explode("/", $src));
            $destination = $path . $filename;
            $ext = strtolower(end(explode(".", $src)));
            switch ($ext) {
                case "gif":
                    $img_r = imagecreatefromgif($src);
                    break;
                case "png":
                    $img_r = imagecreatefrompng($src);
                    break;
                default:
                    $img_r = imagecreatefromjpeg($src);
                    break;
            }

            $dst_r = ImageCreateTrueColor($width, $height);
            imagecopyresampled($dst_r, $img_r, 0, 0, $source_x, $source_y, $width, $height, $des_w, $des_h);

            switch ($ext) {
                case "gif":
                    imagegif($dst_r, $destination);
                    break;
                case "png":
                    imagepng($dst_r, $destination);
                    break;
                default:
                    imagejpeg($dst_r, $destination, $quality);
                    break;
            }
        }//if 
    }//for

    die("1");
}

function renderThumb($src) {
    if (!empty($src)) {
        return '<img src="../' . $src . '" height="20" class="no-need" />';
    } else {
        return '';
    }
}

function renderDim($res) {
    global $sizes;
    list($w, $h) = explode("|", $sizes[$res]);
    return "$w x $h px (JPG)";
}

if (!defined("PATH"))
    include_once("../../common.php");



if($_GET["duplicate"] != ""){
    $id = $_GET["duplicate"];     
    Challenges::duplicate($id);
    jumpto("?");
}
                
if (isset($_POST["submit_challenge"])) {


    /* processing jpg */
    $pending_crop = array();

    foreach ($resource_list as $resource) {
        $count = $_POST[$resource . "_count"];
        for ($j = 1; $j <= $count; $j++) {
            $upload_name = $resource . "_thumb_upload$j";
            if (isset($_FILES[$upload_name]) && $_FILES[$upload_name]["name"] != "") {
                $t = time() . $resource . $j;
                $fieldname = $resource . "_thumb$j";
                if (!empty($_POST[$fieldname]))
                    @unlink("../" . $fieldname);
                $name = $_FILES[$upload_name]["name"];
                $ext = end(explode(".", $name));
                $filename = "$t.$ext";
                $thumb_dest = $path . $filename;
                $_POST[$fieldname] = str_replace("../", "", $path . $filename);
                list($width, $height) = explode("|", $sizes[$resource]);
                move_uploaded_file($_FILES[$upload_name]["tmp_name"], $thumb_dest);
                $pending_crop[] = array("image" => $thumb_dest,
                    "width" => $width, "height" => $height, "caption" => "");
            }


            if ($resource == "calendar") { //if calendar, lets check and process a special upload 
                $upload_name = $resource . "_file_upload$j";
                if (isset($_FILES[$upload_name]) && $_FILES[$upload_name]["name"] != "") {
                    $t = time() . $resource . $j;
                    $fieldname = $resource . "_link$j";
                    if (!empty($_POST[$fieldname]))
                        @unlink("../" . $fieldname);
                    $name = $_FILES[$upload_name]["name"];
                    $ext = end(explode(".", $name));
                    $filename = "$t.$ext";
                    $thumb_dest = $path . $filename;
                    $_POST[$fieldname] = str_replace("../", "", $path . $filename);
                    move_uploaded_file($_FILES[$upload_name]["tmp_name"], $thumb_dest);
                }
            }
        }
    }

    ////////////////////////////////////////////////////////////////
    $array = array();


    if (isset($_FILES["top_splash_upload"]) && $_FILES['top_splash_upload']["name"] != "") {
        $filename = time() . ".png";
        move_uploaded_file($_FILES["top_splash_upload"]["tmp_name"], $top_splash_path . $filename);
    } else {
        $filename = $_POST["top_splash"];
    }


    foreach ($_POST as $field => $val) {
        $array[$field] = urlencode($val);
    }


    $array["top_splash"] = $filename;

    $serialized = serialize($array);



    $array = array("params" => $serialized,
        "name" => $_POST["name"],
        "ending_date" => $_POST["ending_date"] != "" ? date("Y-m-d", strtotime($_POST["ending_date"])) : "",
        "url_key" => $_POST["url_key"],
        "active" => $_POST["active"],
        "params" => $serialized);




    if ($_POST["id"] != "") {
        $array["id"] = $_POST["id"];
        Challenges::update($array);
    } else {
        Challenges::add($array);
    }
    /////////////////////////////////////////////////////////////// 
    //Config::update("challenge1_cms", $_POST);


    if (count($pending_crop) > 0) {

        $_SESSION["pending_crop"] = serialize($pending_crop);
        $_SESSION["goback"] = "challenges.php";
        jumpto("?crop=1");
    } else {
        jumpto("?");
    }
}
?>