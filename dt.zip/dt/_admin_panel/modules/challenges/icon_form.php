<?php
error_reporting(E_ERROR | E_PARSE); 

if(isset($_GET["editicon"])){
    $icon = new ChallengeIcons($_GET["editicon"]);
    $_POST = $icon->array;
}
?>
<style>
    .hide-prize{ display:none; }
    input[type=text]{ width: 200px; }
    textarea{ width: 470px; height: 80px; }
    .graphical_entry, 
    .events_entry,
    .workouts_entry,
    .recipes_entry,
    .articles_entry,
    .calendar_entry{ border: 1px solid #ccc; margin:5px 0 5px 0; padding: 10px; }

    .removebtn { width:60px!important;  }

    hr{ color: #eee; }
</style> 

<div class="box"> 
    <div class="title"> 
        <h2>Icon Form</h2> 
        <?php echo $_dahide; ?>
    </div> 
    <div class="content forms">
        <form id='thisform' action="" method="post" enctype="multipart/form-data"    >
            
            <input type="hidden" name="submit_icon" value="1" /> 
            <input type="hidden" name="filename" value="<?php echo $_POST["filename"]; ?>" /> 
            <input type="hidden" name="id" value="<?php echo $_POST["id"]; ?>" /> 
            
            
            <table>  
                <tr><td>Icon Name:</td>
                    <td>  <input type="text" name="name" class="text-input" value="<?php echo $_POST['name']; ?>" /> 
                    </td></tr> 
                
                <tr><td>Icon: <br/>(PNG ONLY 64x64px)</td><td><div  class="row">    
                            <input type="file" size="46"  name="upload" class="upload"  />             
                            
                        </div></td></tr>
            </table>
            <div class="row buttons fixed-buttons"   > 
                <button type="button" onclick="location.href = '?'" ><span>&laquo; Back</span></button>                                                
                <button type="submit" class="save-btn" ><span>Save</span></button>     
                <img src="../images/loading-small.gif" class="loader" style="display:none"/>
                <span class="status"></span>
            </div>
        </form>
    </div>
</div>     
