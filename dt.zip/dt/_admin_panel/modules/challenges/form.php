<?php
error_reporting(E_ERROR | E_PARSE);
//print_r($_POST);exit();
?>
<style>
    #challenges-bg-template{ width:435px; height:225px;   background: url(../images/challenges/challenges-bg-template.jpg) no-repeat; }  
    #challenges-bg-template.bg1{ background-position: -10px -10px; }
    #challenges-bg-template.bg2{ background-position: -470px -10px; }
    #challenges-bg-template.bg3{ background-position: -10px -277px; }
    #challenges-bg-template.bg4{ background-position: -470px -277px; }
    #challenges-bg-template.bg5{ background-position: -10px -544px; }
    #challenges-bg-template.bg6{ background-position: -470px -544px; }
    #challenges-bg-template.bg7{ background-position: -10px -810px; }
    #challenges-bg-template.bg8{ background-position: -470px -810px; }



    .hide-prize{ display:none; }
    input[type=text]{ width: 200px; }
    textarea{ width: 470px; height: 80px; }
    .graphical_entry, 
    .events_entry,
    .workouts_entry,
    .recipes_entry,
    .articles_entry,
    .calendar_entry{ border: 1px solid #ccc; margin:5px 0 5px 0; padding: 10px; }

    .removebtn { width:60px!important;  }

    hr{ color: #eee; }
</style>

<script>
    var _bg = 1;

    function moveBG() {
        _bg++;

        if (_bg > 8) {
            _bg = 1;
        }

        $("#challenges-bg-template").attr("class", "bg" + _bg);
        $(".theme").val(_bg);
    }


    function AddEntry(target) {
        $("." + target + "_entry input[type=radio]").each(function() {
            if ($(this).attr("checked")) {
                $(this).attr("ischecked", "1");
            } else {
                $(this).attr("ischecked", "");
            }
        });

        var cls = "" + target + "_entry";
        var $first = $("." + cls).eq(0);
        var html = "<table class='" + cls + "'>" + $first.html() + "</table>";
        var $x = $(html);
        $x.find("input:not([type=radio]),textarea").val("");
        $x.find(".no-need,.attached").remove();

        $x.insertBefore($first);
        $(".removebtn").val("Remove");
        fixEntryOrder(target);
    }

    function removeEntry(button, target) {

        var cls = "" + target + "_entry";
        var $cls = $("." + cls);

        if ($cls.length > 1) {
            $(button).parent().parent().parent().parent().remove();
            //$cls.eq($cls.length - 1).remove();           
            fixEntryOrder(target);
        } else {
            alert("Sorry, the initial entry cannot be deleted!")
        }

    }

    function checkprize() {
        if ($("input[name=isprizeactive4]").val() == "1") {
            $("input[name=isprizeactive4]").val("0");
            $(".other_prize").addClass("hide-prize");
            $(".toogleprize").val("[Add Other Prize");
        } else {
            $("input[name=isprizeactive4]").val("1");
            $(".other_prize").removeClass("hide-prize");
            $(".toogleprize").val("[Remove Other Prize");
        }
    }


    function fixEntryOrder(target) {
        var count = 0;

         //alert($("." + target + "_entry").length);

        $("." + target + "_entry").each(function() {
            count++;
             
            
            $(this).find(".item_label").text( target + " " + count);
            
                    
             $(this).find("input,textarea").each(function() {
                
                
                        
              //  /*  
              var attr = $(this).attr('name');
 
               try{ 
                if (  attr != false && attr != "" && attr != "undefined" ) {
                    var name = $(this).attr("n");    
                    $(this).attr("name", name + "" + count);
                    
                                    
                    //$(this).val(name); 
                }//*/
            } catch(e){
            }
            
            });
            
        });


        $("." + target + "_entry input[type=radio]").each(function() {
            if ($(this).attr("ischecked") == "1") {
                $(this).attr("checked", true);
            } else {
                $(this).attr("checked", "");
            }
        });



        var countnow = $("." + target + "_entry").length; 
         $("."+target+"_counter").text(countnow); 
        $("input[name='" + target + "_count']").val(countnow);
        $(".datepicker").removeClass("hasDatepicker").removeClass("dp-applied").unbind("click");
        $(".datepicker").datepicker();
    }

    $(function() {
        initMCET(".editor");
        $(".datepicker").removeClass("hasDatepicker").removeClass("dp-applied").unbind("click");
        $(".datepicker").datepicker();
    });

    function checkurlkey(id) {
        var key = $("input[name=url_key]").val();
        $.get("challenges.php?checkkey=" + key + "&id=" + id, function(result) {
            if (result == 1) {
                $("#thisform").submit();
            } else {
                alert("Url key is already been used. Please change it to continue.");
                $("input[name=url_key]").focus();
            }
        });
        return false;
    }
</script>

<div class="box"> 
    <div class="title"> 
        <h2>Update Challenge</h2> 
        <?php echo $_dahide; ?>
    </div> 
    <div class="content forms">
        <form id='thisform' action="" method="post" enctype="multipart/form-data"    >
            <input type="hidden" value="<?php echo $_POST["theme"] != "" ? $_POST["theme"] : 1; ?>" name="theme" class="theme" />

            <div style="color:grey; font-size: 20px; font-weight: bold; margin-bottom:5px;">Challenge Box Design</div>
            <div style=" border-top: 1px solid #ccc;  margin-top: 10px;  margin-bottom: 20px;">


                <table>
                    <tr><td>Select Icon:</td><td>
                            <select name="icon">
                                <?php
                                $icons = ChallengeIcons::getList();
                                foreach ($icons as $i) {
                                    $sel = $i["filename"] == $_POST["icon"] ? "selected" : "";
                                    echo "<option value='{$i["filename"]}' $sel>{$i["name"]}</option>";
                                }
                                ?></select> <a href="?newicon=1">Create Icon</a>

                        </td></tr>
                    <tr><td>Select Theme:</td><td>

                            <div id="challenges-bg-template" class="bg<?php echo $_POST["theme"] != "" ? $_POST["theme"] : 1; ?>" >

                            </div>

                            <input value="Change>>" type="button" onclick="moveBG()" />

                        </td></tr> 
                </table>
            </div>

            <div style="color:grey; font-size: 20px; font-weight: bold; margin-bottom:5px;">Challenge Top Splash (PNG only 873x363)</div>
            <div style=" border-top: 1px solid #ccc;  margin-top: 10px;  margin-bottom: 20px;"> 
                
                <div class="row11">    
                            <input type="file" size="46"  name="top_splash_upload" class="upload"  />             
                </div> 
                
                <img src="<?php echo PATH."content/challenges/splash/".  $_POST["top_splash"]; ?>" width="50" />
                
                
                <input type="hidden" name="top_splash" value="<?php echo $_POST["top_splash"]; ?>" /> 
                
            </div> 


            <div style="color:grey; font-size: 20px; font-weight: bold; margin-bottom: 5px;">Challenge Details</div>
            <div style=" border-top: 1px solid #ccc;  margin-top: 10px;  margin-bottom: 20px;">


                <table class="cms-home">                                                         

                    <tr>
                        <td valign="top">Is Active ?:</td>
                        <td valign="top">

                            <label><input type='radio' name='active' value='1' <?php echo $_POST['active'] != '0' ? 'checked="true"' : ''; ?>   >yes</label>                         
                            <label><input type='radio' name='active' value='0'   <?php echo $_POST['active'] == '0' ? 'checked="true"' : ''; ?>   >no</label>
                        </td>                          
                    </tr>                                      


                    <tr>
                        <td valign="top"  >Challenge Name:</td>                          
                        <td valign="top" ><input type='text' name='name' value='<?php echo $_POST['name']; ?>' /></td>                          
                    </tr>                                           

                    <tr>
                        <td valign="top">Schedule:</td>
                        <td valign="top" style="background:#fef;">
                            <label><input type='radio' name='ending' value='0'   <?php echo $_POST['ending_date'] == '' ? 'checked="true"' : ''; ?> onclick='$("[name=ending_date]").val("");
                                    $("#ending-date-tr").hide();' >ongoing</label>



                            <label><input type='radio' name='ending' value='1' <?php echo $_POST['ending_date'] != '' ? 'checked="true"' : ''; ?>  onclick='$("[name=ending_date]").show();
                                    $("#ending-date-tr").show();'> With timeframe </label> 
                            <br/>



                            <table><tr id="starting-date-tr"><td>
                                        Starting Date: 
                                    </td>
                                    <td>
                                        <input type='text' name='starting_date' value='<?php echo $_POST['starting_date']; ?>' placeholder="enter starting date"  class='datepicker hasDatepicker' />

                                    </td> 
                                </tr> 
                                <tr id="ending-date-tr" <?php $_POST['ending_date'] == '' ? "style='display:none;'" : ""; ?> ><td>
                                        Ending Date: 
                                    </td>
                                    <td>
                                        <input type='text' name='ending_date' value='<?php echo $_POST['ending_date']; ?>' placeholder="enter ending date"  class='datepicker hasDatepicker' />

                                    </td> 
                                </tr>
                            </table>



                        </td>                          
                    </tr>                                      

                    <tr>
                        <td valign="top"  >URL KEY:</td>                          
                        <td valign="top" >http://diettools.com/challenges/<input type='text' name='url_key' value='<?php echo $_POST['url_key']; ?>' style='width:100px!important;' />/</td>                          
                    </tr>                  

                    <tr>
                        <td valign="top" colspan="2"><h1>Challenge Content</h1></td>                          
                    </tr>                                           



                    <tr>
                        <td valign="top" colspan="2"><h1><b>Terms and Condition</b></h1></td>                          
                    </tr>                                           


                    <tr>                    
                        <td colspan="2" style="padding-bottom:30px;">
                            <textarea name="terms"  class="editor"  ><?php echo $_POST["terms"]; ?></textarea>
                        </td>                        
                    </tr>                                      



                    <tr>
                        <td valign="top" colspan="2"><h1><b>Top Header</b></h1></td>                          
                    </tr>                                           





                    <tr>
                        <td valign="top">Challenge Name/Heading: </td>
                        <td>
                            <input type="text" name="challenge_name" value="<?php echo $_POST["challenge_name"]; ?>"/>
                        </td>                        
                    </tr>                                           

                    <tr>
                        <td valign="top">Challenge Top Short Desc: </td>
                        <td>
                            <textarea name="challenge_shortdesc"><?php echo $_POST["challenge_shortdesc"]; ?></textarea>
                        </td>                        
                    </tr>                                      
                    <tr>
                        <td valign="top">Challenge Start Date: </td>
                        <td>
                            <input type="text" name="challenge_begin" value="<?php echo $_POST["challenge_begin"]; ?>" class="datepicker"/>
                        </td>                        
                    </tr>                                           
                    <tr>
                        <td valign="top">Challenge End Date: </td>
                        <td>
                            <input type="text" name="challenge_end" value="<?php echo $_POST["challenge_end"]; ?>" class="datepicker"/>
                        </td>                        
                    </tr>                                    

                    <tr>
                        <td valign="top">Steps heading: </td>
                        <td>
                            <input type="text" name="steps_heading" value="<?php echo $_POST["steps_heading"]; ?>" />
                        </td>                        
                    </tr>                                    
                    <tr>
                        <td valign="top">Steps bullets </td>
                        <td>
                            <textarea name="steps_bullets" ><?php echo $_POST["steps_bullets"]; ?></textarea>
                            <br/>
                            <small> (separated by | and add "*" at the beginning of the sentence to mark as optional step):</small>
                        </td>                        
                    </tr>                                    
                    <tr>
                        <td valign="top">Challenge heading: </td>
                        <td>
                            <input type="text" name="challenge_heading" value="<?php echo $_POST["challenge_heading"]; ?>" />
                        </td>                        
                    </tr>                                    
                    <tr>
                        <td valign="top">Challenge Text: </td>
                        <td>
                            <textarea name="challenge_text" class="editor"  ><?php echo $_POST["challenge_text"]; ?></textarea>
                        </td>                        
                    </tr>                                    


                    <tr>
                        <td valign="top" colspan="2"><br/><br/>
                            <h1><b>Prizes</b></h1>
                            <input type="hidden" name="prize_count" value="4" />
                        </td>                          
                    </tr>                                           
                    <tr>
                        <td valign="top">Prize heading: </td>
                        <td>
                            <input type="text" name="prize_heading" value="<?php echo $_POST["prize_heading"]; ?>" />
                        </td>                        
                    </tr>                                    
                    <tr>
                        <td valign="top">Prize Text: </td>
                        <td>
                            <textarea name="prize_text" ><?php echo $_POST["prize_text"]; ?></textarea>
                        </td>                        
                    </tr>                                    

                    <?php
                    $prizes_arr = array("1st prize", "2nd prize", "3rd prize", "other prize");
                    $prizes_cls = array("prize1", "prize1", "prize1", "other_prize");
                    $i = 0;

                    $isOtherPrizeActive = false;
                    $otherPrizeButton = "[Add Other Prize]";
                    foreach ($prizes_arr as $prize) {
                        $cls = $prizes_cls[$i];
                        $i++;


                        if ($i == 4) {
                            $isOtherPrizeActive = intval($_POST["isprizeactive" . $i]);
                            if ($isOtherPrizeActive) {
                                $otherPrizeButton = "[Remove Other Prize]";
                            } else {
                                $cls .= " hide-prize";
                            }
                        }
                        ?>
                        <tr class="<?php echo $cls; ?>">
                            <td valign="top" colspan="2"><b><?php echo $prize; ?>: </b></td>                        
                        </tr>                                    
                        <tr class="<?php echo $cls; ?>">
                            <td valign="top">Heading: </td>
                            <td>
                                <input type="hidden" name="isprizeactive<?php echo $i; ?>" value="<?php echo $_POST["isprizeactive" . $i]; ?>" />                            
                                <input type="text" name="prize_heading<?php echo $i; ?>" value="<?php echo $_POST["prize_heading" . $i]; ?>" />                            
                            </td>                        
                        </tr>                       
                        <tr class="<?php echo $cls; ?>">
                            <td valign="top">Thumbnail: 
    <?php echo renderDim("prize"); ?>
                            </td>
                            <td>
                                <div class="row11">  
                                    <input type="hidden" name="prize_thumb<?php echo $i; ?>" value="<?php echo $_POST["prize_thumb" . $i]; ?>" />
                                    <input type="file" name="prize_thumb_upload<?php echo $i; ?>" />                                                            
    <?php echo renderThumb($_POST["prize_thumb" . $i]); ?>                                            
                                </div>
                            </td>                        
                        </tr>                                    
                        <tr class="<?php echo $cls; ?>">
                            <td valign="top">Text: </td>
                            <td>
                                <textarea name="prize_text<?php echo $i; ?>" ><?php echo $_POST["prize_text" . $i]; ?></textarea>
                            </td>                        
                        </tr>                                    
                        <tr class="<?php echo $cls; ?>">
                            <td valign="top">Bullets: </td>
                            <td>
                                <textarea name="prize_bullets<?php echo $i; ?>" ><?php echo $_POST["prize_bullets" . $i]; ?></textarea>
                            </td>                        
                        </tr>                                    
<?php }
?> 

                    <tr><td colspan="2">

                            <input type="button" class="toogleprize" onclick="checkprize()" value="<?php echo $otherPrizeButton; ?>" />
                        </td></tr>        


                    <tr><td valign="top" colspan="2"><br/><br/>
                            <h1><b>Events and Announcements</b></h1> 

                            

                            <?php
                            $count = intval($_POST["events_count"]);
                            $count = $count == 0 ? 1 : $count;
                            ?>
                            Add Entry (<span class="events_counter"><?php echo $count; ?></span>):                                                             
                            <input type="button" value="+" onclick="AddEntry('events')" style="width:50px;" />
                            <input type="hidden" name="events_count" value="<?php echo $count; ?>" />                                    





                            <br/><br/>
                        </td>                                              
                    </tr>   

                    <tr><td colspan="2"  >                                                

<?php for ($i = 1; $i <= $count; $i++) { ?>
                                <table class="events_entry">
                                    <tr><td colspan="2" align="right"><span class="item_label">events <?php echo $i; ?></span></td></tr>


                                    <tr><td valign="top">Type: </td>
                                        <td>                                                                           
                                            <label><input type="radio" n="events_type" name="events_type<?php echo $i; ?>" value="1" <?php echo $_POST["events_type" . $i] == "1" || $_POST["events_type" . $i] == "" ? "checked" : "" ?> />Announcement </label>
                                            <label><input type="radio" n="events_type" name="events_type<?php echo $i; ?>" value="2" <?php echo $_POST["events_type" . $i] == "2" ? "checked" : "" ?> />Event </label>
                                        </td>                        
                                    </tr>                                           

                                    <tr><td valign="top">Thumbnail: 
    <?php echo renderDim("events"); ?>
                                        </td>
                                        <td>
                                            <div class="row11">  
                                                <input type="hidden" n="events_thumb" name="events_thumb<?php echo $i; ?>" value="<?php echo $_POST["events_thumb" . $i]; ?>" />                            
                                                <input type="file" n="events_thumb_upload" name="events_thumb_upload<?php echo $i; ?>" />                            
    <?php echo renderThumb($_POST["events_thumb" . $i]); ?>                                            
                                            </div>

                                        </td>                        
                                    </tr>        
                                    <tr><td valign="top">Title: </td>
                                        <td>
                                            <input type="text" n="events_title" name="events_title<?php echo $i; ?>" value="<?php echo $_POST["events_title" . $i]; ?>" />                            
                                        </td>                        
                                    </tr>  

                                    <tr><td valign="top">Date: </td>
                                        <td>
                                            <input type="text" n="events_date" name="events_date<?php echo $i; ?>" value="<?php echo $_POST["events_date" . $i]; ?>" class="datepicker" />                            
                                        </td>                        
                                    </tr>                       
                                    <tr><td valign="top">Text: </td>
                                        <td>
                                            <textarea n="events_text" name="events_text<?php echo $i; ?>" ><?php echo $_POST["events_text" . $i]; ?></textarea>
                                        </td>                        
                                    </tr>                       

                                    <tr><td colspan="2">
                                            <input type="button" value="Remove" class="removebtn"  onclick="removeEntry(this, 'events')" />
                                        </td>                        
                                    </tr>                       
                                </table>

<?php } ?>  

                        </td></tr>


                    <tr><td valign="top" colspan="2"><br/><br/>
                            <h1><b>Challenge Resources</b></h1>                        
                        </td>                                              
                    </tr>   

                    <?php
                    $array_list = array("workouts", "recipes", "articles", "calendar");
                    foreach ($array_list as $entry) {
                        ?>
                        <tr>                    
                            <td colspan="2">
                                <b><?php echo ucfirst($entry); ?></b>: <br/>                                                       
                                Popup <?php echo $entry; ?> title: <input name="<?php echo $entry; ?>_heading" value="<?php echo $_POST[$entry . "_heading"]; ?>" /> <br/>
                                Description/Text: <br/>
                                <textarea name="<?php echo $entry; ?>_text" ><?php echo $_POST[$entry . "_text"]; ?></textarea> <br/>
                                Add Entry (<span class="<?php echo $entry; ?>_counter"><?php echo $count; ?></span>):                                                             
                                <input type="button" value="+" onclick="AddEntry('<?php echo $entry; ?>')" style="width:50px;" />
                                <table >
                                    <tr><td>
                                            
                                            <?php
                                            $count = intval($_POST[$entry . "_count"]);
                                            $count = $count == 0 ? 1 : $count;
                                            ?>
                                            <input type="hidden" name="<?php echo $entry; ?>_count" value="<?php echo $count; ?>" />                                    

    <?php for ($i = 1; $i <= $count; $i++) { ?>


                                            
                                                <table  class="<?php echo $entry; ?>_entry" >                                        
                                                    
                                                     <tr><td colspan="2" align="right"><span class="item_label"><?php echo $entry; ?> <?php echo $i; ?></span></td></tr>
                                                    <tr>
                                                        <td>Title</td>
                                                        <td><input type="text" n="<?php echo $entry; ?>_title" name="<?php echo $entry; ?>_title<?php echo $i; ?>"  value="<?php echo $_POST[$entry . "_title" . $i]; ?>" /></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Short Desc</td>
                                                        <td><textarea n="<?php echo $entry; ?>_desc" name="<?php echo $entry; ?>_desc<?php echo $i; ?>" ><?php echo $_POST[$entry . "_desc" . $i]; ?></textarea></td>
                                                    </tr>


        <?php if ($entry == "calendar") { ?>
                                                        <tr>
                                                            <td>Downloadable</td>
                                                            <td>
                                                                <input type="hidden" n="<?php echo $entry; ?>_link" name="<?php echo $entry; ?>_link<?php echo $i; ?>" value="<?php echo $_POST[$entry . "_link" . $i]; ?>"/>                                                               

                                                                <div class="row11">                                                                      
                                                                    <input type="file" n="<?php echo $entry; ?>_file_upload" name="<?php echo $entry; ?>_file_upload<?php echo $i; ?>" />                                                                       
                                                                </div>

                                                                <?php
                                                                $attached = $_POST[$entry . "_link" . $i];
                                                                if (!empty($attached)) {
                                                                    $name = slug($_POST[$entry . "_title" . $i]);
                                                                    echo '<a href="' . getDownloadLink(PATH . $attached, $name) . '" class="attached" >attached</a>';
                                                                }
                                                                ?>


                                                            </td>
                                                        </tr>
        <?php } else { ?>
                                                        <tr>
                                                            <td>Link </td>
                                                            <td>
                                                                <input type="text" n="<?php echo $entry; ?>_link" name="<?php echo $entry; ?>_link<?php echo $i; ?>" value="<?php echo $_POST[$entry . "_link" . $i]; ?>"/> 
                                                            </td>
                                                        </tr>
        <?php } ?>



                                                    <tr>
                                                        <td>Thumbnail
        <?php echo renderDim($entry); ?>
                                                        </td>
                                                        <td>
                                                            <div class="row11">  
                                                                <input type="hidden" n="<?php echo $entry; ?>_thumb" name="<?php echo $entry; ?>_thumb<?php echo $i; ?>" value="<?php echo $_POST[$entry . "_thumb" . $i]; ?>" />                            
                                                                <input type="file" n="<?php echo $entry; ?>_thumb_upload" name="<?php echo $entry; ?>_thumb_upload<?php echo $i; ?>" />                                                                                        
        <?php echo renderThumb($_POST[$entry . "_thumb" . $i]); ?>                                            
                                                            </div>
                                                        </td>

                                                    </tr>

                                                    <tr><td colspan="2">
                                                            <input type="button" value="Remove" class="removebtn" onclick="removeEntry(this, '<?php echo $entry; ?>')" />    
                                                        </td>                        
                                                </table>                                           
    <?php } ?>



                                        </td>
                                    </tr>

                                </table>

                            </td>                        
                        </tr>                       
<?php } ?>


                    <tr><td valign="top" colspan="2"><br/><br/>
                            <h1><b>Graphical Announcements</b></h1>                        

                            <?php
                            $count = intval($_POST["graphical_count"]);
                            $count = $count == 0 ? 1 : $count;
                            ?>
                            <input type="hidden" name="graphical_count" value="<?php echo $count; ?>" />                                    
                            Add Entry (<span class="graphical_counter"><?php echo $count; ?></span>):                                                  
                            <input type="button" value="+" onclick="AddEntry('graphical')" style="width:50px;" />

                        </td>                                              
                    </tr>  
                    <tr><td colspan="2"  >                                                

<?php for ($i = 1; $i <= $count; $i++) { ?>
                                <table class="graphical_entry" >
                                    <!-- <tr><td valign="top" colspan="2"><b>Entry <?php echo $i; ?>: </b></td></tr>   -->
                                    <tr><td valign="top">Thumbnail: 
    <?php echo renderDim("graphical"); ?>
                                        </td>
                                        <td>
                                            <div class="row11">  
                                                <input type="hidden" n="graphical_thumb" name="graphical_thumb<?php echo $i; ?>" value="<?php echo $_POST["graphical_thumb" . $i]; ?>" />                            
                                                <input type="file" n="graphical_thumb_upload" name="graphical_thumb_upload<?php echo $i; ?>" />                                                                        
    <?php echo renderThumb($_POST["graphical_thumb" . $i]); ?>                                            
                                            </div>

                                        </td>                        
                                    </tr>                                           
                                    <tr><td valign="top">Title: </td>
                                        <td>
                                            <input type="text"  n="graphical_title" name="graphical_title<?php echo $i; ?>" value="<?php echo $_POST["graphical_title" . $i]; ?>" />
                                        </td>                        
                                    </tr>                       
                                    <tr><td valign="top">Date: </td>
                                        <td>
                                            <input type="text" n="graphical_date" name="graphical_date<?php echo $i; ?>" value="<?php echo $_POST["graphical_date" . $i]; ?>" class="datepicker" />                            
                                        </td>                        
                                    </tr>                       
                                    <tr><td valign="top">Time: </td>
                                        <td>
                                            <input type="text" n="graphical_time" name="graphical_time<?php echo $i; ?>" value="<?php echo $_POST["graphical_time" . $i]; ?>" />                            
                                        </td>                        
                                    </tr>                       
                                    <tr><td valign="top">Text: </td>
                                        <td>
                                            <textarea n="graphical_text" name="graphical_text<?php echo $i; ?>" ><?php echo $_POST["graphical_text" . $i]; ?></textarea>
                                        </td>                        
                                    </tr>                       
                                    <tr><td valign="top">Link: </td>
                                        <td>
                                            <input type="text" n="graphical_link" name="graphical_link<?php echo $i; ?>" value="<?php echo $_POST["graphical_link" . $i]; ?>" />                            
                                        </td>                        
                                    </tr>                       
                                    <tr><td colspan="2">
                                            <input type="button" value="Remove" class="removebtn" onclick="removeEntry(this, 'graphical')"  style="width:60px!important;" />
                                        </td></tr>
                                </table>

<?php } ?>  

                        </td></tr>


                    <tr><td valign="top" colspan="2"><br/><br/>
                            <h1><b>Hashtag</b></h1>                        
                        </td>                                              
                    </tr>  
                    <tr><td valign="top">Hashtag: </td>
                        <td>
                            <input type="text" name="hashtag" value="<?php echo $_POST["hashtag"]; ?>" />
                        </td>                        
                    </tr>                       
                    <tr><td valign="top">Text: </td>
                        <td>
                            <textarea name="hashtag_text"><?php echo $_POST["hashtag_text"]; ?></textarea>
                        </td>                        
                    </tr>                       


                    <tr><td valign="top" colspan="2"><br/><br/>
                            <h1><b>Social Networks</b></h1>                         
                            (paste social network embeded code) <br/><br/>
                        </td>                                              
                    </tr>  

                    <tr><td valign="top">Pinterest Block </td>
                        <td>
                            <textarea name="pinterest_block"><?php echo $_POST["pinterest_block"] ?></textarea>
                        </td>                        
                    </tr>                       

                    <tr><td valign="top">Facebook Block</td>
                        <td>
                            <textarea name="facebook_block"><?php echo $_POST["facebook_block"] ?></textarea>
                        </td>                        
                    </tr>                       

                    <tr><td valign="top">Twitter Block</td>
                        <td>
                            <textarea name="twitter_block"><?php echo $_POST["twitter_block"] ?></textarea>
                        </td>                        
                    </tr>                       





                </table>   

            </div>
            <input type="hidden" name="submit_challenge" value="1" />
            <input type="hidden" name="id" value="<?php echo $_GET["edit"]; ?>" />
            <div class="row buttons">                                        
                <button type="button"   onclick="checkurlkey('<?php echo $_GET['edit']; ?>')"><span>Save</span></button>                                                
            </div>
        </form>

    </div>
</div>     
