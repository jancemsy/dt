 
<style>
    tr.inactive *{ color:#ccc!important; text-decoration: line-through; }
</style>

<div class="box"> 
    <div class="title"> 
        <h2>Participants of <?php echo $challenge->name; ?> </h2> 
        <?php echo $_dahide; ?>
    </div> 
    <div class="content pages"> 

        <p align='right'>


            <a href="challenges.php">Challenges</a>  

        <table>
            <tr>
                <td>#</td> 
                <td width="50">Thumb</td>
                <td>Name</td>
                <td align="center">Points</td>
                <td>Joined</td> 
            </tr>
            <?php
            
            $result = mysql_query("
SELECT u.*,cp.dateJoined FROM challenge_participants cp INNER JOIN users u ON u.id = cp.userID WHERE
cp.challengeID = '$challenge->id'  ");
            
            
            while($item = mysql_fetch_array($result)){ 
                  $class = $item["active"] == "0" ? "inactive" : "";
                  
                   
                  $thumb = "<img src='". PATH .(  $item["avatar"] == "" ? "images/icon2.jpg" : $item["avatar"] ) ."' />  ";
                  $name = "<a href='".User::profile_link($item["id"])."' style='color:blue; text-decoration:underline;'>".$item["username"]."</a>";
                  $joined = $item["dateJoined"];
                  
                ?>
                <tr class="<?php echo $class; ?>">
                    <td><?php echo $item["id"]; ?></td>
                    <td width="50"><?php echo $thumb; ?></td>
                    <td><?php echo $name;  ?></td> 
                    <td align="center"><?php echo $item["points"];  ?>pts</td> 
                    <td><?php echo $joined;  ?></td>  
                </tr> 
            <?php } ?>  
        </table>
    </div>
</div>    

