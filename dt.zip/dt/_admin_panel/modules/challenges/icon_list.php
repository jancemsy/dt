<?php

$list = ChallengeIcons::getList();

?>
<style>
    tr.inactive *{ color:#ccc!important; text-decoration: line-through; }
</style>

<div class="box"> 
    <div class="title"> 
        <h2>Challenges Icons</h2> 
<?php echo $_dahide; ?>
    </div> 
    <div class="content pages"> 
        
        <p align='right'> 
            <a href="?">&#8656;Go back to challenges</a>  | <a href="?newicon=1">Create New Icons</a>  </p>

<table>
    <tr>
        <td>id</td> 
        <td>Icon Name</td> 
        <td>Icon</td> 
        <td>Action</td> 
    </tr>
    <?php  
    foreach($list as $item){ 
        $class = $item["active"] == "0" ? "inactive" : "";
        ?>
            <tr class="<?php echo $class; ?>">
                <td><?php echo $item["id"]; ?></td>
                <td><?php echo $item["name"]; ?></td> 
                <td style="background: #eee;"><img src="../content/challenges/challenge_icons/<?php echo $item["filename"]; ?>" /></td> 
                <td><a href="?editicon=<?php echo $item["id"]; ?>">edit</a></td>
            </tr> 
      <?php } ?>  
</table>
    </div>
</div>    
    
    