<?php
if (!defined("PATH"))
    @include_once("../../common.php");



if (isset($_GET["preview"]))
    $tid = $_GET["preview"];


$result = mysql_query("SELECT *FROM newsletter WHERE id = '$tid' ");
$row = mysql_fetch_array($result);

if (empty($row["id"])) {
    die("Invalid preview! ");
}
$array = array();
$bam = unserialize($row["params"]);
foreach ($bam as $field => $value) {
    $array[$field] = stripslashes(urldecode($value));
}



$value = $array;
$nl = $value;


//if still using the old values, convert it
if ($nl["unit_img"] != "") {
    $nl["unit_text1"] = $nl["unit_text"];
    $nl["unit_size1"] = $nl["unit_size"];
    $nl["unit_link1"] = $nl["unit_link"];
    $nl["unit_img1"] = $nl["unit_img"];
}

?>
<center>
    <table  width="600" border="0" cellpadding="0" cellspacing="0">
        <tr>
            <td
                height="117"
                width="100%"
                style=" 
                height:117px!important;
                background:url(<?php echo PATH; ?>images/newsletterv2/logo.jpg) no-repeat #f1f1f1; ">
                <table><tr><td width="400"></td><td  width="200">
                            <a href="http://facebook.com/diettools"><img src="<?php echo PATH; ?>images/newsletter/top_fb.jpg" width="35" height="28" border="0" alt="" style="display: inline-block;line-height: 50%"/></a>
                            <a href="http://plus.google.com/+Diettools/posts"><img src="<?php echo PATH; ?>images/newsletter/top_google.jpg" width="35" height="28" border="0" alt="" style="display: inline-block;line-height: 50%"/></a>
                            <a href="http://twitter.com/diettoolscom"><img src="<?php echo PATH; ?>images/newsletter/top_twitter.jpg" width="35" height="28" border="0" alt="" style="display: inline-block;line-height: 50%"/></a>
                            <a href="http://diettools.com/rss"><img src="<?php echo PATH; ?>images/newsletter/top_rss.jpg" width="35" height="28" border="0" alt="" style="display: inline-block;line-height: 50%"/></a>                                
                            <br/>
                          <span style="display:block;padding-top:10px; font-size:20px; color: #333; font-family: arial;"><!--<?php echo $nl["date"]; ?>--></span>
                        </td></table>
            </td>
        </tr>
        <tr>
            <td height="38">
                <table width="100%;" cellpadding="0" cellspacing="2"><tr>                                        
                            
                        <td style="width:200px; height: 38px; background:#85a425; text-align: center;"><a href="http://diettools.com/aboutus/" style="color:#fff; font-family: arial; font-size:14px;">About Us</a></td>
                        <td style="width:200px; background:#85a425; text-align: center;"><a href="http://diettools.com/" style="color:#fff; font-family: arial; font-size:14px;">DietTools</a></td>
                        <td style="width:200px; background:#85a425; text-align: center;"><a href="http://diettools.com/blog/" style="color:#fff; font-family: arial; font-size:14px;">Blog</a></td>
                        <td style="width:200px; background:#85a425; text-align: center;"><a href="http://diettools.com/recipes/" style="color:#fff; font-family: arial; font-size:14px;">Recipes</a></td>
                    </tr></table>
            </td>
        </tr>
        <tr>
            <td style="background:url(<?php echo PATH; ?>images/newsletterv2/scale.jpg) no-repeat 10px 40px;" >
                <table><tr>
                        <td style="width:300px; height: 190px;">
                        </td>
                        <td style="width:500px; padding-top: 50px;" valign="top">
                            <span style="font-size:44px; font-weight: bold; font-family: arial; color:#7f9d17;"><?php echo $nl["headline"];          ?></span> <br/>
                            <span style="padding-left:20px;color:#ce3a00; font-family: arial; font-size: 25px; font-style:italic; margin-left: -10px;  "><?php echo $nl["sub_headline"];          ?></span> <br/><br/>

                            <a href="<?php echo $nl["link1_link"]; ?>" style="background:url('images/newsletter/bullet-orange.jpg') 0px 5px no-repeat; font-size:15px; padding-left:15px; color:#333; text-decoration:underline;"><?php echo $nl["link1_text"]; ?></a>
                            <a href="<?php echo $nl["link2_link"]; ?>" style="background:url('images/newsletter/bullet-orange.jpg') 0px 5px no-repeat; font-size:15px; padding-left:15px; color:#333; text-decoration:underline;"><?php echo $nl["link2_text"]; ?></a>
                            <a href="<?php echo $nl["link3_link"]; ?>" style="background:url('images/newsletter/bullet-orange.jpg') 0px 5px no-repeat; font-size:15px; padding-left:15px; color:#333; text-decoration:underline;"><?php echo $nl["link3_text"]; ?></a>
                            <a href="<?php echo $nl["link4_link"]; ?>" style="background:url('images/newsletter/bullet-orange.jpg') 0px 5px no-repeat; font-size:15px; padding-left:15px; color:#333; text-decoration:underline;"><?php echo $nl["link4_text"]; ?></a>                

                        </td>
                    </tr></table>  

                <div style=" font-size: 15px; font-family: verdana; padding-bottom: 35px; padding-top: 35px;" width="600" height="172" ><?php echo $nl["text"]; ?></div>
            </td>
        </tr>

        <tr>
            <td>
                <table cellspacing="5"><tr>


                        <?php
                        $colors = array("#85a425", "#4c4c4c", "#066a8c", "#d2530e");

                        for ($i = 1; $i < 5; $i++) {
                            ?>

                            <td valign="top" style="padding:10px; width:300px; height: 300px; background:<?php echo $colors[$i - 1]; ?>;">
                                <table ><tr><td height="280"  valign="top">
                                            <a href="<?php echo $nl["ftb{$i}_link"]; ?>" style="font-size:15px; color:#fff; font-weight: bold; font-family: Arial; " ><?php echo $nl["ftb{$i}_title"]; ?></a> <br/><br/>

                                            <div style="height:202px; display:block; color:#fff; font-size:12px; font-family: verdana; line-height: 20px; border:none; overflow: hidden!important;">          
                                                <img width="92" height="123"  style="float:left; margin-right:10px; margin-top: 0px; " src="<?php echo $nl["ftb{$i}_img"]; ?>" />
                                                <?php echo $nl["ftb{$i}_text"]; ?>    
                                            </div>
                                        </td></tr>
                                    <tr><td align="right">
                                            <a href="<?php echo $nl["ftb{$i}_link"]; ?>" style="color:#fff; font-family: arial; font-size: 12px;" >read more</a>                        
                                        </td>   
                                    </tr>
                                </table>
                            </td>

                            <?php
                            if ($i == 2)
                                echo "</tr><tr>";
                        }
                        ?>
                    </tr>
                </table>
            </td>
        </tr>


        <tr>
            <td colspan="27" width="600" style="padding-top:15px; padding-bottom: 15px;"  > 



                <?php if ($nl["unit_size"] == "468x60") { ?>
                    <?php if (!empty($nl["unit_text1"])) { ?>
                        <div style='margin-top:50px;position:absolute; text-align:center;'><?php echo $nl["unit_text1"]; ?></div>                      
                    <?php } ?>
            <center>
                <d2 style="padding:15px 15px 20px 15px; display:block;">
                    <?php
                    list($w, $h) = array(468, 60);
                    echo "<a href='" . $nl["unit_link1"] . "'><img src='" . $nl["unit_img1"] . "' width='$w' height='$h' /></a>";
                    ?> 
                </d2>                
            </center>
            <?php
        } else {
            ?>

            <table align="center"> 
                <tr>
                    <?php for ($i = 2; $i <= 4; $i++) { ?>
                        <td>
                            <?php if (!empty($nl["unit_text$i"])) { ?>
                                <div style='margin-top:50px;position:absolute; text-align:center;'><?php echo $nl["unit_text$i"]; ?></div>
                            <?php } ?>
                    <center>
                        <d2 style="padding:15px 15px 20px 15px; display:block;">
                            <?php
                            list($w, $h) = array(125, 125);
                            echo "<a href='" . $nl["unit_link$i"] . "'><img src='" . $nl["unit_img$i"] . "' width='$w' height='$h' /></a>";
                            ?> 
                        </d2>                
                    </center>
                    </td>
                <?php } ?>                
                </tr>
            </table>                

            <?php
        }
        ?>
        </td>
        </tr>

        <tr>
            <td height="500" style="background:url('<?php echo PATH; ?>images/newsletterv2/horizontal_line.jpg') repeat-x;">
                <table style="margin-top:5px; background:url('<?php echo PATH; ?>images/newsletterv2/vertical_line.jpg') repeat-y;" >
                    <tr>
                        <td colspan="8"   valign="top"  width="200" height="441" >                       
                            <div style="width:170px;     word-wrap:break-word;">
                                <div style=" color:#d2530e;  display:block; padding-bottom:10px;  font-size:13px; font-weight:bold; font-family: verdana;"><?php echo $nl["bbox2_title1"]; ?></div>           
                                <img width="150" height="150"  src="<?php echo $nl["bbox2_img1"]; ?>" />      
                                <div style=" padding-top: 10px; padding-right: 20px; color:#333; font-size:13px;  font-weight:normal!important; font-family: verdana; display: block;"><?php echo $nl["bbox2_text1"]; ?></div>                          
                            </div>
                        </td>
                        <td colspan="9"  valign="top" style="" width="201" height="441" >
                            <div style="margin-left:10px; width:160px;   word-wrap:break-word;  ">
                                <div style=" color:#d2530e;  display:block; padding-bottom:10px;  font-size:13px; font-weight:bold; font-family: verdana;"><?php echo $nl["bbox2_title2"]; ?></div>           
                                <img width="150" height="150"  src="<?php echo $nl["bbox2_img2"]; ?>" />              
                                <div style=" padding-top: 10px; color:#333; font-size:13px;  font-weight:normal!important; font-family: verdana; display: block;"><?php echo $nl["bbox2_text2"]; ?></div>   
                            </div>
                        </td>
                        <td colspan="10"  valign="top"  width="200" height="441" >
                            <div style="width:180px;  word-wrap:break-word; padding:5px; padding-left:15px;">
                                <div style=" color:#d2530e;  display:block; padding-bottom:10px;  font-size:13px; font-weight:bold; font-family: verdana;"><?php echo $nl["bbox2_title3"]; ?></div>   
                                <img width="150" height="150"  src="<?php echo $nl["bbox2_img3"]; ?>" />
                                <div style=" padding-top: 10px; color:#333; font-size:13px;  font-weight:normal!important; font-family: verdana; display: block;">
                                    <?php echo $nl["bbox2_text3"]; ?></div>   
                            </div>
                        </td>
                    </tr>
                </table>
                <div  style="height:10px; display:block; width:100%; background:url('<?php echo PATH; ?>images/newsletterv2/horizontal_line.jpg') repeat-x;">
                    &nbsp;
                </div>   
            </td>
        </tr>



        <tr>
            <td height="140" valign="top">
                <table width="600"><tr><td>
                            <a href="http://diettools.com/aboutus/" style="color:#333333!important; font-size:11px; font-family: arial;">About Us</a> |
                            <a href="http://diettools.com/privacy/" style="color:#333333!important;  font-size:11px; font-family: arial;">Privacy</a> | 
                            <a href="http://diettools.com/contact-us/" style="color:#333333!important;  font-size:11px; font-family: arial;">Contact us</a> |
                            <a href="http://diettools.com/blog/" style="color:#333333!important;  font-size:11px; font-family: arial;">Blog</a>
                        </td>
                        <td align="right">

                            
                            <a href="http://facebook.com/diettools"><img src="<?php echo PATH; ?>images/newsletterv2/bottom_fb.jpg" width="35" height="44" border="0" alt=""/></a>
                            <a href="http://plus.google.com/+Diettools/posts"><img src="<?php echo PATH; ?>images/newsletterv2/bottom_google.jpg" width="35" height="44" border="0" alt=""/></a>
                            <a href="http://twitter.com/diettoolscom"><img src="<?php echo PATH; ?>images/newsletterv2/bottom_twitter.jpg" width="35" height="44" border="0" alt=""/></a>
                            <a href="http://diettools.com/rss"><img src="<?php echo PATH; ?>images/newsletterv2/bottom_rss.jpg" width="35" height="44" border="0" alt=""/></a>                                

                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</center>    