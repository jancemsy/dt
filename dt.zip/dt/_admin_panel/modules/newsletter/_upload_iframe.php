<?php
if (!defined("PATH"))
    include_once("../../common.php");

$uploadname = $_GET["uploadname"];
$script = "";
$error = "";

if (isset($_POST["partial_upload"])) {
    if (isset($_FILES["upload"]) && $_FILES["upload"]["name"] != "") {
        $name = $_FILES["upload"]["name"];
        $ext = strtolower(end(explode(".", $name)));

        if ($ext == "jpg" || $ext == "jpeg") {
            $filename = "$uploadname.$ext";
            $thumb_orig = ABSPATH."content/newsletter/$filename";            
            move_uploaded_file($_FILES["upload"]["tmp_name"], $thumb_orig);
            
            $script = "parent.set_upload_url('" . PATH . "content/newsletter/$filename" . "','$uploadname');";
        }else{
            $error = "<div style='color:red'>Error: invalid image format</div>";
        }
    }
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"> 
    <head>	
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>
    </head>
    <script>
        $(function(){
<?php echo $script; ?>
        $("input[type=file]").change(function(){
            $("#loading").text("Uploading...");
            $("form").hide().submit();
        });             
    });        
    </script>
    <body>
        <form action="" method="post" enctype="multipart/form-data">
            <input type="hidden" name="upload_name" value="<?php echo $uploadname; ?>" />
            <input type="hidden" name="partial_upload" value="1" />
            <div  class="row" style="float:left!important; display:inline-block!important; width: 360px;">   
                  <?php echo $error; ?>
                <input  type="file" name="upload" /> (jpg only)
            </div>
        </form>
        <div id="loading"></div>
    </body></html>