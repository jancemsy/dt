<div class="box"> 
    <div class="title"> 
        <h2>Newsletters</h2> 
        <?php echo $_dahide; ?>
    </div> 
    <div class="content  pages">       
        
    <p><a href="?new=1" class="button">New Newsletter</a></p>                 
        <table>            
            <tr>
                <td>#</td>
                <td>Date</td>
                <td>Headline</td>
                <td>Sub Headline</td>
                <td>Action</td>
            </tr>                        
            <?php            
                $result = mysql_query("SELECT *FROM newsletter ORDER BY id DESC");
                while($row = mysql_fetch_array($result)){
                    
                    $buttons  = "<a  href='javascript:;' onclick=' if(confirm(\"Are you sure you want to delete this?\")) location.href=\"?delete={$row['id']}\";' class='delete'>Delete</a> |
                        <a href='?edit={$row["id"]}'>Edit</a> | <a href='?preview={$row["id"]}'>Preview</a>";
                    ?>
                    <tr>
                        <td><?php echo $row["id"];?></td>
                        <td><?php echo $row["date"];?></td>
                        <td><?php echo $row["headline"];?></td>
                        <td><?php echo $row["sub_headline"];?></td>
                        <td><?php echo $buttons;?></td>
                    </tr><?php
                    
                }                                    
            ?>
            
                
        
        </table>


    </div>
</div>