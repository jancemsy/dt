<?php

if (!defined("PATH"))
    include_once("../../common.php");



global $_i;

function cropUpload($src, $dimension, $oldthumb = "") {
    global $_i;
    $_i++;
    $dim = explode("|", $dimension);
    $des_h = $dim[0];
    $des_w = $dim[1];
    $source_x = $dim[2];
    $source_y = $dim[3];

    //$width = 92;
    //$height = 123;

    $width = $des_w;
    $height = $des_h;


    if (!empty($des_h) && !empty($src)) {
        $fn = $_i . time() . ".jpg";
        $destination = "../content/newsletter/$fn";
        $img_r = imagecreatefromjpeg($src);
        $dst_r = ImageCreateTrueColor($width, $height);
        imagecopyresampled($dst_r, $img_r, 0, 0, $source_x, $source_y, $width, $height, $des_w, $des_h);
        imagejpeg($dst_r, $destination, 100);

        if (!empty($oldthumb))
            @unlink($_POST[$oldthumb]);

        return PATH . "content/newsletter/" . $fn;
    }//if 

    return "";
}

if (isset($_POST["uploadpasted"])) {
    if (!empty($_POST["uploadpasted"]) && !empty($_POST["name"])) {
        $url = $_POST["uploadpasted"];
        $thumb_name = $_POST["name"];
        $dest = "content/newsletter/";
        $filename = move_file($url, ABSPATH . $dest, $thumb_name);
        $newthumb = PATH . $dest . $filename;
        die($newthumb);
    }
}

if (isset($_GET["checklink"])) {
    $permalink = urldecode($_GET["checklink"]);


    //check permalink for keywords
    /*
     * article: http://localhost/LAD/dpp/article/fhgfhgfhfg-31
     * recipe: http://localhost/LAD/dpp/recipe/meat-chiken-fox-6
     * fitness: http://localhost/LAD/dpp/fitness/title-3
     * blog: http://dt.liquidapogeedev.com/blog/?p=5
     */

    $obj = "";
    $id = trim(end(explode("-", $permalink)));


    if (search("\/article\/", $permalink) && is_numeric($id)) {
        $thumb_name = "_Article";
        $obj = new Article($id);
    } else if (search("\/recipe\/", $permalink) && is_numeric($id)) {
        $thumb_name = "_Recipe";
        $obj = new Recipe($id);
    } else if (search("\/fitness\/", $permalink) && is_numeric($id)) {
        $thumb_name = "_Fitness";
        $obj = new Fitness($id);
    } else if (search("\/blog\/", $permalink)) {
        //check blog content and get the image link, title, and desc 
        //off the page (no need to use db here)
        $content = file_get_contents($permalink);
        $tmp = explode('entry-title">', $content);
        $tmp = explode('</h1>', $tmp[1]);
        $title = $tmp[0];



        $tmp = explode('<div class="entry-content">', $content);
        $tmp = explode('</div>', $tmp[1]);
        $insidecontent = $tmp[0];
        $text = $insidecontent;
        $tmp = explode("</p>", $text);

        $is_empty = trim(strip_tags($tmp[0]));
        if (!empty($is_empty)) {
            $text = strip_tags($tmp[0]);
        } else {
            $text = strip_tags($tmp[1]);
        }



        $tmp = explode('src="', $insidecontent);
        $tmp = explode('"', $tmp[1]);
        $filename = $tmp[0];



        $thumb_name = "_Blog";
        $dest = "content/newsletter/";
        $filename = move_file($filename, ABSPATH . $dest, $thumb_name);
        $newthumb = $dest . $filename;
    }


    if (!empty($obj->id)) {
        $file = PATH . $obj->getThumb();
        $dest = "content/newsletter/";
        $filename = move_file($file, ABSPATH . $dest, $thumb_name);
        $newthumb = $dest . $filename;

        if (!empty($obj->text))
            $text = $obj->text;
        else if (!empty($obj->desc))
            $text = $obj->desc;
        else if (!empty($obj->description))
            $text = $obj->description;


        if (!empty($obj->title))
            $title = $obj->title;
        else if (!empty($obj->name))
            $title = $obj->name;

        $text = string_cut(trim(strip_tags($text)), 200);
    }else {

        $text = trim(strip_tags($text));
    }


    if (!empty($filename)) {




        die(json_encode(array(
                    "thumb" => $newthumb,
                    "title" => $title,
                    "desc" => $text
                )));
    }



    die("nomatch");
}


if (isset($_POST['crop_images'])) {  //ajax call   
    $_SESSION["pending_crop"] = "";
    $quality = 100;

    $count = count($_POST['h']);

    for ($i = 0; $i < $count; $i++) {
        $des_h = $_POST['h'][$i];
        $des_w = $_POST['w'][$i];
        $width = $_POST['_w'][$i];
        $height = $_POST['_h'][$i];
        $source_x = $_POST['x'][$i];
        $source_y = $_POST['y'][$i];
        $size = empty($_POST['size'][$i]) ? "" : "-" . $_POST['size'][$i];
        $src = $_POST['thumb'][$i];

        if (!empty($des_h) && !empty($src)) {
            $filename = end(explode("/", $src));
            $destination = "../content/newsletter/$filename";
            $ext = strtolower(end(explode(".", $src)));
            switch ($ext) {
                case "gif":
                    $img_r = imagecreatefromgif($src);
                    break;
                case "png":
                    $img_r = imagecreatefrompng($src);
                    break;
                default:
                    $img_r = imagecreatefromjpeg($src);
                    break;
            }

            $dst_r = ImageCreateTrueColor($width, $height);
            imagecopyresampled($dst_r, $img_r, 0, 0, $source_x, $source_y, $width, $height, $des_w, $des_h);


            switch ($ext) {
                case "gif":
                    imagegif($dst_r, $destination);
                    break;
                case "png":
                    imagepng($dst_r, $destination);
                    break;
                default:
                    imagejpeg($dst_r, $destination, $quality);
                    break;
            }
        }//if 
    }//for        
    die("1");
}


if ($_GET["delete"]) {
    $id = $_GET["delete"];
    $result = mysql_query("DELETE FROM newsletter WHERE id = $id ");
    jumpto("?");
}

if (isset($_POST["save_newsletter"])) {
    $is_preview = $_POST["preview_cms"];
    unset($_POST["preview_cms"]);
    $pending_crop = array();

    $dir = "../content/newsletter/";
    if (!file_exists($dir))
        mkdir($dir);

    for ($i = 1; $i < 5; $i++) {
        $pname = "ftb" . $i . "_img";

        $filename = $_POST[$pname];
        $dimension = $_POST["ftb{$i}_dimension"];

        if (!empty($dimension)) {
            $src = $_POST["ftb{$i}_img"];
            $old = $_POST["ftb{$i}_oldimg"];
            $_POST["ftb{$i}_img"] = cropUpload($src, $dimension, $old);
        } else if (!empty($filename) && !search("newsletter", $filename) ||
                !empty($_POST["ftb" . $i . "_dimension"])) { //not empty and external link 
            $fn = move_file($filename, $dir, $i . time());
            if (!empty($fn)) {
                $dimension = $_POST["ftb" . $i . "_dimension"];

                if (empty($dimension)) {
                    //we already transfered the file to our dir, 
                    //now we need to crop/resize the image to our likings
                    $source = $dir . $fn;
                    //createThumb($source, $source, 92, 123);
                    //crop 
                    $pending_crop[] = array("image" => $source,
                        "width" => "92",
                        "height" => "123",
                        "caption" => "thumbnail");
                    $_POST[$pname] = PATH . "content/newsletter/" . $fn;
                    @unlink($_POST["ftb" . $i . "_oldimg"]);
                } else {
                    $_POST[$pname] = cropUpload($filename, $dimension, "ftb" . $i . "_oldimg");
                }//
            }
        }
    }//for




    if (!empty($_POST["bbox1_dimension"])) {
        $src = $_POST["bbox1_img"];
        $dimension = $_POST["bbox1_dimension"];
        $old = $_POST["bbox1_img_old"];
        $_POST["bbox1_img"] = cropUpload($src, $dimension, $old);
    }

    for ($i = 1; $i < 4; $i++) {
        $dimension = $_POST['bbox2' . $i . '_dimension'];
        $old = $_POST['bbox2' . $i . '_img_old'];
        $src = $_POST['bbox2_img' . $i];

        if (!empty($dimension)) {
            $_POST['bbox2_img' . $i] = cropUpload($src, $dimension, $old);
        }
    }




    $array = array();
    foreach ($_POST as $field => $val) {
        $array[$field] = urlencode($val);
    }




    $params = serialize($array);
    $headline = addslashes($_POST["headline"]);
    $sub_headline = addslashes($_POST["sub_headline"]);
    $date = addslashes($_POST["date"]);
    $id = $_POST["id"];


    if (empty($id)) {
        $result = mysql_query("INSERT INTO newsletter SET headline = '$headline',
        sub_headline = '$sub_headline', date  = '$date', params = '$params' ");
        $id = mysql_insert_id();
    } else {
        $result = mysql_query("UPDATE newsletter SET headline = '$headline',
        sub_headline = '$sub_headline', date  = '$date', params = '$params' WHERE id = '$id' ");
    }


    if (count($pending_crop) > 0) {
        $_SESSION["pending_crop"] = serialize($pending_crop);
        $_SESSION["goback"] = "newsletter.php?preview=" . $id;
        jumpto("newsletter.php?crop=1");
    }

    jumpto("?preview=$id");
}



if (!empty($_GET["search"]) && !empty($_GET["module"])) {
    $search = $_GET["search"];
    $output = "";
    $textField = "";
    switch ($_GET["module"]) {
        case "article":
            extract(Article::getList("title LIKE '%$search%' OR text LIKE '%$search%' ", 100));
            $textField = "text";
            break;
        case "recipe":
            extract(Recipe::getList("title LIKE '%$search%' OR text LIKE '%$search%' ", 100));
            $textField = "short_desc";
            break;
        case "fitness":
            extract(Fitness::getList("name LIKE '%$search%' ", 100));
            $textField = "description";
            break;
    }

    if (is_array($list)) {
        foreach ($list as $item) {
            $title = !empty($item['title']) ? $item["title"] : $item["name"];

            $arr = array(
            "title" => $title,
            "text" => string_cut(strip_tags($item[$textField]), 300),
            "thumb" => $item["thumb"],
            "permalink" => $item["permalink"],
            "id" => $item["id"]
            );

            $json = json_encode($arr);

            $output .= "<li><a href='javascript:;' onclick='initBox($json,\"" . $_GET["module"] . "\")'>$title</a></li>";
        }
    }

    if (empty($output)) {
        die("Not found!");
    }

    die("<ul>$output</ul>");
}
?>