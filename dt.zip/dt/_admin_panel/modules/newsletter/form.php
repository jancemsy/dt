<?php
$tid = isset($_GET["edit"]) ? $_GET["edit"] : 0;

if (!empty($tid)) {
    $result = mysql_query("SELECT *FROM newsletter WHERE id = '$tid' ");
    $row = mysql_fetch_array($result);
    $array = array();
    $bam = unserialize($row["params"]);
    foreach ($bam as $field => $value) {
        $array[$field] = stripslashes(urldecode($value));
    }

    $value = $array;
    $_POST = $value;
    if ($_POST["unit_img"] != "") {
        $_POST["unit_text1"] = $_POST["unit_text"];
        $_POST["unit_size1"] = $_POST["unit_size"];
        $_POST["unit_link1"] = $_POST["unit_link"];
        $_POST["unit_img1"] = $_POST["unit_img"];
    }


    $_POST["headline"] = $row["headline"];
    $_POST["sub_headline"] = $row["sub_headline"];
    $_POST["date"] = $row["date"];
    $_POST["id"] = $row["id"];
}

if ($_POST["id"] == "") {
    $result = mysql_query("SELECT id FROM newsletter WHERE 1  ORDER BY id DESC LIMIT 1");
    $row = mysql_fetch_array($result);
    $recID = intval($row["id"]) + 1;
} else {
    $recID = $_POST["id"];
}
?>
<script src="<?php echo PATH; ?>js/jcrop/js/jquery.Jcrop.js"></script>
<link rel="stylesheet" href="<?php echo PATH; ?>js/jcrop/css/jquery.Jcrop.css" type="text/css" />

<script>        
    var ratio = "";    
    var $parent;
    var $img;
    var $dimension = "";
    var api = new Object;
    var jcrop_api;
    var thumbname = "";
    
    
    $('.upload_url_1,.upload_url_2,.upload_url_3,\n\
.upload_url_4,.bbox1,.bbox21,.bbox22,.bbox23').live(' change ',function (e) { /*works for pasting only.... backup ===> input */
        //var element = this;
        //if(e.target.id == 'editor') {
  
        var url = e.target.value + "";                
        url = url.toLowerCase();        
        thumbname = $(e.target).attr("t");
                       
        if(url.match(/\.(jpeg|jpg)$/) != null) {                       
            //upload and init cropping here
            $("<span class='pastedimage-loading'>Loading Image...</span>").insertAfter($(e.target));                           
            $.post("<?php echo PATH; ?>_admin_panel/modules/newsletter/process.php",{ 'uploadpasted' : url , 'name' : thumbname  }, function(result){                                       
                $(".pastedimage-loading").remove();                    
                set_upload_url(result,thumbname);
                //$("."+thumbname+"_img").attr("src",result);                    
            });            
        }
        
        
        
    });
    
    function set_upload_url(url,target){    
        $("." + target).val(url);
        $img = $("."+target+"_img");        
        
        $img.val(url);
        $img.attr("src",url);        
        var $holder = $img.parent();
        
        var newimg = "<img class='"+target+"_img' src='"+$img.attr('src')+"' h='"+$img.attr('h')+"' w='"+$img.attr('w')+"' /> ";                                
        $holder.html(newimg);
        $img = $("."+target+"_img");
                
                
        var h =  $img.attr("h"); //123;
        var w = $img.attr("w");// 92;
        var x = 0;
        var y = 0;                      
        var ratio = $img.attr("w")  / $img.attr("h");                   
        
        $dimension = $("."+target+"_dim");
        $dimension.val(h + "|" + w + "|" + x + "|" + y);                                                                                 
        
        $img.Jcrop({               
            onChange: showPreview,
            onSelect: showPreview,
            aspectRatio:   ratio,
            setSelect:   [ w , h, x, y ]            
        });
    }
    
    function showPreview(coords){        
        if (parseInt(coords.w) > 0)
        {                                                                  
            if($dimension == ""){
                $parent.find(".dimension").val(coords.h + "|" + coords.w + "|" + coords.x + "|" + coords.y);            
            }else{
                $dimension.val(coords.h + "|" + coords.w + "|" + coords.x + "|" + coords.y);              
            }
        }
    }                 


    function populate(target){        
        $parent = $(target);     
        var permalink = $parent.find(".permalink").val();
        $parent.find(".dimension").val(""); //default

        //if found a match, save the image partially for cropping
        $.get("<?php echo PATH; ?>_admin_panel/modules/newsletter/process.php?checklink="+ encodeURIComponent(permalink),function(data){
            
            var $img = $parent.find(".img");                    
            var h = $img.attr("h");
            var w = $img.attr("w");
            var x = 0;
            var y = 0;
            
        
        
            if(data == "nomatch"){              
            }else{
                $parent.find(".dimension").val(h + "|" + w + "|" + x + "|" + y);            
                var json = JSON.parse(data);
              
                $parent.find(".img").attr("src","../"+json.thumb);
                var $img = $parent.find(".img");                                                                              
                
                var newimg = "<img class='img' src='"+$img.attr('src')+"' h='"+$img.attr('h')+"' w='"+$img.attr('w')+"' /> ";                                
                $parent.find(".holder").html(newimg);
                $img = $parent.find(".img");                              
                
                
                
                ratio = $img.attr("w")  / $img.attr("h");                                                       
                $img.Jcrop({               
                    onChange: showPreview,
                    onSelect: showPreview,
                    aspectRatio:   ratio,
                    setSelect:   [ w , h, x, y ]            
                });
                                    
                
                
                
                //$img = $parent.find(".img");              

                   
                
                    
                
                
                
                $parent.find(".img_txt").val("<?php echo PATH; ?>"+json.thumb);
                $parent.find(".txttitle").val(json.title);
                $parent.find(".desc").val(json.desc);
            }          
        });      
    }
    
    
    function unit_change(tt,t){        
        var v1 ,v2, img;
        if(tt == 2 ){
           $(".box-type-ad").show()    
           $(".box-type-single").hide();
        }else{
           $(".box-type-ad").hide();
           $(".box-type-single").show();
        }
        
        
        /*
        for(var i = 1; i < 4; i ++){
            v1 = $("input[name=unit_1"+i+"]").val();
            v2 = $("input[name=unit_2"+i+"]").val(); 
            img =(tt == 1) ? v1 : v2;                                    
                        
            $("input[name=unit_img"+i+"]").val(img);            
            //$(".unit_status").hide().html("Image has been changed. ").fadeIn();
        }
        */
    }
    
    function set_unit(t,v){      
        $("."+t+"_input").val(v);
        $("."+t+"_img").attr("src",v);
        
        $("input[name=unit_1"+t+"]").val("<?php echo PATH; ?>" + v1);
        $("input[name=unit_2"+t+"]").val("<?php echo PATH; ?>" + v2);           
        var img = $("input[name=unit_size]:checked").val() == "468x60" ? "<?php echo PATH; ?>"+v1 : "<?php echo PATH; ?>"+v2;            
        $("input[name=unit_img"+t+"]").val(img);            
        //$(".unit_status").hide().html("Image has been uploaded. <a href='"+img+"' target='_blank'> see</a>").fadeIn();
    }
    function unit_error(error){
        alert(error);
    }
    
    var search = "";
    
    function SearchContent(search,module,container){                    
        if(search != "" && search.length >= 2){  
            container.html("searching..").show();
            $(".searchbox_overlay").show().live("click",function(){
                $(".searchbox").hide();
                $(".searchbox_overlay").hide();
            });
                 
            search = $.get("modules/newsletter/process.php?search="+search+"&module="+module,function(result){
                container.html(result);
            });                                  
        }else{
            container.hide();
            $(".searchbox_overlay").hide();
        }
    }
    
    
    function initBox(json,module){        
        $("."+module+"_search").val("");
        $("."+module+"_title").val(json.title);
        $("."+module+"_img").val("<?php echo PATH; ?>"+json.thumb);
        $("."+module+"_img").attr("src","<?php echo PATH; ?>"+json.thumb);
        $("."+module+"_text").val(json.text);
        $("."+module+"_link").val( json.permalink);      
        $(".searchbox_overlay").click();
    }
    
    
    function uploadit(){
        $("#frmuploader").submit();
        $("#frmuploader .file").val();            
    }
    
    $(function(){
        
        $(".boxes-file").change(function(){
            
        });
        
        $("input[name=ftb1_search]").keyup(function(){                      
            SearchContent($(this).val(),"article",$(".sb1"));           
            //article            
        });

        $("input[name=ftb2_search]").keyup(function(){
            SearchContent($(this).val(),"recipe",$(".sb2"));
            //recipe
        });

        $("input[name=ftb3_search]").keyup(function(){
            SearchContent($(this).val(),"fitness",$(".sb3"));
            //fitness
        });

        $("input[name=ftb4_search]").keyup(function(){
            var $container  = $(".sb4");
            //blog
        });
    });
</script> 
<style>
    .searchbox{width: 480px; height: 150px;  padding: 0px; margin: 0px;   z-index: 55!important;  display:none; border:1px solid #ccc; overflow: auto;  background: #fff; position: absolute; }
    .searchbox ul{ padding: 0px; margin: 0px; }     
    .searchbox li{ padding: 5px; margin: 0px 0px 1px 0;  background: #eee; }
    .searchbox_overlay{   z-index: 50!important;  display:none;  top:0px; left: 0px; position:fixed;   width: 100%; height: 100%;   }
    .subbox {border:1px solid #ccc; display: block; width: 750px;padding:10px 10px 10px 10px;margin-bottom: 20px;  background:#fff!important; color: #333!important; }     
    .subbox input[type=text]{ width: 448px; }
    .subbox .permalink{   }
    .subbox textarea{  height:150px; }
    td input{ width: 570px!important; }
    td textarea{ width: 638px!important; }
    .searchtext{ }
    .subbox.blue{ border: 1px solid blue; }
    .subbox.green{ border: 1px solid green; }
    .subbox.orange{ border: 1px solid orange; }
    .subbox.gray{ border: 1px solid gray; }         
    .inputtextboxes input[type=text]{ width: 680px!important;  }
    .inputtextboxes textarea{ width: 740px!important;  }    
    #newsletter p{ margin: 2px; }
    .holder{ width: 100%!important; border: none;}
</style> 

<div class="box"> 
    <div class="title"> 
        <h2><?php echo empty($tid) ? "Create Newsletter" : "Update Newsletter"; ?> </h2> 
        <?php echo $_dahide; ?>
    </div> 
    <div class="content  forms">   
        <form action="" method="post" enctype="multipart/form-data">
            <p><b>Date:</b> <input name="date" size="70" type="text" value="<?php echo $_POST["date"]; ?>" /> </p>
            <p><b>Headline:</b> <input name="headline"  size="70" type="text" value="<?php echo $_POST["headline"]; ?>" /> </p>
            <p><b>Sub Headline:</b> <input name="sub_headline"   size="65" type="text" value="<?php echo $_POST["sub_headline"]; ?>" /> </p>
            <p><b>Link1:</b> <input type="text" name="link1_text"  value="<?php echo $_POST["link1_text"]; ?>"  placeholder="anchor text" /><input type="text"  size="50" value="<?php echo $_POST["link1_link"]; ?>" name="link1_link"  placeholder="url" /> </p>
            <p><b>Link2:</b> <input type="text" name="link2_text"  value="<?php echo $_POST["link2_text"]; ?>"  placeholder="anchor text"/><input type="text"   size="50"  value="<?php echo $_POST["link2_link"]; ?>" name="link2_link" placeholder="url" /> </p>
            <p><b>Link3:</b> <input type="text" name="link3_text"  value="<?php echo $_POST["link3_text"]; ?>"  placeholder="anchor text"/><input type="text"   size="50" value="<?php echo $_POST["link3_link"]; ?>" name="link3_link" placeholder="url" /> </p>
            <p><b>Link4:</b> <input type="text" name="link4_text"  value="<?php echo $_POST["link4_text"]; ?>" placeholder="anchor text"/><input type="text"    size="50" value="<?php echo $_POST["link4_link"]; ?>" name="link4_link" placeholder="url"/> </p>
            <p><b>Introductory paragraph:</b> </p>
            <p><textarea name="text" rows="5"  cols="50"><?php echo $_POST["text"]; ?></textarea></p> 
            <?php
            $feature_boxes =
                    array("Green Box" => array("green", "Article"),
                        "Gray Box" => array("gray", "Recipe"),
                        "Orange Box" => array("orange", "Fitness"),
                        "Blue Box" => array("blue", "Blog"));
            $i = 1;
            foreach ($feature_boxes as $field => $val) {
                list($class, $module) = $val;
                $targetname = "upload_url_{$recID}$i";
                ?>  
                <p><b><?php echo $field; ?>:</b></p>
                <div class="subbox <?php echo $class; ?> inputtextboxes">
                    <input type="hidden" class="dimension <?php echo $targetname; ?>_dim " name="ftb<?php echo $i; ?>_dimension" />
                    <table>
                        <tr><td>Search <?php echo $module; ?>:</td><td> <input  class="<?php echo strtolower($module) . "_search"; ?> searchtext" name="ftb<?php echo $i; ?>_search" type="text"   />
                                <div class="searchbox sb<?php echo $i; ?>"></div>
                            </td></tr>
                        <tr><td>Permalink:</td><td> <input onchange="populate('.subbox.<?php echo $class; ?>')" class="<?php echo strtolower($module) . "_link"; ?> permalink" name="ftb<?php echo $i; ?>_link" value="<?php echo $_POST["ftb" . $i . "_link"]; ?>" type="text" /> </td></tr>                        
                        <tr><td>Title: </td><td><input class="<?php echo strtolower($module) . "_title txttitle"; ?>" name="ftb<?php echo $i; ?>_title" value="<?php echo $_POST["ftb" . $i . "_title"]; ?>" type="text" /> </td></tr>
                        <tr><td colspan="2">
                                <fieldset style="background:#FAFDFE;">
                                    <legend>IMG(JPG /92x123px only):</legend>

                                    <div class="holder">
                                        <img h="123" w="92" src="<?php echo $_POST["ftb" . $i . "_img"]; ?>" class=" img <?php echo $targetname; ?>_img <?php echo strtolower($module) . "_img"; ?>  "   /> <br/> 
                                    </div>
                                    URL: <input t="<?php echo "upload_url_$i"; ?>" class="<?php echo strtolower($module) . "_img img_txt upload_url_{$recID}$i"; ?>" style="width:375px;" name="ftb<?php echo $i; ?>_img" value="<?php echo $_POST["ftb" . $i . "_img"]; ?>" type="text" />                            
                                    <input class="" style="width:375px;" name="ftb<?php echo $i; ?>_oldimg" value="<?php echo $_POST["ftb" . $i . "_img"]; ?>" type="hidden" />                                                                                                    
                                    <iframe frameborder="0" scrolling="no" width="500px" height="70" src="modules/newsletter/_upload_iframe.php?uploadname=<?php echo $targetname; ?>"></iframe>
                                </fieldset>
                                <div class="clear"></div>
                            </td></tr>

                        <tr><td colspan="2">Desc: <br/> <textarea class="<?php echo strtolower($module) . "_text desc"; ?>" name="ftb<?php echo $i; ?>_text" cols="50"><?php echo $_POST["ftb" . $i . "_text"]; ?></textarea> </td></tr>

                    </table>
                </div>   
                <?php
                $i++;
            }
            ?>
            <div class="searchbox_overlay"></div>

            Ad Unit:
            <div class="subbox">                                

                <input type="hidden" name="unit_11" value="<?php echo $_POST["unit_11"]; ?>" />
                <input type="hidden" name="unit_21" value="<?php echo $_POST["unit_21"]; ?>" />

                <input type="hidden" name="unit_12" value="<?php echo $_POST["unit_12"]; ?>" />
                <input type="hidden" name="unit_22" value="<?php echo $_POST["unit_22"]; ?>" />

                <input type="hidden" name="unit_13" value="<?php echo $_POST["unit_13"]; ?>" />
                <input type="hidden" name="unit_23" value="<?php echo $_POST["unit_23"]; ?>" />


                Size: <label> <input name="unit_size" type="radio" <?php echo $_POST["unit_size"] == "468x60" || empty($_POST["unit_size"]) ? "checked" : ""; ?> value="468x60" onclick="unit_change(1)"  /> 468x60</label>                                
                <label> <input type="radio" name="unit_size" value="125x125" <?php echo $_POST["unit_size"] == "125x125" ? "checked" : ""; ?>  onclick="unit_change(2)"  />125x125</label>

                <script>$(function(){unit_change(<?php echo $_POST["unit_size"] == "125x125" ? 2 : 1; ?>);}); </script>

                <br/><br/>

                <div class="box-type-single">
                    <b>Ad 1:</b> <br/>
                    <p>Image: <input name="unit_img1" type="text" class="ad<?php echo $recID; ?>1_input" value="<?php echo $_POST["unit_img1"]; ?>"   /> or 
                        <iframe  src="modules/newsletter/upload.php?t=ad<?php echo $recID; ?>1&h=1&old=<?php echo $_POST["unit_link1"]; ?>"  frameborder="0" scrolling="no" height="30" width="500" ></iframe>                                                              
                        <span class="unit_status"></span> <br/>
                        <img src="<?php echo $_POST["unit_img1"]; ?>"  class="<?php echo "ad".$recID."1_img"; ?>"    />
                    </p>              
                    <p>Link:  <input type="text" name="unit_link1"   value="<?php echo $_POST["unit_link1"]; ?>" /> </p>            
                    <p>Optional text: <br/><textarea name="unit_text1" style="height:50px!important;"  cols="50"><?php echo $_POST["unit_text1"]; ?></textarea> </p>            
                </div>


                <div class="box-type-ad">
                    <b>Ad 1:</b> <br/>
                    <p>Image: <input name="unit_img2" type="text" class="ad<?php echo $recID; ?>2_input" value="<?php echo $_POST["unit_img2"]; ?>"   /> or 
                        <iframe  src="modules/newsletter/upload.php?t=ad<?php echo $recID; ?>2&h=2&old=<?php echo $_POST["unit_link2"]; ?>"  frameborder="0" scrolling="no" height="30" width="500" ></iframe>  
                        <span class="unit_status"></span> <br/>
                        <img src="<?php echo $_POST["unit_img2"]; ?>"  class="<?php echo "ad".$recID."2_img"; ?>"    />
                    </p>              
                    <p>Link:  <input type="text" name="unit_link2"   value="<?php echo $_POST["unit_link2"]; ?>" /> </p>            
                    <p>Optional text: <br/><textarea name="unit_text2" style="height:50px!important;"  cols="50"><?php echo $_POST["unit_text2"]; ?></textarea> </p>            


                    <b>Ad 2:</b> <br/>
                    <p>Image: <input name="unit_img3" type="text" class="ad<?php echo $recID; ?>3_input" value="<?php echo $_POST["unit_img3"]; ?>"   /> or 
                        <iframe  src="modules/newsletter/upload.php?t=ad<?php echo $recID; ?>3&h=2&old=<?php echo $_POST["unit_link3"]; ?>"  frameborder="0" scrolling="no" height="30" width="500" ></iframe>  
                        <span class="unit_status"></span> <br/>
                        <img src="<?php echo $_POST["unit_img3"]; ?>"  class="<?php echo "ad".$recID."3_img"; ?>"    />
                    </p>              
                    <p>Link:  <input type="text" name="unit_link3"   value="<?php echo $_POST["unit_link3"]; ?>" /> </p>            
                    <p>Optional text: <br/><textarea name="unit_text3" style="height:50px!important;"  cols="50"><?php echo $_POST["unit_text3"]; ?></textarea> </p>            
                    
                    <b>Ad 3:</b> <br/>
                    <p>Image: <input name="unit_img4" type="text"  class="ad<?php echo $recID; ?>4_input" value="<?php echo $_POST["unit_img4"]; ?>"   /> or 
                        <iframe  src="modules/newsletter/upload.php?t=ad<?php echo $recID; ?>4&h=2&old=<?php echo $_POST["unit_link4"]; ?>"  frameborder="0" scrolling="no" height="30" width="500" ></iframe>  
                        <span class="unit_status"></span> <br/>
                        <img src="<?php echo $_POST["unit_img4"]; ?>"  class="<?php echo "ad".$recID."4_img"; ?>"   />
                    </p>              
                    <p>Link:  <input type="text" name="unit_link4"   value="<?php echo $_POST["unit_link4"]; ?>" /> </p>            
                    <p>Optional text: <br/><textarea name="unit_text4" style="height:50px!important;"  cols="50"><?php echo $_POST["unit_text4"]; ?></textarea> </p>            
                </div>





            </div>



            Bottom Box2:
            <div class="subbox"> 
                <?php
                for ($i = 1; $i < 4; $i++) {

                    $targetname = "bbox2$recID$i";
                    echo 'Column ' . $i . ': <br/>
                        
                   <input type="hidden" name="bbox2' . $i . '_img_old" value="' . $_POST["bbox2_img" . $i] . '" />               
                   <input type="hidden" name="bbox2' . $i . '_dimension" value="" class="' . $targetname . '_dim" />
                                           

              <p>Title: <input type="text"  name="bbox2_title' . $i . '" value="' . $_POST["bbox2_title" . $i] . '" /> </p>
              IMG: <input type="text"  t="bbox2' . $i . '" class="' . $targetname . '"  name="bbox2_img' . $i . '" value="' . $_POST["bbox2_img" . $i] . '" /> <br/>
                  
<div class="holder">
              <img  h="150" w="150"   src="' . $_POST["bbox2_img" . $i] . '" class=" img ' . $targetname . '_img"   />      
                  </div>
                
<iframe frameborder="0" scrolling="no" width="500px" height="70" src="modules/newsletter/_upload_iframe.php?uploadname=' . $targetname . '"></iframe>                                     
                  
              <p>Text: <br/><textarea  class="mceEditor" name="bbox2_text' . $i . '" cols="50">' . $_POST["bbox2_text" . $i] . '</textarea> </p> ';
                }
                ?>                      
            </div> 
            <br/>



            <input type="submit" name="save_newsletter" value="<?php echo empty($tid) ? "Create" : "Save"; ?>" />

            <input type="hidden" name="id" value="<?php echo $tid; ?>" />
        </form>


    </div>
</div> 

<script>
    initMCET(".mceEditor");
</script>     
