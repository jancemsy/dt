<?php
if (!defined("PATH"))
    include_once("../../common.php");


$t = $_GET["t"];
$hh = $_GET["h"];
$old = $_GET["old"];
$value = "";

function CleanNewsLetter($file) {
    if ($handle = opendir($file)) {
        while (false !== ($file = readdir($handle))) {
            if (is_file($file)) {
                @unlink($file);
            }
        }
        @closedir($handle);
    } else {
        mkdir($file, 0777, true);
    }
}

if (isset($_FILES["upload_picture"]) && $_FILES['upload_picture']["name"] != "") {
    $imginfo = getimagesize($_FILES['upload_picture']['tmp_name']);
    $w = $imginfo[0];
    $h = $imginfo[1];
    $ext = strtolower(end(explode(".", $_FILES['upload_picture']["name"])));
    
    
    $old = str_replace(PATH,"",$old);
    @unlink(ABSPATH.$old);

    if (empty($imginfo)) { //Not an Image?
        $ErrorMessage .= "The uploaded file doesn't seem to be an image.<br/>";
    } else if ($_FILES["upload_picture"]["size"] > VALID_UPLOAD_MAX_SIZE) {
        $ErrorMessage .= "Acceptable file size is " . intval(VALID_UPLOAD_MAX_SIZE / 1048576) . "mega bytes.<br/>";
        /* }else if( $w > 2000 || $h > 3000 ) {
          $ErrorMessage .= "Image resolution must not higher than 2000x2000 pixels.<br/>";
         * 
         */
    } else {
        if (!search($ext, VALID_UPLOAD_PHOTO_TYPES)) {
            $ErrorMessage .= " Please only upload '" . VALID_UPLOAD_PHOTO_TYPES . "' images.";
        } else {
            $name = $_FILES['upload_picture']["name"];



            if ($hh == 1) {
                $filename = "unit$t" . "_468_60".time().".". $ext;
            } else {
                $filename = "unit$t" . "_125_125".time().".". $ext;
            }

            $thumb_dest = "../../../content/newsletter/$filename";

            @CleanNewsLetter("../../../content/newsletter");
            if (@move_uploaded_file($_FILES["upload_picture"]["tmp_name"], $thumb_dest)) {

                if ($hh == 1) {
                    @createThumb($thumb_dest, $thumb_dest, 468, 60);
                } else {
                    @createThumb($thumb_dest, $thumb_dest, 125, 125);
                }

                if (file_exists($thumb_dest)) {
                    $value = PATH."content/newsletter/$filename";                    
                } else {
                    $ErrorMessage .= "There is an error uploading $name. Please try again if the problem persists, Contact the administrator.<br/>";
                }
            } else {
                $ErrorMessage .= "There is an error uploading $name. Please try again if the problem persists, Contact the administrator.<br/>";
            }
        }
    }
}
?>   
<html>
    <head>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>
        <style>
            html,body{ padding:0px; margin: 0px;}
            *{
                font-size: 12px; 
                font-family: arial;
            }
            td{ color:#666; }
        </style>
        <script>
            function loader(){          
<?php
if (!empty($ErrorMessage)) {
    echo "window.parent.unit_error('sdfdsf');";
}

if (!empty($value)) {
    echo "window.parent.set_unit('$t','$value');";
}
?>
    }
        </script>
        <script>
            $(function(){
                $("input[type=file]").change(function(){
                    $("#loading").text("Uploading...");
                    $("form").hide().submit();
                });             
            });
        </script>
    </head>
    <body onLoad="loader()"> 
        <form action="" method="post" enctype="multipart/form-data">
            <table><tr><td>File:</td><td> <input type="file" name="upload_picture" /></td>                    
                </tr></table>                    
            <div id="loading"></div>
        </form>        
    </body>
</html>