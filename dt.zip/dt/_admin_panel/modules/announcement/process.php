<?php

if (isset($_GET["delete"])) {
    $id = $_GET["delete"];
    $announcement = new Announcement($id);
    $announcement->delete($id);
    jumpto("announcement.php");
}

if (isset($_POST["save"])) {
    $path = "../content/announcement/";
    if (!file_exists($path)) {
        mkdir($path);
    }



    $params = array(
        "link"  => $_POST["link"],
        "title" => addslashes($_POST["title"]),
        "message" => addslashes($_POST["message"]),
        "expiration" => addslashes($_POST["expiration"]),
        "content_type" => $_POST["content_type"],
        "is_dismissible" => intval($_POST["is_dismissible"])
    );

    
    $target_file = (isset($_FILES["upload_banner1"]) && $_FILES['upload_banner1']["name"] != "") ? 'upload_banner1' : '';
    $target_file = (isset($_FILES["upload_banner2"]) && $_FILES['upload_banner2']["name"] != "") ? 'upload_banner2' : $target_file;

    if (!empty($target_file) ){                        
        if (!empty($_POST["banner1"])) @unlink("../" . $_POST["banner1"]);
        if (!empty($_POST["banner2"])) @unlink("../" . $_POST["banner2"]);
        
        
        $name = $_FILES[$target_file]["name"];
        $ext = end(explode(".", $name));
        
        $time = "1" . time();
        $filename = "$time.$ext";
        $thumb = $path . "$filename";
        
        
        move_uploaded_file($_FILES[$target_file]["tmp_name"], $thumb);
        
        $banner1_dest = $thumb;
        $banner2_dest = str_replace(".$ext","2.$ext",$thumb);
        

        createThumb($thumb, $banner1_dest, 728, 90);
        $params["banner1"] = str_replace("../", "", $banner1_dest);
        
        createThumb($thumb, $banner2_dest, 468, 60);
        $params["banner2"] = str_replace("../", "", $banner2_dest);        
    }   



    if ($_POST["id"] != "") {
        $params["id"] = $_POST["id"];
        Announcement::update($params);
    } else {
        Announcement::add($params);
    }

    jumpto("announcement.php");
}
?> 