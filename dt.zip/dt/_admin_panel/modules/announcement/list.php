<div class="box"> 
    <div class="title"> 
        <h2>Announcement</h2> 
        <?php echo $_dahide; ?>
    </div> 
    <div class="content pages"> 

        <p><a href="?new=1" class="button">New Announcement</a></p>   


        <table cellspacing="0" class="table">
            <thead> 
                <tr class="tr-header">
                    <td>#</td>                    
                    <td>Title</td>
                    <td>Content</td>
                    <td>Expiration</td>
                    <td align='center'>Dismissible</td>
                    <td width="70">Action</td>
                </tr>
            </thead> 
            <?php
            $list = Announcement::getList();

            foreach ($list as $item) {
                $button = "<a href='?delete={$item["id"]}'  class='delete-btn' >$_dadelete</a> 
            <a href='?edit={$item["id"]}'>$_daedit</a> ";


                if ($item["content_type"] == "banner1") {
                    $content = "728x90 Banner<br/><a target='_blank' href='" .$item["link"] . "'><img src='" . PATH . $item["banner1"] . "' width='90' /></a>";
                } else if ($item["content_type"] == "banner2") {
                    $content = "468x60 Banner <br/><a target='_blank'href='" . $item["link"] . "'><img src='" . PATH . $item["banner2"] . "' width='90' /></a>";
                } else {
                    $content = $item["message"];
                }

                $dismissible = $item["is_dismissible"] == 1 ? "yes" : "no";

                echo "
           <tr>
            <td>{$item["id"]}</td>            
            <td>{$item["title"]}</td>
            <td>$content</td>
            <td>{$item["expiration"]}</td>
            <td align='center'>$dismissible</td>
            <td>$button</td>
           </tr>";
            }
            ?>
        </table>
    </div>
</div>    