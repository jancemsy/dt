<?php
$type = "Add";
if( isset($_GET["edit"]) ){
    $id = $_GET["edit"]; 
    
    $announcement = new Announcement($id);
    $_POST = $announcement->array;            
    $type = "Edit";
}

?> 

<div class="box"> 
            <div class="title"> 
                    <h2><?php echo $type; ?> Announcement</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms">
<form action="" method="post"    enctype="multipart/form-data" class="diet-form" id="category_form" >
    <input type="hidden" name="id" value="<?php echo $_POST['id']; ?>" /> 
    
    <table>
        <tr>
            <td>Expiration:</td><td><input type="text" class="datepicker" name="expiration" value="<?php echo $_POST['expiration']; ?>"   /></td>                        
        </tr>
        <tr>
            <td>Title:</td><td><input type="text" name="title" value="<?php echo $_POST['title']; ?>" size="105" /></td>                        
        </tr>
        
        
        <tr><td>Content Type</td>
            <td><select name="content_type">
                    <option value="text">Text</opti2on>
                    <option value="banner1">728x90 banner</option>
                    <option value="banner2">468x60 banner</option>
                </select></td>
        </tr>
        
        
        
        
        
        <tr  class="tr_banner1 tr_banner2 acontent" ><td>Banner Link: </td><td>
                        <input type="text" name="link" size="50" value="<?php echo $_POST["link"]; ?>" />
         </td></tr>
        
        
        <tr  class="tr_banner1  acontent" ><td>728x90 Banner: </td><td>
                        <div  class="row">    
                            <input type="file" size="46"  name="upload_banner1" class="upload"  />             
                            <input type="hidden" name="banner1" value="<?php echo $_POST["banner1"]; ?>" />
                        </div>
                        <?php
                        if (!empty($_POST["banner1"])) {
                            echo ' <br/> <img class="attached-banner1" src="' . PATH . $_POST["banner1"] . '" width="100" /> ';
                        }
                        ?>             
         </td></tr>
        
        <tr class="tr_banner2 acontent"><td>468x60 Banner:</td><td>
                        <div  class="row">    
                            <input type="file" size="46"  name="upload_banner2" class="upload"  />             
                            <input type="hidden" name="banner2" value="<?php echo $_POST["banner2"]; ?>" />                            
                        </div>
                        <?php
                        if (!empty($_POST["banner2"])) {
                            echo ' <br/> <img class="attached-banner2" src="' . PATH . $_POST["banner2"] . '" width="100" /> ';
                        }
                        ?>             
         </td></tr>
        
        <tr class="tr_text  acontent">
            <td>Text:</td>
            <td><textarea name="message"    cols="52"><?php echo $_POST['message']; ?></textarea></td>                        
        </tr>
        
        
        <tr>
            <td>Is dismissible?:</td>
            <td>
                <label><input type="radio" value="1" name="is_dismissible" <?php echo  $_POST["is_dismissible"] == "1" ? "checked" : "" ?> /> Yes</label>
                <label><input type="radio" value="0" name="is_dismissible"  <?php echo  $_POST["is_dismissible"] == "0" || $_POST["is_dismissible"] == "" ? "checked" : "" ?> />No </label>            
            </td>                        
        </tr>
        
         
        <tr>
            <td colspan="2"> 
                             
                 <div class="row buttons"> 
                   <button type="button" onclick="location.href='?'" ><span>Cancel</span></button>                                                
                   <button type="submit" name="save"><span>Save</span></button>                                                
                </div>
                
            </td>                        
        </tr>
        
    </table>
</form>
        
    </div>        
</div>    


<script>
  showcontenttype('<?php echo $_POST["content_type"]; ?>');
  
  $(function(){
     $("select[name=content_type]").change(function(){
         var v = $(this).val();
         showcontenttype(v);
     })
  });
  function showcontenttype(type){
      if(type == "") type = "text"
      $("select[name=content_type]").val(type);
      $(".acontent").hide();
      $(".tr_"+ type).show();            
  }
  
  
  initMCE();          
</script>