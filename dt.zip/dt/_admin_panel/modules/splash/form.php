<?php
$id = "";
$type = "Add";
if(isset($_GET["edit"])){
    $id = $_GET["edit"];
    $splash = new Splash($id);
    if( !empty($splash->id) ){     
        $_POST = unserialize($splash->params);
        $_POST["type"] = $splash->type;
        $_POST["video_embed"] = convert_to_original(serializeDecode($_POST["video_embed"]));
        $_POST["num"] = $splash->num;
    }
    $type = "Update";
}




?>

<div class="box"> 
            <div class="title"> 
                    <h2><?php echo $type; ?> Splash</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms">
<form action="" method="post" onsubmit="return checkSplashForm()"   enctype="multipart/form-data" id="splash_form" >
    <input type="hidden" name="id" value="<?php echo $id; ?>" />
    <input type="hidden" name="flv" value="<?php echo $_POST['flv']; ?>" />
    <input type="hidden" name="video_thumb" value="<?php echo $_POST['video_thumb']; ?>" />
            
    <table>
    <tr><td>Show at:</td><td> 
            <select name="type"><option value="all">All Areas</option>                
                <option value="home" <?php echo $_POST['type'] == 'home' ? 'selected' : ''; ?> >Home Page</option>
                <option value="category" <?php echo $_POST['type'] == 'category' ? 'selected' : ''; ?> >Category Page</option>
                <option value="product" <?php echo $_POST['type'] == 'product' ? 'selected' : ''; ?> >Product Page</option></select>
            </td></tr>     
    
    <tr><td>Order:</td><td>  <input type="text" name="num" class="text-input" value="<?php echo $_POST['num']; ?>" /></td></tr> 
    <tr><td>Headline:</td><td>  <input type="text" name="headline" class="text-input" value="<?php echo $_POST['headline']; ?>" /></td></tr> 
    <tr><td>Description:</td><td><textarea name="description"  class="editor text-input" ><?php echo $_POST['description']; ?></textarea></td></tr> 
    <tr><td>Link:</td><td> <input type="text" name="link" class="text-input" value="<?php echo $_POST['link']; ?>" /> (learn more link) </td></tr> 
    <tr><td>Background Image<br/> 
            960x306px
            (Required)*: </td>
        <td>  
            
            
            <i>Select Image:</i> <div style="width:400px;">
            <?php
            $path = "../content/splash_bg/";
               if ( $handle = opendir($path) ) {   

                /* This is the correct way to loop over the directory. */
                while (false !== ($file = readdir($handle))) {
                    $ext = strtolower(end(explode(".",$file)));

                    if($file != ".." && $file != "." ){  
                      $check = ($_POST['bg'] == $file) ? 'checked' : '';
                      
                      echo "<label>  
                         <span><input type='radio' name='bg' value='$file' class='radio' $check /></span>
                      <img src='$path/$file' width='100' /> 
                       
                       </label>  ";
                    }
                }

                closedir($handle);
              }
             ?>  
                <div class="clear"></div>
             
            </div>
            or Upload BG: 
            <div class="row" style="border:none!important;">
             <input type="file" id="upload" name="upload" value="" />  <br/><br/>
            </div>
            
        </td></tr>    
    
    
    
    
    <tr><td>Video:</td><td>
            <div class="row"  >
            <input type="file" size="46" id="upload_flv" name="upload_flv"  /> (flv)
            
            <?php echo $_POST['flv']; ?> 
           
            </div>
            
             or  (embed)  <br/> 
            <textarea id="video_embed" name="video_embed" cols="55" rows="6" ><?php echo $_POST['video_embed']; ?></textarea> 
        </td></tr> 
    
     <tr><td>Video Thumbnail 334px × 246px:</td><td>
             <div class="row">         
               <input type="file" size="46"  name="upload_vid_thumbnail"  /> 
             </div>
             <?php
             if( !empty($_POST["video_thumb"]) ){
                 echo '<img src="'.PATH.$_POST["video_thumb"].'" width="100" /> ';
                 
                 echo '<br/><br/><label><input type="checkbox" name="remove_video" value="1" /> Remove Video from this slide</label>';
             }
             ?>
             
        </td></tr> 
      
      
    
    </table>
     
    
     <div class="row buttons"> 
           <button type="button" onclick="location.href='?'" ><span>Cancel</span></button>                                                
           <button type="submit" name="add_splash"><span>Save</span></button>                                                
        </div>
         
</form>

<script>
    initMCET('.editor');
    function checkSplashForm(){
        var errors = "";
        
        if($("input[name='bg']:checked").val() == undefined){
            if( $("#upload").val() == ""){
                errors = "Invalid background image!!";
            }
                
        }
        
        if(errors != ""){
            alert(errors);
            return false;
        }else{ 
            return true;
        } 
    }

</script>

  </div>
</div>
    