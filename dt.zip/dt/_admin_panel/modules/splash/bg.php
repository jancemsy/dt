<?php
 include("../../common.php");    
 
 if(isset($_FILES["upload"])){
    $name = $_FILES['upload']["name"];
    $ext   = end(explode(".",$name));
    $time = time();                 
    $filename = "$time.$ext";
    $thumb_dest = "../../../content/splash_bg/$filename";
    move_uploaded_file($_FILES["upload"]["tmp_name"], $thumb_dest ); 
    jumpto("../../splash.php"); 
 }
    
?> 

<h1>Background</h1>

<form action="modules/splash/bg.php" method="post" enctype="multipart/form-data" >
    File Upload:<br>
    <input type="file" id="upload" name="upload" value="" />  <br/>
    <input type="submit" value="upload" />
    <input type="button" value="cancel" onclick="closePopup()" />
</form>