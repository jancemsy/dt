<?php


if( isset($_GET["delete_splash"]) ){ 
    $id = $_GET["delete_splash"];
    $splash = new Splash($id);
    $post = unserialize($splash->params); 
    @unlink("../content/splash/".$post["bg"]);     
    Splash::delete($id);
    jumpto("splash.php");
}

if( isset($_GET["delete_bg"]) ){ 
    @unlink(APATH."content/splash_bg/".$_GET["delete_bg"]); 
    jumpto("splash.php");
}

if( isset($_POST["add_splash"]) ){ 
     if(isset($_FILES["upload"]) && $_FILES['upload']["name"] != ""){        
        $name = $_FILES['upload']["name"];
        $ext   = end(explode(".",$name));
        $time = time();                 
        $filename = "$time.$ext";
        $thumb_dest = "../content/splash_bg/$filename";
        move_uploaded_file($_FILES["upload"]["tmp_name"], $thumb_dest ); 
        $bg = $filename;
     }else{
       $bg = $_POST["bg"];
     }
     
     if(isset($_FILES["upload_flv"]) && $_FILES['upload_flv']["name"] != ""){
        if( !empty($_POST["flv"]) ) @unlink("../".$_POST["flv"]);
        $name = $_FILES['upload_flv']["name"];
        $ext   = end(explode(".",$name));
        $time = time();                 
        $filename = "flv$time.$ext";
        $thumb_dest = "../content/splash_video/$filename";
        move_uploaded_file($_FILES["upload_flv"]["tmp_name"], $thumb_dest ); 
        $_POST["flv"] = "content/splash_video/".$filename;
     } 
     
     $video_embed =  serializeEncode($_POST["video_embed"]);
          
     
     if(isset($_FILES["upload_vid_thumbnail"]) && $_FILES['upload_vid_thumbnail']["name"] != ""){
        if( !empty($_POST["video_thumb"]) ) @unlink("../".$_POST["video_thumb"]);
        $name = $_FILES['upload_vid_thumbnail']["name"];
        $ext   = end(explode(".",$name));
        $time = time();                 
        $filename = "$time.$ext";
        $thumb_dest = "../content/splash_video/$filename";  
        move_uploaded_file($_FILES["upload_vid_thumbnail"]["tmp_name"], $thumb_dest); 
        createThumb($thumb_dest,$thumb_dest,334,246);  
        $video_thumb = "content/splash_video/".$filename;
     }else{
        $video_thumb = $_POST["video_thumb"];
     }
     
     
     if($_POST["remove_video"] == 1){
         @unlink("../".$_POST["video_thumb"]);
         @unlink("../".$_POST["flv"]);
         $video_embed = "";
         $video_thumb = "";
         $_POST["flv"] = "";         
     }
     

     
     $array = array(              
       "video_thumb" => $video_thumb,
       "video_embed" => $video_embed, 
       "flv" => $_POST["flv"],
       "bg" => $bg,
       "headline" => $_POST["headline"],       
       "description" => $_POST["description"],         
       "link" => $_POST["link"]    
     );
     
     $params = serialize($array); 
     
     
     if($_POST["id"] != ""){
        Splash::update($_POST["num"],$_POST["id"],$params,$_POST["type"]); 
     }else{
        Splash::add($_POST["num"],$params,$_POST["type"]); 
     }
     
     jumpto("splash.php"); 
}
 
 
?> 