 <?php 
    $path = "../content/splash_bg/"; 
 ?>


<div class="box"> 
        <div class="title"> 
                <h2>Splash Area</h2> 
                <?php echo $_dahide; ?>
        </div> 
        <div class="content pages">  
            
<p><a href="?new=1" class="button">New Splash</a></p>

 <table cellspacing="0" class="table">
    <thead>  
    <tr class="tr-header">
        <td>ID</td> 
        <td width="100">Headline</td>
        <td width="150">Desc</td>
        <td width="150">Link/Video</td> 
        <td>BG</td> 
        <td>Type</td> 
        <td>Order</td> 
        <td width="70">Action</td>         
    </tr>
    </thead> 
    <?php
       $output = "";
       $list = Splash::getList(99999,"num","all");
       $i = 0;
       foreach($list as $item){
           $array = unserialize($item["params"]);
            
           $img  = "<img src='$path{$array['bg']}'  width='150'  /> ";
           $button = "<a href='?delete_splash={$item['id']}' class='delete-btn'>$_dadelete</a> <a href='?edit={$item['id']}'>$_daedit</a>";
           $i++;
           
           $video = !empty($array["flv"]) || !empty($array["video_embed"]) ?  "<br/>[w/ video]" : "";
           
           $tr_class = $i%2 == 0 ? "tr-odd" : "tr-even";
           
           $text =  string_cut(strip_tags($array['description']),250);
           
           $output .= "<tr class='$tr_class' >
                <td>{$item['id']}</td> 
                <td>{$array['headline']}</td>
                <td>$text</td>
                <td>{$array['link']} $video</td> 
                <td>$img</td>
                <td>{$item['type']}</td>
                <td>{$item['num']}</td> 
                <td>$button</td>
            </tr>";
           
       }
       echo $output;
    
    ?>    
</table>


</div></div>

 

 


                        <!--[if !IE]> START LEFT BOX <![endif]--> 
			<div class="box medium"> 
				<div class="title"> 
					<h2>Backgrounds</h2> 
					<?php echo $_dahide ; ?>
				</div> 
				<div class="content thumbs"> 
				   <?php 
                                       if ( $handle = opendir($path) ) {   

                                        /* This is the correct way to loop over the directory. */
                                        while (false !== ($file = readdir($handle))) {
                                            $ext = strtolower(end(explode(".",$file)));

                                            if($file != ".." && $file != "." ){  ?>
                                                <div class="thumb" style="width:200px!important; background: none!important;"> 
                                                            <div ><a href='?delete_bg=<?php echo $file; ?>' class='delete-btn'></a></div> 
                                                            <img   src="<?php echo $path.$file; ?>" alt="" style=" background: none!important; border: 1px solid #ccc; width:190px!important; height: auto!important;" /> 
                                                    </div> 
                                                <?php
                                            }
                                        }

                                        closedir($handle);
                                      }
                                     ?> 
				</div> 
			</div> 
			<!--[if !IE]> END LEFT BOX <![endif]-->  
		
			<!--[if !IE]> START RIGHT BOX <![endif]--> 
			<div class="box medium"> 
				<div class="title"> 
					<h2>New Background</h2> 
					<?php echo $_dahide ; ?>
				</div> 
				<div class="content  forms">
					 <form action="modules/splash/bg.php" method="post" enctype="multipart/form-data" >
                                            File Upload:<br>
                                            <div class="row"> 
                                              <input type="file" class="file_1" id="upload" name="upload" value="" />  <br/>
                                            </div>
                                            
                                            <div class="row buttons"> 
                                               <button type="button" onclick="closePopup()" ><span>Clear</span></button>                                                
				               <button type="submit"><span>Submit</span></button>                                                
                                            </div>
                                            
                                        </form>
				</div> 
			</div> 
			<!--[if !IE]> END RIGHT BOX <![endif]--> 