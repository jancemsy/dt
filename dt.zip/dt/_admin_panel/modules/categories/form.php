


<div class="box"> 
            <div class="title"> 
                    <h2>Add/Update Category</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
            <div class="content  forms">
                                    
                                    
 

<?php
$id = "";
if(isset($_GET["edit"])){
    $id = $_GET["edit"];
    $category = new Category($id);
    if( !empty($category->id) ){
        $_POST = $category->array; 
    }
}


?>
<form action="" method="post" onsubmit="return checkCategoryForm()"   enctype="multipart/form-data" id="category_form" >
    <input type="hidden" name="id" value="<?php echo $id; ?>" />
    <input type="hidden" name="icon" value="<?php echo $_POST["icon"]; ?>" />
    <table width="100%">
    <tr><td width="100">Name:</td><td>  <input type="text" name="name" class="text-input" value="<?php echo $_POST['name']; ?>" /></td></tr> 
    <tr><td>Description:</td><td><textarea name="description"  class="text-input" ><?php echo $_POST['description']; ?></textarea></td></tr>             
    <tr><td>Type:</td><td>
            <select name="type">
                <option value="diet" <?php  echo $_POST['type'] == 'food' ? 'selected' : '';  ?> >diet</option>
                <option value="price" <?php  echo $_POST['type'] == 'price' ? 'selected' : '';  ?> >price</option>
                <option value="duration" <?php  echo $_POST['type'] == 'duration' ? 'selected' : '';  ?> >duration</option>
                <option value="product" <?php  echo $_POST['type'] == 'produc' ? 'selected' : '';  ?> >product</option>
            </select>
        </td></tr>
     <tr><td>Order Num:</td><td>  <input type="text" name="num" class="text-input" value="<?php echo $_POST['num']; ?>" /></td></tr> 
       <tr><td>Icon 22px × 25px :</td><td>               
             <div class="row">                
                <input type="file"   class="file_1"  name="upload"  />             
                <?php if( !empty($_POST["icon"]) ){ echo '   <img src="'.PATH.$_POST["icon"].'" width="25" /> ';  } ?>             
             </div>
        </td></tr> 
     
    </table>
     
     
     
     <div class="row buttons"> 
           <button type="button" onclick="location.href='?'" ><span>Cancel</span></button>                                                
           <button type="submit" name="add_category"><span>Save</span></button>                                                
        </div>
    
      
</form>

<script>
    initMCE();
    function checkCategoryForm(){
        var errors = "";
        
        if($("input[name='name']").val() == ""){           
                errors += "Invalid Category Name\n";        
        }
        
         if($("textarea[name='description']").val() == ""){           
                errors += "Invalid Category Description\n";        
        }
        
        
        if(errors != ""){
            alert(errors);
            return false;
        }else{ 
            return true;
        } 
    }

</script>

        </div>
</div>    