<?php


if( isset($_GET["delete_cat"]) ){ 
    Category::delete($_GET["delete_cat"]);
    jumpto("category.php");
}
 
if( isset($_POST["add_category"]) ){   
     if(isset($_FILES["upload"]) && $_FILES['upload']["name"] != ""){
        if( !empty($_POST["thumb"]) ) @unlink("../".$_POST["thumb"]);
        $name = $_FILES['upload']["name"];
        $ext   = end(explode(".",$name));
        $time = time();                 
        $filename = "$time.$ext";
        $thumb_dest = "../content/category_icon/$filename";
        move_uploaded_file($_FILES["upload"]["tmp_name"], $thumb_dest );         
        createThumb($thumb_dest,$thumb_dest,37,37);          
        $_POST["icon"] = "content/category_icon/$filename";
     }
     
    
    
     $params = array("name" => $_POST["name"],
         "description" => $_POST["description"],
         "type" => $_POST["type"] ,
         "icon" => $_POST["icon"], 
         "num" => $_POST["num"]);
             
     if($_POST["id"] != ""){
         $params["id"] =  $_POST["id"];
         Category::update($params); 
     }else{
         Category::add($params); 
     }
     
     jumpto("category.php"); 
}
 
 
?> 