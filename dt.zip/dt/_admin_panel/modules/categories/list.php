 

<div class="box"> 
        <div class="title"> 
                <h2>Add/Edit Category</h2> 
                <?php echo $_dahide; ?>
        </div> 
        <div class="content pages"> 
            
<p><a href="?new=1" class="button">New Category</a></p>

 <table cellspacing="0" class="table">
    <thead> 
    <tr class="tr-header">
        <td>ID</td> 
        <td width="250">Name</td>
        <td width="450">Desc</td>                
        <td>Type</td> 
        <td>Order</td>
        <td width="60">Action</td>         
    </tr>
    </thead> 
    <?php
       $output = "";
       $list = Category::getList();
       $i = 0;
       foreach($list as $item){ 
             
           $button = "
           
           
           <a href='?delete_cat={$item['id']}' class='delete-btn'>$_dadelete</a>  <a href='?edit={$item['id']}'>$_daedit</a>";
           $i++;
           
           $text =  string_cut(strip_tags($item["description"]),50);
           
           $tr_class = $i%2 == 0 ? "tr-odd" : "tr-even";           
           $icon = "<img src='".PATH."{$item["icon"]}' />";           
           $output .= "<tr class='$tr_class' >
                <td>{$item['id']}</td> 
                <td>{$item['name']} <br/>
                    $icon
                  
                </td>
                <td>$text</td>                
                <td>{$item['type']}</td>                
                <td>{$item['num']}</td> 
                <td>$button</td>
            </tr>";
           
       }
       echo $output;
    
    ?>    
</table>

        </div>
</div>    
 