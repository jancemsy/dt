<?php
$path = "../content/products/tmp";


if (!file_exists($path)) {
    mkdir($path);
}



if (isset($_POST["update_quantities"])) {
    $created = 0;
    $updated = 0;
    $catID = $_POST["catID"];
    $handle = fopen($_POST["target_file"], 'r');
    $ignore_list = explode(",", $_POST["ignore_list"]);
     $ignore_count  =0;

    $i = 0;
    while (($data = fgetcsv($handle) ) !== FALSE) {

        if ($i == 0) {
            $field_names = $data;
        } else if (!in_array($i, $ignore_list)) {
            //extract variables 
            for ($index = 0; $index < count($field_names); $index ++) {
                eval(' $' . $field_names[$index] . ' = $data[$index];  ');
            }

            $qty = $qty_avail;
            $model_number = $product_sku;
            $doba_product_id = $product_id;
            $price = $custom_price;
            $product_name = $title;
            if (!empty($model_number)) {
                //check if doba product id is exists 
                $result = mysql_query("SELECT *FROM products  WHERE doba_product_id = '$doba_product_id'  ");
                if (mysql_num_rows($result) > 0) {
                    // echo "  $qty --- $doba_product_id  --- $model_number <br/> ";
                    $result = mysql_query("UPDATE products SET qty = $qty WHERE doba_product_id = '$doba_product_id'  ");
                    $updated ++;
                } else {
                    //*
                    $result = mysql_query("SELECT *FROM products  WHERE model_number = '$model_number'  ");
                    if (mysql_num_rows($result) > 0) {
                        $result = mysql_query("UPDATE products  SET doba_product_id = '" . mysql_real_escape_string($doba_product_id) . "' , "
                                . " qty = $qty WHERE model_number = '$model_number'  ");
                        $updated ++;
                    } else {
                        //*/
                        // incase no doba_product_id and model_number has match, we will create a new record 
                        $created ++;

                        //image_file;
                        $filename = "$doba_product_id.jpg";
                        $src = "../content/products/$filename";
                        copy($image_file, $src);
                        $large_dest = $src;
                        $thumb_dest = "../content/products/$doba_product_id-small.jpg";
                        createThumb($src, $large_dest, 288, 288);
                        createThumb($src, $thumb_dest, 67, 67);
                        $thumbs = serialize(array(
                            "thumb1" => str_replace("../", "", $thumb_dest)
                        ));

                        $params = array(
                            "qty" => $qty,
                            "category_id" => $catID,
                            "doba_product_id" => mysql_real_escape_string($doba_product_id),
                            "model_number" => mysql_real_escape_string($model_number),
                            "product_name" => mysql_real_escape_string($product_name),
                            "description" => mysql_real_escape_string($description),
                            "thumbs" => $thumbs,
                            "regular_price" => $price,
                            "total_price" => $price,
                        );

                        $id = Product::add($params);
                    }
                }
            }
        }else{
            $ignore_count  ++;
        }
        $i ++;
    }//while
    // exit();

    echo "<html><head><meta http-equiv=\"refresh\" content=\"5; url=products.php\" /></head><body> "
    . "<div style='padding:10px;'>Successuflly processed. Created records: $created, Updated records: $updated, ignored records: $ignore_count <br/> "
    . "This will redirect in 5 seconds...</div> </body> </html> ";
    exit();
} else if (isset($_POST["upload_product"])) {

    $str = $_FILES["upload"]["name"];
    $duplicate_error = "";

    if (search("equipment", $str)) {
        $catID = 18;
    } else if (search("supplement", $str)) {
        $catID = 19;
    } else if (search("book", $str)) {
        $catID = 21;
    } else {
        $catID = 0;
    }

    if ($catID === 0) {
        echo "<div style='color:red; margin:50px; padding:10px;'>The system cannot recognize the category of this csv. The filename must contain a cue word like export_20140812130540_<b>equipment</b>.csv or "
        . " export_20140813123344_<b/>books</b>.csv to work. </div>";
    } else {

        $target_file = $path . time() . ".csv";
        move_uploaded_file($_FILES["upload"]["tmp_name"], $target_file);

        $to_display_names = array("product_id", "product_sku", "qty_avail", "msrp");
        $i = 0;
        $fields_output = "";
        $handle = fopen($target_file, 'r');
        $display = "  <br/><table>";

        while (($data = fgetcsv($handle) ) !== FALSE) {
            if ($i == 0) {
                $field_names = $data;
                $display .= "<tr><td>#</td>";
                $j = 0;
                foreach ($field_names as $name) {
                    if ($name == "product_id") {
                        $product_id_index = $j;
                    }
                    $j++;

                    if (in_array($name, $to_display_names)) {
                        $display .= "<td>$name</td>";
                    }
                }
                $display .= "<td>Ignore</td></tr>";
            } else {
                $fields = $data;
                if (!empty($fields[0])) {


                    if (search("prod_id_" . $fields[$product_id_index], $display)) {
                        $is_duplicate = 1;
                        $duplicate_error = "<div style='color:red'>We found a duplicate doba product_id in the list. Please check the checkbox if you desired to ignore some items in the list.</div> <br/> "; 
                    } else {
                        $is_duplicate = 0;
                    }


                    $display .= "<tr class='prod_id_" . $fields[$product_id_index] . " " . ($is_duplicate ? "duplicate" : "") . "' ><td  >$i</td>";

                    for ($index = 0; $index < count($field_names); $index ++) {

                        if (in_array($field_names[$index], $to_display_names)) {

                            if ($is_duplicate && $field_names[$index] == "product_id") {
                                $display .= "<td>{$fields[$index]} (DUPLICATE) </td>";
                            } else {
                                $display .= "<td>{$fields[$index]} </td>";
                            }
                        }


                        $fields_output .= "  <textarea name='{$field_names[$index]}[]' style='display:none'>" . mysql_real_escape_string($fields[$index]) . "</textarea> ";
                    }

                    $display .= "<td><input type='checkbox' class='ignore_checker' onclick='init_ignore()' value='$i'  /></td></tr>";
                }
            }
            $i ++;
        }


        $display .= "</table>   ";
        $rows = $i - 1;
        ?>  
        <script>
            function init_ignore() {
                var checked = "";
                $(".ignore_checker:checked").each(function() {
                    checked += checked != "" ? "," : "";
                    checked += $(this).val();
                });

                $("[name=ignore_list]").val(checked);
            }
        </script>

        <style> .duplicate{ color: red; }
        </style> 
        <div class="box"> 
            <div class="title"> 
                <h2><?php echo $title; ?></h2> 
                <?php echo $_dahide; ?>
            </div> 
            <div class="content pages">  

                
                <form action="" method="post"> 
                    <?php
                    echo $duplicate_error; 
                    echo "<input type='hidden' name='target_file' value='$target_file'  /> ";
                    echo "<input type='hidden' name='catID' value='$catID' /> ";
                    echo "<input type='hidden' name='ignore_list' value='' /> ";
                    ?>  
                    <div style=' border:1px solid #ccc; padding:10px; font-size:18px; font-weight:bold; margin-bottom:20px;   '>Confirm product <?php
                        if ($catID == 18)
                            echo "equipment";
                        else if ($catID == 19)
                            echo "supplement";
                        else if ($catID == 21)
                            echo "book";
                        ?> update (<?php echo $rows; ?> rows)
                        <div class="row buttons" >                                                  
                            <button type="button"  onclick="location.href = 'products.php';" class="save-btn" ><span>Cancel</span></button>                                                
                            <button type="submit" name="update_quantities" class="save-btn" ><span>Update Products</span></button>                                                

                            <img src="../images/loading-small.gif" class="loader" style="display:none"  />
                            <span class="status"></span>
                        </div> 
                    </div>  

                    <?php
                    echo $display;
                    define("NO_FORM", 1);
                    ?>
                </form>
            </div> 
        </div> 
        <?php
    }
}


if (!defined("NO_FORM")) {
    ?>
    <div class="box"> 
        <div class="title"> 
            <h2><?php echo $type; ?> Upload CSV to update product available quantities</h2> 
            <?php echo $_dahide; ?>
        </div> 
        <div class="content  forms">
            <form action="" method="post"   enctype="multipart/form-data"  > 
                Updoad product csv: 
                <div  class="row">   
                    <input type="file" name="upload" />   
                </div>

                <div class="row buttons" >                                                  
                    <button type="submit" name="upload_product" class="save-btn" ><span>Upload CSV</span></button>                                                
                    <img src="../images/loading-small.gif" class="loader" style="display:none"  />
                    <span class="status"></span>
                </div>
            </form>


        </div>        
    </div>    
<?php } ?>
