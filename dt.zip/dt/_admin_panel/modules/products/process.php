<?php
 


if( isset($_GET["delete"]) ){ 
    $id = $_GET["delete"];
    $product = new Product($id); 
    @unlink("../".$product->thumb);     
    $product->delete($id);
    jumpto("products.php?cat=".$catID); 
}

if( isset($_POST["add"])    ){     
    
    
    
    for($i = 1; $i < 6; $i++){         
      if(isset($_FILES["upload$i"]) && $_FILES["upload$i"]["name"] != ""){
        if( !empty($_POST["thumb$i"]) ){
            @unlink("../".$_POST["thumb$i"]);
            @unlink("../".str_replace("-small","",$_POST["thumb$i"]));            
        }
        
        $name = $_FILES["upload$i"]["name"];
        $ext   = end(explode(".",$name));
        $time = time()."-$i";                 
        $filename = "$time.$ext";
        $src = "../content/products/$filename";
        $large_dest = "../content/products/$filename";
        $thumb_dest = "../content/products/$time-small.$ext";
        
        move_uploaded_file($_FILES["upload$i"]["tmp_name"], $src );         
        createThumb($src,$large_dest,288,288);          
        createThumb($src,$thumb_dest,67,67);                  
        
        $_POST["thumb$i"] = str_replace("../","",$thumb_dest);        
       } 
    }
     
          
    $thumbs = serialize(array( "thumb1" => $_POST["thumb1"],
                      "thumb2" => $_POST["thumb2"],
                      "thumb3" => $_POST["thumb3"],
                      "thumb4" => $_POST["thumb4"],
                      "thumb5" => $_POST["thumb5"],
                     ));
     
  
   $params = array( 
                     "meta_title" => addslashes($_POST["meta_title"]),         
                     "meta_desc" => addslashes($_POST["meta_desc"]),
                     "meta_keywords" => addslashes($_POST["meta_keywords"]),
                     "qty" => intval($_POST["qty"]),
                     "short_description" => addslashes($_POST["short_description"]),
                     "bullets" => addslashes($_POST["bullets"]),
                     "category_id" => $catID,
                     "model_number" => addslashes($_POST["model_number"]),
                     "product_name" => addslashes($_POST["product_name"]), 
                     "description" => addslashes($_POST["description"]),
                     "thumbs" => $thumbs,
                     "discount" => addslashes($_POST["discount"]),
                     "regular_price" => addslashes($_POST["regular_price"]), 
                     "total_price" => addslashes($_POST["total_price"]) ,
          
                     "featured" => addslashes($_POST["featured"]),
                     "featured_text" => clean_quote($_POST["featured_text"]),
                     "featured_order" => intval($_POST["featured_order"])
       );
    
     if($_POST["id"] != ""){
        $params["id"] = $_POST["id"]; 
        $id = $_POST["id"];
        Product::update($params); 
     }else{
        $id = Product::add($params); 
     }
     
     jumpto("products.php?edit=$id&cat=".$catID); 
     //jumpto("products.php?cat=".$catID); 
     
}      

  
?>