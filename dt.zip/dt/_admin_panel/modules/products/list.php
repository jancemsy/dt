 

<div class="row" style="width:800px; display: block; padding: 20px 0 0 520px;  border: none;  ">   
</div>




<div class="box"> 
    <div class="title"> 
        <h2><?php echo $title; ?></h2> 
        <?php echo $_dahide; ?>
    </div> 
    <div class="content pages"> 


        <?php if (!isset($_GET["featured"])) { ?>
            <div id="content-container">  
                <p><a href="?new=1&cat=<?php echo $catID; ?>" class="button">New Product</a>
                    
                      <a href="?update_qty=1" class="button">Update Products By CSV</a> 
                </p>  
                
            </div>     
        <?php } else { ?>
            <div id="content-container">  
                <p><a href="?new=1&cat=<?php echo $catID; ?>&featured=1" class="button">New Product</a>
                <a href="?update_qty=1" class="button">Update Product Qty By CSV</a>  
                </p>  
            </div>                           
        <?php } ?>            






        <div class="row" style="position: absolute;width: 420px; border: none;display: block; margin: -40px 10px 10px 340px;  padding: 0 0 15px 0;">      


            <span>Search:</span> <input type="text" name="search" style="width:150px!important;" /> 
            <img class="loader" style="margin-left:-115px; margin-top: 5px; display:none;"   src="<?php echo PATH . "images/loading-small.gif"; ?>" />
            <span>&nbsp;&nbsp;&nbsp;Display by:</span>            
            <select name="jumper" id="prodjumper"   >
                <option value="0" <?php echo intval($_GET["cat"]) == 0 ? "checked" : ""; ?>   >All Products</option> 
                <!--<option value="filter_featured"  >Featured Products</option>  -->
                <?php
                $list = Category::getList(99999, "num", "product");
                foreach ($list as $item) {
                    echo "<option value='{$item["id"]}'  ".($item["id"] == $_GET["cat"] ? "checked='checked'" : "")." >{$item["name"]}</a></li>";
                    
                }
                ?>                                        
            </select>   


            <script>
                $(function() {
                     
                     
                    ///*
                    setTimeout(function() {
                      
                        /*var pcat = _cookie("adminprodcat");
                        if (pcat && pcat != '') {
                          
                            
                            var v = _cookie("adminprodcat");
                            $(".tr").hide();
                            $("." + v).show();
                         */
        
                           <?php if($_GET["cat"] != ""){  ?> 
                               
                             $('#prodjumper option[value="<?php echo $_GET["cat"]; ?>"]').attr("selected", "selected"); 
                            var i = $('#prodjumper option[value="<?php echo $_GET["cat"]; ?>"]').eq();
                            $(".sb-select").val($('#prodjumper option[value="<?php echo $_GET["cat"]; ?>"]').text());
                            $("ul.sb-dropdown li").removeClass("selected").eq(i).attr("class", "selected");
                            
                            <?php } ?> 
                          
                       // }
                    }, 100);
                    //*/

                    $("input[name=search]").keypress(function() {
                        $(".loader").show();
                        var s = $(this).val();
                        $.get("modules/products/_list.php?s=" + s, function(output) {
                            $("#search-result").html(output);
                            $(".loader").hide();
                        });
                    });

                    $("#prodjumper").change(function() {
                        
                        location.href="?cat=" +$(this).val();
                        
                        /*
                        _cookie("adminprodcat", $(this).val());
                        $(".tr").hide();
                        $("." + $(this).val()).show();
                        */
                    });
                });
            </script>
        </div> 


        <div id="search-result" >                
            <?php include("_list.php"); ?>
        </div>