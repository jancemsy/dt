<?php

  
if(isset($_POST["save_product_cms"])){ 
     Config::update("product_cms", $_POST );   
 }
 
 
 $_POST =  Config::get("product_cms");   

?> 

<div class="box"> 
            <div class="title"> 
                    <h2>Setting</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms">
<form action="" method="post" enctype="multipart/form-data"   >  
    <table  >
        <tr>
            <td>Popular Count:</td><td><input type="text" name="popular_count" value="<?php echo $_POST['popular_count']; ?>" size="55" /></td>                        
        </tr>        
         
    </table>
    
   
    <div class="row buttons">        
       <button type="submit" name="save_product_cms"><span>Save</span></button>                                                
    </div>
           

</form>
    </div>
</div>    
 