<?php

  if(!defined("PATH")) include_once("../../common.php");
  $_dapath = PATH."_admin_panel/dreamadmin/";
  $_daedit = '<img src="'.$_dapath.'gfx/icon-edit.png" alt="Edit this item" />';
  $_dadelete = '<img src="'.$_dapath.'gfx/icon-delete.png" alt="Delete this item" />';             
  $_dahide = '<img src="'.$_dapath.'gfx/title-hide.gif" class="toggle" alt="" />';
  
  extract(Product::getAdminList($_GET["s"],100));
  echo "<div>$pagination</div><br/><br/>";
?>


 <table cellspacing="0" class="table">
    <thead>  
    <tr class="tr-header">
        <td>doba</td>
        <td>Model Number</td>
        <td>Thumb</td>
        <td>Product name</td>
        <td>Regular price</td>
        <td>Discount</td>
        <td>Total price</td>
        <td>Qty</td>
        <!--<td><a href="#" title="Popular Count">#</a></td>-->
        
        <td width="70">Action</td>
    </tr>
    </thead> 
<?php
  
 




  
foreach($list as $item){        
    $catID = $item["category_id"];
    $thumbs  = unserialize($item["thumbs"]);          
    $thumb = "<img src='".PATH.$thumbs["thumb1"]."' />";
    $button = "<a href='?delete={$item['id']}&cat=$catID' class='delete-btn'>$_dadelete</a>
           <a href='?edit={$item['id']}&cat=$catID'>$_daedit</a>";
    $featured = $item["featured"] == 1 ? "<div style='color:green'>[featured]</div>" : "";
           
    
    $featured_class = $item["featured"] == 1  ? "filter_featured" : "";
    $desc = string_cut($item["description"],200);
    echo " 
     <tr class='tr $featured_class filter_".$catID."' >
        <td>{$item["doba_product_id"]}</td>
        <td>{$item["model_number"]}</td>
        <td>$thumb</td>
        <td>{$item["product_name"]} $featured</td>
        <td>{$item["regular_price"]}</td>
        <td>{$item["discount"]}</td>
        <td>{$item["total_price"]}</td>
        <td>{$item["qty"]}</td>
        <!-- <td>{$item["popular_count"]}</td>-->
        <td>$button</td>
    </tr>";        
}
?></table>
            
    </div>            
</div>     