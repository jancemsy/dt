<?php
$id = "";
$type = "Add";
if(isset($_GET["edit"])){
    $id = $_GET["edit"];
    $product = new Product($id);  
    $_POST = $product->array; 
    $thumbs  = unserialize($product->array["thumbs"]);   
    $type = "Edit";
}
 
?> 
<div class="box"> 
            <div class="title"> 
                    <h2><?php echo $type; ?> Product</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms">
<form action="" method="post"   enctype="multipart/form-data"  >
    
     
    <input type="hidden" name="id" value="<?php echo $id; ?>" />
    <input type="hidden" name="thumb1" value="<?php echo $thumbs["thumb1"]; ?>" /> 
    <input type="hidden" name="thumb2" value="<?php echo $thumbs["thumb2"]; ?>" /> 
    <input type="hidden" name="thumb3" value="<?php echo $thumbs["thumb3"]; ?>" /> 
    <input type="hidden" name="thumb4" value="<?php echo $thumbs["thumb4"]; ?>" /> 
    <input type="hidden" name="thumb5" value="<?php echo $thumbs["thumb5"]; ?>" />     
     
      
  <table>      
      <input type="hidden" name="category_id" value="<?php echo $catID; ?>" />
      <tr>
           <td>Category:</td> <td></td>
           <td>
               <select name="category_id">                  
                   <?php
                            $list = Category::getList(99999,"num","product");                            
                            $poutput = "";
                            foreach($list as $item){                                
                               $selected  = ($catID == $item["id"]) ? "selected" : "";                                
                               $poutput .= "<option $selected value=\"{$item["id"]}\">{$item["name"]}</option>";
                            } 
                            echo $poutput;
                   ?>                   
               </select>               
           </td>
      </tr>
      
      
      
      <tr><td>Is Featured?:</td><td></td><td>  
              <label><input type="radio"  name="featured" value="1" onclick="$('.featured-container').show();" <?php echo $_POST['featured'] != '0' || isset($_GET["featured"]) ? 'checked' : ''; ?> />Yes</label>
              <label><input type="radio"  name="featured" value="0" onclick="$('.featured-container').hide();" <?php echo $_POST['featured'] == '0' ? 'checked' : ''; ?> />No</label>
          </td></tr> 
      <tr class="featured-container" <?php echo $_POST['featured'] == '0' ? 'style="display:none;"' : ''; ?> ><td>Featured Order#:</td><td></td><td>  <input type="text" name="featured_order" class="text-input" value="<?php echo $_POST['featured_order']; ?>" /></td></tr> 
      <tr class="featured-container" <?php echo $_POST['featured'] == '0' ? 'style="display:none;"' : ''; ?> ><td>Featured Text:</td><td></td><td>  <textarea name="featured_text"  class="thiseditor  " ><?php echo $_POST['featured_text']; ?></textarea></td></tr> 
      
      
      
      <tr><td>Meta Title <counter style="display:none" max="70" required="1" target="input[name=meta_title]'"></counter>:</td><td></td><td>  <input type="text" name="meta_title" class="text-input" value="<?php echo $_POST['meta_title']; ?>" /></td></tr> 
      <tr><td>Meta Desc <counter style="display:none" max="155" required="1" target="input[name=meta_desc]'"></counter>:</td><td></td><td>  <input type="text" name="meta_desc" class="text-input" value="<?php echo $_POST['meta_desc']; ?>" /></td></tr> 
      <tr><td>Meta Keywords:</td><td></td><td>  <input type="text" name="meta_keywords" class="text-input" value="<?php echo $_POST['meta_keywords']; ?>" /></td></tr> 
        
    <tr><td>Model Number:</td><td></td><td><input type="text" name="model_number" class="text-input" value="<?php echo $_POST['model_number']; ?>" /></td></tr> 
    <tr><td><b>Available Quantity</b>:  </td><td></td><td><input type="text" name="qty" class="text-input" value="<?php echo $_POST['qty']; ?>" /></td></tr> 
    <tr><td>Product Name:  </td><td></td><td><input type="text" name="product_name" class="text-input" value="<?php echo $_POST['product_name']; ?>" /></td></tr> 
    <tr><td>Regular Price:  </td><td>$</td><td><input type="text" name="regular_price" class="text-input" value="<?php echo $_POST['regular_price']; ?>" /></td></tr> 
    <tr><td>Discount: </td><td></td><td><input type="text" name="discount" autocomplete="off" class="discount text-input" value="<?php echo $_POST['discount']; ?>" /> e.g. 10%  (optional)</td></tr> 
    <tr><td>Total Price:</td><td>$</td><td><input type="text" name="total_price" class="text-input" value="<?php echo $_POST['total_price']; ?>" /></td></tr> 
        
    
    <tr><td>Description:</td><td></td><td><textarea name="description"  class="thiseditor  " ><?php echo $_POST['description']; ?></textarea></td></tr>             
    <tr><td>Short Description:</td><td></td><td><textarea name="short_description"  class="thiseditor " ><?php echo $_POST['short_description']; ?></textarea></td></tr>                 
    <tr><td>Bullets (separated by |):</td><td></td><td><textarea name="bullets" cols="72" rows="5"   ><?php echo $_POST['bullets']; ?></textarea></td></tr>             
    
     
    <tr><td>Thumbnail 1 (default): <br/>
                  288px × 288px JPG only:</td><td></td><td>
            <div class="row">                
               <input type="file" size="46"  name="upload1"  />             
            </div>   
             <?php
               if( !empty($thumbs["thumb1"]) ){
                 echo ' <br/> <img src="'.PATH.$thumbs["thumb1"].'"   /> ';                                  
               }
             ?>             
     </td></tr>  
     <tr><td>Thumbnail 2: <br/>
                  288px × 288px JPG only:</td><td></td><td>
             <div class="row"> 
               <input type="file" size="46"  name="upload2"  />             
              </div>
             
             <?php
             if( !empty($thumbs["thumb2"]) ){
                 echo ' <br/> <img src="'.PATH.$thumbs["thumb2"].'"   /> ';                                  
             }
             ?>             
        </td></tr>  
        <tr><td>Thumbnail 3: <br/>
                  288px × 288px JPG only:</td><td></td><td>
                <div class="row">
                    <input type="file" size="46"  name="upload3"  />             
                 </div>   
             <?php
             if( !empty($thumbs["thumb3"]) ){
                 echo ' <br/> <img src="'.PATH.$thumbs["thumb3"].'"  /> ';                                  
             }
             ?>             
        </td></tr> 
        <tr><td>Thumbnail 4: <br/>
                  288px × 288px JPG only:</td><td></td><td>
             <div class="row">   
               <input type="file" size="46"  name="upload4"  />             
             </div>
             <?php
             if( !empty($thumbs["thumb4"]) ){
                 echo ' <br/> <img src="'.PATH.$thumbs["thumb4"].'"  /> ';                                  
             }
             ?>             
        </td></tr> 
        <tr><td>Thumbnail 5: <br/>
                  288px × 288px JPG only:</td><td></td><td>
            <div class="row">
             <input type="file" size="46"  name="upload5"  />             
            </div>
             <?php
             if( !empty($thumbs["thumb5"]) ){
                 echo ' <br/> <img src="'.PATH.$thumbs["thumb5"].'"   /> ';                                  
             }
             ?>             
        </td></tr> 
        
        
    </table> 
    
     
    <div class="row buttons"> 
       <button type="button" onclick="location.href='?cat=<?php echo $catID; ?>'" ><span>Cancel</span></button>                                                
       <button type="submit" name="add"><span>Save</span></button>                                                
    </div>
              
     
</form>   
    </div>        
</div>    

<script>
  $(function(){
      $(".discount").keyup(function(){ 
            var str =  $(this).val(); 
            if( str == "" ){
                var num = 0;
            }else  if( str.search("%") > -1 ) {
                var num = parseFloat(str.replace("%",""));                
            }else{
                var num = parseFloat(str);
            } 
            var total = parseFloat($("input[name=regular_price]").val());   
            total = total - num;
            $("input[name=total_price]").val(total); 
      })
  });
  initMCET('.thiseditor');
</script>  