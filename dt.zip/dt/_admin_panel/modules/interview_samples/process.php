<?php

$path = "../content/interview_samples/";
if (!file_exists($path)) {
    mkdir($path);
}

if (isset($_POST["save_desc"])) {
    $filename = "interview_sample.pdf";
    $dest = $path . $filename;

    $is_uploaded_pdf = false;
    if (isset($_FILES["pdf_upload"]) && $_FILES['pdf_upload']["name"] != "") {
        $name = $_FILES['pdf_upload']["name"];
        $ext = end(explode(".", $name));
        @unlink($dest); //clear
        move_uploaded_file($_FILES["pdf_upload"]["tmp_name"], $dest);
        $_POST["pdf"] = str_replace("../", "", $dest);
        $is_uploaded_pdf = true;
    } else if ($_POST["select_pdf"] != "") {
        //if its in our folder, lets move the pdf from podcasts to interview sample dir
        if (!search("http:", $_POST["select_pdf"])) {
            @unlink($dest); //clear    
            copy("../" . $_POST["select_pdf"], $dest);
            $_POST["pdf"] = $dest;
            $is_uploaded_pdf = true;
        } else {
            $_POST["pdf"] = $_POST["select_pdf"];
        }
    }

    $_POST["download_name"] = empty($_POST["download_name"]) ? "download" : $_POST["download_name"];
    Config::update("interview_samples_cms", $_POST);
    if ($is_uploaded_pdf)  init_s3_uploads("interview_samples_cms[config]", "pdf", $_POST["pdf"], "");
}


if ($_GET["delete"] != "") {
    $id = $_GET["delete"];
    $result = mysql_query("SELECT *FROM interview_samples WHERE id = '$id' ");
    if (mysql_num_rows($result) > 0) {
        $sample = mysql_fetch_array($result);

        $mp3path = "../" . $sample["mp3"];
        $thumbpath = "../" . $sample["thumb"];

        @unlink($mp3path);
        @unlink($thumbpath);

        $result = mysql_query("DELETE FROM interview_samples WHERE id = '$id' ");
        jumpto("?");
    }
}

if (isset($_POST["save_samples"])) {
    if ($_FILES["thumb_upload"]["name"] != "") {
        $name = $_FILES['thumb_upload']["name"];
        $ext = strtolower(end(explode(".", $name)));

        if ($ext != "jpg") {
            $_error .= "Please upload a valid jpg image!<br/>";
        } else {
            if (!empty($_POST["thumb"]))
                @unlink("../" . $_POST["thumb"]);
            $time = time();
            $filename = "$time.$ext";
            $thumb_dest = $path . $filename;            
            move_uploaded_file($_FILES["thumb_upload"]["tmp_name"], $thumb_dest);            
            createThumb($thumb_dest, $thumb_dest, 40, 40);                        
            $_POST["thumb"] = str_replace("../", "", $path) . $filename;
            $_POST["thumb"] = upload_s3($_POST["thumb"]);             
        }
    }


    $is_uploaded_mp3 = false;
    if ($_FILES["mp3_upload"]["name"] != "") {
        $name = $_FILES['mp3_upload']["name"];
        $ext = strtolower(end(explode(".", $name)));
        if ($ext != "mp3") {
            $_error .= "Please upload a valid mp3!<br/>";
        } else {
            if (!empty($_POST["mp3"]))
                @unlink("../" . $_POST["mp3"]);
            $time = time();
            $filename = "$time.$ext";
            $thumb_dest = $path . $filename;
            move_uploaded_file($_FILES["mp3_upload"]["tmp_name"], $thumb_dest);
            $_POST["mp3"] = str_replace("../", "", $path) . $filename;            
            $_POST["mp3"] = upload_s3($_POST["mp3"]); 
            $is_uploaded_mp3 = true;
        }
    }


    if ($_error == "") {
        $id = $_POST["id"];
        $title = addslashes($_POST["title"]);
        $name = addslashes($_POST["name"]);        
        $thumb = $_POST["thumb"];
        $mp3 = $_POST["mp3"];
        
        
        

        if (empty($id)) {
            $query = "INSERT INTO interview_samples SET
            title = '$title', 
            name = '$name', 
            thumb = '$thumb', 
            created_at = NOW(),
            mp3 = '$mp3' ";
            $result = mysql_query($query);
            $tid = mysql_insert_id();
            $jump = "?";
        } else {
            $query = "UPDATE interview_samples   SET                     
            title = '$title', 
            name = '$name', 
            thumb = '$thumb', 
            mp3 = '$mp3'
            WHERE id = '$id' ";
            $jump = "?edit=$id";
            $jump = "?";
            $result = mysql_query($query);
            $tid = $id;
        }

         /*old
        if ($is_uploaded_mp3){            
            init_s3_uploads("interview_samples", "mp3", $_POST["mp3"], $tid);
        }          
        */


        jumpto($jump);
    } else {
        
    }
}
?>