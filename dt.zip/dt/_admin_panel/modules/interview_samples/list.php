
 

<p><a href="?new=1" class="button">New Sample</a></p>   
<div class="content pages">
    <table>
        <tr>
            <td>Created</td>
            <td>Title</td>
            <td>Interview With</td>
            <td>Thumb</td>
            <td align="center">MP3</td>            
            <td>Actions</td>        
        </tr>    
        <?php
        $result = mysql_query("SELECT *FROM interview_samples WHERE 1 order by id DESC");
        while ($row = mysql_fetch_array($result)) {
            ?>
            <tr>
                <td><?php echo $row["created_at"]; ?></td>
                <td><?php echo $row["title"]; ?></td>
                <td><?php echo $row["name"]; ?></td>
                <td>
                    <img src="<?php echo cpath($row["thumb"]); ?>" />
                </td>
                <td align="center">
                    <a href="<?php echo cpath($row["mp3"]); ?>"  target="_blank" class="premium_mp3"></a>
                </td>                
                <td>                
                    <a href="javascript:;" onclick=" confirm('are you sure you want to delete this?') ?  location.href='?delete=<?php echo $row["id"]; ?>' : ''; " class="delete">Delete</a> /
                    <a href="?edit=<?php echo $row["id"]; ?>">Edit</a>                
                </td>
            </tr>
        <?php } ?>
    </table></div>


