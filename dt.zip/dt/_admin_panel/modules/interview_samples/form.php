
<div class="content form"> 
    <a href='?'>&laquo; Go Back</a> <br/><br/>


    <form action="" method="post" enctype="multipart/form-data" onSubmit="return checkInput()"   >
        <?php
        
          if(isset($_error)){
              echo "<div style='color:red!important;'>$_error</div>";
          }
        ?>
        <input type="hidden" name="id" value="<?php echo $_POST["id"]; ?>" />
        <input type="hidden" name="thumb" value="<?php echo $_POST["thumb"]; ?>" />
        <input type="hidden" name="mp3" value="<?php echo $_POST["mp3"]; ?>" />
        <input type="hidden" name="save_samples" value="1" />

        <table>

            <tr><td>Title:</td><td> <input type="text" name="title" class="text-input" value="<?php echo $_POST["title"]; ?>" /></td></tr>
            <tr><td>Name:</td><td> <input type="text" name="name" class="text-input" value="<?php echo $_POST["name"]; ?>" /> </td></tr>
            <tr><td>Thumbnail: (40x40px jpg)</td><td> 
                    <div class="row" >
                        <input type="file" name="thumb_upload" class="text-input"   />
                    </div>
                </td></tr>
            <tr><td>Mp3:</td><td>
                    <div class="row" >
                        <input type="file" name="mp3_upload" class="text-input"   />                              
                    </div>
                </td></tr>            
        </table>


        <div class="row buttons" > 
            <button type="button" onclick="location.href='?'" ><span>Back</span></button>                                                
            <button type="submit"  ><span>Save</span></button>                                                
            <img src="../images/loading-small.gif" class="loader" style="display:none"  />
            <span class="status"></span>
        </div>


    </form>

</div>

<script>
    function checkInput(){
        return true;
        
    }
</script>