<?php
 
  
if(isset($_POST["save_become_a_member"])){ 
     Config::update("res_become_a_member", $_POST );   
 }
 
 
 $_POST =  Config::get("res_become_a_member") ;   

?>
 

  
<div class="box"> 
            <div class="title"> 
                    <h2><?php echo $title; ?></h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms">
        
    
<form action="" method="post"> 
 <table class="table2" >
     
       <tr ><td style="width:200px;">Headline:</td>
        <td>  
            <textarea name="var1" rows="2" cols="80"><?php echo $_POST["var1"];?></textarea>            
        </td>       
    </tr>         
    
    <tr ><td>Sign Up text:</td>
        <td>  
         <input size="107" type="text" name="var2" value="<?php echo $_POST["var2"];?>" />  
        </td>       
    </tr>       
     
     
     <tr><td colspan="2">Description: <br/>
        <textarea name="var3" rows="10" cols="105"><?php echo $_POST["var3"];?></textarea></td>       
    </tr>   
</table>
    
 


        <div class="row buttons">           
           <button type="submit"  name="save_become_a_member"><span>Save</span></button>                                                
        </div>


</form>

        </div>
</div>    
