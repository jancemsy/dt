<?php
  
if(isset($_GET["edit"])){
    $id = $_GET["edit"];
    $testimonials = new Testimonials($id);  
    $_POST = $testimonials->array; 
}

 
?> 

<div class="box"> 
            <div class="title"> 
                    <h2><?php if( isset($_GET["edit"]) ) echo "Edit Testimonial";
                              else echo "Add New Testimonial"; 
                      ?>                        
                    </h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms" > 
         
         


<form action="resources.php?testimonials=1" method="post"  enctype="multipart/form-data"  >
    <input type="hidden" name="id" value="<?php echo $_POST["id"]; ?>" />
    <input type="hidden" name="thumb" value="<?php echo $_POST["thumb"]; ?>" />
 <table class="table2" > 
     <tr ><td>Order #:</td>
        <td>  
            <input type="text" name="num" size="60"  value="<?php echo $_POST["num"];?>" />
        </td>       
    </tr>         
       <tr ><td>Name:</td>
        <td>  
            <input type="text" name="name" size="60"  value="<?php echo $_POST["name"];?>" />
        </td>       
    </tr>         
       <tr ><td>Location:</td>
        <td>  
            <input type="text" name="location" size="60" value="<?php echo $_POST["location"];?>" />
        </td>       
    </tr>         
    <tr ><td>Comment:</td>
        <td>  
            <textarea name="comment" cols="44" ><?php echo $_POST["comment"];?></textarea>
        </td>       
    </tr>         
    <tr ><td>Thumb: (109px × 119px)</td>
        <td>  
            <div class="row">
            <input type="file" name="upload" />
            </div>
            <?php
              if($_POST["thumb"] != ""){
                  echo "<img src='".PATH."{$_POST["thumb"]}' width='68' />";
              }
            ?> 
        </td>       
    </tr>          
</table>
    

    
    <div class="row buttons">           
        <?php
         if( isset($_GET["edit"]) )
             echo '<button type="button"  name="save_testimonial" onclick="window.location.href=\'resources.php?testimonials=1\'"><span>Cancel</span></button>';             
          ?>
           <button type="submit"  name="save_testimonial"><span>Save</span></button>                                                
        </div>
   
</form>
        
        
        </div>
</div>    



<div class="box"> 
            <div class="title"> 
                    <h2>Testimonial List</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  pages" > 
        
 <table >
    <tr class="tr-header">
        <td>Name</td>
        <td>Thumb</td>
        <td>Location</td>
        <td>Comment</td>
        <td>Order</td>
        <td width="60">Action</td>
    </tr>

<?php
$list = Testimonials::getList();
foreach($list as $item){
    
    $thumb = "<img src='".PATH."{$item["thumb"]}' />";
    $button = "<a href='resources.php?delete_testimonial={$item["id"]}' class='delete-btn' >$_dadelete</a> 
    <a href='resources.php?testimonials=1&edit={$item["id"]}' >$_daedit</a>";
    
    echo "
         <tr>
        <td>{$item["name"]}</td>
        <td>$thumb</td>
        <td>{$item["location"]}</td>
        <td>{$item["comment"]}</td>
        <td>{$item["num"]}</td>
        <td>$button</td>
    </tr>
    ";
    
}
?></table>



        </div>
</div>    