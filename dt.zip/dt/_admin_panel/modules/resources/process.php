<?php

if( isset($_POST['crop_images'] ) ){  //ajax call   
       $_SESSION["pending_crop"] = "";
       $width = 270;
       $height = 160;
       $quality = 100;  

        $size = count($_POST['h']);

        for($i = 0; $i< $size; $i++){
          $des_h = $_POST['h'][$i];
          $des_w = $_POST['w'][$i];
          $source_x = $_POST['x'][$i];
          $source_y = $_POST['y'][$i];
          $src = $_POST['thumb'][$i];    
          
           if( !empty($des_h) && !empty($src) ){
                    $filename = end(explode("/",$src));  
                    $filename = str_replace("-orig","",$filename);                        
                    $destination = "../content/experts/$filename";    
                    
                    $ext = strtolower(end(explode(".",$src)));

                    switch ($ext){
                        case "gif":
                          $img_r = imagecreatefromgif($src);
                          break;
                        case "png":
                          $img_r = imagecreatefrompng($src);
                          break;
                        default:
                          $img_r = imagecreatefromjpeg($src);
                          break;
                      }

                    $dst_r = ImageCreateTrueColor( $width , $height );
                    imagecopyresampled($dst_r,$img_r,0,0,$source_x,$source_y ,$width ,$height ,$des_w ,$des_h);

                    @unlink($destination);  //delete the old one
                    switch($ext){
                        case "gif":
                           imagegif($dst_r, $destination);
                          break;
                        case "png":
                           imagepng($dst_r, $destination);
                          break;
                        default:
                           imagejpeg($dst_r, $destination,$quality);
                          break;
                      }
                      
                  @unlink($src);//unlink original                     
          }
        }
        die("1");
}


  if( isset($_POST["save_expert_settings"]) ){  
     Config::update("expert_tools", array("headline" => $_POST["headline"],
                                          "text" => $_POST["text"]) );  
 } 
 
 
 if( isset($_GET["delete_expert"]) ){       
     Experts::delete($_GET["delete_expert"]);
     jumpto("resources.php?experts=1");  
 }
 
 if( isset($_POST["save_experts"]) ){  
    $pending_crop = array();
    $path = "../content/experts/";     
    if(!file_exists($path)){  mkdir($path); }
    
    
     if(isset($_FILES["upload"]) && $_FILES['upload']["name"] != ""){
        if( !empty($_POST["thumb"]) ) @unlink("../".$_POST["thumb"]);
        $name = $_FILES['upload']["name"];
        $ext   = end(explode(".",$name));
        $time = time();                 
        $filename = "$time.$ext";
        
        $thumb_orig = "../content/experts/$time-orig.$ext";
        $thumb_dest = "../content/experts/$filename";
               
        move_uploaded_file($_FILES["upload"]["tmp_name"], $thumb_orig );         
        @createThumb($thumb_orig,$thumb_dest,270,160);          
        
        $pending_crop[] = $thumb_orig; 
        $_POST["thumb"] = "content/experts/$filename";
     }
    
     
     $params = array("name" => $_POST["name"],
                       "age" => $_POST["age"],
                       "expertise" => $_POST["expertise"],
                       "location" => $_POST["location"],
                       "thumb" => $_POST["thumb"]);
     
     
    if( !empty($_POST["id"]) ){
      $params["id"] = $_POST["id"];
      Experts::update($params);  
    }else{
      Experts::add($params);
    }
    
    
      if(count($pending_crop) > 0 ){
         $_SESSION["pending_crop"] = serialize($pending_crop);
         jumpto("resources.php?crop=1"); 
     }
     
       jumpto("resources.php?experts=1"); 
     
     
 }     

 
  
  
  
  
     
?>
