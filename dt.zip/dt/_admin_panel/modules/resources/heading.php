<?php
  
if(isset($_POST["save_heading"])){  
      if(isset($_FILES["upload"]) && $_FILES['upload']["name"] != ""){        
        $name = $_FILES['upload']["name"];
        $ext   = end(explode(".",$name));
        $time = time();                 
        $filename = "$time.$ext";
        $thumb_dest = "../content/splash_bg/$filename";
        move_uploaded_file($_FILES["upload"]["tmp_name"], $thumb_dest ); 
        $_POST["bg"] = $filename;
     }
      
     
     Config::update("res_heading", $_POST );   
 } 
 
 $_POST =  Config::get("res_heading") ;   

?>
 

<div class="box"> 
            <div class="title"> 
                    <h2><?php echo $title; ?></h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms">

<form action="" method="post"> 
 <table   > 
       <tr >
           <td colspan="2" >Title: <input name="var1"  size="60" value="<?php echo $_POST["var1"];?>" /> </td>       
    </tr>          
     <tr><td colspan="2"  >Description: <br/>
        <textarea name="var2" rows="10" cols="105"><?php echo $_POST["var2"];?></textarea></td>       
    </tr> 
    <tr><td  valign="top">Background Image<br/> 
            960x306px
            (Required)*: </td>
        <td>  
            <i>Select Image:</i>
            <div style="width:400px;">
            <?php
            $path = "../content/splash_bg/";
               if ( $handle = opendir($path) ) {   

                /* This is the correct way to loop over the directory. */
                while (false !== ($file = readdir($handle))) {
                    $ext = strtolower(end(explode(".",$file)));

                    if($file != ".." && $file != "." ){  
                      $check = ($_POST['bg'] == $file) ? 'checked' : '';
                      
                      echo "<label>  
                         <span><input type='radio' name='bg' value='$file' class='radio' $check /></span>
                      <img src='$path/$file' width='100' /> 
                       
                       </label>  ";
                    }
                }

                closedir($handle);
              }
             ?>  
                <div class="clear"></div>
            </div> 
            <i>or Upload BG:</i> <input type="file" id="upload" name="upload" value="" />  <br/><br/>
        </td></tr>  
</table>



<div class="row buttons">           
           <button type="submit"  name="save_heading"><span>Save</span></button>                                                
        </div>

</form>

</div>
</div>    