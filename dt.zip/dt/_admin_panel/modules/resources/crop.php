<?php
       $width = 270;
       $height = 160;
       $quality = 100;  

       
       

?>


<script src="<?php echo PATH; ?>js/jcrop/js/jquery.Jcrop.js"></script>
<link rel="stylesheet" href="<?php echo PATH; ?>js/jcrop/css/jquery.Jcrop.css" type="text/css" />
<style type="text/css">
    #crop-container{ background: none;  }
    #crop-container h2{ font-size: 20px; margin: 5px auto 5px auto; background: #fff; padding:10px; }
    #images-holder{ margin-top: 20px; position: absolute; }
    #images-holder h2{ margin: 20px 0 10px 0; color: #fff; }

     #images-holder hr{ color:#fff; }

    #preview_holder{ display:none; width:<?php echo $width; ?>px; height:<?php echo $height; ?>px; z-index:999999; border:5px solid red; position:fixed; bottom:0px; right:0px;  overflow:hidden; }
    #bottom-container{ padding:10px;  background:#fff; margin-top:40px;
     bottom:0px; left:0px;
     border-top:2px solid #333;
     width:100%;
     position:fixed;
     padding-left:200px;
     z-index:999998;
    }
    #bottom-container input{ font-size:15px; font-weight:bold;}
</style>
<form id="form-crop" action="" method="post"> 
<input type="hidden" name="crop_images" value="1" />
<div style="padding:10px;">
<h1>Crop Images</h1>

<?php

     $crop = unserialize( $_SESSION["pending_crop"]) ;
     //= unserialize($pending_crop);
 

     $i = 0;
     foreach($crop as $thumb){
         $i++;
         $id = "t$i";               
         ?>
         <img  src="<?php echo $thumb; ?>" class="crop" tid="<?php echo $id ;?>" />
         <input type="hidden" name="thumb[]" value="<?php echo $thumb; ?>" />
         <input type="hidden" name="h[]" value="" class="h<?php echo $id ;?>" />
         <input type="hidden" name="w[]" value="" class="w<?php echo $id ;?>" />
         <input type="hidden" name="x[]" value="" class="x<?php echo $id ;?>" />
         <input type="hidden" name="y[]" value="" class="y<?php echo $id ;?>" />
       <?php

     }

?>

</div>    
<script type="text/javascript">
  $("#form-crop").submit(function(){
        $("#submit-btn").val("Please wait, this could take a while...").attr("disabled","true");
      $.post("", $("#form-crop").serialize(),function(data){
          //$("#subtabholder").html(data);
          location.href="resources.php?experts=1";
        });
       return false;
    }); 
    
     var $selected_image  = "";
     var $selected_h = "";
     var $selected_w = "";

    var api = $('.crop').Jcrop({
                onChange: showPreview,
                onSelect: showPreview,
                aspectRatio:  <?php echo ($width/ $height); ?>
         }) ;
                 
   function showPreview(coords){

        $("#preview_holder").show();

        if( $selected_image != "" ){
          var url = $selected_image.attr("src");
          if($('#preview').attr("src") !=  url || $selected_h == "" || $selected_h == 0 ){     
               $('#preview').attr("src",url);
               var newImg = new Image();
               newImg.src = url;
               $selected_h = newImg.height;
               $selected_w = newImg.width;
          }
        }


        if (parseInt(coords.w) > 0)
        {

                //var reduce_size = $selected_w - $selected_image.width();


                var h = $selected_h;
                var w = $selected_w;
                var rx = <?php echo $width; ?> / coords.w;
                var ry = <?php echo $height; ?> / coords.h;

                //var rx = 100 / coords.w;
                //var ry = 100 / coords.h;
                //$width = 372;
                //$height = 248;

                 var final_w = Math.round(rx * w);
                 var final_h = Math.round(ry * h) ;
                 var final_x = Math.round(rx * coords.x);
                 var final_y = Math.round(ry * coords.y);

                 var tid = $selected_image.attr("tid");
                 $(".h"+tid).val(coords.h);
                 $(".w"+tid).val(coords.w);
                 $(".x"+tid).val(coords.x);
                 $(".y"+tid).val(coords.y);

                $("#dummy").html("w: "+coords.w+"<br/>h: "+coords.h+"<br/>x: "+ coords.x+" <br/>y: "+ coords.y );

                $('#preview').css({
                        width: final_w + 'px',
                        height: final_h + 'px',
                        marginLeft: '-' +  final_x + 'px',
                        marginTop: '-' +  final_y  + 'px'
                });
        }
}                 

</script>    


<div id="preview_holder">
  <div id="dummy" style="position:absolute; background: #fff;"></div>
  <img src="" id="preview" />
 </div>

<div id="bottom-container">
  <input type="submit" id="submit-btn" name="crop" value="save"  />
  Note: Please wait to load all images completely to start cropping...
</div> 
</form>