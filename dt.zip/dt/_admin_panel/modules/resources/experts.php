<?php 

   $thumb = "";
 
   $expert =  Config::get("expert_tools"); 
   
   if( isset($_GET["id"]) ){
      $ex = new Experts($_GET["id"]);
      $_POST = $ex->array; 
      
       $thumb = !empty($_POST["thumb"]) ? "<br/><img  width=50 src='".PATH.$_POST["thumb"]."' />  " : "";
   }
    
   
?>
 

  
<div class="box"> 
            <div class="title"> 
                    <h2>Experts</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms">
         

         <form action="" method="post"> 
             <h1>Expert Settings:</h1>
             <table class="table2" > 
                   <tr ><td style="width:160px;">Headline:</td>
                    <td>  
                         <input size="50" type="text" name="headline" value="<?php echo $expert["headline"];?>" />            
                    </td>       
                </tr>         

                <tr ><td>Text: <br/>
                        <i>%expert_include%</i>
                    </td>
                    <td>  
                     <textarea name="text" rows="10" cols="50" class="mceEditor" ><?php echo empty($expert["text"]) ? "%expert_include%" : $expert["text"]; ?></textarea>
                    </td>       
                </tr>       

            </table>  
                <div class="row buttons" style="border: none!important;">           
                   <button type="submit"  name="save_expert_settings"><span>Save</span></button>                                                
                </div> 
        </form>

        
        <br/><br/>
    </div>
    
    
      <div class="content  forms">
          <a name="edit"></a>
        
          <form action="" method="post"  enctype="multipart/form-data" >
              <input type="hidden" name="id" value="<?php echo $_POST["id"];?>" />
             <h1>New/Update Expert:</h1>
             <table class="table2" > 
                   <tr ><td style="width:160px;">Name</td>
                    <td>  
                         <input size="50" type="text" name="name" value="<?php echo $_POST["name"];?>" />            
                    </td>       
                </tr>         

                <tr ><td style="width:160px;">Age</td>
                    <td>  
                         <input size="50" type="text" name="age" value="<?php echo $_POST["age"];?>" />            
                    </td>       
                </tr>    
                
                 <tr ><td style="width:160px;">Expertise</td>
                    <td>                          
                         <input size="50" type="text" name="expertise" value="<?php echo $_POST["expertise"];?>" />            
                    </td>       
                </tr>  

                 <tr ><td style="width:160px;">Location</td>
                    <td>  
                         <input size="50" type="text" name="location" value="<?php echo $_POST["location"];?>" />            
                    </td>       
                </tr>  
                
                
                  <tr ><td style="width:160px;">Thumb (270x160)</td>
                    <td>  
                         <div  class="row">          
                           <input type="file" size="46"  name="upload"  />             
                           <?php echo $thumb; ?>
                         </div>
                    </td>       
                </tr>  
                
                  
                
            </table>  
                <div class="row buttons" style="border: none!important;">           
                   <button type="submit"  name="save_experts"><span>Save</span></button>                                                
                </div> 
        </form>
      <br/><br/>
        
        
        
        
        

        </div>
    
    
    
    
    
     
    <div class="content pages">       
        
        <table cellspacing="0" class="table">
        <thead>  
        <tr class="tr-header">
            <td>ID</td>
            <td>Name</td>
            <td>Age</td> 
            <td>Location</td>
            <td>Expertise</td>   
            <td>Thumb</td>   
            <td width="60">Action</td> 
        </tr>
        </thead> 
        <?php
           $experts = Experts::getList();
           foreach($experts as $item){ 
               $thumb = !empty($item["thumb"]) ? "<img  width=50 src='".PATH.$item["thumb"]."' /> " : "";
               $delete_btn = "<a href='?delete_expert={$item["id"]}' class='delete-btn'>delete</a>";
               $edit_btn = "<a href='?experts=1&id={$item["id"]}#edit'>edit</a>";
        ?>
                  <tr class="tr-header">
                    <td><?php echo $item["id"]; ?></td>
                    <td><?php echo $item["name"]; ?></td>
                    <td><?php echo $item["age"]; ?></td>
                    <td><?php echo $item["location"]; ?></td>
                    <td><?php echo $item["expertise"]; ?></td>
                    <td><?php echo $thumb; ?></td>
                    <td width="60"><?php echo $delete_btn." / ".$edit_btn; ?></td> 
                </tr>
        <?php
           }
        ?>
        
        </table>
    
    </div>

                
    
    
    
    
    
    
    
    
    
    
    
    
</div>    


<script>
   initMCET(".mceEditor");
</script>