<?php 
  
if(isset($_POST["save_become_a_member"])){ 
     Config::update("res_ebook", $_POST );   
 }
  
 $_POST =  Config::get("res_ebook") ;   

?>
 

<div class="box"> 
            <div class="title"> 
                    <h2><?php echo $title; ?></h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms">

        
<form action="" method="post"> 
 <table class="table2" >
     
       <tr ><td style="width:200px;">Heading:</td>
        <td>  
            <textarea name="var1" rows="2" cols="95"><?php echo $_POST["var1"];?></textarea>            
        </td>       
    </tr>         
       <tr ><td style="width:200px;">Sub-Heading:</td>
        <td>  
            <textarea name="var2" rows="2" cols="95"><?php echo $_POST["var2"];?></textarea>            
        </td>       
    </tr>  
    <tr ><td>Link text:</td>
        <td>  
         <input size="50" type="text" name="var3" value="<?php echo $_POST["var3"];?>" />  
        </td>       
    </tr>       
     
 
</table>


        <div class="row buttons">           
           <button type="submit"  name="save_become_a_member"><span>Save</span></button>                                                
        </div>

</form>


        </div>
</div>    

