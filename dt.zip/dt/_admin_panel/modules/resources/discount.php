<?php
 
  
if(isset($_POST["save_become_a_member"])){ 
     Config::update("res_discount", $_POST );   
 }
 
 
 $_POST =  Config::get("res_discount") ;   

?>
 
<div class="box"> 
            <div class="title"> 
                    <h2><?php echo $title; ?></h2> 
                    <?php echo $_dahide ; ?>
            </div> 
    <div class="content  forms">

<form action="" method="post"> 
 <table class="table2" >
     
       <tr ><td style="width:200px;">Heading:</td>
        <td>  
            <textarea name="var1" rows="2" cols="105"><?php echo $_POST["var1"];?></textarea>            
        </td>       
    </tr>         
       <tr ><td style="width:200px;">Text:</td>
        <td>  
            <textarea name="var2" rows="2" cols="105"><?php echo $_POST["var2"];?></textarea>            
        </td>       
    </tr>  
  
</table>

    <div class="row buttons">           
           <button type="submit"  name="save_become_a_member"><span>Save</span></button>                                                
        </div>
    
</form>


        </div>
</div>    

