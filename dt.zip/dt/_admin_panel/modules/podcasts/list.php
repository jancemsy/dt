
 <div class="box"> 
        <div class="title"> 
                <h2>Premium Member Podcasts</h2> 
                <?php echo $_dahide; ?>
        </div> 
        <div class="content pages"> 
            
             <p><a href="?new=1" class="button">New Podcast</a></p> 
 


        <div id="search-result" >                
             <table cellspacing="0" class="table">
                <thead>  
                <tr class="tr-header">
                    <td>ID</td>
                    <td>Title</td>
                    <!--<td>Desc</td>-->
                    <!--<td>Bullets</td>-->
                    <td>Category</td>
                    <td>Ratings</td> 
                    <td>Aired</td> 
                    <td>With/casts</td> 
                    <td>mp3</td> 
                    <td>pdf</td> 

                    <td width="70">Action</td>
                </tr>
                </thead>                 
                <?php
                 extract(Podcast::getList($_GET["s"],999999,"_admin_panel/podcasts.php?page="));
                
                foreach($list as $item) { ?>
                  <tr >
                    <td><?php echo $item["id"];?></td>
                    <td><?php echo $item["title"];
                      if($item["isFeatured"]) echo "<div style='color:blue; font-weight:bold;'>[Featured]</div>";
                    ?></td>
                    <!--<td><?php echo $item["description"];?></td>-->
                    <!--<td><?php echo $item["bullets"];?></td>-->
                    <td><?php echo $item["category"];?></td>
                    <td><?php echo $item["ratings"];?></td> 
                    <td><?php echo $item["aired"];?></td> 
                    <td><?php echo $item["casts"];?></td> 
                    <td>
                        <?php                        
                          if( empty($item["mp3"]) ){                            
                            echo "<a href='javascript:;' class='premium_mp3 disabled'></a>";                           
                          }else{
                            echo "<a href='".CPATH($item["mp3"])."'  target='_blank' class='premium_mp3'></a>";
                          }
                        
                        ?>
                    </td> 
                    <td><?php 
                         if( empty($item["pdf"]) ){                            
                            echo "<a href='javascript:;' class='premium_pdf disabled'></a>";
                            
                          }else{
                            echo "<a href='".CPATH($item["pdf"])."' target='_blank' class='premium_pdf '></a>";
                          }
                        
                    //echo $item["mp3"];                                  
                    //echo $item["pdf"];
                    
                    ?></td> 
                    <td width="70"><a href="podcasts.php?delete=<?php echo $item["id"];?>" class="delete">Delete</a>  / 
                        <a href="podcasts.php?edit=<?php echo $item["id"];?>">Edit</a> </td>
                </tr>
               <?php  } ?>
             </table>
        </div>

       
                     
</div> 
              
</div> 


<script>
    $(".delete").click(function(){
        if(confirm("Are you sure you want to delete this?")){
            return true;
        }
        return false; 
    });
</script>