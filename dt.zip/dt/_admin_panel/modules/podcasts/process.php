<?php

if (isset($_POST['crop_images'])) {  //ajax call   
    $_SESSION["pending_crop"] = "";
    $quality = 100;

    $size = count($_POST['h']);

    for ($i = 0; $i < $size; $i++) {
        $width = $_POST['_w'][$i];
        $height = $_POST['_h'][$i];
        $src = $_POST['thumb'][$i];

        $des_h = $_POST['h'][$i];
        $des_w = $_POST['w'][$i];
        $source_x = $_POST['x'][$i];
        $source_y = $_POST['y'][$i];
        
        $fieldname = $_POST['fieldname'][$i];
        

        if (!empty($des_h) && !empty($src)) {
            $filename = end(explode("/", $src));
            $filename = str_replace("-orig", "", $filename);
            $destination = "../content/podcasts/$filename";

            $ext = strtolower(end(explode(".", $src)));
            switch ($ext) {
                case "gif":
                    $img_r = imagecreatefromgif($src);
                    break;
                case "png":
                    $img_r = imagecreatefrompng($src);
                    break;
                default:
                    $img_r = imagecreatefromjpeg($src);
                    break;
            }

            $dst_r = ImageCreateTrueColor($width, $height);
            imagecopyresampled($dst_r, $img_r, 0, 0, $source_x, $source_y, $width, $height, $des_w, $des_h);

            @unlink($destination);  //delete the old one

            imagejpeg($dst_r, $destination, $quality);

            sleep(1);

            if (!empty($_POST['src2'][$i])) {
                $width2 = $_POST['_w2'][$i];
                $height2 = $_POST['_h2'][$i];
                $destination2 = $_POST['src2'][$i];
                @createThumb($destination, $destination2, $width2, $height2);
            }
            
            
            

            
                        
              if( isset($_SESSION["is_pending_s3_upload"])  ){   
                  $destination = str_replace("../","",$destination);
                  $destination = upload_s3($destination);                  
                  $query = "UPDATE podcasts   SET
                         $fieldname = '$destination'
                  WHERE id = '{$_SESSION["is_pending_s3_upload"]}' ";
                  mysql_query($query);
                  //die($query);
              }
            


            #@unlink($src);//unlink original   
        }
    }

    if( isset($_SESSION["is_pending_s3_upload"])  ){                                                     
        unset($_SESSION["is_pending_s3_upload"]);
    }

    die("1");
}



if ($_GET["delete"] != "") {
    Podcast::delete($_GET["delete"]);
    jumpto("?");
}

if (isset($_POST["save_podcast"])) {
    $title = $_POST["title"];
    $desc = $_POST["description"];

    if (empty($title) || empty($desc)) {
        $error = "Invalid title and description";
    } else {
        $pdf = $_POST["pdf"];
        $mp3 = $_POST["mp3"];
        $thumb = $_POST["thumb"];
        $feature_thumb = $_POST["feature_thumb"];
        $dir = "../content/podcasts/";

        if (!file_exists($dir)) {
            mkdir($dir);
        }

        $pending_crop = array();

        if ("jpg" == @end(explode(".", strtolower($_FILES["thumb_upload"]["name"])))) {
            $time = time();
            $src = $dir . $time . "t.jpg";
            $src2 = $dir . $time . "t-small.jpg";

            move_uploaded_file($_FILES["thumb_upload"]["tmp_name"], $src);
            $pending_crop[] = array("image" => $src,
            "width" => "191",
            "height" => "250",
            "caption" => "Large Logo",
            "width" => "313", "height" => "410",
            "width2" => "191", "height2" => "248", 
            "src2" => $src2,
            "fieldname" => "thumb"
            );

            if (!empty($thumb)) {
                @unlink("../" . $thumb); //delete old
                @unlink("../" . str_replace(".jpg", "-small.jpg", $thumb)); //delete old
            }
            $thumb = str_replace("../", "", $src);


            //s3 upload later after crop 
        }

        if ("jpg" == @end(explode(".", strtolower($_FILES["feature_thumb_upload"]["name"])))) {
            $src = $dir . time() . "f.jpg";
            move_uploaded_file($_FILES["feature_thumb_upload"]["tmp_name"], $src);
            $pending_crop[] = array("image" => $src, "width" => "893", "height" => "324", "caption" => "Large Logo",
                "fieldname" => "feature_thumb" );

            if (!empty($feature_thumb)) @unlink("../" . $feature_thumb); //delete old            
            $feature_thumb = str_replace("../", "", $src);
            
            
        }



        if ("mp3" == @end(explode(".", strtolower($_FILES["mp3_upload"]["name"])))) {
            $src = $dir . time() . ".mp3";
            move_uploaded_file($_FILES["mp3_upload"]["tmp_name"], $src);

            if (!empty($mp3)) @unlink("../" . $mp3); //delete old
            $mp3 = str_replace("../", "", $src);
            $mp3 = upload_s3($mp3);
        }

        if ("pdf" == @end(explode(".", strtolower($_FILES["pdf_upload"]["name"])))) {
            $src = $dir . time() . ".pdf";
            move_uploaded_file($_FILES["pdf_upload"]["tmp_name"], $src);

            if (!empty($pdf)) @unlink("../" . $pdf); //delete old
            $pdf = str_replace("../", "", $src);
            $pdf = upload_s3($pdf);
        }


        $params = array(
            "title" => addslashes($title),
            "description" => addslashes($desc),
            "bullets" => addslashes($_POST["bullets"]),
            "category" => addslashes($_POST["category"]),
            "aired" => $_POST["aired"],
            "casts" => addslashes($_POST["casts"]),
            "mp3" => $mp3,
            "pdf" => $pdf,
            "thumb" => $thumb,
            "feature_thumb" => $feature_thumb,
            "isFeatured" => $_POST["isFeatured"]
        );

        if ($_POST["id"]) {
            $params["id"] = $_POST["id"];
            Podcast::Update($params);
            $id = $params["id"];
        } else {
            $id = Podcast::Add($params);
        }

        /*
          if($thumb != $_POST["thumb"]){
          init_s3_uploads("podcasts", "thumb", $thumb, $id);
          }

          if($mp3 != $_POST["mp3"]){
          init_s3_uploads("podcasts", "mp3", $mp3, $id);
          }

          if($pdf != $_POST["pdf"]){
          init_s3_uploads("podcasts", "pdf", $pdf, $id);
          }
         * 
         */




        if (count($pending_crop) > 0) {
            $_SESSION["is_pending_s3_upload"] = $id;
            $_SESSION["pending_crop"] = serialize($pending_crop);
            //$_SESSION["goback"] = "podcasts.php?edit=".$id;
            jumpto("podcasts.php?crop=1");
        } else {
            jumpto("?");
        }
    }
}
?>
