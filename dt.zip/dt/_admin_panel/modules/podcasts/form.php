<?php

if($_GET["edit"]!=""){
    
    $podcast = new Podcast($_GET["edit"]);
    if(!empty($podcast->id)){
        $_POST  = $podcast->array;
    } 
}


?>


<style>
    input.errors,select.errors,textArea.errors{ border:1px solid red!important; }
    input[type=text]{ width: 400px; }
    textarea{ width: 400px; }
</style>

<div class="box"> 
            <div class="title"> 
                    <h2>Add/Update Podcast</h2> 
                    <?php echo $_dahide ; ?>
            </div> 
<div class="content  forms">
<form action="" method="post"  onsubmit="return checksubmit();" enctype="multipart/form-data"  >
    <table>
        <tr>
            <td>Title</td><td><input type="text" name="title" value="<?php echo $_POST["title"]; ?>"/></td>
        </tr>    
        <tr>
            <td>Description</td>
            <td><textarea name="description"><?php echo $_POST["description"]; ?></textarea></td>        
        </tr>
        <tr>
            <td>Bullets (separated by | )</td>
            <td><textarea name="bullets"><?php echo $_POST["bullets"]; ?></textarea></td>        
        </tr>
        <tr>
            <td>Category</td>
            <td>
                <select name="category"><?php
                $cat = Podcast::getCategories();     
                foreach($cat as $item){
                   echo "<option>{$item["category"]}</option>";
                  }
                ?></select>            
                <input type="button" onclick="addCategory()" value="&#171; add category" />            
            </td>        
        </tr>
     

         <tr>
            <td>Aired (date)</td><td><input type="text" name="aired"   class="datepicker2" autocomplete="off" value="<?php echo $_POST["aired"]; ?>"/></td>
        </tr> 

         <tr>
            <td>Casts/With (starring)</td><td><input type="text" name="casts" value="<?php echo $_POST["casts"]; ?>" /></td>
        </tr> 

         <tr>
            <td>Thumbnail (jpg only)</td>
            <td>
                <div class="row">      
                <input type="file" name="thumb_upload"  /> <?php if($_POST["thumb"] != "") { echo "  &nbsp; &nbsp;<a href='".cpath($_POST["thumb"])."' target='_blank'><img src='".PATH."images/attach.png' /></a>"; } ?>
                <input type="hidden" name="thumb" value="<?php echo $_POST["thumb"]; ?>" />                
                </div>
                
            </td>
        </tr> 



        <tr>
            <td>Is Featured</td>
            <td>
                <select name="isFeatured" onchange="  this.value == 1 ? $('#feature-thumb').show() : $('#feature-thumb').hide(); "><option value="0">no</option><option value="1">yes</option></select>
            </td>
        </tr> 

        <tr style=" <?php echo $_POST["isFeatured"] == "1" ? "": "display:none;"; ?> " id="feature-thumb">
            <td>Featured Thumbnail (jpg only)</td>
            <td>
                <div class="row">      
                <input type="file" name="feature_thumb_upload"  /> <?php if($_POST["feature_thumb"] != "") { echo " &nbsp; &nbsp;<a href='".cpath($_POST["feature_thumb"])."' target='_blank'><img src='".PATH."images/attach.png' /></a>"; } ?>
                <input type="hidden" name="feature_thumb" value="<?php echo $_POST["feature_thumb"]; ?>" />                
                </div>                
            </td>
        </tr> 


         <tr>
            <td>Mp3</td><td>
                <input type="hidden" name="mp3" value="<?php echo $_POST["mp3"]; ?>" />
                  <div class="row">                
                  <input type="file" size="46"  name="mp3_upload"  />             
                </div>
                 <?php                        
                      if( !empty($_POST["mp3"]) ){    
                        echo "<a href='".cpath($_POST["mp3"])."' class='premium_mp3'></a>";
                      }

                    ?>
            </td>
        </tr>     
        <tr>
            <td>Pdf</td>
            <td>
                <input type="hidden" name="pdf" value="<?php echo $_POST["pdf"]; ?>" />
              <div class="row">                
                  <input type="file" size="46"  name="pdf_upload"  />             
                </div> 
                <?php 
                     if( !empty($_POST["pdf"]) ){    
                        echo "<a href='".cpath($_POST["pdf"])."' class='premium_pdf '></a>";
                      } 
                ?>
            </td>
        </tr> 

        <tr>
            <td colspan="2">


        <div class="row buttons"> 
           <button type="button" onclick="location.href='?'" ><span>&#171; Back</span></button>                                                
           <button type="submit" name="save_podcast"><span>Save</span></button>                                                
        </div>


                </td>
        </tr> 
    </table>

        <input type="hidden" name="id" value="<?php echo $_POST["id"]; ?>" />
    </form>
    </div>
</div>    
 


<script type="text/javascript"> 
<?php
    if($_GET["edit"]!=""){ 
        echo "$('select[name=isFeatured]').val('".$_POST["isFeatured"]."'); ";
        echo "$('select[name=category]').val('".$_POST["category"]."');";
        echo "$('select[name=ratings]').val('".$_POST["ratings"]."');"; 
    } 
?>
    
    
    
    function checksubmit(){
        var errors = 0;
        $(".errors").removeClass("errors");
        
        if($("input[name=title]").val() == ""){
            $("input[name=title]").addClass("errors");
            errors++;
        }
        
        if($("textarea[name=description]").val() == ""){
            $("textarea[name=description]").addClass("errors");
            errors++;
        }
        
        
        if($("textarea[name=bullets]").val() == ""){
            $("textarea[name=bullets]").addClass("errors");
            errors++;
        }
        
        if($("select[name=category]").val() == ""){
           $("select[name=category]").addClass("errors");
            errors++;
        }
        
        if($("input[name=aired]").val() == ""){
            $("input[name=aired]").addClass("errors");
            errors++;
        }
        
        if($("input[name=with]").val() == ""){
            $("input[name=with]").addClass("errors");
            errors++;
        }
        
        
        
        if(errors > 0){
            alert("Please complete the missing fields");            
        }else{
            return true;
        }
        
        return false;
    }
    
    function addCategory(){
        var input = prompt("Enter New Podcast Category");
        if(input != null){
           $("select[name=category]").append('<option selected>'+input+'</option>');
        }
    }
    
  
   $(function(){ 
       $(".datepicker2").datepicker({ "appendText" : '(yyyy-mm-dd)', "dateFormat" : 'yy-mm-dd'    }); 
    });
       
</script>    