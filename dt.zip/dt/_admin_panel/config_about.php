<?php
include("common.php");
$path = "../content/aboutus/";
if (!file_exists($path)) {
    mkdir($path);
}

if (isset($_POST["save_cms"])) {
    $photos_count = $_POST["photos_count"];

    for ($i = 1; $i <= 100; $i++) {
        $t = "photo_upload$i";

        if (isset($_FILES[$t]) && $_FILES[$t]["name"] != "") {
            if (!empty($_POST["photo$i"]))
                @unlink("../" . $_POST["photo$i"]);
            
            if (!empty($_POST["photo_small$i"]))
                @unlink("../" . $_POST["photo_small$i"]);
            
            $name = $_FILES[$t]["name"];
            $ext = end(explode(".", $name));
            $time = time();
            $filename = "$time-orig1.$ext";
            $filename_small = "$time-small.$ext";

            $thumb_orig = $path . "/" . $filename;
            move_uploaded_file($_FILES[$t]["tmp_name"], $thumb_orig);

            $thumb_small = $path . "/" . $filename_small;
            @createThumb($thumb_orig, $thumb_small, 258, 173);

            $_POST["photo_small$i"] = "content/aboutus/$filename_small";
            $_POST["photo$i"] = "content/aboutus/$filename";

            $_POST["photo$i"] = upload_s3($_POST["photo$i"]);
            $_POST["photo_small$i"] = upload_s3($_POST["photo_small$i"]);
        }
    }


    if (isset($_FILES["video_upload"]) && $_FILES["video_upload"]["name"] != "") {
        if (!empty($_POST["video"]))
            @unlink("../" . $_POST["video"]);
        $name = $_FILES["video_upload"]["name"];
        $ext = end(explode(".", $name));
        $time = time();
        $filename = "$time-video.$ext";
        $thumb_orig = $path . "/" . $filename;
        move_uploaded_file($_FILES["video_upload"]["tmp_name"], $thumb_orig);
        $_POST["video"] = "content/aboutus/$filename";
        $_POST["video"] = upload_s3($_POST["video"]);
    }

    //other_photo_upload echo $i; 
    //no cropping for now
    for ($i = 1; $i <= 20; $i++) {
        if (!empty($_FILES["team_upload$i"]["tmp_name"])) {
            if (!empty($_POST["team_thumb$i"]))
                @unlink("../" . $_POST["team_thumb$i"]);
            $name = strtolower($_FILES["team_upload$i"]["name"]);
            $ext = end(explode(".", $name));
            $time = time();
            $filename = "$time.$ext";
            $thumb_dest = $path . $filename;
            move_uploaded_file($_FILES["team_upload$i"]["tmp_name"], $thumb_dest);
            @createThumb($thumb_dest, $thumb_dest, 359, 285);
            $_POST["team_thumb$i"] = str_replace("../", "", $thumb_dest);
        }
    }

    Config::update("aboutus_cms", $_POST);
}


$_POST = Config::get("aboutus_cms");
$menu_class[11] = 'class="current"';

include("_header.php");
$_POST["video_type"] = $_POST["video_type"] == '' ? 'upload' : $_POST["video_type"];
?> 
<script type="text/javascript">
    $(function(){
        $("input[name=video_type]").click(function(){
            $(".vtype").hide();
            $("." + $(this).val() ).show();           
        });
    });
    
    function photomanage(flag){
        var team_count = $("input[name=photos_count]").val();        
        if(flag == '+1'){                        
            team_count ++;            
            if(team_count < 20){                                              
                $(".photo_box_" + team_count ).show();    
            }            
        }else if(team_count > 1) {                       
            $(".photo_box_<?php echo $i; ?>" + team_count ).hide();
            team_count --;             
        }
        $("input[name=photos_count]").val(team_count);        
    }
    
    function teammanage(flag){
        var team_count = $("input[name=team_count]").val();        
        if(flag == '+1'){                        
            team_count ++;            
            if(team_count < 20){                                              
                $(".team_" + team_count ).show();    
            }            
        }else if(team_count > 1) {                       
            $(".team_" + team_count ).hide();
            team_count --;             
        }
        $("input[name=team_count]").val(team_count);        
    }
</script>
<style>
    .team input,.team textarea{ width: 350px; }
</style>
<div class="box"> 
    <div class="title"> 
        <h2>About Us CMS</h2> 
<?php echo $_dahide; ?>
    </div> 
    <div class="content forms">  

        <form action="" method="post" enctype="multipart/form-data"   >  
            <table>         
                <tr>            
                    <td >
                        <b>About Us:</b> <br/>
                        <textarea name="text" class="mceEditor" cols="102" rows="10"><?php echo $_POST['text']; ?></textarea>
                    </td>       

                </tr><tr>
                    <td>
                        <b>Address box:</b>
                        <div style="padding:0px 5px;" >
                            <table>
                                <tr><td>Address Line 1:</td><td> <input type="text" name="line1" value="<?php echo $_POST['line1']; ?>" /> </td></tr>
                                <tr><td> Address Line 2:</td><td> <input type="text" name="line2" value="<?php echo $_POST['line2']; ?>" /> </td></tr>
                                <tr><td> Address Line 3:</td><td> <input type="text" name="line3" value="<?php echo $_POST['line3']; ?>" /> </td></tr>
                                <tr><td> Phone:</td><td> <input type="text" name="line4" value="<?php echo $_POST['line4']; ?>" /> </td></tr>
                                <tr><td> Fax: </td><td><input type="text" name="line5" value="<?php echo $_POST['line5']; ?>" /> </td></tr>
                                <tr><td> Email:</td><td> <input type="text" name="line6" value="<?php echo $_POST['line6']; ?>" /> </td></tr>

                                <tr><td> FB Link:</td><td> <input type="text" name="line7" value="<?php echo $_POST['line7']; ?>" /> </td></tr>
                                <tr><td>Google+ Link:</td><td> <input type="text" name="line8" value="<?php echo $_POST['line8']; ?>" /> </td></tr>
                                <tr><td> Twitter Link:</td><td> <input type="text" name="line9" value="<?php echo $_POST['line9']; ?>" /> </td></tr>
                                <tr><td> Pinterest Link:</td><td> <input type="text" name="line10" value="<?php echo $_POST['line10']; ?>" /> 
                            </table>
                        </div>
                    </td>
                </tr>

                <tr>   
                    <td>
                        <b>Trivia:</b> <br/>
                        <textarea name="text3" class="mceEditor" cols="102" rows="10"><?php echo $_POST['text3']; ?></textarea>
                    </td>       
                </tr> 

                <tr>   
                    <td>
                        <b>Philosophy:</b> <br/>
                        <textarea name="text2" class="mceEditor" cols="102" rows="10"><?php echo $_POST['text2']; ?></textarea>
                    </td>       
                </tr> 


                <tr>   
                    <td>
                        <?php
                        $count = intval($_POST["team_count"]) == 0 ? 1 : intval($_POST["team_count"]);
                        ?>
                        <b>Our Team: </b>                        
                        <input type="button" value="-" onclick="teammanage('-1')" />
                        <input type="button" value="+" onclick="teammanage('+1')" />
                        <input type="hidden" value="<?php echo $count; ?>" name="team_count"/>

                        <br/>



                        <?php
                        $arr = array("team_thumb", "team_name", "team_position", "team_about", "team_facebook", "team_twitter", "team_google", "team_linkedin");
                        for ($i = 1; $i <= 20; $i++) {
                            $style = $count < $i ? "style='display:none;'" : "";
                            if ($count < $i) {
                                foreach ($arr as $field) {
                                    $_POST[$field . $i] = "";
                                }
                            }
                            ?>
                            <table class="team team_<?php echo $i; ?>" <?php echo $style; ?> >
                                <tr><td>Thumbnail: <br/>
                                        (359x285) jpg only</td>
                                    <td>
                                        <?php
                                        if ($_POST["team_thumb" . $i] != "") {
                                            echo "<img src='" . PATH . $_POST["team_thumb" . $i] . "' width='50' />";
                                        }
                                        ?>
                                        <div  class="row">
                                            <input name="team_upload<?php echo $i; ?>" type="file" /> 
                                            <input type="hidden" name="team_thumb<?php echo $i; ?>" value="<?php echo $_POST["team_thumb" . $i]; ?>" />
                                        </div>
                                    </td></tr>
                                <tr><td>Name:</td><td> <input name="team_name<?php echo $i; ?>" type="text" value="<?php echo $_POST["team_name$i"]; ?>" /> </td></tr>
                                <tr><td>Position:</td><td> <input type="text" name="team_position<?php echo $i; ?>" value="<?php echo $_POST["team_position$i"]; ?>" /> </td></tr>
                                <tr><td>About:</td><td> 
                                        <textarea  name="team_about<?php echo $i; ?>"><?php echo $_POST["team_about$i"]; ?></textarea> </td></tr>
                                <tr><td>facebook:</td><td> <input type="text" name="team_facebook<?php echo $i; ?>" value="<?php echo $_POST["team_facebook$i"]; ?>" /> </td></tr>
                                <tr><td>twitter:</td><td> <input type="text" name="team_twitter<?php echo $i; ?>" value="<?php echo $_POST["team_twitter$i"]; ?>" /> </td></tr>
                                <tr><td>google:</td><td> <input type="text" name="team_google<?php echo $i; ?>" value="<?php echo $_POST["team_google$i"]; ?>" /> </td></tr>
                                <tr><td>linkedin:</td><td> <input type="text" name="team_linkedin<?php echo $i; ?>" value="<?php echo $_POST["team_linkedin$i"]; ?>" /> </td></tr>
                            </table>
<?php } ?>

                    </td>       
                </tr> 


                <tr>   
                    <td>
                        <b>Helping Others:</b> <br/>
                        <div style="padding:10px;">
                            <textarea name="text4" class="mceEditor" cols="102" rows="10"><?php echo $_POST['text4']; ?></textarea> <br/>

                            Video: 
                            <label><input type="radio" <?php echo $_POST["video_type"] == 'upload' ? 'checked="checked"' : ''; ?> name="video_type" value="upload" /> Upload</label> 
                            <label><input type="radio" <?php echo $_POST["video_type"] == 'embed' ? 'checked="checked"' : ''; ?> name="video_type" value="embed" /> Embed</label>                    
                            &nbsp;&nbsp;&nbsp;
                            <?php
                            if (!empty($_POST["video"])) {
                                echo "<a href='" . cpath($_POST["video"]) . "' target='_blank'>attached video</a> (<a href='?edit=" . $_POST["id"] . "&del=4'>delete</a>)";
                            }
                            ?>
                            <div  class="vtype row upload" <?php echo $_POST["video_type"] == "upload" ? '' : 'style="display:none;"'; ?> ><input type="file" name="video_upload"  /> 
                            <input type="hidden" name="video" value="<?php echo $_POST["video"]; ?>"  /> </div>
                            <div  class="vtype embed" <?php echo $_POST["video_type"] == "embed" ? '' : 'style="display:none;"'; ?> ><textarea name="embed" cols="70" ><?php echo $_POST["embed"]; ?></textarea> </div>


                            <br/>
                            Photos: 
                            <?php
                            $photos_count = intval($_POST["photos_count"]) == 0 ? 1 : intval($_POST["photos_count"]);
                            ?>
                            <input type="button" value="-" onclick="photomanage('-1')" />
                            <input type="button" value="+" onclick="photomanage('+1')" />
                            <input type="hidden" value="<?php echo $photos_count; ?>" name="photos_count"/>
                            <br/>
                            <?php
                            for ($i = 1; $i <= 100; $i++) {
                                $style = $photos_count < $i ? "style='display:none;'" : "";
                                ?>
                                <div class="photo_box_<?php echo $i; ?>" <?php echo $style; ?> style="border:1px solid #ccc; margin-bottom: 10px; padding: 10px;" >
                                    Title: <input name="photo_name<?php echo $i; ?>" value="<?php echo $_POST["photo_name$i"]; ?>" /> <br/>
                                    Caption: <input name="photo_caption<?php echo $i; ?>" value="<?php echo $_POST["photo_caption$i"]; ?>" /> <br/>
                                    <div  class="row"  >
                                        <input name="photo_upload<?php echo $i; ?>" type="file" /> 
                                        <input type="hidden" name="photo_small<?php echo $i; ?>" value="<?php echo $_POST["photo_small" . $i]; ?>" />
                                        <input type="hidden" name="photo<?php echo $i; ?>" value="<?php echo $_POST["photo" . $i]; ?>" />
                                    </div>
                                    <?php
                                    if ($_POST["photo$i"] != "") {
                                        echo "<a href='".$_POST["photo$i"]."' target='_blank'><img src='" . cpath($_POST["photo_small$i"]) . "' width='100' /></a>";
                                    }
                                    ?>
                                </div>
                            <?php }
                            ?>


                        </div>
                    </td>       
                </tr> 

                <tr>   
                    <td>
                        <b>Get involved text:</b> <br/>
                        <textarea name="text5" class="mceEditor" cols="102" rows="10"><?php echo $_POST['text5']; ?></textarea>
                    </td>       
                </tr> 



            </table>


            <div class="row buttons">                  
                <button type="submit" name="save_cms"><span>Save</span></button>                                                
            </div> 
        </form>



        <script type="text/javascript"> 
            $(function(){
                initMCE(); 
            });
        </script>  

    </div>
</div>     


<?php include("_footer.php"); ?>  