<?php
include("../common.php");
$cms = Config::get("register_email_cms");
?>
<html>
    <body> 
        <table width="600" align="center" style="width:600px; border:1px solid #e6e6e6;" border="0" cellpadding="0" cellspacing="0">
            <tr><td style="background:url(<?php echo PATH; ?>images/signup/ntop.jpg?2123) 1px 1px no-repeat; height:63px;" >
                    &nbsp;
                </td></tr>
            <tr><td style=" height:auto; padding:30px;" valign="top" > 
                    <span style="color:#f77a20; font-size:16px; font-family:verdana;   "><?php echo $cms["hello"]; ?></span> <br/><br/> 
                    <div style="color:#686868; font-size:14px; font-family:verdana;">
                        <?php echo $cms["body"]; ?> 
                    </div>  
                </td></tr> 

            <?php for ($i = 1; $i < 5; $i++) { ?>
                <tr>
                    <td style="background:#e5ead3; height:63px;" > 
                        <div style="font-family:arial; font-size:20px; color:#FFFFFF; display:inline-block; width:auto; background:#799c1e; padding:20px;">
                            <div style="font-size:14px;color:#b7c98d;">STEP <?php echo $i; ?></div>
                            <?php echo $cms["step{$i}_title"]; ?> 
                        </div>
                    </td></tr>
                <tr><td style=" height:auto; padding:10px;" valign="top" >


                        <table><tr><td width="270"><img src="<?php echo PATH . $cms["thumb_$i"]; ?>" /></td><td  style="color:#686868; font-size:14px; font-family:verdana;" >
                                    <?php echo $cms["step{$i}_text"]; ?> 
                                </td></tr></table>

                    </td>       </tr> 
            <?php } ?> 
            <tr><td style=" height:auto; padding:30px;  color:#686868; font-size:14px; font-family:verdana;" valign="top" >

                    <?php echo $cms["footer_text1"]; ?> 

                    <ul style="padding:10px;">
                        <?php
                        $bullets = $cms["footer_bullets"];
                        $b = explode("|", $bullets);
                        foreach ($b as $item) {
                            echo '<li style="list-style:none; background:url(' . PATH . 'images/signup/nbullet.jpg) no-repeat 0px 4px;  padding-left:20px;" >' . $item . '</li>';
                        }
                        ?> 
                    </ul>

                    <?php echo $cms["footer_text2"]; ?> 
                </td></tr> 

            <tr><td style="background:url(<?php echo PATH; ?>images/signup/nbottom.jpg) no-repeat; height:185px;" >
                    &nbsp;
                </td></tr>

        </table> 
        <br/><br/>&nbsp;<br/>
    </body>
</html>