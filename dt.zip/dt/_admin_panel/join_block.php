<?php
 include("common.php"); 
 
if(isset($_POST["save_desc"])){ 
     Config::update("join_box_cms", $_POST );  
 }
  
 $_POST =  Config::get("join_box_cms");   
 
  include("_header.php"); 

?> 

<div class="box"> 
            <div class="title"> <h2>Join Box CMS</h2>  </div> 
    <div class="content  forms" > 
<form action="" method="post" enctype="multipart/form-data"   >  
    <table  >
        <tr><td>Headline:</td><td>  <input type="text"  size="55" name="headline" class="text-input" value="<?php echo $_POST["headline"]; ?>" /></td></tr> 
        <tr><td>Short Desc:</td><td>  <textarea name="desc" ><?php echo $_POST["desc"]; ?></textarea></td></tr>                
        <tr><td>Short Desc2 <br/>
                (used in register page lower text):</td><td>  <textarea name="desc2" ><?php echo $_POST["desc2"]; ?></textarea></td></tr>                
        <tr>
            <td>Feature 1:</td>
            <td><input type="text" name="feature1" value="<?php echo $_POST['feature1']; ?>" size="55" /></td>                        
        </tr>
        <tr>
            <td>Feature 2:</td>
            <td><input type="text" name="feature2" value="<?php echo $_POST['feature2']; ?>" size="55" /></td>                        
        </tr>
        <tr>
            <td>Feature 3:</td>
            <td><input type="text" name="feature3" value="<?php echo $_POST['feature3']; ?>" size="55" /></td>                        
        </tr>
        <tr>
            <td>Feature 4:</td>
            <td><input type="text" name="feature4" value="<?php echo $_POST['feature4']; ?>" size="55" /></td>                        
        </tr>
        <tr>
            <td>Feature 5:</td>
            <td><input type="text" name="feature5" value="<?php echo $_POST['feature5']; ?>" size="55" /></td>                        
        </tr>
         
        <tr>
            <td>Feature 6:</td>
            <td><input type="text" name="feature6" value="<?php echo $_POST['feature6']; ?>" size="55" /></td>                        
        </tr>
        <tr>
            <td>Feature 7:</td>
            <td><input type="text" name="feature7" value="<?php echo $_POST['feature7']; ?>" size="55" /></td>                        
        </tr>
         <tr>
            <td>Feature 7:</td>
            <td><input type="text" name="feature8" value="<?php echo $_POST['feature8']; ?>" size="55" /></td>                        
        </tr>
          
         
        
    </table>
    
       <div class="row buttons">                      
           <button type="submit"  name="save_desc"><span>Save</span></button>                                                
        </div>
    
</form>



<script type="text/javascript"> 
      initMCE();
</script>    

</div>
</div>    
    
<?php include("_footer.php"); ?>  