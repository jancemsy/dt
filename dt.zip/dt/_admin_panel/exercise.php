<?php
 include("common.php");  
 include("modules/exercise/process.php");  
 
 
  if($_GET["new"] == 1 || $_GET["edit"] != ""){      
    $include = "modules/exercise/form.php";    
  }else{   
     $include = "modules/exercise/list.php"; 
  }
 
 
 $menu_class[9] = 'class="current"' ;
 
 include("_header.php");     
 include($include);
 include("_footer.php"); ?>  