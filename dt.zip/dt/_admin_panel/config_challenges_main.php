<?php
include("common.php");
$path = "../content/aboutus/";
if (!file_exists($path)) {
    mkdir($path);
}

if (isset($_POST["save_cms"])){ 
    Config::update("challenges_main_cms", $_POST);
    jumpto("challenges.php");
}


$_POST = Config::get("challenges_main_cms");
$menu_class[11] = 'class="current"';

include("_header.php");
$_POST["video_type"] = $_POST["video_type"] == '' ? 'upload' : $_POST["video_type"];
?> 
 
<style>
    .team input,.team textarea{ width: 350px; }
</style>
<div class="box"> 
    <div class="title"> 
        <h2>Challenges Main CMS</h2> 
<?php echo $_dahide; ?>
    </div> 
    <div class="content forms">  

        <form action="" method="post" enctype="multipart/form-data"   >  
            <table>         
                <tr>            
                    <td >
                        <b>Banner Title:</b> <br/> 
                        <input type="text" name="title" value="<?php echo $_POST['title']; ?>"   size="97" /> 
                    </td>       

                </tr><tr>
                    <td>
                        <b>Banner Description:</b> <br/>
                        <textarea name="description" class="mceEditor" cols="102" rows="10"><?php echo $_POST['description']; ?></textarea>
                    </td>       
  
            </table>


            <div class="row buttons">                  
                <button type="submit" name="save_cms"><span>Save</span></button>                                                
            </div> 
        </form>



        <script type="text/javascript"> 
            $(function(){
                initMCE(); 
            });
        </script>  

    </div>
</div>     


<?php include("_footer.php"); ?>  