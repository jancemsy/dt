<?php

@set_time_limit(0);
ini_set("post_max_size", "228M");
ini_set("upload_max_filesize", "228M");
ini_set("memory_limit", "228M");

include("common.php");
include("modules/challenges/process.php");
$menu_class[11] = 'class="current"';
define("NO_FILE_TWEAK",1);

include("_header.php");


if (isset($_GET["participants"])) {
  $challenge = new Challenges($_GET["participants"]);  
  include("modules/challenges/participants.php"); 
} else if (isset($_GET["editicon"])) {
    include("modules/challenges/icon_form.php");
}else if (isset($_GET["icons"])) {
    include("modules/challenges/icon_list.php");
}else if (isset($_GET["newicon"])) {
    include("modules/challenges/icon_form.php");
}else if (isset($_GET["crop"])) {
    include("modules/challenges/crop.php");
} else if (isset($_GET["new"])) {
    $_POST = "";
    include("modules/challenges/form.php");
} else if (isset($_GET["edit"])) {
    $c = new Challenges($_GET["edit"]); 
    $_POST = $c->array;
    include("modules/challenges/form.php");
} else {
    include("modules/challenges/list.php");
}


include("_footer.php");
?>  