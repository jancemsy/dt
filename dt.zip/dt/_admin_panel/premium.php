<?php
 include("common.php"); 
 $path = "../content/premium/";     
 $path2 = "content/premium/";     
 if(!file_exists($path)){  mkdir($path); }
 
 if(isset($_POST["save_cms"])){           
     if( isset($_FILES["upload"]) && !empty($_FILES["upload"]["name"]) ){                                        
          $ext = end(explode(".",strtolower($_FILES["upload"]["name"])));
          $src = $path."thumb.$ext";                       
          $_POST["plan_monthly_price"] = number_format($_POST["plan_monthly_price"],2);
          if(move_uploaded_file($_FILES["upload"]["tmp_name"], $src )){
            $_POST["thumb"]    = $path2."thumb.$ext";
          }                    
     }               
     
     Config::update("premium", $_POST );   
 }
       
 $height = 399; 
 $width = 465; 
 $quality = 100; 

 
 $_POST =  Config::get("premium");   
 $menu_class[11] = 'class="current"' ;
 include("_header.php");   
 

 ?> 
 <div class="box"> 
        <div class="title"> 
                <h2>Premium Settings</h2> 
                <?php echo $_dahide; ?>
        </div> 
     <div class="content forms" >
         <form action="" method="post"  enctype="multipart/form-data"  >         
             
             <!-- 
             <p>
                Paypal Email: 
               <input type="text" size="20" name="paypal" value="<?php echo $_POST["paypal"]; ?>" />
             </p>  
             
             <p>
                Monthly Plan Price: 
               $<input type="text" size="10" name="plan_monthly_price" value="<?php echo $_POST["plan_monthly_price"]; ?>" />
             </p>  
             -->
             
            <p>
                Heading: 
               <input type="text" size="80" name="heading" value="<?php echo $_POST["heading"]; ?>" /> 
             </p>  
             
             <p>
                Description:
               <textarea name="description" class="onlythis"><?php echo $_POST["description"]; ?></textarea>
             </p>
             
             <p>
                Header Background: (png or jpg) 882x429 pixels <br/>
               <div class="row">      
               <?php if($_POST["thumb"] != ""){
                       echo "<img src='../{$_POST["thumb"]}' height='50' /> ";
               }?>
                <input type="file" name="upload"  />
                <input type="hidden" name="thumb" value="<?php echo $_POST["thumb"]; ?>" />                
                </div>                
             </p>
             
         
             <p>
               Bullets: (separated by comma)  <br/>
               <textarea cols="72" size="20" name="bullets"><?php echo $_POST["bullets"]; ?></textarea>
             </p>                                                                              
             <br/>                                         
             <div class="row buttons">                                        
                    <button type="submit" name="save_cms"><span>Save</span></button>                                                
             </div>
         </form>
         
         
         <br/><br/>
         <a href="config_landing.php#testimonial">Go to Testimonial (landing page)</a>
         
     </div>
 </div>     
  
<script>
    $(function(){
        initMCET(".onlythis");
    });
</script>
    
 
 

<?php include("_footer.php"); ?>  