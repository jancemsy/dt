<?php
include("common.php");

if (isset($_POST["save_cms"])) {
    Config::update("socialbuttons_cms", $_POST);
}


$_POST = Config::get("socialbuttons_cms");
$menu_class[11] = 'class="current"';

include("_header.php");
?> 

<div class="box"> 
    <div class="title"> 
        <h2>Social Media Codes</h2> 
<?php echo $_dahide; ?>
    </div> 
    <div class="content forms">  

        <form action="" method="post" enctype="multipart/form-data"   >  
            <table>         
                <tr>
                    <td>Facebook %fb_like%:</td>
                    <td><textarea name="fb"   cols="52"><?php echo $_POST['fb']; ?></textarea></td>
                </tr> 
                
                
                
                <tr>
                    <td>Google %g_follow%:</td>
                    <td><textarea name="google"  cols="52"><?php echo $_POST['google']; ?></textarea></td>
                </tr> 
                
                <tr>
                    <td>Pinterest %pinterest%:</td>
                    <td><textarea name="pinterest"   cols="52"><?php echo $_POST['pinterest']; ?></textarea></td>
                </tr> 
            </table>


            <div class="row buttons">                  
                <button type="submit" name="save_cms"><span>Save</span></button>                                                
            </div> 
        </form>



        

    </div>
</div>     


<?php include("_footer.php"); ?>  