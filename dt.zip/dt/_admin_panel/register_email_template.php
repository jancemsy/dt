<?php
include("common.php");
include("modules/register_email_template/process.php");



if (isset($_REQUEST["save_preview_cms"])) {
    ?>
    <html><head> 
            <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script> 
            <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css" />
            <script src="http://code.jquery.com/ui/1.10.2/jquery-ui.js"></script>
            <script>
                function hidegencode() {
                    $(".gencode").hide();
                    $(".gencodetop").removeClass("open");
                }
                function showgencode() {
                    $(".gencode").show();
                    $(".gencodetop").addClass("open");
                }
            </script>
            <style>
                .gencodetop{ border-bottom: 2px solid #555;  background:#ccc; height: 20px;padding:10px;  }
                .gencodetop.open{ height: 380px; }
                .gencode{ clear:both; float:right;   }        
                a{ color: #333; }
                html,body{ margin: 0px; padding: 0px; overflow: hidden; }
            </style></head><body>
            <div class="gencodetop"  >  
                <input style="float:right" type="button" value="Close" onclick="location.href = '?'"/> 
            </div>
            <iframe  frameborder="0" width="100%" height="100%" src="_preview_welcome_email.php"></iframe>
        </body>
    </html>
    <?php
    exit();
}


include("modules/register_email_template/form.php");


include("_footer.php"); ?>  