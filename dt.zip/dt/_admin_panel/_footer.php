                  

                </div>

		<!--[if !IE]> START FOOTER <![endif]--> 
		<div class="footer"> 
			<div class="split">&#169; Copyright <a href="#">DDP</a></div> 
			<div class="split right"></div> 
		</div> 
		<!--[if !IE]> END FOOTER <![endif]--> 
		
	</div> 
</div> 






 
</body>
</html>