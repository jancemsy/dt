<?php
 include("common.php"); 
 $menu_class[8] = 'class="current"' ;
    
 include("_header.php");
 
 
  $page = isset($_GET["page"]) ? $_GET["page"] : $_SESSION["subscription_page"];                 
  if(!empty($page)) $_SESSION["subscription_page"] = $page;
  else $page = 1;
  
  $order = "id DESC ";            
  $url = "?page=";
  $span = 4;                       
  $rows_per_page = 50;
  $condition = "1";
  $result  = mysql_query("SELECT id FROM subscription_transaction  WHERE $condition   ");            
  $numrows = mysql_num_rows($result);
            
  $query = "SELECT st.*, u.username, u.id as userID FROM 
  subscription_transaction st INNER JOIN users u ON u.id = s.userID WHERE $condition";
    
          
  $tmp = generatePaginationAdmin(array(
                             "numrows" => $numrows,
                             "url" => $url,
                             "page" => $page,
                             "rows_per_page" => $rows_per_page,
                             "span" => $span,
                             "query" => $query
                             ));
    extract($tmp);
    
    $result  = mysql_query("$query ORDER BY $order  $limit "); 
    
    
    $list = setArray($result);
                      
 
 ?>
  

<div class="box"> 
        <div class="title"> 
                <h2>Subscriber Payments</h2> 
                <?php echo $_dahide; ?>
        </div> 
        <div class="content pages"> 
            <table class="purchase_history_table" cellpadding="2" cellspacing="0">
                                    <tr class="hd">
                                        <td>ID</td>
                                        <td>Transaction Date</td>
                                        <td>Subscriber</td>
                                        <td>Subscription ID</td>
                                        
                                        <td>Amount</td>
                                        <td>Payer Email</td>
                                        <td>Receiver Email</td>                                        
                                    </tr>
                                    <?php                                                                                   
                                         foreach($list as $item){                                                                               
                                                $permalink = User::profile_link($item["username"]);                                        
                                                
                                                 echo "<tr>
                                                         <td>{$item["tid"]}</td>       
                                                         <td>{$item["created_at"]}</td>   
                                                         <td><a href='$permalink' target='_blank'>{$item["username"]}</a></td> 
                                                         <td>"."{$item["pid"]}</td>                                                             
                                                         <td>$"."{$item["amount"]}</td>                                                         
                                                         <td>"."{$item["receiver_email"]}</td>
                                                         <td>"."{$item["payer_email"]}</td>                                                                                                                      
                                                     </tr>";
                                            }
                                    ?>
                                </table>    
            <br/>
            
            <?php echo $pagination; ?>
 	<br/>
        </div>
</div>                                         
<?php include("_footer.php"); ?>  