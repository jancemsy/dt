<?php
 include("common.php");  
 include("modules/categories/process.php");
 
 $menu_class[2] = 'class="current"' ;
 
 include("_header.php"); ?>
  
 
            <?php

              if($_GET["new"] == 1 || $_GET["edit"] != ""){      
                include("modules/categories/form.php");
              }else{  
                include("modules/categories/list.php");
              }
            ?> 
                          
<?php include("_footer.php"); ?>  