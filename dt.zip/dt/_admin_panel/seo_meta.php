<?php
@set_time_limit(0);
ini_set("post_max_size", "228M");
ini_set("upload_max_filesize", "228M");
ini_set("memory_limit", "228M");

include("common.php");

if (isset($_POST["save"])) {
    Config::update("seo_meta", $_POST);
}

$_POST = Config::get("seo_meta");

$menu_class[9] = 'class="current"';

include("_header.php");
?>

<script>
    $(function(){
        $(".tabnav a").click(function(){               
            _cookie("target_tab",$(this).attr("class"));
        });
         
        if(_cookie("target_tab") != ""){          
            $(".tabnav ."+_cookie("target_tab")).click();            
        }
             
         
         
    });
</script>    

<div class="box"> 
    <div class="title"> 
        <h2>SEO Meta</h2> 
        <?php echo $_dahide; ?>
    </div> 
    <div class="content tabs" style="width:938px; padding:20px;">  
        <ul class="tabnav">
            <li><a href="#tab1" class="t1">Home Page</a></li>  
            <li><a href="#tab2" class="t2">Diet categories</a></li> 
            <li><a href="#tab3"  class="t3">Tools & Resources</a></li>  
            <li><a href="#tab4"  class="t4">Articles</a></li> 
            <li><a href="#tab5"  class="t5">Videos</a></li> 
            <li><a href="#tab6"  class="t6">Recipes</a></li> 
            <li><a href="#tab7"  class="t7">Products</a></li>                     
            <li><a href="#tab8"  class="t8">Fitness</a></li>                     
            <li><a href="#tab9"  class="t9">Premium Product</a></li>  
            <li><a href="#tab10"  class="t10">Podcast Main</a></li>  
            <li><a href="#tab11"  class="t11">Podcast Individual</a></li>  
            <li><a href="#tab12"  class="t12">Point System</a></li>                      
            <li><a href="#tab13"  class="t13">Landing Page</a></li>  
            <li><a href="#tab14"  class="t14">Register Page</a></li>  
            
            
            <li><a href="#tab15"  class="t15">About Us</a></li>  
            <li><a href="#tab16"  class="t16">Privacy</a></li>  
            <li><a href="#tab17"  class="t17">Contact Us</a></li>  
        </ul> 

        <form action="" method="post">

            <?php
            for ($i = 1; $i < 18; $i++) {
                $info = $i == 11 ? "<p>Tips: you can use our defined variables such  {title} for title or {description} for description </p>" : "";
                echo '<div id="tab' . $i . '" class="tabdiv"> 
                                ' . $info . '
                                   <div class="row">                                    
                                     Page Title <counter style="display:none" max="70" required="1" target=".meta_title' . $i . '"></counter>: 
                                     <input type="text" name="title' . $i . '" class="meta_title' . $i . '" value="' . $_POST['title' . $i] . '" />
                                   </div>
                                   <div class="row">
                                     Meta Description <counter style="display:none" max="155" required="1" target=".meta_desc' . $i . '"></counter>: 
                                         <textarea  name="desc' . $i . '" class="meta_desc' . $i . '">' . $_POST['desc' . $i] . '</textarea>
                                   </div>
                                   <div class="row">
                                     Meta Keywords: <textarea name="keywords' . $i . '">' . $_POST['keywords' . $i] . '</textarea>
                                   </div>
                           </div>';
            }
            ?> 

            <div class="row" style="padding:0px 20px 15px 20px; border: none!important;">                                 
                <button type="submit" name="save"><span>Save</span></button>                                                
            </div>

        </form>
    </div>
</div>


<?php include("_footer.php"); ?>  