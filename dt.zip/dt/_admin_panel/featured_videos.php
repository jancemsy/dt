<?php
 include("common.php"); 
 include("_header.php"); ?>
  
<div id="main">
                featured video
</div>		
                                
                                 
<?php include("_footer.php"); ?>  