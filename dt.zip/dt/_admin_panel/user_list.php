<?php
include("common.php");
$menu_class[15] = 'class="current"';
include("modules/user_list/process.php");

if (isset($_GET["joined"])) {
    $title = "Members who joined our challenge";
    $include = "modules/user_list/joined.php";
} else if (isset($_GET["edit"])) {
    $title = "User Edit";
    $include = "modules/user_list/form.php";
} else {
    $title = "User List";
    $include = "modules/user_list/list.php";
}

include("_header.php");
include($include);
include("_footer.php");
?>  