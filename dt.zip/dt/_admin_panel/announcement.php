<?php
 include("common.php");   
 $menu_class[9] = 'class="current"' ;
 include("modules/announcement/process.php");  
 
 if($_GET["new"] == 1 || $_GET["edit"] != ""){      
    $include = "modules/announcement/form.php";
 }else{  
    $include = "modules/announcement/list.php";
 }
  include("_header.php");    
 include($include); 
 include("_footer.php"); ?>  