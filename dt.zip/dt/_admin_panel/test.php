<?php 
include("common.php");
 
require_once 'Zend/Loader.php'; // the Zend dir must be in your include_path
Zend_Loader::loadClass('Zend_Gdata_YouTube'); 
Zend_Loader::loadClass('Zend_Gdata_ClientLogin');  
 
$authenticationURL= 'https://www.google.com/accounts/ClientLogin';
$httpClient = Zend_Gdata_ClientLogin::getHttpClient(
              $username = YT_USERNAME,
              $password = YT_PASSWORD,
              $service = 'youtube',
              $client = null,
              $source = 'MySource', // a short string identifying your application
              $loginToken = null,
              $loginCaptcha = null,
              $authenticationURL);

//https://developers.google.com/youtube/2.0/developers_guide_protocol
//GET THE DEVELOPER KEY AT http://code.google.com/apis/youtube/dashboard/ 
$yt = new Zend_Gdata_YouTube($httpClient, YT_APPID, YT_CLIENTID, YT_DEVKEY); 
$yt->setMajorProtocolVersion(2); 
$myVideoEntry = new Zend_Gdata_YouTube_VideoEntry();

$myVideoEntry->setVideoTitle('My Test Movie');
$myVideoEntry->setVideoDescription('My Test Movie');
// The category must be a valid YouTube category!
$myVideoEntry->setVideoCategory('Education');

// Set keywords. Please note that this must be a comma-separated string
// and that individual keywords cannot contain whitespace
$myVideoEntry->SetVideoTags('diet','tools','video');

$tokenHandlerUrl = 'http://gdata.youtube.com/action/GetUploadToken';
$tokenArray = $yt->getFormUploadToken($myVideoEntry, $tokenHandlerUrl);
$tokenValue = $tokenArray['token'];
$postUrl = $tokenArray['url'];
// place to redirect user after upload
$nextUrl = YT_NEXTURL;

// build the form
$form = '<form action="'. $postUrl .'?nexturl='. $nextUrl .
        '" method="post" enctype="multipart/form-data">'. 
        '<input name="file" type="file"/>'. 
        '<input name="token" type="hidden" value="'. $tokenValue .'"/>'.
        '<input value="Upload Video File" type="submit" />'. 
        '</form>'; 
echo $form;
  
  
  

?>
