<?php
 define("IN_LOGGEDIN",1);
 include("common.php");  
 $_dapath = PATH."_admin_panel/dreamadmin/";
  if( isset($_POST["username"]) ){
   $result = Admin::login($_POST["username"],$_POST["password"]); 
   if(!$result){
       $error = "Invalid username and/or password!";
   } 
  } 
 
  ?> 

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8" /> 
        <meta name="robots" content="noindex,nofollow" />
	<title><?php echo SITE_NAME; ?> - Login</title>
	
	<style type="text/css">
		@import url("<?php echo $_dapath; ?>css/inlog.css");
		@import url('<?php echo $_dapath; ?>css/style_text.css');
		@import url('<?php echo $_dapath; ?>css/c-orange.css'); /* COLOR FILE CAN CHANGE TO c-blue.ccs, c-grey.ccs, c-orange.ccs, c-purple.ccs or c-red.ccs */ 
		@import url('<?php echo $_dapath; ?>css/form.css');
		@import url('<?php echo $_dapath; ?>css/messages.css');
	</style>
	
	<script type="text/javascript" src="<?php echo $_dapath; ?>js/jquery-1.6.1.min.js"></script>
	
</head>

<body>

                        

    
<div class="wrapper">
	
	<div class="container">   
	
		<!--[if !IE]> START TOP <![endif]-->  
		<div class="top"> 
			<div class="split"><h1><?php echo SITE_NAME; ?></h1></div> 
			
		</div> 
		<!--[if !IE]> END TOP <![endif]-->  
	  
		<!--[if !IE]> START LOGIN <![endif]--> 
		<div class="box">
			<div class="title"><h2>Login</h2></div>
			<div class="content forms">
			
                            
                            <?php if(!empty($error)){  ?>
                            <div class="message red">
                               <?php echo $error; ?>
                                	<img src="<?php echo $_dapath; ?>gfx/icon-close.gif" alt="Close this item" />
                            </div>
                            <?php }  ?>  
                            
									
				
			
			
				<form action="" method="post">
					
					<div class="row">
						<div class="half-left">
							<label>Username:</label>
							<input type="text" value="" name="username" />
						</div>
						
						<div class="half">
							<label>Password:</label>
							<input type="password" value="" name="password" />
						</div>
					</div>
					
					<div class="row logged">
						<!--<label>Remember me:</label> 
						<select> 
							<option value="opt1">1 week</option> 
							<option value="opt2">2 weeks</option> 
							<option value="opt3">1 month</option> 
							<option value="opt4">6 months</option> 
							<option value="opt5">Alwasy</option> 
						</select> -->
						
						<div class="buttons">
							<button type="submit" name=""><span>Login</span></button>
						</div>
					</div>
					
				</form>
				
			</div>
		</div>
		<!--[if !IE]> END LOGIN <![endif]-->  
		
	</div>
</div>

<script type="text/javascript" src="<?php echo $_dapath; ?>js/jquery.pngFix.js"></script>
<script type="text/javascript" src="<?php echo $_dapath; ?>js/jquery.sparkbox-select.js"></script>
<script type="text/javascript" src="<?php echo $_dapath; ?>js/inlog.js"></script>

</body>

</html> 