<?php
include("common.php");
$path = "../content/jumpstarterkit/";
if (!file_exists($path)) {
    mkdir($path);
}

if (isset($_POST["save_cms"])) {
    if (isset($_FILES["video_upload"]) && $_FILES["video_upload"]["name"] != "") {
        if (!empty($_POST["video"]))
            @unlink("../" . $_POST["video"]);
        $name = $_FILES["video_upload"]["name"];
        $ext = end(explode(".", $name));
        $time = time();
        $filename = "$time-video.$ext";
        $thumb_orig = $path . "/" . $filename;
        move_uploaded_file($_FILES["video_upload"]["tmp_name"], $thumb_orig);
        $_POST["video"] = str_replace("../", "", $path . $filename);
        $_POST["video"] = upload_s3($_POST["video"]);
    }

    if (isset($_FILES["samplepdf_upload"]) && $_FILES["samplepdf_upload"]["name"] != "") {
        if (!empty($_POST["samplepdf"]))
            @unlink("../" . $_POST["samplepdf"]);
        $name = $_FILES["samplepdf_upload"]["name"];
        $ext = end(explode(".", $name));
        $time = time();
        $filename = "$time-video.$ext";
        $thumb_orig = $path . "/" . $filename;
        move_uploaded_file($_FILES["samplepdf_upload"]["tmp_name"], $thumb_orig);
        $_POST["samplepdf"] = str_replace("../", "", $path . $filename);
        $_POST["samplepdf"] = upload_s3($_POST["samplepdf"]);
    }


    for ($i = 1; $i <= 4; $i++) {
        if (isset($_FILES["testi_upload" . $i]) && $_FILES["testi_upload" . $i]["name"] != "") {
            $ext = end(explode(".", $_FILES["testi_upload" . $i]["name"]));
            $filename = "testi$i.$ext";
            $thumb_dest = $path . $filename;

            @unlink($thumb_dest);

            if (!file_exists($path)) {
                mkdir($path);
            }

            move_uploaded_file($_FILES["testi_upload$i"]["tmp_name"], $thumb_dest);

            createThumb($thumb_dest, $thumb_dest, 100, 100);

            $_POST["testi_thumb$i"] = str_replace("../", "", $path . $filename);
        }
    }


    Config::update("jumpstarterkit_cms", $_POST);
}


$_POST = Config::get("jumpstarterkit_cms");
$menu_class[11] = 'class="current"';

include("_header.php");
$_POST["video_type"] = $_POST["video_type"] == '' ? 'upload' : $_POST["video_type"];
?> 
<script type="text/javascript">
    $(function(){
        $("input[name=video_type]").click(function(){
            $(".vtype").hide();
            $("." + $(this).val() ).show();           
        });
    });
</script>    
<style>
    .team input,.team textarea{ width: 350px; }
</style>
<div class="box"> 
    <div class="title"> 
        <h2>Jumpstarter Kit CMS</h2> 
        <?php echo $_dahide; ?>
    </div> 
    <div class="content forms">  

        <form action="" method="post" enctype="multipart/form-data"   >  
            <table>         
                <tr>            
                    <td >
                        <b>Get Access Text:</b> <br/>
                        <input size="100" type="text" name="getaccess"  value="<?php echo $_POST['getaccess']; ?>" />
                    </td>       

                </tr><tr>                       
                    <td>
                        <b>Top Description:</b> <br/>
                        <textarea name="description" class="mceEditor" cols="102" rows="10"><?php echo $_POST['description']; ?></textarea>
                    </td>       
                </tr>

                <tr>            
                    <td >
                        <b>Top Bullets:</b>  (separated by |)<br/>
                        <textarea name="top_bullets" rows="5"  cols="90"><?php echo $_POST['top_bullets']; ?></textarea>
                    </td>       
                </tr>

                <tr>            
                    <td >
                        <b>Learn More Video:<br/>                            

                            <label><input type="radio" <?php echo $_POST["video_type"] == 'upload' ? 'checked="checked"' : ''; ?> name="video_type" value="upload" /> Upload</label> 
                            <label><input type="radio" <?php echo $_POST["video_type"] == 'embed' ? 'checked="checked"' : ''; ?> name="video_type" value="embed" /> Embed</label>                    
                            &nbsp;&nbsp;&nbsp;
                            <?php
                            if (!empty($_POST["video"])) {
                                echo " &nbsp; <a href='" . cpath($_POST["video"]) . "' target='_blank'>attached video</a>  )";
                            }
                            ?>
                            <div  class="vtype row upload" <?php echo $_POST["video_type"] == "upload" ? '' : 'style="display:none;"'; ?> ><input type="file" name="video_upload"  /> </div>
                            <div  class="vtype embed" <?php echo $_POST["video_type"] == "embed" ? '' : 'style="display:none;"'; ?> ><textarea name="embed" cols="70" ><?php echo $_POST["embed"]; ?></textarea>
                                <input type="hidden" name="video" value="<?php echo $_POST["video"]; ?>"  /> 
                            </div>


                    </td>       
                </tr>

                <tr>            
                    <td >
                        <b>Download Sample PDF:<br/>                            
                            <div  class="row">
                                <input name="samplepdf_upload" type="file" /> 
                                <?php
                                if (!empty($_POST["samplepdf"])) {
                                    echo " &nbsp;<a href='" . cpath($_POST["samplepdf"]) . "' target='_blank'>attached pdf</a> ";
                                }
                                ?>
                                <input type="hidden" name="samplepdf" value="<?php echo $_POST["samplepdf"]; ?>" />
                            </div>
                    </td>       
                </tr>


                <tr>            
                    <td >
                        <b>Personalize Heading:</b> <br/>
                        <input size="100" type="text" name="personalize_heading"  value="<?php echo $_POST['personalize_heading']; ?>" />
                    </td>       

                </tr><tr>                       
                    <td>
                        <b>Personalize Description:</b> <br/>
                        <textarea name="personalize_description" class="mceEditor" cols="102" rows="10"><?php echo $_POST['personalize_description']; ?></textarea>
                    </td>       
                </tr>

                <tr>                       
                    <td>
                        <b>Personalize Kits:</b> <br/>




                        <?php for ($i = 1; $i <= 6; $i++) { ?>
                            <table style="border:1px solid #ccc; margin:10px; padding:10px;">
                                <tr><td>Title: </td><td><input type="text" name="kits_title<?php echo $i; ?>" value="<?php echo $_POST["kits_title" . $i]; ?>" size="91" /></td> </tr>
                                <tr><td>Bullets: (separated by |)</td><td>
                                        <textarea name="kits_bullet<?php echo $i; ?>" cols="70" rows="5"><?php echo $_POST["kits_bullet$i"]; ?></textarea>
                                    </td> </tr>
                                <tr><td>Description</td><td>
                                        <textarea name="kits_description<?php echo $i; ?>" cols="70" rows="5"><?php echo $_POST["kits_description$i"]; ?></textarea>
                                    </td> </tr>

                            </table>
                        <?php } ?>


                    </td>       
                </tr>


                <tr>            
                    <td >
                        <b>Form Title:</b> <br/>
                        <input size="100" type="text" name="form_title"  value="<?php echo $_POST['form_title']; ?>" />
                    </td>       

                </tr>

                <tr>                       
                    <td>
                        <b>Form Description:</b> <br/>
                        <textarea name="form_description" class="mceEditor" cols="102" rows="10"><?php echo $_POST['form_description']; ?></textarea>
                    </td>       
                </tr>

                <tr>                       
                    <td>
                        <b>Jumpstarter kit Price:</b> <br/>
                        (price can be configured <a href="config_products.php">here</a>.)
                    </td>       
                </tr>


                <tr>            
                    <td >
                        <b>Questions:</b> <br/>                        
                        <?php for ($i = 1; $i < 5; $i++) { ?>                        
                            Question <?php echo $i; ?>: <input type="text" size="107" name="questions<?php echo $i; ?>" value="<?php echo $_POST["questions" . $i]; ?>"  /> <br/>
                            Options (separated by |) : <br/>
                            <textarea cols="90" rows="10" name="options<?php echo $i; ?>"><?php echo $_POST["options" . $i]; ?></textarea> <br/>
                        <?php } ?>                        
                    </td>       

                </tr>


                <tr>            
                    <td >
                        <b>People Who've loved Title:</b> <br/>
                        <input size="100" type="text" name="wholoved_title"  value="<?php echo $_POST['wholoved_title']; ?>" />
                    </td>       

                </tr>

                <tr>                       
                    <td>
                        <b>People who've love Description:</b> <br/>
                        <textarea name="wholoved_description" class="mceEditor" cols="102" rows="10"><?php echo $_POST['wholoved_description']; ?></textarea>
                    </td>       
                </tr>


                <tr>
                    <td>
                        <b>People who've love:</b> <br/>
                        (the system will grab the info from testimonials)
                        <br/>                        

                        <table>
                            <?php for ($i = 1; $i <= 4; $i++) { ?> 

                                <tr>
                                    <td>

                                        <div style="border:1px solid #ccc; padding: 10px;">
                                            <b>Person <?php echo $i; ?>:</b> <br/>
                                            Thumbnail (100x100px JPG ONLY):            
                                            <?php
                                            if (!empty($_POST['testi_thumb' . $i])) {
                                                echo "<br/><img src='" . PATH . $_POST['testi_thumb' . $i] . "?" . time() . "' height='50' />";
                                            }
                                            ?>

                                            <div class="row"  >                  
                                                <input type="hidden" name="testi_thumb<?php echo $i; ?>" value="<?php echo $_POST['testi_thumb' . $i]; ?>"   />
                                                <input type="file" name="testi_upload<?php echo $i; ?>"   />
                                            </div>

                                            Name: <br/>
                                            <input type="text" name="testi_name<?php echo $i; ?>" value="<?php echo $_POST['testi_name' . $i]; ?>"   size="97" />
                                            <br/> 
                                            Location: <br/>
                                            <input type="text" name="testi_location<?php echo $i; ?>" value="<?php echo $_POST['testi_location' . $i]; ?>"   size="97" />
                                        </div>
                                        <br/><br/>
                                    </td>                        
                                </tr>

                            <?php } ?>

                        </table>
                    </td></tr>                    





            </table>


            <div class="row buttons">                  
                <button type="submit" name="save_cms"><span>Save</span></button>                                                
            </div> 
        </form>



        <script type="text/javascript"> 
            $(function(){
                initMCET(".mceEditor"); 
            });
        </script>  

    </div>
</div>     


<?php include("_footer.php"); ?>  