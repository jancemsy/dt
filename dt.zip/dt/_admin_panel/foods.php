<?php

include("common.php");


if (isset($_POST["savefood"])) {
    FoodDB::update(array("id" => $_POST["foodID"],
        "company" => $_POST["company"],
        "name" => $_POST["name"],
        "grams" => $_POST["grams"],
        "size" => $_POST["size"],
        "calories" => $_POST["calories"],
        "fat" => $_POST["fat"],
        "saturated" => $_POST["saturated"],
        "polyunsaturated" => $_POST["polyunsaturated"],
        "polyunsaturated" => $_POST["polyunsaturated"],
        "trans" => $_POST["trans"],
        "cholesterol" => $_POST["cholesterol"],
        "sodium" => $_POST["sodium"],
        "potassium" => $_POST["potassium"],
        "carbs" => $_POST["carbs"],
        "size" => $_POST["size"],
        "fiber" => $_POST["fiber"],
        "sugars" => $_POST["sugars"],
        "protein" => $_POST["protein"],
        "calcium" => $_POST["calcium"],
        "iron" => $_POST["iron"],
        "type" => $_POST["type"]
    ));

    if (isset($_GET["back"]))
        jumpto($_GET["back"]);
    else
        jumpto("?");
}


$menu_class[9] = 'class="current"';
include("_header.php");

if (isset($_GET["edit"])) {
    include("modules/foods/form.php");
} else {
    include("modules/foods/list.php");
}

include("_footer.php");
?>  