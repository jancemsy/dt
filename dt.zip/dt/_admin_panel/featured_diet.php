<?php
 include("common.php"); 
 
   
 
 if( isset($_POST["save_diet"]) ){  
     Config::update("featured_diet", $_POST);  
 } 
 
 
  $_POST =  Config::get("featured_diet") ;   
 
 include("_header.php"); ?>
  
<div id="main">
               <h1>Featured Diet</h1>
               
              <form action="" method="post"   >   
               <p> Diet Name: <input type="text" value="<?php echo $_POST["diet"]; ?>"  name="diet" class="text-input"   /> </p>
               <p> Sub-headline: <input type="text" value="<?php echo $_POST["subheadline"]; ?>"  name="subheadline"  class="text-input" /> </p>
                
               <p> <b>Feature Bullets:</b><br/>
               1. <input type="text" name="feature1" value="<?php echo $_POST["feature1"]; ?>"  class="text-input"  /> <br/>
               2. <input type="text" name="feature2" value="<?php echo $_POST["feature2"]; ?>"  class="text-input"  /> <br/>
               3. <input type="text" name="feature3" value="<?php echo $_POST["feature3"]; ?>"  class="text-input"  /> <br/>
               4. <input type="text" name="feature4" value="<?php echo $_POST["feature4"]; ?>"  class="text-input" /> <br/>
               5. <input type="text" name="feature5" value="<?php echo $_POST["feature5"]; ?>"  class="text-input"  /> </p>
               
               <p><b>Nutrition Facts Bullets:</b><br/>
               1. <input type="text" name="nutrition1" value="<?php echo $_POST["nutrition1"]; ?>"  class="text-input" /> <br/>
               2. <input type="text" name="nutrition2" value="<?php echo $_POST["nutrition2"]; ?>"  class="text-input"  /> <br/>
               3. <input type="text" name="nutrition3" value="<?php echo $_POST["nutrition3"]; ?>"  class="text-input"  /> <br/>
               4. <input type="text" name="nutrition4" value="<?php echo $_POST["nutrition4"]; ?>"  class="text-input"  /> <br/>
               5. <input type="text" name="nutrition5" value="<?php echo $_POST["nutrition5"]; ?>"  class="text-input"  /> </p>
               
               <p>
                   Learn More Link<br/>                   
                   <input type="text" value="<?php echo $_POST["learn_more_link"]; ?>"  name="learn_more_link" class="text-input"   />
               </p>
               
          <input type="submit"  value="Save" name="save_diet" /> 
     </form>         
               
</div>		 
                                
                                 
<?php include("_footer.php"); ?>  