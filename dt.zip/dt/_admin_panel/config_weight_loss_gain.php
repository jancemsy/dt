<?php
 include("common.php"); 
 $path = "../content/splash/";     
 if(!file_exists($path)){  mkdir($path); }
 
 if(isset($_POST["save_cms"])){ 
     Config::update("weight_settings", $_POST );   
 }
       
 $height = 399; 
 $width = 465; 
 $quality = 100; 

 
 $_POST =  Config::get("weight_settings");  
 $menu_class[11] = 'class="current"' ; 
 include("_header.php");   
 

 ?> 
 <div class="box"> 
        <div class="title"> 
                <h2>Goal Settings</h2> 
                <?php echo $_dahide; ?>
        </div> 
     <div class="content forms" >
         <form action="" method="post">
         
            <p>
                Safe Minimum Calories for Female  (used for Update Goal settings)
               <input type="text" name="min_cal_female" value="<?php echo $_POST["min_cal_female"]; ?>" /> (lbs)
             </p>  
             
             <p>
                Safe Minimum Calories for Male  (used for Update Goal settings)
               <input type="text" name="min_cal_male" value="<?php echo $_POST["min_cal_male"]; ?>" /> (lbs)
             </p>  
             
         
             <p>
               Safe Weight Loss Rate Max: 
               <input type="text" name="loss_max" value="<?php echo $_POST["loss_max"]; ?>" /> (lbs)
             </p>             
             <p>
               Safe Weight Gain Rate Max:
               <input type="text" name="gain_max" value="<?php echo $_POST["gain_max"]; ?>" /> (lbs)
             </p>
             
             <p>
               Goal Met Text: <br/>
               <textarea name="goal_met" cols="70" rows="5" ><?php echo $_POST["goal_met"]; ?></textarea>
             </p>
             
             <p>
               Goal Failed Text: <br/>
               <textarea name="goal_failed" cols="70" rows="5"><?php echo $_POST["goal_failed"]; ?></textarea>
             </p>
             
             
             <br/>                          
               
             <div class="row buttons">                                        
                    <button type="submit" name="save_cms"><span>Save</span></button>                                                
             </div>
         </form>
         
     </div>
 </div>     
  
<script>
    $(function(){
        initMCE();
    });
</script>
    
 
 

<?php include("_footer.php"); ?>  