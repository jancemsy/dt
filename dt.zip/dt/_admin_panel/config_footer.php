<?php
 include("common.php");  

 
 if(isset($_POST["save_cms"])){ 
     Config::update("footer_cms", $_POST );   
 }
      
 
 $_POST =  Config::get("footer_cms");  
 $menu_class[11] = 'class="current"' ; 
 include("_header.php");   
 
  
?>
<style>
    .cms-home input{ width: 200px; }
    .cms-home textarea{ width: 470px; }
    hr{ color: #eee; }
</style>

 <div class="box"> 
        <div class="title"> 
                <h2>Footer CMS</h2> 
                <?php echo $_dahide; ?>
        </div> 
     <div class="content forms">
         <form action="" method="post">
              <table class="cms-home">
                    <tr>
                        <td valign="top">Diet categories:</td><td> 
                            <table>           
                                <?php  
                                     $label = "category";                                 
                                     for($i = 1; $i < 12; $i ++){
                                       $label_name = $label.$i;
                                       $link_name  = $label.'link'.$i;
                                       echo '<tr><td>Label:<input type="text" name="'.$label_name.'" value="'.$_POST[$label_name].'"   size="97" /></td> 
                                       <td>Link:<input type="text" name="'.$link_name.'" value="'.$_POST[$link_name].'"   size="97" /></td> </tr>';                                                                       
                                     }    
                                ?>                                                                                            
                            </table> 
                        </td>                        
                    </tr>
                    <tr><td colspan="2"> <hr size="1" /></td></tr>
                    <tr>
                        <td valign="top">Recipes:</td>
                        <td>
                            <i>Links are auto generated</i>
                            <!--
                            <table>           
                                
                                <?php  
                                     $label = "recipe";                                 
                                     for($i = 1; $i < 5; $i ++){
                                       $label_name = $label.$i;
                                       $link_name  = $label.'link'.$i;
                                       echo '<tr><td>Label:<input type="text" name="'.$label_name.'" value="'.$_POST[$label_name].'"   size="97" /></td> 
                                       <td>Link:<input type="text" name="'.$link_name.'" value="'.$_POST[$link_name].'"   size="97" /></td> </tr>';                                                                       
                                     }    
                                ?>                                                                                            
                            </table> -->
                        </td>                        
                    </tr>   
                    <tr><td colspan="2"> <hr size="1" /></td></tr>
                    <tr>
                        <td valign="top">Tools:</td>
                        <td>
                            <table>           
                                <?php  
                                     $label = "tools";                                 
                                     for($i = 1; $i < 5; $i ++){
                                       $label_name = $label.$i;
                                       $link_name  = $label.'link'.$i;
                                       echo '<tr><td>Label:<input type="text" name="'.$label_name.'" value="'.$_POST[$label_name].'"   size="97" /></td> 
                                       <td>Link:<input type="text" name="'.$link_name.'" value="'.$_POST[$link_name].'"   size="97" /></td> </tr>';                                                                       
                                     }    
                                ?>                                                                                            
                            </table>   
                        </td>                        
                    </tr>
                    <tr><td colspan="2"> <hr size="1" /></td></tr>
                    <tr>
                        <td valign="top">Diets:</td>
                        <td>
                            <i>Links are auto generated</i>
                            <!-- 
                           <table>           
                                <?php  
                                     $label = "diets";                                 
                                     for($i = 1; $i < 5; $i ++){
                                       $label_name = $label.$i;
                                       $link_name  = $label.'link'.$i;
                                       echo '<tr><td>Label:<input type="text" name="'.$label_name.'" value="'.$_POST[$label_name].'"   size="97" /></td> 
                                       <td>Link:<input type="text" name="'.$link_name.'" value="'.$_POST[$link_name].'"   size="97" /></td> </tr>';                                                                       
                                     }    
                                ?>                                                                                            
                            </table>  
                            -->
                        </td>                        
                    </tr>
                    <tr><td colspan="2"> <hr size="1" /></td></tr>
                    <tr>
                        <td valign="top">Videos:</td>
                        <td>
                            
                            <i>Links are auto generated</i>
                            <!--
                            <table>           
                                <?php  
                                     $label = "videos";                                 
                                     for($i = 1; $i < 5; $i ++){
                                       $label_name = $label.$i;
                                       $link_name  = $label.'link'.$i;
                                       echo '<tr><td>Label:<input type="text" name="'.$label_name.'" value="'.$_POST[$label_name].'"   size="97" /></td> 
                                       <td>Link:<input type="text" name="'.$link_name.'" value="'.$_POST[$link_name].'"   size="97" /></td> </tr>';                                                                       
                                     }    
                                ?>                                                                                            
                            </table>  -->
                        </td>                        
                    </tr>
                    <tr><td colspan="2"> <hr size="1" /></td></tr>
                    <tr>
                        <td valign="top">Articles:</td>
                        <td> 
                            <i>Links are auto generated</i>
                            <!--
                            <table>           
                                <?php  
                                     $label = "articles";                                 
                                     for($i = 1; $i < 5; $i ++){
                                       $label_name = $label.$i;
                                       $link_name  = $label.'link'.$i;
                                       echo '<tr><td>Label:<input type="text" name="'.$label_name.'" value="'.$_POST[$label_name].'"   size="97" /></td> 
                                       <td>Link:<input type="text" name="'.$link_name.'" value="'.$_POST[$link_name].'"   size="97" /></td> </tr>';                                                                       
                                     }    
                                ?>                                                                                            
                            </table>  -->
                        </td>                        
                    </tr>
                    <tr><td colspan="2"> <hr size="1" /></td></tr>
                    <tr>
                        <td valign="top">Resources:</td>
                        <td>
                             <table>           
                                <?php  
                                     $label = "resources";                                 
                                     for($i = 1; $i < 5; $i ++){
                                       $label_name = $label.$i;
                                       $link_name  = $label.'link'.$i;
                                       echo '<tr><td>Label:<input type="text" name="'.$label_name.'" value="'.$_POST[$label_name].'"   size="97" /></td> 
                                       <td>Link:<input type="text" name="'.$link_name.'" value="'.$_POST[$link_name].'"   size="97" /></td> </tr>';                                                                       
                                     }    
                                ?>                                                                                            
                            </table>  
                        </td>                        
                    </tr>
                    <tr><td colspan="2"> <hr size="1" /></td></tr>
                    <tr>
                        <td>Contact Us:</td>
                        <td>
                            <textarea name="contact_us" class="editor"><?php echo $_POST["contact_us"]; ?></textarea>  
                            
                        </td>                        
                    </tr>
                    <tr><td colspan="2"> <hr size="1" /></td></tr>
                    <tr>
                        <td>HTML/Tracking/Javascript Code:</td>
                        <td>
                            <textarea name="code"><?php echo $_POST["code"]; ?></textarea>                              
                        </td>                        
                    </tr>
                    
              </table>   
             <div class="row buttons">                                        
                    <button type="submit" name="save_cms"><span>Save</span></button>                                                
             </div>
         </form>
         
     </div>
 </div>     

<script>
    $(function(){
        initMCET(".editor");
    });
</script>
    

   


<?php include("_footer.php"); ?>  