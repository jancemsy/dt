<?php
 include("common.php");    
 include("modules/resources/process.php");    
 
  $menu_class[4] = 'class="current"' ;
  
 if( $_GET["delete_testimonial"] != ""){
     Testimonials::delete($_GET["delete_testimonial"]);
     jumpto("resources.php?testimonials=1");
 }
 
 
 if( isset($_POST["save_testimonial"]) ){
      if(isset($_FILES["upload"]) && $_FILES['upload']["name"] != ""){
        if( !empty($_POST["thumb"]) ) @unlink("../".$_POST["thumb"]);
        $name = $_FILES['upload']["name"];
        $ext   = end(explode(".",$name));
        $time = time();                 
        $filename = "$time.$ext";
        $thumb_dest = "../content/testimonials/$filename";
        move_uploaded_file($_FILES["upload"]["tmp_name"], $thumb_dest );         
        createThumb($thumb_dest,$thumb_dest,109,119);          
        $_POST["thumb"] = "content/testimonials/$filename";
     }
     
       $params = array(
                     "num" => intval($_POST["num"]),
                     "name" => addslashes($_POST["name"]),
                     "location" => addslashes($_POST["location"]), 
                     "comment" => addslashes($_POST["comment"]),
                     "thumb" => $_POST["thumb"] ); 
     
     if($_POST["id"] != ""){
        $params["id"] = $_POST["id"];
        Testimonials::update($params); 
     }else{
        Testimonials::add($params); 
     } 
          
     jumpto("resources.php?testimonials=1");
  } 


 
   if($_GET["crop"] == 1){ 
    $include = "modules/resources/crop.php";  
   }else if($_GET["experts"] == 1){ 
    $include = "modules/resources/experts.php";  
   }else if($_GET["community"] == 1){ 
    $include = "modules/resources/community.php";  
   }else if($_GET["news"] == 1){ 
    $include = "modules/resources/news.php";  
   }else if($_GET["tdesc"] == 1){
    $title = "Settings";
    $include = "modules/resources/desc_form.php";  
   }else if($_GET["testimonials"] == 1){
    $title = "Tools & Resources/Testimonials";
    $include = "modules/resources/testimonials.php";  
   }else if($_GET["become_member"] == 1){
    $title = "Tools & Resources/Become a member";
    $include = "modules/resources/become_a_member.php";  
   }else  if($_GET["ebook"] == 1){
    $title = "Tools & Resources/Ebook";
    $include = "modules/resources/ebook.php";  
  } else  if($_GET["discount"] == 1){
    $title = "Tools & Resources/Discount";
    $include = "modules/resources/discount.php";  
  } else  if($_GET["membership"] == 1){
    $title = "Tools & Resources/Community Membership";
    $include = "modules/resources/membership.php";  
  } else  if($_GET["heading"] == 1){
    $title = "Heading";
    $include = "modules/resources/heading.php";  
  }     
              
  
              
              
 include("_header.php"); ?>
  
 
       <?php     
             include($include);
            ?> 
                                 
                                 
<?php include("_footer.php"); ?>  