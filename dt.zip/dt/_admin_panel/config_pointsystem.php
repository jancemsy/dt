<?php
include("common.php");

$arr = $POINT_SYSTEM;




if (isset($_POST["save_cms"])) {
    $config = "";
    foreach ($arr as $name => $label) {        
        $_POST[$name] = intval($_POST[$name]);
        $config .= "define('".strtoupper($name)."'," . $_POST[$name] . ");" . chr(13);
    }

    file_put_contents("../content/points_config.conf", "<?php " . chr(13) . " $config ?>");
    Config::update("pointsystem_cms", $_POST);
}


$_POST = Config::get("pointsystem_cms");
$menu_class[11] = 'class="current"';
include("_header.php");
?>
<style>
    .cms-home input{ width: 200px; }
    .cms-home textarea{ width: 470px; }
    hr{ color: #eee; }
</style>

<div class="box"> 
    <div class="title"> 
        <h2>Point System CMS</h2> 
        <?php echo $_dahide; ?>
    </div> 
    <div class="content forms">
        <form action="" method="post">
            Headline: <br/>
            <input name="headline" size="70" value="<?php echo $_POST['headline']; ?>" /><br/>
            Text: <br/>
            <textarea name="text" class="editor" cols="72"><?php echo $_POST['text']; ?></textarea> 




            <br/><br/>
            <b>Points Configuration:</b>

            <table>

                <?php
                foreach ($arr as $name => $label) {
                    echo "<tr><td>$label</td>
                  <td><input type=\"text\" size=\"5\" style=\"text-align:center;width:30px;\" name=\"$name\" value=\"{$_POST["$name"]}\" /></td></tr>";
                }
                ?>



            </table>
            <div class="row buttons">                                        
                <button type="submit" name="save_cms"><span>Save</span></button>                                                
            </div>
        </form>

    </div>
</div>     

<script>
    $(function(){
        initMCET(".editor");
    });
</script>





<?php include("_footer.php"); ?>  