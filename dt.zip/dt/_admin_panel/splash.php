<?php
 include("common.php");  
 include("modules/splash/process.php");
 $menu_class[1] = 'class="current"' ;
 include("_header.php");
?> 

 
            <?php
              if($_GET["new"] == 1 || $_GET["edit"] != ""){      
                include("modules/splash/form.php");
              }else{  
                include("modules/splash/list.php");
              }
            ?> 
                    
<?php include("_footer.php"); ?>  