<?php
//session_start(); 
$path = dirname(__FILE__).'/../';

define('APATH',$path);


$no_xss_protection = true;

include($path."common.php");
set_time_limit(0);

ini_set('memory_limit', '154M');

$Admin = new Admin();


if(!defined("IN_LOGGEDIN")){
    $thispage = getThisPage();
   if( empty($Admin->adminID ) ) {   
    jumpto("login.php?redirect=".urlencode($thispage));
   }
}

 
?>