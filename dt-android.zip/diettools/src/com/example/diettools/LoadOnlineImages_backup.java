package com.example.diettools;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
 
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.widget.ImageView;

class LoadOnlineImages_backup extends AsyncTask<String, Void, String> { 
	ImageView imagev;
	String url;
	URL newurl;
	Bitmap  myBitmap;
	
	public LoadOnlineImages_backup(String url, ImageView i)  {
		    imagev = i; 
		    this.url = url; 
		    
		    
	} 
	
	@Override
    protected void onPreExecute() {
	       
	 }

	
	@Override
	protected String doInBackground(String... params) { 	 
         
		try {
			newurl = new URL(url);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} 
        URLConnection conn;
		try {
			conn = newurl.openConnection();
			conn.connect();
			InputStream is = conn.getInputStream();	             
	        BufferedInputStream bis = new BufferedInputStream(is);	                 	                
	        myBitmap =  BitmapFactory.decodeStream( bis);
	       return "okey";
		} catch (IOException e) {
			e.printStackTrace();
		}	 
		 	           
		return "";
	}

	
	@Override  
	protected void onPostExecute(String result) {
		super.onPostExecute(result);	 		 
		if(result.equals("okey"))
		{
			 imagev.setImageBitmap(myBitmap);  
		}
	}
} 