package com.example.diettools;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
   
public class RegistrationStep2Activity extends Activity {
	MYAPP me;
	RadioGroup radioGoal; 

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.registration_step2);
		me = (MYAPP) getApplication();		
		me.init(this);		
		
		RadioButton radio = (RadioButton) findViewById(R.id.radioLoseWeight);
		radio.setChecked(true);
		radioGoal = (RadioGroup) findViewById(R.id.radioGoal);
 
		
		Button btnregnext = (Button) findViewById(R.id.btnregnext); 		 	
		btnregnext.setOnClickListener(new OnClickListener() {
            // @Override
			public void onClick(View view) {				
				int selectedId    = radioGoal.getCheckedRadioButtonId();
				RadioButton radioGoalButton = (RadioButton) findViewById(selectedId); 			
				String goal    = radioGoalButton.getText().toString();			
				
				if( goal.equals("I want to lose weight")) goal = "lose weight";
				if( goal.equals("I want to gain weight")) goal = "gain weight";
				if( goal.equals("I want to live healthy without a weight goal")) goal = "live healthy without a weight goal";
				                
				
				me.user.goal = goal;						
				me.openscreen(RegistrationStep3Activity.class);								
			}   
		});   
  }

}
