package com.example.diettools;
 


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.EditText;
import android.widget.TextView;

public class MessagesNewActivity extends Activity {
	MYAPP me; 
	Button btnSend;
	AutoCompleteTextView txtSearch;
	EditText txtSubject;
	EditText txtMessage;   
	int userID = 0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.messages_new);	 
		me = (MYAPP)getApplication(); 
		me.init(this);	
		me.SetMainMenuListeners(); 	
		
		btnSend = (Button) findViewById(R.id.btnSend);		
		txtSubject = (EditText) findViewById(R.id.txtSubject);
		txtMessage = (EditText) findViewById(R.id.txtMessage);  				 
		txtSearch = (AutoCompleteTextView) findViewById(R.id.txtSearch);
		
		
		if( !MYAPP.isEmpty(me._message_id) ){
		   String query = "SELECT  m.*, u." + Users.C_username + ",u."+Users.C_avatar +  
		   " FROM  "+Messages.TABLE+" m " +
		   " LEFT JOIN "+Users.TABLE+" u  ON (u."+Users.C_oid+"=m."+Messages.C_sender+") " +
		   " WHERE  m."+Messages.C_id + " = " + me._message_id + " " +     
		   " ORDER BY m.created DESC LIMIT 50";
		
		   Cursor c = MYAPP.static_ds.rawQuery(query  , null);
		 
		   if( c.getCount() > 0 ){
			   c.moveToFirst();
			   //String created   = c.getString(  c.getColumnIndex( Messages.C_created ) ); 
	           String subject   = c.getString(  c.getColumnIndex( Messages.C_subject ) );
	          // String message   = c.getString(  c.getColumnIndex( Messages.C_message ) );
	           String from      = c.getString(  c.getColumnIndex( Users.C_username ) );	           
	           userID = c.getInt( c.getColumnIndex( Messages.C_sender));
	           txtSearch.setText(from);
	           txtSubject.setText("Re:"+subject);
	           btnSend.setText("Reply Message");
			   //txtMessage.setText("");
		   }
		   
		}
		
		ItemAutoTextAdapter adapter1 = this.new ItemAutoTextAdapter();
		 
		txtSearch.setAdapter(adapter1);
		txtSearch.setOnItemClickListener(adapter1);
		txtSearch.addTextChangedListener(new TextWatcher(){
	        public void afterTextChanged(Editable s) { }
	        public void beforeTextChanged(CharSequence s, int start, int count, int after){  }
	        public void onTextChanged(CharSequence s, int start, int before, int count){}
	    });  
				
		
		btnSend.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {
				String subject = txtSubject.getText().toString();
				String message = txtMessage.getText().toString();   
				if(userID == 0){
					 me.alertbox("Invalid user");
					 txtSearch.setText("");
					 txtSearch.requestFocus();					 
				 }else if( MYAPP.isEmpty(message) || MYAPP.isEmpty(subject) ){
					 me.alertbox("Please complete the form.");					 
				 }else{
					 Messages msg = new Messages();
					 msg.created    = me.dateString;
					 msg.sender     = me.userID;
				     msg.recipient  = userID;
				     msg.subject    = subject;
				     msg.message    = message;	
				     msg.status     = MYAPP.UNREAD;
			         msg.insert();
			         new SynchUploader(MessagesNewActivity.this, msg,  "newmessage" ).execute();			         
			       
			         me.openscreen(MessagesInboxActivity.class);
				 }				 				
			}
		});
		
		
		
		 
	}
	
	 

	class ItemAutoTextAdapter extends CursorAdapter implements android.widget.AdapterView.OnItemClickListener {
		SQLiteDatabase db;
		Activity act;
		MYAPP me;

		public ItemAutoTextAdapter() {
			super(MessagesNewActivity.this, null);
			db = MYAPP.static_ds.db; 
			me = (MYAPP) getApplication();
		}

		public Cursor getMatches(String constraint) throws SQLException {			
			Log.d("AutoCompleteDbAdapter", " STRING ====> " + constraint);

			String queryString = "SELECT " + Users.C_username + ", " + Messages.C_id + ", "
					+ Users.C_userID + "  FROM " + Messages.TABLE;
			if (constraint != null) {
				constraint = "%" + constraint.trim() + "%";
				queryString += " WHERE " + Users.C_username + " LIKE ? ";
			}

			String params[] = { constraint };
			if (constraint == null) {
				params = null;
			}

			try {
				Cursor cursor = db.rawQuery(queryString, params);
				Log.d("AutoCompleteDbAdapter", " MATCH COUNT ====> "
						+ queryString + "=" + cursor.getCount()); 
				 
				if(cursor.getCount() == 0){
					userID = 0;
				} 
				
				if (cursor != null) {
					cursor.moveToFirst(); 
					return cursor;
				}
			} catch (SQLException e) {
				Log.e("AutoCompleteDbAdapter", e.toString());
				throw e;
			}
			return null;
		}

		@Override
		public Cursor runQueryOnBackgroundThread(CharSequence constraint) {
			if (getFilterQueryProvider() != null) {
				return getFilterQueryProvider().runQuery(constraint);
			}
			Cursor cursor = getMatches(constraint != null ? constraint.toString() : null);
			return cursor;
		}

		@Override
		public String convertToString(Cursor cursor) {
			final int columnIndex = cursor.getColumnIndexOrThrow(Users.C_username);
			final String str = cursor.getString(columnIndex);
			return str;
		}

		@Override
		public void bindView(View view, Context context, Cursor cursor) {
			final String text = convertToString(cursor);
			((TextView) view.findViewById(R.id.text1) ).setText(text); 
		}

		@Override
		public View newView(Context context, Cursor cursor, ViewGroup parent) {			
			final LayoutInflater inflater = LayoutInflater.from(context);
			final View view = inflater.inflate(R.layout._custom_completer_find_user, parent, false);
			return view;
		}
 
		
		
		@Override
		public void onItemClick(AdapterView<?> listView, View view, int position, long id) {
			// Get the cursor, positioned to the corresponding row in the result
			Cursor cursor = (Cursor) listView.getItemAtPosition(position);

			// Get the state's capital from this row in the database.			
			userID =  cursor.getInt(cursor.getColumnIndexOrThrow(Users.C_userID)); 
			String username = cursor.getString(cursor.getColumnIndexOrThrow(Users.C_username)); 
			txtSearch.setText(username.trim());			
			txtSubject.requestFocus();				
		}
	}

	
	
	
	class SynchUploader extends AsyncTask<String, Void, String> {		
		Context context;  
		ProgressDialog progress; 
		String TAG = "AddMessage Synch Uploader";
		Messages message;
		String method = "addjournal";
			
		public SynchUploader(Context c, Messages m, String method ) { 
			this.context    = c; 
			this.message    = m; 
			this.method     = method;
		}	
		@Override
	    protected void onPreExecute() {
		        progress = ProgressDialog.show(this.context, "", "Please wait..."); 
		        super.onPreExecute();
		 }		
		@Override
		protected String doInBackground(String... params) { 
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(9);						         
			nameValuePairs.add(new BasicNameValuePair("subject",   message.subject));						
			nameValuePairs.add(new BasicNameValuePair("message",   message.message));			
			nameValuePairs.add(new BasicNameValuePair("recipient", String.valueOf(message.recipient)));			
			nameValuePairs.add(new BasicNameValuePair("sender",    String.valueOf(me.userID)));
			nameValuePairs.add(new BasicNameValuePair("oid",       String.valueOf(message.oid)));
			nameValuePairs.add(new BasicNameValuePair("created",   message.created));			
			nameValuePairs.add(new BasicNameValuePair("method",    method));
			nameValuePairs.add(new BasicNameValuePair("email",     me.user.email));
			nameValuePairs.add(new BasicNameValuePair("password",  me.user.password));
						
			Log.d(TAG,"*************Debugging.... subject:" + message.subject +
					", msg: " + message.message + ",recipient: "+
					message.recipient+", method: " + method + " email: " + me.user.email + ", p: " + me.user.password);
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(MYAPP.API_BASE);

			try {
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = httpclient.execute(httppost);
				String output = MYAPP.getWebString(response.getEntity().getContent());
				Log.d(TAG, "API Connection Result for "+method+": " + output); 
				return output;
			} catch (ClientProtocolException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} catch (IOException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} 
			return "";   
		}  
		
		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);	 
			if(result.length() == 0){
				progress.dismiss();
				//flash("Invalid Username/Password!");
			}else{
				if( !MYAPP.isNumeric(result) ){
					 progress.dismiss();
					 me.flash("Error for some reason"); 
				}else{ //user found here      					    
 			         message.oid = Integer.parseInt(result);
			         message.update(); 	
			         me.flash("Message has been sent!");
				}				
			}  
       }
	
  }
	
	
	
	
	
	
	
	
	
 
}
