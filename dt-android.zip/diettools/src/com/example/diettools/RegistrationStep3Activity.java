package com.example.diettools;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
  
public class RegistrationStep3Activity extends Activity {
	public static String TAG = "::FINAL REGISTRATION ACTIVY::";	
	MYAPP me;
	Datasource2 ds;
	EditText txtheight;
	EditText txtbody;
	EditText txtbirthdate;
	EditText txtgoaldate;
	EditText txtgoalweight;
	Button btnregsubmit;
	DialogFragment newFragment = null; 
	static EditText currentDate;
	Users user2;
	RadioGroup radioSex;
	RadioButton radioFemale;
	RadioButton radioMale;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.registration_step3);
		me = (MYAPP) getApplication();		
		me.init(this);
		ds = new Datasource2(this);
		me.initDs(ds);
		
		txtheight         = (EditText) findViewById(R.id.txtheight);
		txtbody           = (EditText) findViewById(R.id.txtbody);
		txtbirthdate      = (EditText) findViewById(R.id.txtbirthdate);			
		txtgoaldate       = (EditText) findViewById(R.id.txtgoaldate);
		txtgoalweight     = (EditText) findViewById(R.id.txtgoalweight);
		radioSex          = (RadioGroup) findViewById(R.id.radioSex);
		radioFemale       = (RadioButton) findViewById(R.id.radioFemale);
		radioMale         = (RadioButton) findViewById(R.id.radioMale);
		btnregsubmit      = (Button) findViewById(R.id.btnregsubmit);
		
		 		
		txtheight.requestFocus();
		radioMale.setChecked(true);
		
		txtgoaldate.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {						
				currentDate = txtgoaldate; 
				if( newFragment != null ) newFragment.dismiss(); 
				newFragment = new DatePickerFragment();
				newFragment.show(getFragmentManager(), "datePicker");						
			}
		});		
		
		txtbirthdate.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {
				currentDate = txtbirthdate;
				if( newFragment != null ) newFragment.dismiss(); 
				newFragment = new DatePickerFragment();
				newFragment.show(getFragmentManager(), "datePicker");						
			}
		});	
		
		if(me.user.goal.equals("lose weight") || me.user.goal.equals("gain weight") ){
			//TODO
			//init goaldate for datepicker here			
		}else{			
			txtgoaldate.setEnabled(false);
			txtgoalweight.setEnabled(false);
		}
		
		
		btnregsubmit.setOnClickListener(new OnClickListener() {
            // @Override
			public void onClick(View view) {				
				double height = MYAPP.parseDoubleOrNull(txtheight.getText().toString()); //in
				double weight = MYAPP.parseDoubleOrNull(txtbody.getText().toString()); //lbs
				String birth   = txtbirthdate.getText().toString();
				
				String goal_date = "";
				String goal_weight = "";				
				
				if(me.user.goal.equals("lose weight") || me.user.goal.equals("gain weight") ){
				   goal_date   = txtgoaldate.getText().toString();
				   goal_weight = txtgoalweight.getText().toString();
				}
														
				
				if(height  < 1){
				 me.alertbox("Invalid height");	
				}else if(weight  < 1){
					me.alertbox("Invalid weight");
				}else if(birth.equals("")){
					me.alertbox("Please provide a birth date");				
				}else if( (me.user.goal.equals("lose weight") || me.user.goal.equals("gain weight"))
						   && (goal_weight.equals("") || goal_date.equals("")  ) ){					
					if( goal_weight.equals("")){
						me.alertbox("Please provide your goal weight");
					}else if( goal_date.equals("") ){
						me.alertbox("Please provide your goal date");
					}										
				}else{					
					me.user.weight = weight;
					me.user.height = height;
					me.user.birth_date = birth;
					me.user.goal_weight = goal_weight;
					me.user.goal_date = goal_date;
					
					int selectedId    = radioSex.getCheckedRadioButtonId();
					RadioButton radioSexButton = (RadioButton) findViewById(selectedId);					
					me.user.sex         = radioSexButton.getText().toString();
					
											 							
					new RegisterToSite().execute();
				}
				                
				
												
			}   
		}); 
		
		
  }
	
	
	public static class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {   
	    Calendar cal;  
		Date date2 = null;
		  

		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {			
         String date = currentDate.getText().toString(); 
			SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy"); 
			
			try {
				date2 = formatter.parse( date );
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
		    cal = Calendar.getInstance();	
		    if(date2 != null) cal.setTime(date2);
		    
			
			int year  = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH);
			int day   = cal.get(Calendar.DAY_OF_MONTH); 
			return new DatePickerDialog(getActivity(), this, year, month, day);
		}

		public void onDateSet(DatePicker view, int year, int month, int day) {
			currentDate.setText( MYAPP.add0( month + 1 ) + "/" + MYAPP.add0(day) + "/" + year);
		}
	}
	

	
	
	
	class RegisterToSite extends AsyncTask<String, Void, String> { 
		ProgressDialog progress;  
		Users user;
		
		@Override
	    protected void onPreExecute() {
		        progress = ProgressDialog.show(RegistrationStep3Activity.this , "", "Please wait..."); 
		        super.onPreExecute();
		        user = new Users();
		        user = me.user;
		 }

		
		@Override
		protected String doInBackground(String... params) { 
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(10);		
			nameValuePairs.add(new BasicNameValuePair("method", "signup"));
			nameValuePairs.add(new BasicNameValuePair("birth_date", user.birth_date));
			nameValuePairs.add(new BasicNameValuePair("email", user.email));
			nameValuePairs.add(new BasicNameValuePair("username", user.username));
			nameValuePairs.add(new BasicNameValuePair("password", user.password));
			nameValuePairs.add(new BasicNameValuePair("height", String.valueOf(user.height) ));
			nameValuePairs.add(new BasicNameValuePair("weight", String.valueOf(user.weight) ));
			nameValuePairs.add(new BasicNameValuePair("goal_weight", user.goal_weight));
			nameValuePairs.add(new BasicNameValuePair("goal_date", user.goal_date));
			nameValuePairs.add(new BasicNameValuePair("goal_sex", user.sex));
			nameValuePairs.add(new BasicNameValuePair("goal", user.goal));			
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(MYAPP.API_BASE);

			try {
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = httpclient.execute(httppost);
				String output = MYAPP.getWebString(response.getEntity().getContent());
				Log.d(TAG, "API Connection Result: \n" + output); 
				return output;
			} catch (ClientProtocolException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} catch (IOException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} 
			return "";
		}

		
		@Override  
		protected void onPostExecute(String result) {
			super.onPostExecute(result);	 
			if(result.length() == 0){     
				progress.dismiss();  
				me.flash("Error occured, Please try again!");
			}else{			 
					Log.d(TAG, "JSON EXECUTED!!!!");
					try{												  					
			            JSONObject json = new JSONObject(result);
			            
			             
			            if( MYAPP.isEmpty(json.get("error").toString()) ) {			            	
			            	me.alertbox(json.get("oid").toString());			            				            	
			            	JSONObject jsonarray = new JSONObject(json.get("data").toString());				            
				            user.oid    = Integer.parseInt(json.get("oid").toString());
				            user.userID = Integer.parseInt(json.get("oid").toString());				            				          
				            user.sex = "male"; //?????				            
				            user.insert();				            
				            me.user = user;
				            me.userID = user.userID;				          
				            me.flash("Account has been created successfully!");
				            me.goToDashboard();
			            }else{
			               me.alertbox(json.get("error").toString());  	 
			            }			            
				    } catch (Exception e) {
				    	Log.e(TAG, "User Json parser error..", e); 
				    } 
				    
				    progress.dismiss();							
			}  
		}
} 


}
