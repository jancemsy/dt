package com.example.diettools;

import android.app.AlarmManager;
import android.app.IntentService;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.text.format.DateUtils;
import android.text.format.Time;
import android.util.Log;

public class MyUpdateService extends IntentService { 
	MYAPP me;
	int i = 0;

	public MyUpdateService() {
		super(MyUpdateService.class.getSimpleName()); 
		me = (MYAPP) MYAPP.static_activity.getApplication();
	}

	@Override
	protected void onHandleIntent(Intent intent) {
		Log.d("INTERNAL SERVICE", "Executing.........");
		me.downloader = new Syncher();
		scheduleNextUpdate();
	}

	private void scheduleNextUpdate() {
		i++;
		Log.d("MyUpdateService","Schedule Next Update........................................"+i);
		Intent intent = new Intent(this, this.getClass());
		PendingIntent pendingIntent = PendingIntent.getService(this, 0, intent,
				PendingIntent.FLAG_UPDATE_CURRENT);

		// The update frequency should often be user configurable. This is not.
		long currentTimeMillis = System.currentTimeMillis();
		long nextUpdateTimeMillis = currentTimeMillis + 15
				* DateUtils.MINUTE_IN_MILLIS;
		Time nextUpdateTime = new Time();
		nextUpdateTime.set(nextUpdateTimeMillis);

		/*every hour*/
		if (nextUpdateTime.hour < 1 || nextUpdateTime.hour >= 18) {
			nextUpdateTime.hour   = 1;
			nextUpdateTime.minute = 0;
			nextUpdateTime.second = 0;
			nextUpdateTimeMillis = nextUpdateTime.toMillis(false)
					+ DateUtils.DAY_IN_MILLIS;
		}
		AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		alarmManager.set(AlarmManager.RTC, nextUpdateTimeMillis, pendingIntent);
	}
}