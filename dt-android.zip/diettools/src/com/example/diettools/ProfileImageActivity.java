package com.example.diettools;


import java.io.File;

import android.app.Activity;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;

public class ProfileImageActivity extends Activity {
	MYAPP me; 
	File path;
	String base_path = "diettools";	
	String gallery_path  = "diettools/gallery";
	String avatar_path   = ""; 
	ImageView imageView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.full_image); 
		me = (MYAPP)getApplication(); 
		me.init(this);
		 
		boolean mExternalStorageAvailable = false;
    	boolean mExternalStorageWriteable = false;
    	String state = Environment.getExternalStorageState();
    	

    	if (Environment.MEDIA_MOUNTED.equals(state)) {
    	    // We can read and write the media
    	    mExternalStorageAvailable = mExternalStorageWriteable = true;
    	} else if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
    	    // We can only read the media
    	    mExternalStorageAvailable = true;
    	    mExternalStorageWriteable = false;
    	} else {
    	    // Something else is wrong. It may be one of many other states, but all we need
    	    //  to know is we can neither read nor write
    	    mExternalStorageAvailable = mExternalStorageWriteable = false;
    	}    
    	
    	
        if(mExternalStorageAvailable)
          path = Environment.getExternalStorageDirectory();
        else
          path = Environment.getDataDirectory();
         
        
        base_path = path + "/" + base_path;    
        gallery_path = path + "/" + gallery_path;
        avatar_path = base_path;
        
        
        Cursor c = MYAPP.static_ds.rawQuery("SELECT *FROM " + UserGalleries.TABLE
				+ " WHERE ( " + UserGalleries.C_id + " = ?  )", 
				new String[] {  me._gallery_item_id  }); 
        
        if ( c.getCount() > 0 ) {
        	 c.moveToFirst();
        	    imageView = (ImageView) findViewById(R.id.fullImage); 
        	    String fn = c.getString(c.getColumnIndex(UserGalleries.C_file));
        	    
        	    if(fn.contains("http://")){ 
        	    	
        	    	ImageLoader imgLoader = new ImageLoader();
                    imgLoader.DisplayImage(fn,imageView);                    
                    /*
        	    	LoadOnlineImages lb = new  LoadOnlineImages(fn,imageView);
					lb.execute();
					*/
        	    }else{
    	           File imgFile = new  File(fn);
    	           if(imgFile.exists()){
    	              Bitmap bm = BitmapFactory.decodeFile(imgFile.getAbsolutePath());    	              
    	        	  imageView.setImageBitmap(bm);
    	        	  //imageView.setImageResource(imageId);
    	        	  imageView.setScaleType(ImageView.ScaleType.FIT_XY);    	        	 
    	           }    
        	    }
        }
	} 
	 
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {   	
		getMenuInflater().inflate(R.menu.profile_full_image_menu, menu); 
		return true;
	}
	    
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {  
		switch (item.getItemId()) {
		case R.id.item_goback_profile: 
			me._profile_tab = "gallery";
			me.openscreen( ProfileActivity.class);
			return true;
		case R.id.item_delete_image:
			MYAPP.static_ds.db.delete(UserGalleries.TABLE,UserGalleries.C_id + " = "+  me._gallery_item_id , null);					 
			me._gallery_item_id = "";
			me._profile_tab = "gallery";
			me.flash("Image has been deleted!");
			me.openscreen( ProfileActivity.class);
			return true;		
		default:
			return false;
		}
	}
	
 
}
