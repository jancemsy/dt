package com.example.diettools;


import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class ToolBMRActivity extends Activity{
	MYAPP me; 
	EditText txtweight;
	EditText txtheight; 
	TextView tvweight;
	TextView tvheight;
	
	Button btnclear;
	Button btncalc;
	Boolean isEnglish = true;
	RadioGroup radiogroup;
	RadioButton radioselected;
	
	RadioButton radiometric;
	RadioButton radioenglish;
	
	RadioButton radiomale;
	RadioButton radiofemale;
	
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.bmr);			
		me = (MYAPP)getApplication(); 
		me.init(this);
		me.SetMainMenuListeners(); 
		
		txtweight     = (EditText) findViewById(R.id.editText1);
		txtheight     = (EditText) findViewById(R.id.txtregpassword);		
		tvweight      = (TextView) findViewById(R.id.textView1);
		tvheight      = (TextView) findViewById(R.id.tvheight);				
		btnclear      = (Button) findViewById(R.id.btnregsubmit);
		btncalc       = (Button) findViewById(R.id.button2);		
		radioenglish  = (RadioButton) findViewById(R.id.radioEnglish);
		radiometric   = (RadioButton) findViewById(R.id.radioMetric); 
		radiomale     = (RadioButton) findViewById(R.id.radioMale);
		radiofemale   = (RadioButton) findViewById(R.id.radioFemale);		
				
		tvweight.setText("Weight (lbs):");
		tvheight.setText("Height (in):");
		
		txtweight.setText(String.valueOf(me.user.weight));
		txtheight.setText(String.valueOf(me.user.height));
		
		radioenglish.setChecked(true);	
		

		if (me.user.sex == "female")
			radiofemale.setChecked(true);
		else
			radiomale.setChecked(true);
		
		
		radioenglish.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {
				tvweight.setText("Weight (lbs):");
				tvheight.setText("Height (in):");
			}
		}); 
		radiometric.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {
				tvweight.setText("Weight (kg):");
				tvheight.setText("Height (cm):");
			}
		});
		
		
		btnclear.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {
				txtweight.setText("");
				txtheight.setText("");
			}
		});
		
		btncalc.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {
				
				if (MYAPP.isNumeric(txtweight.getText().toString())
						&& MYAPP.isNumeric(txtweight.getText().toString())) {

				           double weight = Double.parseDouble(txtweight.getText().toString());
					       double height = Double.parseDouble(txtheight.getText().toString()); 
						   double bmr;
						   int age = me.user.age;
						   String gender = getGender();    
 						    						 
						   if(gender == "Male") { 
						       bmr = Math.round((66 + (6.23 * weight) + (12.7 * height) - (6.8 * age)) * 10) / 10;
						   } else { 
						       bmr = Math.round((665 + (4.35 * weight) + (4.7 * height) - (4.7 * age)) * 10) / 10;
						   }
						   
						   me.user.weight = weight;
						   me.user.height = height;
						   me.user.bmr    = bmr;
						   me.user.update();
						     
							me._bmr_result1 = String.valueOf(bmr);
							me._bmr_result2 = String.valueOf(Math.round(bmr * 1.2));
							me._bmr_result3 = String.valueOf(Math.round(bmr * 1.375));
							me._bmr_result4 = String.valueOf(Math.round(bmr * 1.55));
							me._bmr_result5 = String.valueOf(Math.round(bmr * 1.725));
							me._bmr_result6 = String.valueOf(Math.round(bmr * 1.9));
							
							me.openscreen(ToolBMRResultActivity.class);						

				} else {
                    me.alertbox("Input must be a number!");
				}

			}// onclick
			 
		});
					
		
	}
	
	
	public String getMeasurement()
	{
		radiogroup     = (RadioGroup) findViewById(R.id.measurement);
		int selectedId = radiogroup.getCheckedRadioButtonId();
		radioselected  = (RadioButton) findViewById(selectedId);		
		return radioselected.getText().toString();
	}
	
	public String getGender()
	{
		radiogroup     = (RadioGroup) findViewById(R.id.gender);
		int selectedId = radiogroup.getCheckedRadioButtonId();
		radioselected = (RadioButton) findViewById(selectedId);		
		return radioselected.getText().toString();
	}
	
 
}
