package com.example.diettools;


import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleCursorAdapter;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TextView;

public class DashboardActivity extends Activity {
	TabHost mTabHost;
	RelativeLayout _rl;
	MYAPP me; 
	LinearLayout.LayoutParams lp;
	TextView dbbottom_cal_txt; 
	UserJournals journal;
	EditText mind_title_txt;
	EditText mind_message_txt;		
	EditText height_txt;
	EditText weight_txt;    
    EditText arms_txt;    
    EditText chest_txt;
    EditText waist_txt;    
    EditText hips_txt;
    Button save_journal_body_btn;    
    TextView txtTypeStrength;
    TextView txtTypeCardio;
    private static final int EDIT_ID = Menu.FIRST + 3;
    private static final int DELETE_ID = Menu.FIRST + 4;
    private static final int DUPLICATE_ID = Menu.FIRST + 5;    
    

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.dashboard);
		me = (MYAPP) getApplication(); 
		me._exercise_id = 0;  
		me._to_add_foodID = "";
		me._to_edit_food_ID = "";
		me._to_edit_exercise_ID = "";
		me.init(this);	
		me.changeMainHeader("Dashboard/Exercise");
		me.SetMainMenuListeners();
		me.setDateButtonListeners();    
		
					     
		mTabHost               = (TabHost) findViewById(android.R.id.tabhost);
		mTabHost.setup();
		mTabHost.getTabWidget().setDividerDrawable(R.drawable.tab_divider); 		
		dbbottom_cal_txt       = (TextView) findViewById(R.id.dbbottom_cal_txt);	 
	    dbbottom_cal_txt.setText( String.valueOf(me.today_burned) );	 						
	    journal                = new UserJournals();
		mind_title_txt         = (EditText) findViewById(R.id.mind_title_txt);
		mind_message_txt       = (EditText) findViewById(R.id.mind_message_txt);
		height_txt             = (EditText) findViewById(R.id.txt_db_height);
		weight_txt             = (EditText) findViewById(R.id.txt_db_weight);
	    arms_txt               = (EditText) findViewById(R.id.txt_db_arms);
	    chest_txt              = (EditText) findViewById(R.id.txt_db_chest);
	    waist_txt              = (EditText) findViewById(R.id.txt_db_waist);
	    hips_txt               = (EditText) findViewById(R.id.txt_db_hips);
	    save_journal_body_btn  = (Button) findViewById(R.id.save_journal_body_btn);
	    txtTypeStrength        = (TextView) findViewById(R.id.txtTypeStrength);
	    txtTypeCardio          = (TextView) findViewById(R.id.txtTypeCardio);	 
	    
	    txtTypeStrength.setTextColor(getResources().getColor(R.color.gray1));
		txtTypeCardio.setTextColor(getResources().getColor(R.color.blue));
		
	    txtTypeStrength.setOnClickListener(new OnClickListener() { 
			@Override
			public void onClick(View view) {
				me.exercise_type = "strength"; 
				txtTypeStrength.setTextColor(getResources().getColor(R.color.blue));
				txtTypeCardio.setTextColor(getResources().getColor(R.color.gray1));
				displayExerciseList();
			}
		}); 
	    
	    txtTypeCardio.setOnClickListener(new OnClickListener() { 
			@Override
			public void onClick(View view) {
			    me.exercise_type = "cardio";
			    txtTypeStrength.setTextColor(getResources().getColor(R.color.gray1));
				txtTypeCardio.setTextColor(getResources().getColor(R.color.blue));
				displayExerciseList();
			}
		}); 
	    
	    
	    ////////////////////////TABS///////////////////////////////////////////
		TabHost.TabSpec spec1 = mTabHost.newTabSpec("Food");
		View tabview1 = createTabView(mTabHost.getContext(), "Food");
		spec1.setIndicator(tabview1);
		spec1.setContent(R.id.dashboard_food_container);
		mTabHost.addTab(spec1);

		TabHost.TabSpec spec2 = mTabHost.newTabSpec("Exercise");
		View tabview2 = createTabView(mTabHost.getContext(), "Exercise");
		spec2.setIndicator(tabview2);
		spec2.setContent(R.id.dashboard_exercise_container);
		mTabHost.addTab(spec2);

		TabHost.TabSpec spec3 = mTabHost.newTabSpec("Mind");
		View tabview3 = createTabView(mTabHost.getContext(), "Mind");
		spec3.setIndicator(tabview3);
		spec3.setContent(R.id.dashboard_mind_container);
		mTabHost.addTab(spec3);

		TabHost.TabSpec spec4 = mTabHost.newTabSpec("Body");
		View tabview4 = createTabView(mTabHost.getContext(), "Body");
		spec4.setIndicator(tabview4);
		spec4.setContent(R.id.dashboard_body_container);
		mTabHost.addTab(spec4); 
		_rl = (RelativeLayout) findViewById(R.id.calories_graph);
	    ////////////////////////TABS///////////////////////////////////////////		
		 
		
		updateTabContent();
		
		
		
		if(me.currentTab == 0){ 
		}else{		   
	      mTabHost.setCurrentTab( me.currentTab );	      
		}		

	

		mTabHost.setOnTabChangedListener(new OnTabChangeListener() {  
			@Override
			public void onTabChanged(String tab) {
				me.currentTab = mTabHost.getCurrentTab();  				
				updateTabContent();   
				me.changeMainHeader( "Dashboard/" + tab );
			}
		});
 

		((Button) findViewById(R.id.btnArrowLeft))
				.setOnClickListener(new OnClickListener() {
					// @Override
					@Override
					public void onClick(View view) {
						me.movePrev();
						updateTodayBurned();
						updateTabContent();
					}
				});

		((Button) findViewById(R.id.btnArrowRight))
				.setOnClickListener(new OnClickListener() {
					// @Override
					@Override
					public void onClick(View view) {						
						me.moveNext();
						updateTodayBurned();
						updateTabContent(); 
					}
				}); 
		
		
	}
	
	
	private void updateTabContent(){
		int i = me.currentTab; 
	    int v = View.INVISIBLE;
	    lp = new LinearLayout.LayoutParams( LayoutParams.FILL_PARENT, 440);
	    
		switch( i ){		  		  		  
		  case  3: 			  			  
			  setBodyDashboard();
			  break;
		  case  2: 			  			  
			  setMindDashboard();
			  break;	  
		  case  0:		
			   v = View.VISIBLE;
			   lp = new LinearLayout.LayoutParams( LayoutParams.FILL_PARENT, 300);			   
			   setFoodDashboard();
			  break;
		  case  1:			     			  			  
			  setExerciseDashboard();
		  break;	  
		}
		
		_rl.setVisibility(v);
		mTabHost.setLayoutParams(lp);   
	}
	

	private static View createTabView(final Context context, final String text) {
		View view = LayoutInflater.from(context)
				.inflate(R.layout.tabs_bg, null);
		TextView tv = (TextView) view.findViewById(R.id.tabsText);
		tv.setText(text);
		return view;			
	}
		
	
	private void updateTodayBurned(){				     	        	   	 
	    dbbottom_cal_txt.setText( String.valueOf(me.today_burned) );
	}
	
	private Cursor getJournalCursor(){
		return MYAPP.static_ds.rawQuery("SELECT *FROM " + UserJournals.TABLE
	    		+ " WHERE " + UserJournals.C_created + " = '" + me.dateString + "'"
	    		+ " AND " + UserJournals.C_userID + " = '" + me.userID + "' ORDER BY " + UserJournals.C_id+" DESC LIMIT 1 " , null);
		
	}
	
	private void setBodyDashboard(){
		Cursor c = this.getJournalCursor();
		if( c.getCount() > 0 ){
			c.moveToFirst();			
			journal.setInfo(c);			
			me._current_journal_id  = c.getString(c.getColumnIndex( UserJournals.C_id ) );
			height_txt.setText( c.getDouble(c.getColumnIndex( UserJournals.C_height )) > 0 ? c.getString(c.getColumnIndex( UserJournals.C_height )) : "" );
			weight_txt.setText( c.getDouble(c.getColumnIndex( UserJournals.C_weight )) > 0 ? c.getString(c.getColumnIndex( UserJournals.C_weight )) : "" );
		    arms_txt.setText(c.getDouble(c.getColumnIndex( UserJournals.C_arms )) > 0 ? c.getString(c.getColumnIndex( UserJournals.C_arms )) : "" );
		    chest_txt.setText(c.getDouble(c.getColumnIndex( UserJournals.C_chest )) > 0 ? c.getString(c.getColumnIndex( UserJournals.C_chest )) : "" );
		    waist_txt.setText(c.getDouble(c.getColumnIndex( UserJournals.C_waist )) > 0 ? c.getString(c.getColumnIndex( UserJournals.C_waist )) : "" );
		    hips_txt.setText(c.getDouble(c.getColumnIndex( UserJournals.C_hips )) > 0 ? c.getString(c.getColumnIndex( UserJournals.C_hips )) : "");
		}else{
			me._current_journal_id = "";	
			height_txt.setText("");
			weight_txt.setText("");
		    arms_txt.setText("");
		    chest_txt.setText("");
		    waist_txt.setText("");
		    hips_txt.setText("");
		} 
	
	    weight_txt.requestFocus();	
	    
	    save_journal_body_btn.setOnClickListener(new OnClickListener() {
			// @Override
			@Override
			public void onClick(View view) {									
				 String height =  String.valueOf(height_txt.getText());
				 String weight =  String.valueOf(weight_txt.getText());
				 String arms   =  String.valueOf(arms_txt.getText());
				 String chest  =  String.valueOf(chest_txt.getText());
				 String waist  =  String.valueOf(waist_txt.getText());
				 String hips   =  String.valueOf(hips_txt.getText());				    	
				    		
				 boolean isComplete = MYAPP.isEmpty(height) && MYAPP.isEmpty(weight) && 
				 MYAPP.isEmpty(arms) && MYAPP.isEmpty(chest)  && MYAPP.isEmpty(waist) &&
				 MYAPP.isEmpty(hips)   ? false : true;
				 //boolean isValidNumber = MYAPP.isNumericOrEmtpy(height) && MYAPP.isNumericOrEmtpy(weight) && MYAPP.isNumericOrEmtpy(arms) && MYAPP.isNumericOrEmtpy(chest)  && MYAPP.isNumericOrEmtpy(waist) &&  MYAPP.isNumericOrEmtpy(hips)   ?  true : false;				 				
				 
				 if( !isComplete ){
					 me.alertbox("Please complete the fields!" );
				 }else if( !MYAPP.isNumericOrEmtpy(height) ){
					 me.alertbox("Height must be a number!" );
					 height_txt.requestFocus();					 
				 }else if( !MYAPP.isNumericOrEmtpy(weight) ){
					 me.alertbox("Weight must be a number!" );
					 weight_txt.requestFocus(); 
				 }else if( !MYAPP.isNumericOrEmtpy(arms) ){
					 me.alertbox("Arms must be a number!" );
					 arms_txt.requestFocus(); 
				 }else if( !MYAPP.isNumericOrEmtpy(chest) ){
					 me.alertbox("Chest must be a number!" );
					 chest_txt.requestFocus();					
				 }else if( !MYAPP.isNumericOrEmtpy(waist) ){
					 me.alertbox("Waist must be a number!" );
					 waist_txt.requestFocus();					
				 }else if( !MYAPP.isNumericOrEmtpy(hips) ){
					 me.alertbox("Hips must be a number!" );
					 hips_txt.requestFocus();					
				 }else{
					Log.d("Starting to insert journal","Log.........................1");
					
				    journal.height = MYAPP.parseDoubleOrNull(height);   
				    journal.weight = MYAPP.parseDoubleOrNull(weight);
				    journal.arms   = MYAPP.parseDoubleOrNull(arms);
				    journal.chest  = MYAPP.parseDoubleOrNull(chest);
				    journal.waist  = MYAPP.parseDoubleOrNull(waist);
				    journal.hips   = MYAPP.parseDoubleOrNull(hips);
				 
				    if( !MYAPP.isEmpty(me._current_journal_id) ){ //update 					 
				   	  journal.update();
				   	  me.flash("Body saved");
				    }else{//insert
				      journal.userID = me.userID;
				      journal.created = me.dateString;
					  journal.insert();
					  me.flash("Body added");
				    }
				 }
			}
	    }); 
	}
	
	private void setMindDashboard(){   		
		Cursor c = this.getJournalCursor();
		if( c.getCount() > 0 ){
			c.moveToFirst();
			Log.d("setMindDashboard", "------ " + c.getCount() ); 
			journal.setInfo(c);
			me._current_journal_id  = c.getString(c.getColumnIndex( UserJournals.C_id ) );   
			mind_title_txt.setText( c.getString(c.getColumnIndex( UserJournals.C_title )) );
			mind_message_txt.setText(  c.getString(c.getColumnIndex( UserJournals.C_message )) );
		}else{
			me._current_journal_id = "";
			mind_title_txt.setText("");
			mind_message_txt.setText("");
		}
		
		mind_title_txt.requestFocus();			
		
	   ((Button) findViewById(R.id.save_mind_btn)).setOnClickListener(new OnClickListener() {
			// @Override
			@Override
			public void onClick(View view) {
				 String title = String.valueOf( mind_title_txt.getText() );
				 String message =  String.valueOf( mind_message_txt.getText() );
				 
				 if( MYAPP.isEmpty(title) || MYAPP.isEmpty(message) ){
					 me.alertbox("Please complete the fields!" );
				 }else{
				    journal.title =  String.valueOf( mind_title_txt.getText() );
				    journal.message =  String.valueOf( mind_message_txt.getText() );
				 
				    if( !MYAPP.isEmpty(me._current_journal_id) ){ //update 					 
				   	  journal.update();
				   	  me.flash("Mind saved");
				    }else{//insert
				      journal.userID = me.userID;
				      journal.created = me.dateString;
					  journal.insert();
					  me.flash("Mind added");
				    }
				 }
			}
	    });
		
	}
	
	
	private void setFoodDashboard(){		
		me.jumpActivityOnClick(R.id.add_food_btn,AddFoodTypeActivity.class);
		displayFoodList();
	}
	
	private void setExerciseDashboard(){
		me.jumpActivityOnClick(R.id.add_exercise_btn ,AddExerciseActivity.class); 
		displayExerciseList();		
	}

	
	public void displayFoodList(){
		Log.d("DisplayFoodList","Yeah display food list has been called!!!!");
		Cursor cursor = MYAPP.static_ds.rawQuery("SELECT * FROM " + UserFoods.TABLE
				+ " WHERE ( " + UserFoods.C_USERID + " = ? AND "
				+ UserFoods.C_CREATED + " = ?  )",  
                new String[] { Integer.toString(me.userID), me.dateString });
				
		String[] FROM2 = {  UserFoods.C_NAME, UserFoods.C_PROTEIN, UserFoods.C_CARB, UserFoods.C_FAT, UserFoods.C_CAL, UserFoods.C_FoodID, UserFoods.C_ID,UserFoods.C_oid  }; 		
		int[] TO2 = { R.id.col1 ,R.id.col2 ,R.id.col3,R.id.col4,R.id.col5,R.id.colFoodID,R.id.colID,R.id.colOID  };
		
		
		SimpleCursorAdapter adapter = new SimpleCursorAdapter(DashboardActivity.this, R.layout._custom_food_list1, cursor, FROM2, TO2);		
		ListView output_list = (ListView)findViewById(R.id.output_list_food);		 
		output_list.setAdapter(adapter);
		output_list.setDivider(null);	
		output_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {  
			@Override
			public void onItemClick(AdapterView<?> arg0, View view,
					int position, long arg3) {  
				    duplicateFood(view);
			}
      }); 
		
		registerForContextMenu(output_list);
	}
	
	public void duplicateExercise(View view){
		 TextView v  = (TextView) view.findViewById(R.id.colExerciseID); 							 
		 TextView v2 = (TextView) view.findViewById(R.id.col2);
		 TextView v3 = (TextView) view.findViewById(R.id.col3);
		 String id   = v.getText().toString();							 							
		 me._to_add_duration = v2.getText().toString();
		 me._to_add_burned = v3.getText().toString();	 
		 me._exercise_id = Integer.parseInt(id);  
	     me.openscreen( AddExerciseActivity.class); 
	}
	
	public void duplicateFood(View view){
		 TextView v  = (TextView) view.findViewById(R.id.colFoodID); 							 
		 TextView v1 = (TextView) view.findViewById(R.id.col1);
		 TextView v2 = (TextView) view.findViewById(R.id.col2);
		 TextView v3 = (TextView) view.findViewById(R.id.col3);
		 TextView v4 = (TextView) view.findViewById(R.id.col4);
		 TextView v5 = (TextView) view.findViewById(R.id.col5); 
		 				 
		 me._to_add_foodID  = v.getText().toString();		 
		 me._to_add_food    = v1.getText().toString();
		 me._to_add_foodP   = v2.getText().toString();
		 me._to_add_foodC   = v3.getText().toString();
		 me._to_add_foodF   = v4.getText().toString();
		 me._to_add_foodCAL = v5.getText().toString();									 						
	     me.openscreen(AddFoodTypeActivity.class); 
	}
	
	
	private void displayExerciseList() {		  
		Cursor cursor = MYAPP.static_ds.rawQuery("SELECT *FROM " + UserExercises.TABLE
				+ " WHERE ( " + UserExercises.C_USERID + " = ? AND "
				+ UserExercises.C_CREATED + " = ?  AND " + UserExercises.C_TYPE + " = ? )",
				new String[] { Integer.toString(me.userID), me.dateString, me.exercise_type });

		 

			String[] FROM = { UserExercises.C_EXERCISE, UserExercises.C_DURATION, UserExercises.C_BURNED, 
					UserExercises.C_ID,UserExercises.C_oid, UserExercises.C_EXERCISEID,  }; 
			int[] TO = { R.id.col1, R.id.col2, R.id.col3 , R.id.colID, R.id.colOID, R.id.colExerciseID };
			SimpleCursorAdapter adapter = new SimpleCursorAdapter(DashboardActivity.this,
					R.layout._custom_exercise_list1, cursor, FROM, TO) {
				@Override
				public View getView(int position, View convertView,
						ViewGroup parent) {
					final View row = super.getView(position, convertView,
							parent);
					if (position % 2 != 0)
						row.setBackgroundResource(R.color.lightgray1);
					else
						row.setBackgroundResource(R.color.white);
					return row;
				}
			}; 
			
			ListView output_list = (ListView) findViewById(R.id.output_list_exercise);
			output_list.setAdapter(adapter);
			output_list.setDivider(null);
			output_list.setClickable(true);
			output_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {  
						@Override
						public void onItemClick(AdapterView<?> arg0, View view,
								int position, long arg3) {  
							duplicateExercise(view);
						}
			 }); 
			
			registerForContextMenu(output_list);		 
	}
	

	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) { 
    	getMenuInflater().inflate(R.menu.dashboard_menu, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {  
		switch (item.getItemId()) {
		case R.id.item_logout: 		 
			me.openscreen( LoginActivity.class );
			return true;
		case R.id.item_update:
			me.openscreen(ProfileUpdateActivity.class);
			return true;
		/*case R.id.item_settings:
			me.flash("Account settings clicked.... TODO????");
			return true;*/	 				
		default:
			return false;
		}     
	}
	          
	
	 
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,ContextMenuInfo menuInfo) {
	super.onCreateContextMenu(menu, v, menuInfo); 
	    me._to_add_foodID = "";
	    me._to_edit_food_ID = "";
	    me._to_edit_exercise_ID = "";
	    me._food_id = "";
	    AdapterView.AdapterContextMenuInfo info; 
	    info = (AdapterView.AdapterContextMenuInfo) menuInfo; 
	    
	    int id = MYAPP.toInt( ((TextView) info.targetView.findViewById(R.id.colID)).getText().toString() );	  	 	
		if( me.currentTab == 0 ){ //food
			    String title = ((TextView) info.targetView.findViewById(R.id.col1)).getText().toString(); 	   
			    menu.setHeaderTitle(title);
			    menu.add(id, DUPLICATE_ID, 0, "Add Food");			    
			    menu.add(id, DELETE_ID, 0, "Delete Food");
			    menu.add(id, EDIT_ID, 0, "Edit Food");
		}else if(me.currentTab == 1){ //exercise 
			    String title = ((TextView) info.targetView.findViewById(R.id.col1)).getText().toString(); 	   
			    menu.setHeaderTitle(title);			    
			    menu.add(id, DUPLICATE_ID, 0, "Add Exercise");
			    menu.add(id, DELETE_ID, 0, "Delete Exercise");
			    menu.add(id, EDIT_ID, 0, "Edit Exercise");
		} 
	} 
    
	
	@Override
	public boolean onContextItemSelected(MenuItem item) {
	  AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();	  
	  int id  =  MYAPP.toInt( ((TextView) info.targetView.findViewById(R.id.colID)).getText().toString() );
	  int oid =  MYAPP.toInt( ((TextView) info.targetView.findViewById(R.id.colOID)).getText().toString() );
	  
      switch (item.getItemId()) {
      case DUPLICATE_ID:  
    	  if( me.currentTab == 0 ){ //food    		      		    		 
    		  duplicateFood(info.targetView);
    	  }else{
    		  duplicateExercise(info.targetView);
    	  }          
          return (true);   
      case EDIT_ID:
    	  if( me.currentTab == 0 ){ //food    		      		      		  
    		  me._to_edit_food_ID = String.valueOf(id);
    		  me.openscreen(AddFoodActivity.class);
    	  }else{
    		  me._to_edit_exercise_ID =  String.valueOf(id);
    		  me.openscreen(AddExerciseActivity.class);
    	  }          
          return (true);          
      case DELETE_ID:
    	  if( me.currentTab == 0 ){ //food
    		  if(oid> 0){    			      						 
    					me.tid = oid;
    					List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(6);		
    					nameValuePairs.add(new BasicNameValuePair("oid",String.valueOf(oid)));
    					ApiCaller api = new ApiCaller(nameValuePairs, "deleteFood",2);	  		
    				    api.setReadyListener(new ApiCaller.OnReadyListener() {
    						@Override
    						public void onReady(String result){					
    							MYAPP me = (MYAPP) MYAPP.static_activity.getApplication();	 
    							MYAPP.static_ds.db.delete(UserFoods.TABLE ,  UserFoods.C_oid + "=" +  me.tid, null);
    							me.tid  = 0;
    							Log.d("calling async", "DeleteFood Callback Success");
    						    displayFoodList(); 
    						} 
    					});
    				    api.execute();    				
    		  }else{
      		        MYAPP.static_ds.db.delete(UserFoods.TABLE ,  UserFoods.C_ID + " = " +  id, null); 
    		        displayFoodList(); /*refesh*/
    		  }
    		  
    	  }else{
	    		if(oid> 0){    			      						 
						me.tid = oid;
						List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(6);		
						nameValuePairs.add(new BasicNameValuePair("oid",String.valueOf(oid)));
						ApiCaller api = new ApiCaller(nameValuePairs, "deleteExercise",2);	  		
					    api.setReadyListener(new ApiCaller.OnReadyListener() {
							@Override
							public void onReady(String result){					
								MYAPP me = (MYAPP) MYAPP.static_activity.getApplication();	 
								MYAPP.static_ds.db.delete(UserExercises.TABLE ,  UserExercises.C_oid + "=" +  me.tid, null);
								me.tid  = 0;
								Log.d("calling async", "DeleteExercise Callback Success");
								displayExerciseList(); 
							} 
						});
					    api.execute();    				
				  }else{
				        MYAPP.static_ds.db.delete(UserExercises.TABLE , UserExercises.C_ID + " = " +  id, null); 
				        displayExerciseList(); /*refesh*/
				  }
    	  }
    	  
          return (true);
      }      
      return true;
	}
	
	

}
