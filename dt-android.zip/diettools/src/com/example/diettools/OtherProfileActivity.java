package com.example.diettools;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TextView;

public class OtherProfileActivity extends Activity {
	MYAPP me; 
	TabHost mTabHost;
	TextView txtname;
	TextView txtstats;		       
	TextView txttotalgained; 
	TextView txttotalminutes;
	TextView txttotalcalburned;
	TextView txtbiotitle;
	TextView txtbio;
	File path; 
	private Menu menu = null;   
	ImageView imgavatar; 	
    UserGalleries ug;
    Users user; 
    
    
    Button btnSend;	
	EditText txtSubject;
	EditText txtMessage; 
   
	Messages msg;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.other_profile);		
		
		me = (MYAPP)getApplication(); 
		me.init(this);
		me.SetMainMenuListeners();
		  
		txtname            = (TextView) findViewById(R.id.txtname);
		txtstats           = (TextView) findViewById(R.id.txtstats);
		imgavatar          = (ImageView) findViewById(R.id.imgAvatar); 
		txttotalgained     = (TextView) findViewById(R.id.txttotalgained);
		txttotalminutes    = (TextView) findViewById(R.id.txttotalminutes);
		txttotalcalburned  = (TextView) findViewById(R.id.txttotalcalburned);
		txtbiotitle        = (TextView) findViewById(R.id.txtbiotitle);
		txtbio             = (TextView) findViewById(R.id.txtbio);
		
		
		btnSend = (Button) findViewById(R.id.btnSend);		
		txtSubject = (EditText) findViewById(R.id.txtSubject);
		txtMessage = (EditText) findViewById(R.id.txtMessage);  	
		
		
		if( MYAPP.isEmpty(me._otheruserid) ){
			me.alertbox("Invalid User!");
		    me.openscreen(ProfileActivity.class);		 
		}else{
			Cursor cursor = MYAPP.static_ds.rawQuery("SELECT *FROM " +
					  Users.TABLE + "  WHERE "+Users.C_userID+"  =   "  +  me._otheruserid + " "  , null);
			if(cursor.getCount() > 0){    
				cursor.moveToFirst();  
				user = new Users();
				user.setInfo(cursor);							    				    
			}else{
				me.alertbox("Invalid User!");
				me.openscreen(ProfileActivity.class);	
			}			
		}
		
						  
		if( !MYAPP.isEmpty(user.avatar) ){						
	       if(user.avatar.contains("http://")){ 
	    	   /*
        		LoadOnlineImages lb; 
				lb = new  LoadOnlineImages(user.avatar,imgavatar);
				lb.execute();
				*/
	    	   ImageLoader imgLoader = new ImageLoader();
               imgLoader.DisplayImage(user.avatar,imgavatar);
           }else{
	           File imgFile = new  File(user.avatar);
	           if(imgFile.exists()){
	              Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
	              imgavatar.setImageBitmap(myBitmap);
	           } 
          }
		}
	 
        
        
		String stats = "Age: "+user.age+", Sex: "+user.sex+", Weight:"+user.weight+
		"lbs, Height: "+user.height+"in ";
		
		txtname.setText(user.username);
		txtstats.setText(stats);			
		 
		mTabHost = (TabHost) findViewById(android.R.id.tabhost);
		mTabHost.setup();
		mTabHost.getTabWidget().setDividerDrawable(R.drawable.tab_divider); 
		 
		
        ////////////////////////TABS///////////////////////////////////////////
		TabHost.TabSpec spec1 = mTabHost.newTabSpec("About me");
		View tabview1 = createTabView(mTabHost.getContext(), "About");
		spec1.setIndicator(tabview1);
		spec1.setContent(R.id.profile_about_container); 
		mTabHost.addTab(spec1);
		
		 
		TabHost.TabSpec spec2 = mTabHost.newTabSpec("Send Message");
		View tabview2 = createTabView(mTabHost.getContext(), "Send Message");
		spec2.setIndicator(tabview2);
		spec2.setContent(R.id.other_profile_pm_container); 
		mTabHost.addTab(spec2);
		 
		
	    setAboutProfile();
	    
	    
		 
		mTabHost.setOnTabChangedListener(new OnTabChangeListener() {  
			@Override
			public void onTabChanged(String tab) { 	
				setMenuLayout();
				      
				switch(  mTabHost.getCurrentTab() ){		  		  		  
				  case  0:							  
					  setAboutProfile();					  
					  break;					
				  case  1:							  
					  setSendMessage();					  
					  break; 
				} 
			}
		});
	    ////////////////////////TABS///////////////////////////////////////////
		
		
		btnSend.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {
				String subject = txtSubject.getText().toString();
				String message = txtMessage.getText().toString();   
				if( MYAPP.isEmpty(message) || MYAPP.isEmpty(subject) ){
					 me.alertbox("Please complete the form.");					 
			   }else{
				     msg = new Messages();
					 msg.created    = me.dateString;
					 msg.sender     = me.userID;
				     msg.recipient  = user.userID; 
				     msg.subject    = subject;
				     msg.message    = message;	
				     msg.status     = MYAPP.UNREAD;
			         msg.insert();
			         new SynchMessageUploader(OtherProfileActivity.this  ).execute();			         			       
				 }				 				
			}
		});
		
		 
	}
	
	
	public void setSendMessage(){
		
	}

	
	
	
	public void setMenuLayout(){
		switch(  mTabHost.getCurrentTab() ){		  		  		  
		  case  0:					  
			  changeMenu(R.menu.profile_menu);
			  break;
		  case  1:
			  changeMenu(R.menu.profile_menu_gallery_tab);
		  break;
        case  2:
      	      changeMenu(0);
			  break;  
		  case  3: 	
			  changeMenu(0);
			  break;
		} 
	}
	
	public void changeMenu(int menuId){		
		if(this.menu != null){ 			
			this.menu.clear();
            if(menuId == 0)  menuId = R.menu.none;         	
		    getMenuInflater().inflate(menuId, this.menu);
		}
	}
	
	 
	
	 
	public void setAboutProfile(){
		    txttotalgained.setText("TOTAL POINTS GAINED: " + String.valueOf(user.points));		    		    		  
		    /*TODO: lets access online server for this additional info*/
			txttotalminutes.setText("TOTAL EXERCISE MINUTES: loading..." );
			txttotalcalburned.setText("TOTAL CALORIES BURNED: loading..." );
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(6);		
			nameValuePairs.add(new BasicNameValuePair("friendID",String.valueOf(user.userID)));
			
			ApiCaller api = new ApiCaller(nameValuePairs, "getFriendInfo",2);	  		
		    api.setReadyListener(new ApiCaller.OnReadyListener() {
				@Override
				public void onReady(String result){										
				    try {
						JSONObject jsonarray = new JSONObject(result);
						String burned = jsonarray.get("burned").toString();
						String cal    = jsonarray.get("cal").toString();
						txttotalminutes.setText("TOTAL EXERCISE MINUTES: " + burned );
						txttotalcalburned.setText("TOTAL CALORIES BURNED: " + cal );					
						Log.d("calling async", "GetFriendInfo in profile Callback Success");
					} catch (JSONException e) {
						e.printStackTrace();
					}					    									
				} 
			});
		    api.execute();  
		    
						
			txtbiotitle.setText( MYAPP.isEmpty(user.bio_title) ? "Biography" : String.valueOf(user.bio_title) );
			txtbio.setText(user.bio); 		
	}
	
	
	 
	 
	
	 

	private static View createTabView(final Context context, final String text) {
		View view = LayoutInflater.from(context)
				.inflate(R.layout.tabs_bg, null);
		TextView tv = (TextView) view.findViewById(R.id.tabsText);
		tv.setText(text);
		return view;			
	}
		
 

	class SynchMessageUploader extends AsyncTask<String, Void, String> {		
		Context context;  
		ProgressDialog progress; 
		String TAG = "AddMessage Synch Uploader"; 
		String method = "addjournal";
			
		public SynchMessageUploader(Context c  ) { 
			this.context    = c;  
			this.method     =  "newmessage";
		}	
		@Override
	    protected void onPreExecute() {
		        progress = ProgressDialog.show(this.context, "", "Please wait..."); 
		        super.onPreExecute();
		 }		
		@Override
		protected String doInBackground(String... params) { 
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(9);						         
			nameValuePairs.add(new BasicNameValuePair("subject",   msg.subject));						
			nameValuePairs.add(new BasicNameValuePair("message",   msg.message));			
			nameValuePairs.add(new BasicNameValuePair("recipient", String.valueOf(msg.recipient)));			
			nameValuePairs.add(new BasicNameValuePair("sender",    String.valueOf(me.userID)));
			nameValuePairs.add(new BasicNameValuePair("oid",       String.valueOf(msg.oid)));
			nameValuePairs.add(new BasicNameValuePair("created",   msg.created));			
			nameValuePairs.add(new BasicNameValuePair("method",    method));
			nameValuePairs.add(new BasicNameValuePair("email",     me.user.email));
			nameValuePairs.add(new BasicNameValuePair("password",  me.user.password));
						
			Log.d(TAG,"*************Debugging.... subject:" + msg.subject +
					", msg: " + msg.message + ",recipient: "+
					msg.recipient+", method: " + method + " email: " + me.user.email + ", p: " + me.user.password);
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(MYAPP.API_BASE);

			try {
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = httpclient.execute(httppost);
				String output = MYAPP.getWebString(response.getEntity().getContent());
				Log.d(TAG, "API Connection Result for "+method+": " + output); 
				return output;
			} catch (ClientProtocolException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} catch (IOException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} 
			return "";   
		}  
		
		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);	 
			if(result.length() == 0){			
				//flash("Invalid Username/Password!");
			}else{
				if( !MYAPP.isNumeric(result) ){					 
					 me.flash("Error for some reason"); 
				}else{ //user found here      					    
 			         msg.oid = Integer.parseInt(result);
			         msg.update(); 	
			         me.flash("Message has been sent!");
			     	 txtSubject.setText("");
					 txtMessage.setText("");
				}				
			}
			
			progress.dismiss();
			
       }
	
  }
	
 
}
