package com.example.diettools;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ProfileUpdateBioActivity extends Activity {
	MYAPP me;      
	EditText txtbiotitle;
	EditText txtbio; 
	Button btnsave;
	 
	
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.profile_bio_update);		
		
		me = (MYAPP)getApplication(); 
		me.init(this);
		me.SetMainMenuListeners();
		 
		txtbiotitle = (EditText) findViewById(R.id.txtbiotitle);
		txtbio      = (EditText) findViewById(R.id.txtbio);
		btnsave     = (Button) findViewById(R.id.btnsave);
				
		txtbiotitle.setText(String.valueOf(me.user.bio_title));
		txtbio.setText(String.valueOf(me.user.bio));	
		
		btnsave.setOnClickListener(new View.OnClickListener() { 
            @Override
            public void onClick(View v) {
            	String title  = txtbiotitle.getText().toString();
            	String bio    = txtbio.getText().toString();
                 if( MYAPP.isEmpty(title) || MYAPP.isEmpty(bio) ){
                	 me.alertbox("Please complete all fields to continue.");
                 }else{
                	 me.user.bio_title = title;
                	 me.user.bio       = bio; 
                	 new SynchUploader("updatebio").execute();		                	                 	
                 }
            }
        });
	} 
	
	
	
	class SynchUploader extends AsyncTask<String, Void, String> {		
		String method = "";  
		Context context; 
		ProgressDialog progress;
		String TAG = "CheckInputSave"; 

		public SynchUploader( String m) { 
			method = m; 
			this.context =  ProfileUpdateBioActivity.this;
			Log.d(TAG, "debugging................ 0");
		}

		@Override
		protected void onPreExecute() {
			progress = ProgressDialog.show(context, "", "Please wait...");
			super.onPreExecute();
		}

		@Override
		protected String doInBackground(String... params) {    
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(12); 
				nameValuePairs.add(new BasicNameValuePair("bio", me.user.bio));			
				nameValuePairs.add(new BasicNameValuePair("bio_title", me.user.bio_title));         									
				nameValuePairs.add(new BasicNameValuePair("method",    method));				
				nameValuePairs.add(new BasicNameValuePair("email",     me.user.email));
				nameValuePairs.add(new BasicNameValuePair("password",  me.user.password));
				  
				HttpClient httpclient = new DefaultHttpClient();
				HttpPost httppost = new HttpPost(MYAPP.API_BASE);

				try {
					httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
					HttpResponse response = httpclient.execute(httppost);
					String output = MYAPP.getWebString(response.getEntity().getContent());
					Log.d("Login Activity", "API Connection Result: \n" + output);
					return output;
				} catch (ClientProtocolException e) {
					Log.e(TAG, "::ERROR::", e);
					e.printStackTrace();
				} catch (IOException e) {
					Log.e(TAG, "::ERROR::", e);
					e.printStackTrace();
				}  
				
				return ""; 
		}

		@Override
		protected void onPostExecute(String result) { 
			super.onPostExecute(result);
			if (result.length() == 0 || result.equals("error")) {
				    progress.dismiss();
			    	me.flash("Error connection");
			} else {
			   	    progress.dismiss();	 
					me.user.update();
               	    me.flash("Bio has been updated!");
               	    me.openscreen(  ProfileActivity.class);  

										
			}
		}
	}
 
} 