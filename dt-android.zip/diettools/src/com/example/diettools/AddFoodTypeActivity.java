package com.example.diettools;


import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class AddFoodTypeActivity extends Activity {
	MYAPP me; 
   
	public void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_food_type);
		me = (MYAPP) getApplication(); 
		me.init(this);
		me.SetMainMenuListeners();
		me.setDateButtonListeners(); 
		
		if( !MYAPP.isEmpty(me._to_add_foodID) ){
		   me.changeMainHeader("Add Food To: ");
		}else{
		   me.changeMainHeader("Select Meal Time");	
		}
		
		
	}

	
	public void fireButton(View v) {
		 switch(v.getId()) {
         case R.id.Button1:
      	   me._food_type = "Breakfast";	        	   
         break;	           
         case R.id.Button2:
      	   me._food_type = "Morning Snack";
         break;
         case R.id.Button3:
      	   me._food_type = "Lunch";
         break;
         case R.id.Button4:
      	   me._food_type = "Midday Snack";
         break;
         case R.id.Button5:
      	   me._food_type = "Dinner";
         break;   	           	          
     }
     
      
     
     if( !MYAPP.isEmpty(me._to_add_foodID) ){   
		    UserFoods myfood   =  new UserFoods();
		    myfood.type        =  me._food_type;
            myfood.created     =  me.dateString;
            myfood.userID      =  me.userID;	           
			myfood.foodID      =  Integer.parseInt(me._to_add_foodID); 
			myfood.name        =  me._to_add_food; 
			myfood.protein     =  Double.parseDouble(me._to_add_foodP); 
			myfood.carb        =  Double.parseDouble(me._to_add_foodC); 
			myfood.fat         =  Double.parseDouble(me._to_add_foodF); 
			myfood.cal         =  Double.parseDouble(me._to_add_foodCAL); 
			myfood.size        =  me._to_add_foodS;
			myfood.qty         =  1;	
			myfood.insert();	
			
			me._food_type      = "";
			me._to_add_food    = "";
		    me._to_add_foodP   = "";
		    me._to_add_foodC   = "";
			me._to_add_foodF   = "";
			me._to_add_foodCAL = "";
			me._to_add_foodS   = "";
			me.flash("Food has been added!");
	       	me.openscreen( DashboardActivity.class);
			
     }else{			 	      
         me.openscreen( AddFoodSearchActivity.class);
     }  
   }
	
	 


}
