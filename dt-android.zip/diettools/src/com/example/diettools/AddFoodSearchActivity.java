package com.example.diettools;


import android.app.Activity;


import android.database.Cursor;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

public class AddFoodSearchActivity extends Activity {
	MYAPP me; 
	EditText search_txt;
	Button search_btn; 

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_food_search);
		me = (MYAPP) getApplication();		 
		me.init(this);	
		me.changeMainHeader("Search Food/" +me._food_type);
		me.SetMainMenuListeners();
		me.setDateButtonListeners();	

		search_txt = (EditText) findViewById(R.id.editText1);
		search_btn = (Button) findViewById(R.id.btnregsubmit);

		search_btn.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {
				String str = search_txt.getText().toString().trim();
				displayFood(str);
			}
		});
		
		
		search_txt.addTextChangedListener(new TextWatcher(){
	        public void afterTextChanged(Editable s) {
	        	String str = search_txt.getText().toString().trim();
				displayFood(str);
	        }
	        public void beforeTextChanged(CharSequence s, int start, int count, int after){}
	        public void onTextChanged(CharSequence s, int start, int before, int count){}
	    });  
		
		
	}

	
     
	
	/*
	 * Edit name by textview
	 * This will be called via SimpleCursorAdapter.setViewText 
	 */
	private String convText(TextView v, String text)
	{
		 switch (v.getId())
		 {
		      case R.id.col1:
		       String name = MYAPP.urldecode(text); 
		      return name;
		 }
		 return text;
	}

	
	
	private void displayFood(String keyword) {			
		String[] separated = keyword.split(" ");
		String word, relevance = "", tags = "",   query;
		for (int i = 0; i < separated.length; i++) {
			word = MYAPP.urlencode(separated[i]);
			relevance = relevance + "(CASE WHEN search_keywords = '["+word+"]'   THEN 9999999 - (search_order * 100)  ELSE 0 END)  + (100 - LENGTH(name) * 0.002 ) + ";
			tags = tags + " +" + word + "*";
		}
		
		relevance = relevance + "(CASE WHEN search_keywords = '["+keyword+"]'   THEN  9999999 - (search_order * 100)  ELSE 0 END) + ";
		
												
		query = "SELECT *, "+relevance+" 0 AS relevance FROM " + Foods.TABLE  
		+ " WHERE " + Foods.C_name + " MATCH '"+tags+"'   ";	
		
		/* 
		 * 
		 * NOTE: 
		 * 1. Sqlite does not support combining OR queries with MATCH condition so we
		 * will be using union here to get our stuff working
		 * 
		 * 2. Android uses an older version of SQLITE ver 3.3.12 which doesnt
		 * support the core functions like INSTR, POSITION ,etc and for this reason
		 * we can't replicate the search result to be 100% the same as the site because we rely on those
		 * functions to give us an a more relevant result.
		 * 
		 * 
		 * There is another way to update the builtin copy of sqlite from the
		 * android but this will require few configurations and alot of adjustments on our working 
		 * source codes which i haven't successfully implemented yet due to my limited time 
		 * 
		 * SQLite Android Bindings
		 * http://www.sqlite.org/android/doc/trunk/www/index.wiki
		 * 
		 * ORDER CODE THAT IS MISSING
		 * + (200 - instr(name,'"+word+"') )
		 * 		 
		 */	
		query = query + " UNION " +
		"SELECT *, "+relevance+" 0 AS relevance FROM  " + Foods.TABLE  
		+ " WHERE (CASE WHEN search_keywords = '["+keyword+"]'   THEN 1 ELSE 0 END) OR name = '"+keyword+"'   ORDER BY relevance DESC LIMIT 5 "; 
			
			
		
		Log.d("SQL FOOD SEARCH", query);
		
		Cursor cursor = MYAPP.static_ds.rawQuery(query,null); 
		
		
		
		
       /*
		if (cursor.getCount() == 0) {
			me.flash("No food match");
		}
		*/

		String[] FROM = { Foods.C_foodID,Foods.C_name, Foods.C_protein,
				Foods.C_carbs, Foods.C_fats, Foods.C_cal };
		int[] TO = { R.id.colID, R.id.col1, R.id.col2, R.id.col3, R.id.col4,
				R.id.col5 };

		SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, R.layout._custom_food_list1, cursor, FROM, TO) {
			
			@Override
			public View getView(int position, View convertView, ViewGroup parent) {								 				 		
				 final View row = super.getView(position, convertView, parent);				 
				 if (position % 2 == 0) row.setBackgroundResource(R.color.lightgray1);
				 else row.setBackgroundResource(R.color.white);	 
				 return row;
			}  
			
			
			@Override
			 public void setViewText(TextView v, String text) {
			  super.setViewText(v, convText(v, text));
			} 
			 
			
		};
 

		 
		ListView output_list = (ListView) findViewById(R.id.output_list);
		output_list.setAdapter(adapter);
		//output_list.setDivider(null); 
	  
		output_list.setClickable(true);
		output_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {  
					@Override
					public void onItemClick(AdapterView<?> arg0, View view,
							int position, long arg3) { 
						 TextView v = (TextView) view.findViewById(R.id.colID);
						 TextView v2 = (TextView) view.findViewById(R.id.col1);
						 
						 String id = v.getText().toString();
						 String name = v2.getText().toString();
						 						
						 me._food_id = id;
						 me._food_name = name; 	
						 
						 
						 
					     me.openscreen(AddFoodActivity.class); 
					}
		 }); 

	}


}
