package com.example.diettools;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;


public class MessagesReadSentActivity extends Activity {
	MYAPP me; 
	TextView txtMessage;
	TextView txtTitle;
	TextView txtTime;
	TextView txtUser;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.messages_read_sent);			
		me = (MYAPP)getApplication(); 
		me.init(this);	
		me.SetMainMenuListeners(); 	 
		me.jumpActivityOnClick(R.id.btnBack, MessagesSentActivity.class);
		
		txtMessage = (TextView) findViewById(R.id.txtMessage);
		txtTitle   = (TextView) findViewById(R.id.txtTitle);
		txtTime    = (TextView) findViewById(R.id.txtTime);
		txtUser    = (TextView) findViewById(R.id.txtUser);
		 
		 
		String query = "SELECT  m.*, u." + Users.C_username + ",u."+Users.C_avatar +  
		" FROM  "+Messages.TABLE+" m " +
		" LEFT JOIN "+Users.TABLE+" u  ON (u."+Users.C_oid+"=m."+Messages.C_recipient+") " +
		" WHERE  m."+Messages.C_id + " = " + me._message_id + " " +     
		" ORDER BY m.created DESC LIMIT 50";
		
		Cursor c = MYAPP.static_ds.rawQuery(query  , null); 
		 
		if( c.getCount() > 0 ){
			c.moveToFirst();
			String created   = c.getString(  c.getColumnIndex( Messages.C_created ) ); 
	        String subject   = c.getString(  c.getColumnIndex( Messages.C_subject ) );
	        String message   = c.getString(  c.getColumnIndex( Messages.C_message ) );
	        String from      = c.getString(  c.getColumnIndex( Users.C_username ) );
	        
	        SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            SimpleDateFormat newFormater = new SimpleDateFormat("MM/dd/yyyy");
            SimpleDateFormat timeFormater = new SimpleDateFormat("hh:mm aa");
            
            Date dateObj;
            String date = "";
            String time      = "";
            
			try {
				dateObj = dateFormater.parse(created);
			    date = newFormater.format(dateObj);
			    time = timeFormater.format(dateObj);			    
			} catch (ParseException e) {	
				Log.d("PROFILE ACTIVITY","ERROR profile date convertion..............",e);
				e.printStackTrace();
			}  
			
			
			txtMessage.setText(message);
			txtTitle.setText(subject);
			txtTime.setText(time + " " + date);
			txtUser.setText("Sent To: "+from);	        
	        
		}
		
	}
 
}
