 package com.example.diettools;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class SignupActivity extends Activity {
	public static String TAG = "::SIGNUP ACTIVY::";	
	MYAPP me; 
	Datasource2 ds; 
	DialogFragment newFragment = null; 
	static EditText currentDate;
	
	EditText txtemail;
	EditText txtusername;
	EditText txtpassword;
	EditText txtpassword2;
	
	RadioGroup radioSex;
	RadioButton radioFemale;
	RadioButton radioMale;
	
	EditText txtbirth;
	EditText txtheight;
	EditText txtweight; 
	
	RadioGroup radioGoal;
	RadioButton radioloseweight;
	RadioButton radionogoal;
	RadioButton radiogainweight;
	
	EditText txtgoalweight;
	EditText txtgoaldate;
	
	Users user;
 
	Button btnsave;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		me = (MYAPP) getApplication();  
		ds = new Datasource2(this);
		me.initDs(ds);      
		me.init(this);		 
		setContentView(R.layout.signup);  		
		
	    txtgoaldate     = (EditText) findViewById(R.id.txtgoaldate);
		txtbirth        = (EditText) findViewById(R.id.txtbirth);			
		txtemail        = (EditText) findViewById(R.id.txtregemail);
		txtusername     = (EditText) findViewById(R.id.txtregusername);
		txtpassword     = (EditText) findViewById(R.id.txtpassword);
		txtpassword2    = (EditText) findViewById(R.id.txtpassword2);
		txtheight       = (EditText) findViewById(R.id.txtheight);
		txtweight       = (EditText) findViewById(R.id.txtweight);
		txtgoalweight   = (EditText) findViewById(R.id.txtgoalweight);			
		radioSex        = (RadioGroup) findViewById(R.id.radioSex);
		radioFemale     = (RadioButton) findViewById(R.id.radioFemale);
		radioMale       = (RadioButton) findViewById(R.id.radioMale);                				
		radioGoal       = (RadioGroup) findViewById(R.id.radioGoal);
		radioloseweight = (RadioButton) findViewById(R.id.radioloseweight);
		radionogoal     = (RadioButton) findViewById(R.id.radionogoal);
		radiogainweight = (RadioButton) findViewById(R.id.radiogainweight);  
		btnsave         = (Button) findViewById(R.id.btnsave);
		
		
		user = new Users();
		radioFemale.setChecked(true);
		radioloseweight.setChecked(true);
		
		
		btnsave.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {					 
				validate_and_submit();
			}
		});		
		
		txtgoaldate.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {						
				currentDate = txtgoaldate; 
				if( newFragment != null ) newFragment.dismiss(); 
				newFragment = new DatePickerFragment();
				newFragment.show(getFragmentManager(), "datePicker");						
			}
		});		
		
		txtbirth.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {
				currentDate = txtbirth;
				if( newFragment != null ) newFragment.dismiss(); 
				newFragment = new DatePickerFragment();
				newFragment.show(getFragmentManager(), "datePicker");						
			}
		});		 
		
	}    
	
	
	public void validate_and_submit(){
		
		    user.birth_date   = txtbirth.getText().toString();			
		    user.email        = txtemail.getText().toString();
		    user.username     = txtusername.getText().toString();
		    user.password     = txtpassword.getText().toString();
			String password2  = txtpassword2.getText().toString();
			user.height       = MYAPP.parseDoubleOrNull(txtheight.getText().toString());
			user.weight       = MYAPP.parseDoubleOrNull(txtweight.getText().toString());
			user.goal_weight  = txtgoalweight.getText().toString();
			user.goal_date    = txtgoaldate.getText().toString();		
			
			int selectedId    = radioSex.getCheckedRadioButtonId();
			RadioButton radioSexButton = (RadioButton) findViewById(selectedId);
			
			user.sex         = radioSexButton.getText().toString();
			int selectedId2    = radioGoal.getCheckedRadioButtonId();
			RadioButton radioGoalButton = (RadioButton) findViewById(selectedId2);
			user.goal        = radioGoalButton.getText().toString();
			  
			
			if( MYAPP.isEmpty(user.birth_date) ||  MYAPP.isEmpty(user.email) || 
		        MYAPP.isEmpty(user.username)  ||  MYAPP.isEmpty(user.password) ||
		        MYAPP.isEmpty(password2) ||  
			    user.height < 1 ||  
			    user.weight < 1 ||  
			    MYAPP.isEmpty(user.goal_weight) || 
			    MYAPP.isEmpty(user.goal_date) ){
				me.alertbox("Please all the fields required!");				
			}else{
				  if( !user.password.equals(password2) ){
					  me.alertbox("Confirm password didn't match");		
				  }else{
					  new RegisterToSite().execute();	
				  }				  						
			}	 
	}
	
	
	
	
	
	class RegisterToSite extends AsyncTask<String, Void, String> { 
		ProgressDialog progress;  
		
		@Override
	    protected void onPreExecute() {
		        progress = ProgressDialog.show(SignupActivity.this , "", "Please wait..."); 
		        super.onPreExecute();
		 }

		
		@Override
		protected String doInBackground(String... params) { 
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(10);		
			nameValuePairs.add(new BasicNameValuePair("method", "signup"));
			nameValuePairs.add(new BasicNameValuePair("birth_date", user.birth_date));
			nameValuePairs.add(new BasicNameValuePair("email", user.email));
			nameValuePairs.add(new BasicNameValuePair("username", user.username));
			nameValuePairs.add(new BasicNameValuePair("password", user.password));
			nameValuePairs.add(new BasicNameValuePair("height", String.valueOf(user.height) ));
			nameValuePairs.add(new BasicNameValuePair("weight", String.valueOf(user.weight) ));
			nameValuePairs.add(new BasicNameValuePair("goal_weight", user.goal_weight));
			nameValuePairs.add(new BasicNameValuePair("goal_date", user.goal_date));
			nameValuePairs.add(new BasicNameValuePair("goal_sex", user.sex));
			nameValuePairs.add(new BasicNameValuePair("goal", user.goal));			
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(MYAPP.API_BASE);

			try {
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = httpclient.execute(httppost);
				String output = MYAPP.getWebString(response.getEntity().getContent());
				Log.d(TAG, "API Connection Result: \n" + output); 
				return output;
			} catch (ClientProtocolException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} catch (IOException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} 
			return "";
		}

		
		@Override  
		protected void onPostExecute(String result) {
			super.onPostExecute(result);	 
			if(result.length() == 0){     
				progress.dismiss();  
				me.flash("Error occured, Please try again!");
			}else{			 
					Log.d(TAG, "JSON EXECUTED!!!!");
					try{																	
			            JSONObject json = new JSONObject(result);
			            if( MYAPP.isEmpty(json.get("error").toString()) ) {				            
			            	//JSONObject jsonarray = new JSONObject(json.get("data").toString());				            
				            user.oid    = Integer.parseInt(json.get("oid").toString());
				            user.userID = Integer.parseInt(json.get("oid").toString());
				            user.insert();				            
				            me.user = user;
				            me.userID = user.userID;				          
				            me.flash("Account has been created successfully!");
				            me.goToDashboard();
			            }else{
			               me.alertbox(json.get("error").toString());  	 
			            }
				    } catch (Exception e) {
				    	Log.e(TAG, "User Json parser error..", e); 
				    } 
				    
				    progress.dismiss();							
			}  
		}
} 
		
	
	
	
	public static class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {   
	    Calendar cal;  
		Date date2 = null;
		  

		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {			
         String date = currentDate.getText().toString(); 
			SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy"); 
			
			try {
				date2 = formatter.parse( date );
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
		    cal = Calendar.getInstance();	
		    if(date2 != null) cal.setTime(date2);
		    
			
			int year  = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH);
			int day   = cal.get(Calendar.DAY_OF_MONTH); 
			return new DatePickerDialog(getActivity(), this, year, month, day);
		}

		public void onDateSet(DatePicker view, int year, int month, int day) {
			currentDate.setText( MYAPP.add0( month + 1 ) + "/" + MYAPP.add0(day) + "/" + year);
		}
	}
	
	
	
	
	

}
