package com.example.diettools; 
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import android.app.Activity;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;

public class AddJournalVideoActivity extends Activity {
	MYAPP me; 
	ImageView image; 
	private static final int CAMERA_REQUEST = 1888;
	private static final int ACTION_TAKE_VIDEO = 100;
	private static final int CAPTURE_VIDEO_ACTIVITY_REQUEST_CODE = 200;
	File path;
	String base_path = "diettools";	 
	String video_path   = "";	
	UserJournals journal; 
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_journal_video);
		me = (MYAPP) getApplication(); 
		me.init(this);
		me.SetMainMenuListeners(); 
		journal = new UserJournals();
		
		if( !MYAPP.isEmpty(me._current_journal_id) ){
			Cursor cursor = MYAPP.static_ds.rawQuery("SELECT *FROM " +  UserJournals.TABLE + " WHERE  " +  
					UserJournals.C_id + " = " + me._current_journal_id + "  " , null);
			
			if(cursor.getCount() > 0){  
				cursor.moveToFirst(); 	 
				journal.setInfo(cursor); 
			}else{
				me.openscreen(JournalsActivity.class);
			}
		}else{
			 me.openscreen(JournalsActivity.class);  
		}
		
		
				
		image   = (ImageView) findViewById(R.id.journalImageVIew); 
		image.setOnClickListener(new View.OnClickListener() { 
            @Override
            public void onClick(View v) {  
                openCamera(); 
            }
        });
		
		
		me.jumpActivityOnClick(R.id.btn_goto_journals, JournalsActivity.class);
					
		boolean mExternalStorageAvailable = false;
    	boolean mExternalStorageWriteable = false;
    	String state = Environment.getExternalStorageState(); 

    	if (Environment.MEDIA_MOUNTED.equals(state)) {
    	    // We can read and write the media
    	    mExternalStorageAvailable = mExternalStorageWriteable = true;
    	} else if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
    	    // We can only read the media
    	    mExternalStorageAvailable = true;
    	    mExternalStorageWriteable = false;
    	} else {
    	    // Something else is wrong. It may be one of many other states, but all we need
    	    //  to know is we can neither read nor write
    	    mExternalStorageAvailable = mExternalStorageWriteable = false;
    	}    
    	
    	
        if(mExternalStorageAvailable)
          path = Environment.getExternalStorageDirectory();
        else
          path = Environment.getDataDirectory();
         
        
        base_path = path + "/" + base_path;     
        video_path = base_path + "/journal";
		
    }
		
	
	public void openCamera(){ 
		//Intent cameraIntent = new Intent("android.media.action.VIDEO_CAMERA");
		//android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
		Intent cameraIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);		
        startActivityForResult(cameraIntent, CAPTURE_VIDEO_ACTIVITY_REQUEST_CODE);
	}	
	 
	
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == RESULT_OK) {
		    if (requestCode == CAPTURE_VIDEO_ACTIVITY_REQUEST_CODE) {

		    	 try
		         {
				    	AssetFileDescriptor videoAsset = getContentResolver().openAssetFileDescriptor(data.getData(), "r");
				        FileInputStream fis = videoAsset.createInputStream();
				        Uri videoUri = data.getData();		        
				        String fn = MYAPP.md5(String.valueOf(journal.id));		        		       
				        String destination = video_path + "/"+ fn +".mp4" ;
				        File file = new File(destination);
				        FileOutputStream fos = new FileOutputStream(file);
				        byte[] buf = new byte[1024];
			            int len;
			            while ((len = fis.read(buf)) > 0) {
			                fos.write(buf, 0, len);
			            }       
			            fis.close();
			            fos.close();			            			            			      			            
		                   
			            //ContentResolver crThumb = getContentResolver();
			            BitmapFactory.Options options = new BitmapFactory.Options();
			            options.inSampleSize = 1;
			            //Bitmap curThumb = MediaStore.Video.Thumbnails.getThumbnail(crThumb, id, MediaStore.Video.Thumbnails.MICRO_KIND, options);
			            Bitmap curThumb = ThumbnailUtils.createVideoThumbnail(file.getAbsolutePath(), MediaStore.Video.Thumbnails.MICRO_KIND);			            
			            image.setImageBitmap(curThumb);
			            
			            journal.video = destination;
		                journal.update();
		                
		                me._current_journal_id = String.valueOf(journal.id); 
		                me.openscreen(JournalPageActivity.class); 
		                
		         } 
		         catch (Exception e) 
		         {
		                e.printStackTrace();
		         }		         
		    }
		}
		
		
        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {          	        
        	      File folder1 = new File(video_path);        
                  if (!folder1.exists()) {
                     folder1.mkdir();              
                 }
                  
                  
               
                  /*
                String fn = MYAPP.md5(String.valueOf(journal.id));                
                String destination = video_path + "/"+ fn +"." ;                                                                                
                File dest = new File(destination);                            
                Bitmap photo = (Bitmap) data.getExtras().get("data"); 
                image.setImageBitmap(photo);            
            
                try {
                   FileOutputStream out = new FileOutputStream(dest);
                   photo.compress(Bitmap.CompressFormat.PNG, 90, out);
                   out.flush();
                   out.close();                                     
                   journal.picture = destination;
                   journal.update();	  			              	  			  	  			  	  			
                } catch (Exception e) {
                   e.printStackTrace();
                }   
                */                     	                  
               
        }  
    } 
	
	  
	
	
	
	

}
