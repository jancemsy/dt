package com.example.diettools;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.AsyncTask;
import android.util.Log;
 

 
 class ApiCaller extends AsyncTask<String, Void, String> { 	     		
	    static String TAG = "APICALLER";
	    List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(20);
	    MYAPP me;
	    String method; 
	    OnReadyListener mListener;
	    OnReadyJsonListener mListenerJson;
	    static int RETURN_IN_BG   = 1;
	    static int RETURN_IN_POST = 2;
	    int return_type = 0;
	    Boolean isStringResult = false;
	    
	    public ApiCaller(List<NameValuePair> nameValuePairs2,String method ) {
	    	return_type = RETURN_IN_BG;
			init(nameValuePairs2,method );
		}
	    	    	   
	    public ApiCaller(List<NameValuePair> nameValuePairs2,String method,  int ReturnType) {
	    	return_type  = ReturnType;
	    	isStringResult = true;
	    	init(nameValuePairs2,method ); 
		}
	    
	    private void init(List<NameValuePair> nameValuePairs2,String method){
	    	nameValuePairs = nameValuePairs2;
	    	me = (MYAPP) MYAPP.static_activity.getApplication();	    	
	    	nameValuePairs.add(new BasicNameValuePair("email", me.user.email)); 
			nameValuePairs.add(new BasicNameValuePair("password", me.user.password));
			nameValuePairs.add(new BasicNameValuePair("method", method));
			this.method = method;
	    }
       
       
	    
	     public interface OnReadyListener{  		        
	    		public void onReady(String result);  
		 }
	     
	     public interface OnReadyJsonListener{  
		        public void onReadyJson(JSONArray jarray) throws JSONException; 
	    		 
		 }

	 	public void onReadyJson(JSONArray jarray) {				
			Log.d("xxxx","Executed inside APICALLER YYYYYYYYYYYYYYYYYYYYYYYYYY");				   
		} 
		
	 	public void onReady(String result) {				
			Log.d("xxxx","Executed "+result+" inside APICALLER YYYYYYYYYYYYYYYYYYYYYYYYYY");				   
		}
	 	
		 public void setReadyListener(OnReadyListener eventListener) {
		     mListener = eventListener;
		 }
		 public void setReadyJsonListener(OnReadyJsonListener eventListener) {
			 mListenerJson = eventListener;
		 }
		  
	   
		@Override
	    protected void onPreExecute(){		        
		        super.onPreExecute();
		} 
		
		@Override
		protected String doInBackground(String... params){  			 						
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(MYAPP.API_BASE);             
			try {
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = httpclient.execute(httppost);
				String output = MYAPP.getWebString(response.getEntity().getContent());
				Log.d(TAG, method + " API Connection Result: \n" + output);
				
				if(output.length() == 0){
					Log.d(TAG, method +" ERROR");					        
				}else if(output.equals("not found")){
				    Log.d(TAG, method +" NOT FOUND");
				}else{ 		 
					
					if(return_type == RETURN_IN_BG){
					    if(isStringResult){ mListener.onReady(output); }
					    else{ PrepareJson(output); }
					}
				}				
				return output;
			} catch (ClientProtocolException e) {
				Log.e(TAG, method + " ::ERROR::", e);
				e.printStackTrace();
			} catch (IOException e) {
				Log.e(TAG, method + " ::ERROR::", e);
				e.printStackTrace();
			} 
			return "";
		}
   
	 
		
		public interface CompleteListener {
	        void resultCallback(Long time);
	    }  
		 
			   
		public void PrepareJson(String result) {   
              try {
					   JSONObject json = new JSONObject(result);
					   String total_records = json.get("total").toString();
					   if(!total_records.equals("0")){		 						      
						   mListenerJson.onReadyJson(json.getJSONArray("data"));
					   }else{
						   Log.d(TAG, method + " has nothing to add");
					   }
				  } catch (Exception e) {
						Log.e(TAG, method +" Json parser error..", e);						 
				  } 			       
		}
		
		
		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);	
			
			if(return_type == RETURN_IN_POST){
			    if(isStringResult){ mListener.onReady(result); }
			    else{ PrepareJson(result); }
			}
					 
		}



   } 
