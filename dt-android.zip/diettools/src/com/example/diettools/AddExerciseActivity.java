package com.example.diettools;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
  
public class AddExerciseActivity extends Activity {
	MYAPP me;
	AutoCompleteTextView ExerciseTextBox;
	EditText DurationText;
	EditText BurnedText;   
	Button AddButton; 
	UserExercises Myexercise;  
	ListView output_list;  
	  

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_exercise);
		me = (MYAPP) getApplication();	  
		me.init(this);			 
		me.SetMainMenuListeners(); 
		me.setDateButtonListeners();		
		
		// lets create a db
		Myexercise = new UserExercises();
		output_list = (ListView) findViewById(R.id.output_list);
			
		
		displayMyExercises();		
					
		DurationText = (EditText) findViewById(R.id.txtregpassword);
		BurnedText = (EditText) findViewById(R.id.editText3);
		ExerciseTextBox = (AutoCompleteTextView) findViewById(R.id.editText1);
		AddButton = (Button) findViewById(R.id.btnregsubmit);
		
		ItemAutoTextAdapter adapter1 = this.new ItemAutoTextAdapter();			 
		
		ExerciseTextBox.setAdapter(adapter1);
		ExerciseTextBox.setOnItemClickListener(adapter1); 
		ExerciseTextBox.addTextChangedListener(new TextWatcher(){
	        public void afterTextChanged(Editable s) {   }
	        public void beforeTextChanged(CharSequence s, int start, int count, int after){}
	        public void onTextChanged(CharSequence s, int start, int before, int count){}
	    });  
		 
		
		if(MYAPP.isEmpty(me._to_edit_exercise_ID)){ 			 			
			prepareAddExercise(); 
		}else{ 
			prepareUpdateExercise();
		}
		
		 DurationText.addTextChangedListener(new TextWatcher(){
		        public void afterTextChanged(Editable s) {
		        	Double min = MYAPP.toDouble(DurationText.getText().toString());
		        	Log.d("addTextWatcher","checking. text watcher executed...  " + me._exercise_met + "... " + min + "..............");
					if( me._exercise_met > 0 && min > 0) computeCal();
		        }
		        public void beforeTextChanged(CharSequence s, int start, int count, int after){}
		        public void onTextChanged(CharSequence s, int start, int before, int count){}
		    });  
			
	   
	}
	
	private Exercises getExerciseById(String id){
		Exercises exercise = new Exercises(); 
		Cursor cursor = MYAPP.static_ds.rawQuery("SELECT *FROM " + Exercises.TABLE
				+ " WHERE (   " + Exercises.C_exerciseID + " LIKE ?  ) ",
				new String[] { id });
		
		if(cursor.getCount() > 0){  
			cursor.moveToFirst();
			exercise.setInfo(cursor);	   		            
		}
		
		return exercise;
	}
	
	
	public void prepareAddExercise(){ 	 
		    Exercises exercise = getExerciseById(String.valueOf(me._exercise_id));		    
		    if( exercise.id  > 0){		    
		    	     ExerciseTextBox.setText(exercise.exercise);			 	
					 me._exercise_met = exercise.met; 
				     DurationText.setText(me._to_add_duration);
				     BurnedText.setText(me._to_add_burned);
					 DurationText.requestFocus();	
		    }
			me.changeMainHeader("Add Exercise");
		   							
		    
			
			AddButton.setOnClickListener(new OnClickListener() {
				// @Override 
				public void onClick(View view) {
					String errors = null;
					Double duration = MYAPP.toDouble(DurationText.getText().toString());
					Double burned = MYAPP.toDouble(BurnedText.getText().toString());
					String exercise = ExerciseTextBox.getText().toString();					
					if(exercise.length() == 0){ errors = "Please enter an exercise"; }
					else if( duration < 1 ){ errors = "Please enter a duration in minutes"; }
					else if( burned < 1 ){ errors = "Please enter a calories burned"; }  
								
					Log.d("AddButtonOnclick","Checking exercise value ...." +  exercise );
					if( errors != null){
					    me.alertbox(errors);
					}else{
						Log.d("AddButtonOnclick","Save exercise here....");					
						Myexercise.created    = me.dateString;
						Myexercise.userID     = me.userID;
						Myexercise.met        = me._exercise_met; 
						Myexercise.burned     = burned;
						Myexercise.duration   = duration;
						Myexercise.exercise   = exercise;
						Myexercise.exerciseID = me._exercise_id;		
						Myexercise.type       = me.exercise_type;
						  
						int tid = Myexercise.insert();	 
						me.addPoints( MYAPP.INPUT_EXERCISE_PTS,  "user exercise" , tid ,   duration, burned);					
																	 
						/////reset//////////////
						me._exercise_id = 0;
						me._exercise_met = 0.0;
						me._to_add_duration = "";
						me._to_add_burned = "";
						me.currentTab = 1; 
						new SynchUploader(AddExerciseActivity.this, Myexercise, "addexercise" ).execute();
					}
				}
			});
	}
	
	public void prepareUpdateExercise(){		  		
		Cursor cursor = MYAPP.static_ds.rawQuery("SELECT *FROM " + UserExercises.TABLE
				+ " WHERE (   " + UserExercises.C_ID + " LIKE ? AND "+UserExercises.C_USERID+" LIKE ?  ) ",
				new String[] { me._to_edit_exercise_ID, String.valueOf(me.userID) });
		
		
		if(cursor.getCount() > 0){
			 me.changeMainHeader("Update Exercise");
			 AddButton.setText("Save Exercise");
			 cursor.moveToFirst();  			
			 Myexercise.setInfo(cursor);	
		    
		     ExerciseTextBox.setText(Myexercise.exercise);			 	
			 me._exercise_met = Myexercise.met;
			 me._exercise_id  = Myexercise.exerciseID;
			 double d = Myexercise.duration;
			 String s = (long) d == d ? "" + (long) d : "" + d; 			 
		     DurationText.setText(s);
		     BurnedText.setText(String.valueOf(Myexercise.burned));
			 DurationText.requestFocus();			 
			
			AddButton.setOnClickListener(new OnClickListener() {
				// @Override 
				public void onClick(View view) {
					String errors = null;
					Double duration = MYAPP.toDouble(DurationText.getText().toString());
					Double burned = MYAPP.toDouble(BurnedText.getText().toString());
					String exercise = ExerciseTextBox.getText().toString();					
					if(exercise.length() == 0){ errors = "Please enter an exercise"; }
					else if( duration < 1 ){ errors = "Please enter a duration in minutes"; }
					else if( burned < 1 ){ errors = "Please enter a calories burned"; }  
								 
					if( errors != null){
					    me.alertbox(errors);
					}else{  
						Myexercise.burned     = burned;
						Myexercise.duration   = duration;
						Myexercise.exercise   = exercise;   
						Myexercise.bmr        = me.user.bmr; 
					    Myexercise.update();	
					    
						/////reset//////////////
						me._exercise_id = 0;
						me._exercise_met = 0.0; 
						me.currentTab = 1;   
						new SynchUploader(AddExerciseActivity.this, Myexercise, "addexercise" ).execute();													  				
					}
				}
			});
	   }else{
		   me.openscreen(DashboardActivity.class);
	   }
	}  
	 
	   
	public void displayMyExercises(){		  
			Cursor cursor = MYAPP.static_ds.getCursor(UserExercises.TABLE,UserExercises.C_ID,UserExercises.C_ID + " DESC", "100"); 			 
			String[] FROM = { UserExercises.C_EXERCISE, UserExercises.C_DURATION, UserExercises.C_BURNED, UserExercises.C_EXERCISEID };
			int[] TO = { R.id.col1, R.id.col2, R.id.col3, R.id.colID };			
			SimpleCursorAdapter adapter = new SimpleCursorAdapter(AddExerciseActivity.this, R.layout._custom_exercise_list1, cursor, FROM, TO);			
			output_list.setAdapter(adapter);			
			output_list.setDivider(null);
			output_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {  
				@Override
				public void onItemClick(AdapterView<?> arg0, View view,
						int position, long arg3) {  					
					
					TextView v  = (TextView) view.findViewById(R.id.colID);
					 TextView v2  = (TextView) view.findViewById(R.id.col2);
					 TextView v3  = (TextView) view.findViewById(R.id.col3);					 
					 String id   = v.getText().toString();					 
					 me._to_add_duration = v2.getText().toString();
				     me._to_add_burned   = v3.getText().toString(); 												 						
					 me._exercise_id     = Integer.parseInt(id); 
				     me.openscreen( AddExerciseActivity.class); 
				}
	      }); 
	}
	 
	
	public void computeCal(){  
		Double Calories; 
		try {
			Double height = me.user.height;
			Double weight = me.user.weight;
			String sex = me.user.sex;
			int age = me.user.age;
			Double time = Double.parseDouble( DurationText.getText().toString() );
			Double RMR = 0.0;
			Double RMRCorrected = 0.0;
			Double METCorrected = 0.0;
			Calories = 0.0;

			weight = weight * 0.45359237; // convert to kg
			height = height * 2.54; // convert to cm
			time = time / 60; // convert to sec

			if (sex == "male") {
				RMR = 66.5 + 5.0 * height + 13.7 * weight - 6.8 * age;
			} else {
				RMR = 655.1 + 1.8 * height + 9.6 * weight - 4.7 * age;
			}

			RMRCorrected = (RMR * 0.138888889 / weight);
			METCorrected = (me._exercise_met * 3.5 / RMRCorrected);
			Calories = me.roundTwoDecimals( METCorrected * weight * time);
			BurnedText.setText(Calories.toString());
		} catch (NumberFormatException e) { 
			Log.e("Calories calc","Error computation......................",e);
			e.printStackTrace();
		}
	}
	
	

	class ItemAutoTextAdapter extends CursorAdapter implements android.widget.AdapterView.OnItemClickListener {		
		SQLiteDatabase db;
		Activity act;
		MYAPP me;

		public ItemAutoTextAdapter() {
			super(AddExerciseActivity.this, null); 
			db = MYAPP.static_ds.db; 
			me = (MYAPP) getApplication();
		}

		public Cursor getMatches(String constraint) throws SQLException {			
			Log.d("AutoCompleteDbAdapter", " STRING ====> " + constraint);

			String queryString = "SELECT *FROM "
					+ Exercises.TABLE;
			if (constraint != null) {
				constraint = "%" + constraint.trim() + "%";
				queryString += " WHERE " + Exercises.C_exercise + " LIKE ? ";
			}

			String params[] = { constraint };
			if (constraint == null) {
				params = null;
			}

			try {
				Cursor cursor = db.rawQuery(queryString, params);
				Log.d("AutoCompleteDbAdapter", " MATCH COUNT ====> "
						+ queryString + "=" + cursor.getCount()); 
				 
				if(cursor.getCount() == 0){
					me._exercise_met = 0.0;	
				} 
				
				if (cursor != null) {
					cursor.moveToFirst();

					Log.d("AutoCompleteDbAdapter",
							" Returned somthing not sure what...");
					return cursor;
				}
			} catch (SQLException e) {
				Log.e("AutoCompleteDbAdapter", e.toString());
				throw e;
			}
			return null;
		}

		@Override
		public Cursor runQueryOnBackgroundThread(CharSequence constraint) {
			if (getFilterQueryProvider() != null) {
				return getFilterQueryProvider().runQuery(constraint);
			}
			Cursor cursor = getMatches(constraint != null ? constraint.toString() : null);
			return cursor;
		}

		@Override
		public String convertToString(Cursor cursor) {
			final int columnIndex = cursor.getColumnIndexOrThrow(Exercises.C_exercise);
			final String str = cursor.getString(columnIndex);
			return str;
		}

		@Override
		public void bindView(View view, Context context, Cursor cursor) {
			final String text = convertToString(cursor);
			((TextView) view).setText(text);
		}

		@Override
		public View newView(Context context, Cursor cursor, ViewGroup parent) {			
			final LayoutInflater inflater = LayoutInflater.from(context);
			final View view = inflater.inflate(R.layout.add_exercise_custom_completer, parent, false);  
			return view;
		}

		
		
		@Override
		public void onItemClick(AdapterView<?> listView, View view, int position, long id) {
			// Get the cursor, positioned to the corresponding row in the result
			// set
			Cursor cursor = (Cursor) listView.getItemAtPosition(position);

			// Get the state's capital from this row in the database.
			String exercise = cursor.getString(cursor.getColumnIndexOrThrow(Exercises.C_exercise));
			me._exercise_met = Double.parseDouble(cursor.getString(cursor.getColumnIndexOrThrow(Exercises.C_met)));
			me._exercise_id  = Integer.parseInt( cursor.getString(cursor.getColumnIndexOrThrow(Exercises.C_exerciseID)) );
			Log.d("Item Onclick","Checking out met value...."+me._exercise_met+"..................");
			ExerciseTextBox.setText(exercise.trim());
			DurationText.requestFocus();	
			computeCal();
		}
	}
	
	
	class SynchUploader extends AsyncTask<String, Void, String> {		
		Context context;  
		ProgressDialog progress; 
		String TAG = "AddMessage Synch Uploader";
		UserExercises exercise;
		String method = "addexercise";
			
		public SynchUploader(Context c, UserExercises ue, String method ) { 
			this.context    = c; 
			this.exercise   = ue; 
			this.method     = method;
		}	
		@Override
	    protected void onPreExecute() {
		        progress = ProgressDialog.show(this.context, "", "Please wait..."); 
		        super.onPreExecute();
		 }		
		@Override
		protected String doInBackground(String... params) { 
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(12);		 
			nameValuePairs.add(new BasicNameValuePair("date",       exercise.created));			
			nameValuePairs.add(new BasicNameValuePair("userID",     String.valueOf(me.user.id) ));  						
			nameValuePairs.add(new BasicNameValuePair("calorie",    String.valueOf(exercise.burned)));       			
			nameValuePairs.add(new BasicNameValuePair("duration",   String.valueOf(exercise.duration)));
			nameValuePairs.add(new BasicNameValuePair("exercise",   String.valueOf(exercise.exercise)));						
			nameValuePairs.add(new BasicNameValuePair("exerciseID", String.valueOf(exercise.exerciseID)));			
			nameValuePairs.add(new BasicNameValuePair("met",        String.valueOf(exercise.met)));			
			nameValuePairs.add(new BasicNameValuePair("id",         String.valueOf(exercise.oid)));
		    nameValuePairs.add(new BasicNameValuePair("type",       String.valueOf(exercise.type)));
			nameValuePairs.add(new BasicNameValuePair("email",      me.user.email));
			nameValuePairs.add(new BasicNameValuePair("password",   me.user.password));						
			nameValuePairs.add(new BasicNameValuePair("method",     method));	 
			 
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(MYAPP.API_BASE);

			try {
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = httpclient.execute(httppost);
				String output = MYAPP.getWebString(response.getEntity().getContent());
				Log.d(TAG, "API Connection Result for "+method+": " + output); 
				return output;
			} catch (ClientProtocolException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} catch (IOException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} 
			return "";   
		}  
		
		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);	 
			if(result.length() == 0){
				progress.dismiss(); 
			}else{
				if( !MYAPP.isNumeric(result) ){
					 progress.dismiss(); 
				}else{ //user found here      					    
 			         exercise.oid = Integer.parseInt(result);
			         exercise.update(); 	 
				}				
			}
			me.openscreen(DashboardActivity.class);
       }
	
  }

}
