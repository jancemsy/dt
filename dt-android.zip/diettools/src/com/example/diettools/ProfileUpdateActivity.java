package com.example.diettools;


import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class ProfileUpdateActivity extends Activity {
	MYAPP me; 
	EditText txtusername;
	RadioGroup radioSex;
	EditText txtstartingweight;
	EditText txtcurrentweight;
	EditText txtcurrentheight;
	EditText txtfacebookurl;
	EditText txttwitterurl;
	EditText txtpinteresturl;
	static EditText txtbirthdate;
	Button btnsaveprofile;
	RadioButton radioFemale;
	RadioButton radioMale;
	DialogFragment newFragment = null;
	Users user;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.profile_update);

		me = (MYAPP) getApplication(); 
		me.init(this);
		me.SetMainMenuListeners(); 
		user  = me.user;
		txtusername       = (EditText) findViewById(R.id.txtregusername);
		radioSex          = (RadioGroup) findViewById(R.id.radioSex);
		txtstartingweight = (EditText) findViewById(R.id.txtstartingweight);
		txtcurrentweight  = (EditText) findViewById(R.id.txtcurrentweight);
		txtcurrentheight  = (EditText) findViewById(R.id.txtcurrentheight);
		txtfacebookurl    = (EditText) findViewById(R.id.txtfacebookurl);
		txttwitterurl     = (EditText) findViewById(R.id.txttwitterurl);
		txtpinteresturl   = (EditText) findViewById(R.id.txtpinteresturl);
		txtbirthdate      = (EditText) findViewById(R.id.txtbirthdate);		
		btnsaveprofile    = (Button) findViewById(R.id.btnsaveprofile);
		radioFemale       = (RadioButton) findViewById(R.id.radioFemale);
		radioMale         = (RadioButton) findViewById(R.id.radioMale);		

		txtusername.setText(String.valueOf(me.user.username));
		txtstartingweight.setText(String.valueOf(me.user.starting_weight));
		txtcurrentweight.setText(String.valueOf(me.user.weight));
		txtcurrentheight.setText(String.valueOf(me.user.height));
		txtfacebookurl.setText(String.valueOf(me.user.facebook));
		txttwitterurl.setText(String.valueOf(me.user.twitter));
		txtpinteresturl.setText(String.valueOf(me.user.pinterest));
		txtbirthdate.setText(String.valueOf(me.user.birth_date));

		if (me.user.sex == "female")
			radioFemale.setChecked(true);
		else
			radioMale.setChecked(true);
 

		btnsaveprofile.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {   
				int selectedId = radioSex.getCheckedRadioButtonId();
				RadioButton radioSexButton = (RadioButton) findViewById(selectedId); 
				user.username         =  txtusername.getText().toString();
				user.starting_weight  = Double.parseDouble(txtstartingweight.getText().toString()); 
				user.weight           = Double.parseDouble(txtcurrentweight.getText().toString()); 
				user.height           = Double.parseDouble(txtcurrentheight.getText().toString());
				user.facebook         = txtfacebookurl.getText().toString(); 
				user.twitter          = txttwitterurl.getText().toString(); 
				user.pinterest        = txtpinteresturl.getText().toString();
			    user.sex              =	radioSexButton.getText().toString(); 
				user.birth_date       = txtbirthdate.getText().toString();  
				
				 if(MYAPP.isEmpty(user.username)){
                       me.alertbox("Invalid username");					                        
				 }else if( !MYAPP.isNumeric(String.valueOf(user.starting_weight))  ){
						me.alertbox("Invalid starting weight");
			     }else if(  !MYAPP.isNumeric(String.valueOf(user.weight))  ){
					    me.alertbox("Invalid current weight");
			     }else if(  !MYAPP.isNumeric(String.valueOf(user.height)) ){
						me.alertbox("Invalid current height");
				 }else{
						new SynchUploader("updateprofile").execute();						 
				  }				 				 		

			}
		});
		
		txtbirthdate.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {						
				if( newFragment != null ) newFragment.dismiss(); 
				newFragment = new DatePickerFragment(txtbirthdate.getText().toString());
				newFragment.show(getFragmentManager(), "datePicker");						
			}
		});
		

	}
	
	public static class DatePickerFragment extends DialogFragment 
	   implements DatePickerDialog.OnDateSetListener {   
		final Calendar cal;  
		Date date2 = null;
		
		DatePickerFragment( String date ){ 
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); 
			
			try {
				date2 = formatter.parse( date );
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
		    cal = Calendar.getInstance();	
		    if(date2 != null) cal.setTime(date2);  		        
		}

		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {  
			int year  = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH);
			int day   = cal.get(Calendar.DAY_OF_MONTH); 
			return new DatePickerDialog(getActivity(), this, year, month, day);
		}
		
		 
		public void onDateSet(DatePicker view, int year, int month, int day) {
			txtbirthdate.setText(year + "-" + MYAPP.add0( month + 1 ) + "-" + MYAPP.add0(day) );
		}
	}
	

	class SynchUploader extends AsyncTask<String, Void, String> {		
		String method = "";  
		Context context; 
		ProgressDialog progress;
		String TAG = "CheckInputSave"; 

		public SynchUploader( String m) { 
			method = m; 
			this.context =  ProfileUpdateActivity.this;
			Log.d(TAG, "debugging................ 0");
		}

		@Override
		protected void onPreExecute() {
			progress = ProgressDialog.show(context, "", "Please wait...");
			super.onPreExecute();
		}

		@Override
		protected String doInBackground(String... params) {  
				Log.d(TAG, "checking for username if exists ===> " + user.username); 
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(12); 
				nameValuePairs.add(new BasicNameValuePair("username", user.username));			
				nameValuePairs.add(new BasicNameValuePair("starting_weight",  String.valueOf(user.starting_weight)));        		
				nameValuePairs.add(new BasicNameValuePair("weight",  String.valueOf(user.weight)));						
				nameValuePairs.add(new BasicNameValuePair("height",   String.valueOf(user.height)));	
				nameValuePairs.add(new BasicNameValuePair("facebook",    String.valueOf(user.facebook)));	
				nameValuePairs.add(new BasicNameValuePair("twitter",   String.valueOf(user.twitter)));			
				nameValuePairs.add(new BasicNameValuePair("pinterest",     String.valueOf(user.pinterest)));	
				nameValuePairs.add(new BasicNameValuePair("sex",     String.valueOf(user.sex)));	
				nameValuePairs.add(new BasicNameValuePair("birth_date",      String.valueOf(user.birth_date)));					
				nameValuePairs.add(new BasicNameValuePair("method",    method));				
				nameValuePairs.add(new BasicNameValuePair("email",     me.user.email));
				nameValuePairs.add(new BasicNameValuePair("password",  me.user.password));				  
				HttpClient httpclient = new DefaultHttpClient();
				HttpPost httppost = new HttpPost(MYAPP.API_BASE);

				try {
					httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
					HttpResponse response = httpclient.execute(httppost);
					String output = MYAPP.getWebString(response.getEntity().getContent());
					Log.d("Login Activity", "API Connection Result: \n" + output);
					return output;
				} catch (ClientProtocolException e) {
					Log.e(TAG, "::ERROR::", e);
					e.printStackTrace();
				} catch (IOException e) {
					Log.e(TAG, "::ERROR::", e);
					e.printStackTrace();
				}  
				
				return ""; 
		}

		@Override
		protected void onPostExecute(String result) { 
			super.onPostExecute(result);
			if (result.length() == 0 || result.equals("error")) {
				progress.dismiss();
				me.flash("Error connection");
			} else {
				progress.dismiss();	
				
				if (result.equals("username taken")) {
					me.alertbox("Username is already taken!");
				} else { 
					 user.update(); 
					 me.user = user;
					 me.openscreen(ProfileActivity.class);
					 me.flash("Profile has been updated!");
				}

										
			}
		}
	}

}
