package com.example.diettools;


import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class JournalPageActivity extends Activity{
	MYAPP me; 
	ListView output_list;  
    Button btnPicture;
    Button btnVideo;
    UserJournals journal;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.journalpage);			
		me = (MYAPP)getApplication(); 
		me.init(this);
		me.SetMainMenuListeners();   
		
		Cursor c = MYAPP.static_ds.rawQuery("SELECT *FROM " + UserJournals.TABLE + " WHERE  " +  
				UserJournals.C_id + " = " + me._current_journal_id + "  " , null);
				
		if( c.getCount() > 0 ){
			 c.moveToFirst();			
			 journal = new UserJournals();
			 journal.setInfo(c);			
			 String stats = "Weight: " + journal.weight + "lbs, Height: " + journal.height + "in, "+
			                "Arms :  "+journal.arms+"in, Chest: "+journal.chest+"in, Waist: "+journal.waist+"in, Hips: "+journal.hips+"in"; 
			 
			 ((TextView) findViewById(R.id.txt_title)).setText(journal.title);  
			 ((TextView) findViewById(R.id.txt_date)).setText(journal.created);			 
			 ((TextView) findViewById(R.id.txt_stats)).setText(stats);
		     ((TextView) findViewById(R.id.txt_message)).setText(journal.message);
		     		     		   
		     me.jumpActivityOnClick(R.id.btnPicture, JournalImageActivity.class);		    
		     
		     ((Button) findViewById(R.id.btnPicture))
				.setOnClickListener(new OnClickListener() {
					// @Override
					public void onClick(View view) {
						
						if(journal.picture.equals("")){ 			
						    me.openscreen(AddJournalPictureActivity.class);
						}else{
							me.openscreen(JournalImageActivity.class);	
						}
					}
				});
		     
		     
		     ((Button) findViewById(R.id.btnVideo))
				.setOnClickListener(new OnClickListener() {
					// @Override
					public void onClick(View view) {						
						if(journal.video.equals("")){ 			
						    me.openscreen(AddJournalVideoActivity.class);
						}else{
							//me.openscreen(JournalVideoActivity.class);
							//me.alertbox("Video display not yet implemented");							
							Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(journal.video));
							intent.setDataAndType(Uri.parse(journal.video), "video/mp4");
							startActivity(intent);							
						}											
					}
				});
 		     		     		   
		     
		}else{
			
		} 
	}  
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) { 
    	getMenuInflater().inflate(R.menu.journal_page_menu, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {  
		switch (item.getItemId()) {
		case R.id.item_delete:			
			MYAPP.static_ds.db.delete(UserJournals.TABLE , UserJournals.C_id + "=" +  me._current_journal_id, null);
			me._current_journal_id = "";
			me.openscreen(  JournalsActivity.class);			
			me.flash("Journal has been deleted");
			return true;
		case R.id.item_update:			
			me.openscreen(  AddJournalMindActivity.class);
			return true;
		case R.id.item_back:			
			me.openscreen(  JournalsActivity.class);
			return true;	 				
		default:
			return false;
		}
	}
	
	
	
	
	
	 
	
	
	
	
	
	
	
	
	
	
	
	
}