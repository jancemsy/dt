 package com.example.diettools;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils.InsertHelper;
import android.os.AsyncTask;
import android.provider.BaseColumns;
import android.util.Log;
  
 

class FriendRequests  { 
	public int oid;
	public static final String C_oid = "oid";
	public int id;
	public String created;
	public int recipientID;
	public int senderID;
	public int status;

	public static final String TABLE = "user_friend_requests";
	public static final String C_id = "id";
	public static final String C_created = "created";
	public static final String C_recipientID = "recipientID";
	public static final String C_senderID = "senderID";
	public static final String C_status = "status";
	public static final String CREATE_TABLE = String
			.format("create table %s "
					+ "(%s integer primary key autoincrement,%s text, %s int, %s int, %s int,%s int)",
					TABLE, C_id, C_created, C_recipientID, C_senderID, C_status,C_oid);

	public void insert() { 
		ContentValues values = new ContentValues();
		values.put(C_id, this.id);
		values.put(C_created, this.created);
		values.put(C_recipientID, this.recipientID);
		values.put(C_senderID, this.senderID);
		values.put(C_status, this.status);
		MYAPP.static_ds.add(TABLE, values);
	}
}

class Generator  {
 
	public int id;
	public int userID;
	public int foodCount = 0;
	public int exerciseCount = 0;
	public int recipeCount = 0;
	public int addedFoodCount = 0;
	public int addedExerciseCount = 0;
	public int addedRecipeCount = 0;
	public long lastUpdate = 0;

	public static final String TABLE = "generator";
	public static final String C_id = BaseColumns._ID;
	public static final String C_userID = "userID";
	public static final String C_foodCount = "foodCount";
	public static final String C_exerciseCount = "exerciseCount";
	public static final String C_recipeCount = "recipeCount";
	public static final String C_addedFoodCount = "addedFoodCount";
	public static final String C_addedExerciseCount = "addedExerciseCount";
	public static final String C_addedRecipeCount = "addedRecipeCount";
	public static final String C_lastUpdate = "lastUpdate";

	public static final String CREATE_TABLE = String
			.format("create table %s "
					+ "(%s integer primary key autoincrement,%s int, %s int, %s int, %s int, %s int, %s int, %s int )",
					TABLE, C_id, C_userID, C_foodCount, C_exerciseCount,
					C_recipeCount, C_addedExerciseCount, C_addedRecipeCount,
					C_lastUpdate);

	public void insert(){
		ContentValues values = new ContentValues();
		values.put(C_id, this.id);
		values.put(C_userID, this.userID);
		values.put(C_foodCount, this.foodCount);
		values.put(C_exerciseCount, this.exerciseCount);
		values.put(C_recipeCount, this.recipeCount);
		values.put(C_addedFoodCount, this.addedFoodCount);
		values.put(C_addedExerciseCount, this.addedExerciseCount);
		values.put(C_addedRecipeCount, this.addedRecipeCount);
		values.put(C_lastUpdate, this.lastUpdate);
		MYAPP.static_ds.add(TABLE, values);
	} 
} 


// this record contains our list of foods
class Exercises{ 
	public int oid;
	public static final String C_oid = "oid";
	public int id;
	public int exerciseID;  
	public String created;
	public double met;
	public int categoryID;
	public String exercise;
	public String search_keywords;
	public int search_order;

	public static final String TABLE = "exercises_fts";
	public static final String C_id = BaseColumns._ID;
	public static final String C_exerciseID = "exerciseID";
	public static final String C_created = "created";
	public static final String C_met = "met";
	public static final String C_categoryID = "categoryID";
	public static final String C_exercise = "exercise";
	
	public static final String C_search_keywords = "search_keywords";
 	public static final String C_search_order    = "search_order";
	
	
	public static final String CREATE_TABLE = String
	.format("CREATE VIRTUAL TABLE %s "
			+ " USING fts3 (%s integer primary key autoincrement,%s int,%s int, %s text, %s text, %s int,%s text,%s text, %s int )",
			TABLE, C_id,C_oid, C_exerciseID, C_created, C_met, C_categoryID,
			C_exercise,C_search_keywords,C_search_order);
	
	public static final String CREATE_TABLE_OLD = String
			.format("create table %s "
					+ "(%s integer primary key autoincrement,%s int,%s int, %s text, %s text, %s int,%s text )",
					TABLE, C_id,C_oid, C_exerciseID, C_created, C_met, C_categoryID,
					C_exercise);

	public void insert() {
		ContentValues values = new ContentValues();
		values.put(C_created, this.created);
		values.put(C_exerciseID, this.exerciseID);
		values.put(C_met, this.met);
		values.put(C_categoryID, this.categoryID);
		values.put(C_exercise, this.exercise);
		values.put(C_search_keywords, this.search_keywords);
	    values.put(C_search_order, this.search_order);
		MYAPP.static_ds.add(TABLE, values);
	} 
	
 	public void setInfo(Cursor c){
		 this.id               =  c.getInt(c.getColumnIndex(C_id));
		 this.oid              =  c.getInt(c.getColumnIndex(C_oid));
		 this.created          =  c.getString(c.getColumnIndex(C_created)) ;		 
		 this.exerciseID       =  c.getInt(c.getColumnIndex(C_exerciseID)) ;		 
		 this.met              =  c.getDouble(c.getColumnIndex(C_met)) ;
		 this.categoryID       =  c.getInt(c.getColumnIndex(C_categoryID)) ;		 
		 this.exercise         =  c.getString(c.getColumnIndex(C_exercise)) ;
		 this.search_keywords  =  c.getString(c.getColumnIndex(C_search_keywords)) ;
		 this.search_order     =  c.getInt(c.getColumnIndex(C_search_order)) ;
	}
	
	public void loadJson(Context context ) {
 		new Json(context, this).execute();
 	}	

	class Json extends AsyncTask<String, Void, String> {
		private String api_url;
		String TAG = "Load Exercises API";
		Context context;
		Exercises exercises; 
		
		public Json(Context context, Exercises ex ) {			
			exercises = ex; 
			this.context = context;
			this.api_url = MYAPP.API_BASE + "?reload=1&method=get_exercises";
			Log.d(TAG, "Loading JSON " + this.api_url);
		}

		@Override
		protected String doInBackground(String... params) {
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(this.api_url);

			try {
				HttpResponse response = httpclient.execute(httppost);
				InputStream is = response.getEntity().getContent();
				BufferedReader in = new BufferedReader(new InputStreamReader(is));
				String line;
				StringBuilder total = new StringBuilder();
				while ((line = in.readLine()) != null) {
					total.append(line);
				}

				String output = total.toString();

				try {
					JSONObject json = new JSONObject(output);
					String total_records = json.get("total").toString();
					JSONArray array = json.getJSONArray("data");										
					InsertHelper ih = new InsertHelper(MYAPP.static_ds.db, Exercises.TABLE); 
					final int col1 = ih.getColumnIndex(Exercises.C_exerciseID);
					final int col2 = ih.getColumnIndex(Exercises.C_created);
					final int col3 = ih.getColumnIndex(Exercises.C_met);
					final int col4 = ih.getColumnIndex(Exercises.C_categoryID);
					final int col5 = ih.getColumnIndex(Exercises.C_exercise);
					final int size = array.length();
					try {
						//exercises.dbHelper.getReadableDatabase().setLockingEnabled(false);
						for (int i = 0; i < size; i++) {
							String str = array.get(i).toString();
							JSONObject jsonarray = new JSONObject(str);
							Log.d(TAG, "INSERT EXERCISE::::: > " + i + "/ json row: "+ size + ": " + jsonarray.get("id") + " : " + jsonarray.get("created_at"));
							ih.prepareForInsert();
							ih.bind(col1, Integer.parseInt(jsonarray.get("id").toString()));
							ih.bind(col2, jsonarray.get("created_at").toString());
							ih.bind(col3, Double.parseDouble(jsonarray.get("met").toString()));
							ih.bind(col4, Integer.parseInt(jsonarray.get("categoryID").toString()));
							ih.bind(col5, jsonarray.get("exercise").toString());
							ih.execute();
						}
					} finally {
						//exercises.dbHelper.getReadableDatabase().setLockingEnabled(true);
						ih.close();
					}
					Log.d(TAG, "ONLINE TOTAL RECORDS ::::: >" + total_records);
					Log.d(TAG, "Total rows of local exercises db ::::>"+ MYAPP.static_ds.count() );
				} catch (Exception e) {
					Log.e(TAG, "Food Json parser error..", e);
					return "";
				}

				return "ok";
			} catch (ClientProtocolException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} catch (IOException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			}
			return "";
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);

			if (result != "") {
				Log.d(TAG, "Exercises Table recorded!!");
				MYAPP.static_ds.close(); 
			}
		}
	}
}





class Messages{ 
	public int oid;
	public static final String C_oid = "oid";
	public int id;
	public String created;
	public String subject;
	public int recipient;	
	public int sender;
	public String message; 
	public int status; 

	public static final String TABLE = "messages";
	public static final String C_id = BaseColumns._ID;
	public static final String C_created = "created";
	public static final String C_subject = "subject";	
	public static final String C_recipient = "recipient";
	public static final String C_sender = "sender";	
	public static final String C_message = "message";
	public static final String C_status = "status";
	
	public static final String CREATE_TABLE = String
			.format("create table %s (%s integer primary key autoincrement, %s text, %s text, %s int , %s int, %s text, %s int , %s int   )",
					TABLE, C_id, C_created, C_subject, C_recipient,C_sender,C_message,C_status,C_oid);

	 
	public ContentValues getValues(){
		ContentValues values = new ContentValues();	
		values.put(C_oid, this.oid);
		values.put(C_created, this.created);
		values.put(C_subject, this.subject); 
		values.put(C_recipient, this.recipient);
		values.put(C_sender, this.sender);
		values.put(C_message, this.message);
		values.put(C_status, this.status);
		return values;
	}
	
	public void setInfo(Cursor c){		 
		this.id        = c.getInt(c.getColumnIndex(C_id));
        this.oid       = c.getInt(c.getColumnIndex(C_oid));
	    this.created   = c.getString(c.getColumnIndex(C_created));	 
	    this.subject   = c.getString(c.getColumnIndex(C_subject)); 	 	    
	    this.recipient = c.getInt(c.getColumnIndex(C_recipient));
	    this.sender    = c.getInt(c.getColumnIndex(C_sender));
	    this.message   = c.getString(c.getColumnIndex(C_message));
	    this.status    = c.getInt(c.getColumnIndex(C_status));	    	    
	}
	
	
	
	public int insert() {		
		return MYAPP.static_ds.add(TABLE, getValues());
	} 
	
	public void setLastId(){	
		if(this.id > 0){				
		}else{
			Cursor cursor = MYAPP.static_ds.rawQuery("SELECT *FROM " + TABLE
					+ " ORDER BY " + C_id +" DESC LIMIT 1 ", null);					
			if(cursor.getCount() > 0){  
				cursor.moveToFirst(); 				
				   this.id =  cursor.getInt(cursor.getColumnIndex(C_id));
			}
		}
	}
	
	public void update() { 
		setLastId();
		MYAPP.static_ds.update(TABLE, getValues(), C_id, String.valueOf( this.id ) );
	}	
	
	public static void saveJsonData(  String output) throws JSONException{ 	
		JSONObject json = new JSONObject(output);
		JSONArray array = json.getJSONArray("messages");
		final int size  = array.length();
		Messages msg;
		
		for (int i = 0; i < size; i++) {
		  String str = array.get(i).toString();  
		  JSONObject arr = new JSONObject(str);	
		  msg            = new Messages();
		  msg.oid         =  MYAPP.toInt(arr.get("id").toString());
		  msg.subject    =  arr.get("subject").toString(); 
		  msg.sender     =  MYAPP.toInt(arr.get("sender").toString()); 
		  msg.recipient  =  MYAPP.toInt(arr.get("recipient").toString()); 
		  msg.message    =  arr.get("message").toString(); 
		  msg.created    =  arr.get("created_at").toString(); 
		  msg.status     =  MYAPP.toInt(arr.get("status").toString()); 
		  msg.insert();              
		}
	}
}



class UserFriends{ 
	public int oid;
	public static final String C_oid = "oid";
	public int id;	
	public String created;
	public int userID;
	public int friendID;

	public static final String TABLE = "user_friends";
	public static final String C_id = BaseColumns._ID;
	public static final String C_created = "created";
	public static final String C_userID = "userID";
	public static final String C_friendID = "friendID";	
	public static final String CREATE_TABLE = String
			.format("create table %s (%s integer primary key autoincrement,%s text, %s int, %s int  ,%s int)",
					TABLE, C_id, C_created, C_userID, C_friendID,C_oid);

	 
	public ContentValues getValues(){
		ContentValues values = new ContentValues();
		values.put(C_oid, this.oid);
		values.put(C_created, this.created);
		values.put(C_userID, this.userID);
		values.put(C_friendID, this.friendID);
		return values;
	}
	
	
	public int insert() {		
		return MYAPP.static_ds.add(TABLE, getValues());
	}
	
	public static void saveJsonData(String output) throws JSONException{ 	
		JSONObject json = new JSONObject(output);
		JSONArray array = json.getJSONArray("friends");
		final int size  = array.length();
		UserFriends f;
		
		for (int i = 0; i < size; i++) {
		  String str = array.get(i).toString();  
		  JSONObject arr   = new JSONObject(str);	
		  f                = new UserFriends();
		  /* sometimes the api passes data that doesn't contains a value for userfriends*/
		  if( MYAPP.toInt(arr.get("userID").toString()) > 0){
		    f.oid            =  MYAPP.toInt(arr.get("id").toString());
		    f.userID         =  MYAPP.toInt(arr.get("userID").toString());
		    f.friendID       =  MYAPP.toInt(arr.get("friendID").toString());
		    f.created        =  arr.get("created_at").toString(); 		  
		    f.insert();              
		  }
		}
	}
}





class MeasurementTracker{  
	public int oid;
	public static final String C_oid = "oid";
	public int id;
	public String created;
	public int userID;
	public double upper_arm;
	public double chest;
	public double waist;
	public double hips; 

	public static final String TABLE = "measurementtracker";
	public static final String C_id = BaseColumns._ID;
	public static final String C_created   = "created";
	public static final String C_userID    = "userID";
	public static final String C_upper_arm = "upper_arm";
	public static final String C_chest     = "chest";
	public static final String C_waist     = "waist";
	public static final String C_hips      = "hips";
	
	public static final String CREATE_TABLE = String
			.format("create table %s (%s integer primary key autoincrement,%s text, %s int, %s int, %s int, %s int, %s int, %s int  )",
					TABLE, C_id, C_created, C_userID, C_upper_arm,C_chest,C_waist, C_hips,C_oid);

 
	
	public ContentValues getValues(){
		ContentValues values = new ContentValues();
		values.put(C_oid, this.oid);
		values.put(C_created, this.created);
		values.put(C_userID, this.userID);
		values.put(C_upper_arm, this.upper_arm); 
		values.put(C_chest, this.chest);
		values.put(C_waist, this.waist);
		values.put(C_hips, this.hips);
		
		return values;
	}
	
	public int insert() {		
		return MYAPP.static_ds.add(TABLE, getValues());
	}
	
}
 

class Points{	
	public int oid;
	public int id;
	public String created; 	
	public int points;	
	public int userID;
	public String message;	
	public int tid;
	
	//for exercises 
	public double burned;
	public double minutes;   
		
	public static final String TABLE     = "points";
	public static final String C_oid = "oid";
	public static final String C_id      = BaseColumns._ID;
	public static final String C_created = "created";
	public static final String C_points  = "points";
	public static final String C_userid  = "userId";
	public static final String C_message = "message";
	public static final String C_tid     = "tid";
	public static final String C_burned  = "burned";
	public static final String C_minutes = "minutes";
	
	public static final String CREATE_TABLE = String
	.format("create table %s (%s integer primary key autoincrement,%s text," +
			" %s int, %s int,        %s text,  %s int,   %s int, %s int, %s int  )", TABLE, C_id, C_created,
			C_points , C_userid,    C_message,  C_tid,   C_burned, C_minutes,C_oid);
	
	public void setInfo(Cursor c){		 
		this.id        = c.getInt(c.getColumnIndex(C_id));
        this.oid       = c.getInt(c.getColumnIndex(C_oid));
	    this.created   = c.getString(c.getColumnIndex(C_created));	 
	    this.points    = c.getInt(c.getColumnIndex(C_points));	 	    
	    this.userID    = c.getInt(c.getColumnIndex(C_userid));
	    this.message   = c.getString(c.getColumnIndex(C_message));
	    this.tid       = c.getInt(c.getColumnIndex(C_tid));
	    this.burned    = c.getDouble(c.getColumnIndex(C_burned));
	    this.minutes   = c.getInt(c.getColumnIndex(C_minutes));
	    
	} 
	 
	public ContentValues getValues(){
		ContentValues values = new ContentValues();				
		//values.put(C_created, this.created); //no need 			
		values.put(C_created, MYAPP.NOW()); 
		values.put(C_oid, this.oid);
		values.put(C_userid,  this.userID);
		values.put(C_points, this.points);
		values.put(C_message, this.message);
		values.put(C_tid, this.tid);
		values.put(C_burned, this.burned);
		values.put(C_minutes, this.minutes);
		return values;
	}
	
	public int insert() {		
		return MYAPP.static_ds.add(TABLE, getValues());
	} 	
}


class UserGalleries{ 
	public int oid;	
	public int id;
	public String created;
	public int albumID;
	public int userID;
	public String caption;
	public String file;
	public String title;

	public static final String TABLE = "user_galleries";
	public static final String C_oid = "oid";
	public static final String C_id = BaseColumns._ID;
	public static final String C_created = "created";
	public static final String C_albumID = "albumID";
	public static final String C_userID = "userID";
	public static final String C_caption = "caption";
	public static final String C_file = "file";
	public static final String C_title = "title";
	public static final String CREATE_TABLE = String
			.format("create table %s (%s integer primary key autoincrement,%s text, %s int, %s int, "
					+ "%s text, %s text, %s text, %s int  )", TABLE, C_id, C_created,
					C_albumID, C_userID, C_caption, C_file, C_title, C_oid);

	
	public void setInfo(Cursor c){		
		this.oid      = c.getInt(c.getColumnIndex(C_oid));
		this.id       = c.getInt(c.getColumnIndex(C_id));	 
	    this.userID   = c.getInt(c.getColumnIndex(C_userID));	 
	    this.created  = c.getString(c.getColumnIndex(C_created));	 
	    this.title    = c.getString(c.getColumnIndex(C_title));	 	    
	    this.albumID  = c.getInt(c.getColumnIndex(C_albumID));
	    this.caption  = c.getString(c.getColumnIndex(C_caption));
	    this.file     = c.getString(c.getColumnIndex(C_file));	    
	}
	
	 
	public ContentValues getValues(){
		ContentValues values = new ContentValues();
		values.put(C_oid, this.oid);
		values.put(C_created, this.created);
		values.put(C_userID, this.userID);
		values.put(C_albumID, this.albumID);
		values.put(C_caption, this.caption);
		values.put(C_file, this.file);
		values.put(C_title, this.title); 
		return values;
	}
	
	public void setLastId(){	
		if(this.id > 0){				
		}else{
			Cursor cursor = MYAPP.static_ds.rawQuery("SELECT *FROM " + TABLE
					+ " ORDER BY " + C_id +" DESC LIMIT 1 ", null);					
			if(cursor.getCount() > 0){  
				cursor.moveToFirst(); 				
				   this.id =  cursor.getInt(cursor.getColumnIndex(C_id));
			}
		}
	}
	
	public void update() { 
		setLastId();
		MYAPP.static_ds.update(TABLE, getValues(), C_id, String.valueOf( this.id ) );
	}	
	
	public int insert() {		
		return MYAPP.static_ds.add(TABLE, getValues());
	}

}

class UserJournals  { 
	public int oid;
	public static final String C_oid = "oid";
	public int id;
	public String created;
	public int userID;
	public String title;
	public String message;
	public String embed;
	public String picture;
	public String video;
	public double weight;
	public double height;
	public double arms;
	public double chest;
	public double waist;
	public double hips;
	public double privacy;
	public double bmr;

	public static final String TABLE = "user_journals";
	public static final String C_id = BaseColumns._ID;
	public static final String C_userID = "userID";
	public static final String C_created = "created";
	public static final String C_title = "title";
	public static final String C_message = "message";
	public static final String C_embed = "embed";
	public static final String C_picture = "picture";
	public static final String C_video = "video";
	public static final String C_weight = "weight";
	public static final String C_height = "height";
	public static final String C_arms = "arms";
	public static final String C_chest = "chest";
	public static final String C_waist = "waist";
	public static final String C_hips = "hips";
	public static final String C_privacy = "privacy";
	public static final String C_bmr = "bmr";

	public static final String CREATE_TABLE = String.format("create table %s "
			+ "(%s integer primary key autoincrement,%s int, %s text,"
			+ " %s text, %s text, %s text, %s text, %s text,"
			+ " %s int, %s int, %s int, %s int, %s int,%s int"  
			+ " %s int, %s int, %s int  )", TABLE, C_id, C_userID, C_created,
			C_title, C_message, C_embed, C_picture, C_video, C_weight,
			C_height, C_arms, C_chest, C_waist, C_hips, C_privacy, C_bmr,C_oid);

	
	public void setInfo(Cursor c){		 
		this.id       = c.getInt(c.getColumnIndex(C_id));	 
		this.oid      = c.getInt(c.getColumnIndex(C_oid));
	    this.userID   = c.getInt(c.getColumnIndex(C_userID));	 
	    this.created  = c.getString(c.getColumnIndex(C_created));	 
	    this.title    = c.getString(c.getColumnIndex(C_title));	 
	    this.message  = c.getString(c.getColumnIndex(C_message));	 
	    this.embed    = c.getString(c.getColumnIndex(C_embed));	 
	    this.picture  = c.getString(c.getColumnIndex(C_picture));	 
        this.video    = c.getString(c.getColumnIndex(C_video));	 
	    this.weight   = c.getDouble(c.getColumnIndex(C_weight));	 
	    this.height   = c.getDouble(c.getColumnIndex(C_height));	 
	    this.arms     = c.getDouble(c.getColumnIndex(C_arms));	 
	    this.chest    = c.getDouble(c.getColumnIndex(C_chest));	 
	    this.waist    = c.getDouble(c.getColumnIndex(C_waist));	 
	    this.hips     = c.getDouble(c.getColumnIndex(C_hips));	 
        this.privacy  = c.getInt(c.getColumnIndex(C_privacy));	 
		this.bmr      = c.getDouble(c.getColumnIndex(C_bmr));	
	}
	
	public ContentValues getValues(){
		ContentValues values = new ContentValues();
		values.put(C_oid, this.oid);
		values.put(C_userID, this.userID);
		values.put(C_created, this.created);
		values.put(C_title, this.title);
		values.put(C_message, this.message);
		values.put(C_embed, this.embed);
		values.put(C_picture, this.picture);
		values.put(C_video, this.video);
		values.put(C_weight, this.weight);
		values.put(C_height, this.height);
		values.put(C_arms, this.arms);
		values.put(C_chest, this.chest);
		values.put(C_waist, this.waist);
		values.put(C_hips, this.hips);
		values.put(C_privacy, this.privacy);
		values.put(C_bmr, this.bmr); 
		return values;
	}
	
	public int insert() {		
		return MYAPP.static_ds.add(TABLE, getValues());
	}
	
	public void setLastId(){	
		if(this.id > 0){				
		}else{
			Cursor cursor = MYAPP.static_ds.rawQuery("SELECT *FROM " + TABLE
					+ " ORDER BY " + C_id +" DESC LIMIT 1 ", null);					
			if(cursor.getCount() > 0){  
				cursor.moveToFirst(); 				
				   this.id =  cursor.getInt(cursor.getColumnIndex(C_id));
			}
		}
	}
	
	public void update() { 
		setLastId();
		MYAPP.static_ds.update(TABLE, getValues(), C_id, String.valueOf( this.id ) );
	}	
	 
	
}


/*
 * oid and userID are the same with the same purpose    
 */
 class Users { 
	public int oid; 
    public static final String C_oid = "oid";
	public int id;
	public String created;
	public int userID;
	public String name;
	public String username;
	public String password;
	public String email;
	public String address;
	public String bio_title;
	public String bio;
	public String interests;
	public String avatar;
	public String activation_code;
	public String status;
	public String goal_weight;
	public String goal_date;
	public Double goal_bmi;
	public Double starting_weight;
	public Double bmr;
	public Double weight;
	public Double height;
	public String birth_date;
	public int age;
	public String level;
	public String twitter;
	public String facebook;
	public String pinterest;
	public String goal;
	public int journal_privacy;
	public int points;
	public String sex;
	public String last_update;

	public static final String TABLE = "users";
	public static final String C_id = BaseColumns._ID;
	public static final String C_created = "created";
	public static final String C_userID = "userID";
	public static final String C_name = "name";
	public static final String C_username = "username";
	public static final String C_password = "password";
	public static final String C_email = "email";
	public static final String C_address = "address";
	public static final String C_bio_title = "bio_title";
	public static final String C_bio = "bio";
	public static final String C_interests = "interests";
	public static final String C_avatar = "avatar";
	public static final String C_activation_code = "activation_code";
	public static final String C_status = "status";
	public static final String C_goal_weight = "goal_weight";
	public static final String C_goal_date = "goal_date";
	public static final String C_goal_bmi = "goal_bmi";
	public static final String C_starting_weight = "starting_weight";
	public static final String C_bmr = "bmr";
	public static final String C_weight = "weight";
	public static final String C_height = "height";
	public static final String C_birth_date = "birth_date";
	public static final String C_age = "age";
	public static final String C_level = "level";
	public static final String C_twitter = "twitter";
	public static final String C_facebook = "facebook";
	public static final String C_pinterest = "pinterest";
	public static final String C_goal = "goal";
	public static final String C_journal_privacy = "journal_privacy";
	public static final String C_points = "points";
	public static final String C_sex = "sex";
	public static final String C_last_update = "last_update";
		

	public static final String CREATE_TABLE = String
			.format("create table %s "
					+ "(%s integer primary key autoincrement, "
					+ " %s text, %s text, %s text, %s text,%s text, %s text, %s text, %s text, "
					+ "%s text,%s text,%s text, %s text, %s text, %s text, %s text, %s text, %s text,"
					+

					" %s int,  %s int, %s int, %s int, %s int,  %s int, %s int, "
					+ "%s int, %s int, %s int, %s int,  %s int, %s int,%s int,%s int ) ",

			TABLE, C_id, C_name, C_username, C_password, C_email, C_address,
					C_bio_title, C_bio, C_interests, C_avatar,
					C_activation_code, C_level, C_twitter, C_facebook,C_pinterest, C_goal,
					C_journal_privacy, C_sex,

					C_points, C_created, C_userID, C_status, C_goal_weight,
					C_goal_date, C_goal_bmi, C_starting_weight, C_bmr,
					C_weight, C_height, C_birth_date, C_age, C_last_update,C_oid);

	public boolean initByOid(int oid){
		Cursor c  = MYAPP.static_ds.rawQuery("SELECT  *FROM  "+Users.TABLE+" WHERE   " + 
				Users.C_oid + " =  "  + oid + " " , null);		
		
		if ( c.moveToFirst() ) { 
			setInfo(c);
			return true;
		}else{
			return false;
		}		
	}
		
	public static void saveJsonDataFromFriends(String output)  throws JSONException{ 
		JSONObject json = new JSONObject(output);  
		JSONArray array = json.getJSONArray("friendsData");
		final int size  = array.length();
		Users users;			         
		for (int i = 0; i < size; i++) {
		  String str = array.get(i).toString();  
		  JSONObject arr = new JSONObject(str);		  
		  users           =  new Users();		  
		  //lets save if not in our db yet
		  //we are saving our friends small info so that
		  //we can use them especially when displaying our friends avatar
		  if( !Users.isExists( MYAPP.toInt(arr.get("friendID").toString())) ){ 
			  users.oid       =  MYAPP.toInt(arr.get("friendID").toString());
			  users.userID    =  MYAPP.toInt(arr.get("friendID").toString());
			  users.username  =  arr.get("username").toString(); 
			  users.avatar    =  arr.get("avatar").toString();		
			  users.avatar    =  users.avatar.replace("\\/", "/");
			  users.insert();              
		  } 		 
		  
		  
		} 
	}
	
	public static boolean isExists(int oid){
  	  	 Cursor c  = MYAPP.static_ds.rawQuery("SELECT  *FROM  "+Users.TABLE+" WHERE   " + 
	              Users.C_oid + " =  "  + oid + " " , null); 		
            if ( c.moveToFirst() ) { 
               return true;
            }else{
               return false;
            }		
	}
	
	
	public Users UpdateUserInfo(Users u, JSONObject jsonarray,String loginpass)
	{
		try { 
			
			Log.d("UpdateUserInfo","Insert or Update user info XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");					
			
			final String SQL_STATEMENT = "SELECT *FROM " + Users.TABLE 
			+ " WHERE (" + Users.C_username + " =? OR " + Users.C_email + " =?  ) ";
			
			String un = jsonarray.get("username").toString();			
			Cursor c = MYAPP.static_ds.rawQuery( SQL_STATEMENT , new String[] { un,un });
			
			
			
            String av = u.avatar;
		  	if(!MYAPP.isEmpty(jsonarray.get("avatar").toString()) ){						            	
            	av = MYAPP.SITE_URL + jsonarray.get("avatar").toString();
            }
		  	
			
		 	 u.created     = jsonarray.get("created_at").toString();
	         u.userID      = MYAPP.toInt(jsonarray.get("id").toString());
	         u.oid         = MYAPP.toInt(jsonarray.get("id").toString()); 
	         u.name        = jsonarray.get("name").toString(); 
	         
	         if(! MYAPP.isEmpty(loginpass))
	         u.password    = loginpass; /*we use login pass -not encrypted so that we can use this to login via the site*/  //jsonarray.get("password").toString();
	         
	         
	         u.username    = jsonarray.get("username").toString();
	         u.email       = jsonarray.get("email").toString();  
	         u.address     = jsonarray.get("address").toString();
	         u.bio_title   = jsonarray.get("bio_title").toString();
	         u.bio         = jsonarray.get("bio").toString();
	         u.interests   = jsonarray.get("interests").toString();	         
	         u.avatar      = av;
	         u.activation_code = jsonarray.get("activation_code").toString();
	         u.level       = jsonarray.get("level").toString();
	         u.twitter     = jsonarray.get("twitter").toString();
	         u.facebook    = jsonarray.get("facebook").toString();	
	         u.pinterest   = jsonarray.get("pinterest").toString();
	         u.journal_privacy = MYAPP.toInt(jsonarray.get("journal_privacy").toString());
	         u.points      = MYAPP.toInt(jsonarray.get("points").toString());
	         u.sex         = jsonarray.get("sex").toString();
	         u.status      = jsonarray.get("status").toString();
	         u.weight      = MYAPP.toDouble(jsonarray.get("weight").toString());
	         u.starting_weight      = MYAPP.toDouble(jsonarray.get("starting_weight").toString());
	         u.height      = MYAPP.toDouble(jsonarray.get("height").toString());
	         u.birth_date  = jsonarray.get("birth_date").toString();
	         
	         u.bmr         = MYAPP.toDouble(jsonarray.get("bmr").toString());
	         u.goal        = jsonarray.get("goal").toString();
	         
	         u.goal_weight = jsonarray.get("goal_weight").toString();
	         u.goal_date   = jsonarray.get("goal_date").toString();	
	         u.last_update = jsonarray.get("last_update").toString();
	         
	         if ( c.moveToFirst() ) {
	        	  u.update(); 
	         }else{
	        	  u.insert();
	         }
	         
	         return u;
		} catch (Exception e) {
			Log.d("Models User","Error "+ e);						 
	  } 
		
		return u;
	}
	
	public ContentValues getValues(){ 
		ContentValues values = new ContentValues();
		values.put(C_oid, this.oid);
		values.put(C_created, this.created);
		values.put(C_userID,  this.userID);
		values.put(C_username, this.username);
		values.put(C_name, this.name);
		values.put(C_password, this.password);
		values.put(C_email, this.email);
		values.put(C_address, this.address);
		values.put(C_bio_title, this.bio_title);
		values.put(C_bio, this.bio);
		values.put(C_interests, this.interests);
		values.put(C_avatar, this.avatar);
		values.put(C_activation_code, this.activation_code);
		values.put(C_level, this.level);
		values.put(C_twitter, this.twitter);
		values.put(C_facebook, this.facebook);		
		values.put(C_pinterest, this.pinterest);
		values.put(C_journal_privacy, this.journal_privacy);
		values.put(C_points, this.points);
		values.put(C_sex, this.sex);
		values.put(C_status, this.status);
		values.put(C_starting_weight,this.starting_weight);
		values.put(C_weight, this.weight);
		values.put(C_height, this.height);
		values.put(C_birth_date, this.birth_date);
		values.put(C_goal, this.goal);
		values.put(C_goal_date, this.goal_date);
		values.put(C_goal_weight, this.goal_weight);
		values.put(C_last_update, this.last_update);
		return values;
	}
	
	public int insert() {		
		return MYAPP.static_ds.add(TABLE, getValues());
	}
	
	public void setLastId(){	
		if(this.id > 0){				
		}else{
			Cursor cursor = MYAPP.static_ds.rawQuery("SELECT *FROM " + TABLE
					+ " ORDER BY " + C_id +" DESC LIMIT 1 ", null);					
			if(cursor.getCount() > 0){  
				cursor.moveToFirst(); 				
				   this.id =  cursor.getInt(cursor.getColumnIndex(C_id));
			}
		}
	}
	
	public void update() { 
		setLastId();
		MYAPP.static_ds.update(TABLE, getValues(), C_userID, String.valueOf( this.userID ) );
	}	
	 
	
	public int getAge(String str) {
		Date dateOfBirth = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); 
		Log.d("Users Model","Date convertion line 1");	
		try {
		    dateOfBirth = formatter.parse( str );
		   Log.d("Users Model","Date convertion line 2");
		}  catch (Exception e) {
	        e.printStackTrace();
		 }
		 Log.d("Users Model","Date convertion line 3");
		  
	    int age = 0;
	    Calendar born = Calendar.getInstance();
	    Calendar now = Calendar.getInstance();
	    if(dateOfBirth != null) {
	        now.setTime(new Date());
	        born.setTime(dateOfBirth);  
	        if(born.after(now)) {
	            throw new IllegalArgumentException("Can't be born in the future");
	        }
	        age = now.get(Calendar.YEAR) - born.get(Calendar.YEAR);             
	        if(now.get(Calendar.DAY_OF_YEAR) < born.get(Calendar.DAY_OF_YEAR))  {
	            age-=1;
	        }
	    }  
	    return age;  
	}      
	
	
	
	
	public long getCAP(double today_burned){
		long cal_cap = 0;	 
		double BMR       = this.getBMR();   
		Calendar cal     = Calendar.getInstance();		 
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String nowFormat = formatter.format( cal.getTime() );                
		long now         =   MYAPP.dateToLong(nowFormat); 				
		long _goal_date  = MYAPP.dateToLong(goal_date); 	
		double _goal_weight = MYAPP.parseDoubleOrNull(goal_weight); 
		double days_left =   (_goal_date - now ) / 86400000;         
	    double goal_cal  =  ( ( _goal_weight - weight ) /(days_left) ) * 3500; 		   
	    cal_cap          =    Math.round( BMR + today_burned + goal_cal);	    	   	    	   
	    //Log.d("GetCap"," cal_cap => " + cal_cap + "   ... age => " + age +  ".... BMR =>" + BMR + " now = >" + now + "_goal_date => " + _goal_date + " goal_weight = > " + _goal_weight +  ".... days_left=> " + days_left +  " ... goal_cal => " + goal_cal );	    	    	  	    
	    return cal_cap;
	}
	  
	
	public double getBMR(){
		 int age = this.getAge(this.birth_date);
		 double bmr = 0.0;
		 
		 if(this.sex.equals("man") || sex.equals("male") ){            
			    bmr = ( (66 + (6.23 * weight) + (12.7 * height) - (6.8 * age)) * 10) / 10;
	     } else {             
			    bmr = ( (665 + (4.35 * weight) + (4.7 * height) - (4.7 * age)) * 10) / 10;
	     }
		 
		 return bmr;
	}
	
	public void findById(int userId)
	{		
		final String SQL_STATEMENT = "SELECT *FROM " + Users.TABLE 
		        + " WHERE (" + Users.C_userID + " =? " + userId;		
		Cursor c = MYAPP.static_ds.rawQuery( SQL_STATEMENT ,  null);	 	
		if ( c.moveToFirst() ) {
		  this.setInfo(c);    
		}
	}
	
	
	
	public void setInfo(Cursor c){	
		 this.oid             = c.getInt(c.getColumnIndex(C_oid));
		 this.created         = c.getString(c.getColumnIndex(C_created));		 
		 this.userID          = c.getInt(c.getColumnIndex(C_userID)) ;
		 this.username        = c.getString(c.getColumnIndex(C_username));
		 this.name            = c.getString(c.getColumnIndex(C_name));
		 this.password        = c.getString(c.getColumnIndex(C_password));
		 this.email           = c.getString(c.getColumnIndex(C_email));
		 this.address         = c.getString(c.getColumnIndex(C_address));
		 this.bio_title       = c.getString(c.getColumnIndex(C_bio_title));
		 this.bio             = c.getString(c.getColumnIndex(C_bio));
		 this.interests       = c.getString(c.getColumnIndex(C_interests));
		 this.avatar          = c.getString(c.getColumnIndex(C_avatar));
		 this.activation_code = c.getString(c.getColumnIndex(C_activation_code));
		 this.level           = c.getString(c.getColumnIndex(C_level));
		 this.twitter         = c.getString(c.getColumnIndex(C_twitter));
		 this.facebook        = c.getString(c.getColumnIndex(C_facebook));
		 this.pinterest       = c.getString(c.getColumnIndex(C_pinterest));
		 this.goal            = c.getString(c.getColumnIndex(C_goal));
		 this.journal_privacy = c.getInt(c.getColumnIndex(C_journal_privacy)) ;
		 this.points          = c.getInt(c.getColumnIndex(C_points));
		 this.sex             = c.getString(c.getColumnIndex(C_sex));
		 this.status          = c.getString(c.getColumnIndex(C_status));
		 this.weight          = c.getDouble(c.getColumnIndex(C_weight));
		 this.starting_weight = c.getDouble(c.getColumnIndex(C_starting_weight));
		 this.height          = c.getDouble(c.getColumnIndex(C_height)); 
		 this.birth_date      = c.getString(c.getColumnIndex(C_birth_date));
		 this.goal_date       = c.getString(c.getColumnIndex(C_goal_date));
		 this.goal_bmi        = c.getDouble(c.getColumnIndex(C_goal_bmi));
		 this.goal_weight     = c.getString(c.getColumnIndex(C_goal_weight));
		 this.age             = this.getAge(this.birth_date);
		 this.last_update     = c.getString(c.getColumnIndex(C_last_update)); 
	}
}
 
 
 
 
 class UserExercises { 
	    public int oid;
		public static final String C_oid = "oid";
		public String username;
		public int id;
		public int userID;
		public String created;
		public String exercise;
		public String type;
		public double duration;
		public double burned;
		public int exerciseID; 	
		public double met; 
		public double bmr;

		public static final String TABLE = "user_exercises";
		public static final String C_ID = BaseColumns._ID;
		public static final String C_USERID     = "userID";
		public static final String C_CREATED    = "created";
		public static final String C_EXERCISE   = "exercise";
		public static final String C_DURATION   = "duration";
		public static final String C_BURNED     = "burned";
		public static final String C_EXERCISEID = "exerciseID";
		public static final String C_BMR        = "bmr";
		public static final String C_MET        = "met";
		public static final String C_TYPE       = "type";

		public static final String CREATE_TABLE = String
				.format("create table %s "
						+ "(%s integer primary key autoincrement,%s int, %s text, %s text, %s double, %s double, %s int, %s int, %s text, %s int,%s int )",
						TABLE, C_ID, C_USERID, C_CREATED, C_EXERCISE, C_BURNED,C_DURATION,C_EXERCISEID,C_MET,C_TYPE,C_BMR,C_oid);

		
		public void setLastId(){	
			if(this.id > 0){				
			}else{
				Cursor cursor = MYAPP.static_ds.rawQuery("SELECT *FROM " + TABLE
						+ " ORDER BY " + C_ID +" DESC LIMIT 1 ", null);					
				if(cursor.getCount() > 0){  
					cursor.moveToFirst(); 				
					   this.id =  cursor.getInt(cursor.getColumnIndex(C_ID));
				}
			}
		}
		
		public void update() { 
			setLastId();
			MYAPP.static_ds.update(TABLE, getValues(), C_ID , String.valueOf( this.id ) );
		}	
		
		public ContentValues getValues(){  
			ContentValues values = new ContentValues();
			values.put(C_oid, this.oid);
			values.put(C_TYPE,this.type);
			values.put(C_MET, this.met); 
			values.put(C_CREATED, this.created);
			values.put(C_USERID, this.userID);
			values.put(C_EXERCISE, this.exercise);
			values.put(C_DURATION, this.duration);
			values.put(C_BURNED, this.burned);
			values.put(C_EXERCISEID, this.exerciseID);
			values.put(C_BMR, this.bmr);
			return values;
		}
		
		public void setInfo(Cursor c){ 		
			 this.id          =  c.getInt(c.getColumnIndex(C_ID));			
	 		 this.oid         =  c.getInt(c.getColumnIndex(C_oid));	 		 
			 this.type        =  c.getString(c.getColumnIndex(C_TYPE));
			 this.met         =  c.getInt(c.getColumnIndex(C_MET));
			 this.created     =  c.getString(c.getColumnIndex(C_CREATED));			 						
			 this.userID      =  c.getInt(c.getColumnIndex(C_USERID));
			 this.exercise    =  c.getString(c.getColumnIndex(C_EXERCISE));
			 this.duration    =  c.getInt(c.getColumnIndex(C_DURATION));
			 this.burned      =  c.getInt(c.getColumnIndex(C_BURNED));
			 this.exerciseID  =  c.getInt(c.getColumnIndex(C_EXERCISEID));
			 this.bmr         =  c.getInt(c.getColumnIndex(C_BMR));
		}
		
		public int insert() { 
			return MYAPP.static_ds.add(TABLE,getValues());
		}

	}
  
 
 
 class UserFoods{ 
	    public int oid;
		public static final String C_oid = "oid";
		public int id;
		public int foodID;
		public String created;
		public int userID;
		public String name;
		public double protein;
		public double carb;
		public double fat;
		public double cal;
		public String type;
		public int qty;
		public String size;
		

		public static final String TABLE = "user_foods";
		public static final String C_ID = BaseColumns._ID;
		public static final String C_CREATED = "created";
		public static final String C_FoodID = "foodID";
		public static final String C_USERID = "userID";
		public static final String C_NAME = "name";
		public static final String C_PROTEIN = "protein";
		public static final String C_CARB = "carb";
		public static final String C_FAT = "fat";
		public static final String C_CAL = "cal";
		public static final String C_SIZE = "size";
		public static final String C_QTY = "qty";
		public static final String C_TYPE = "type";

		public static final String CREATE_TABLE = String
				.format("create table %s "
						+ "(%s integer primary key autoincrement,%s text, %s int, %s text, %s double, %s double, " +
								"%s double, %s double, %s int , %s text, %s int, %s text, %s int  )",
						TABLE, C_ID, C_CREATED, C_USERID, C_NAME, C_PROTEIN,
						C_CARB, C_FAT, C_CAL, C_FoodID, C_SIZE, C_QTY,C_TYPE, C_oid );

		public int insert() { 
			return MYAPP.static_ds.add(TABLE, getValues());
		}

		
		public ContentValues getValues(){
			ContentValues values = new ContentValues();
			values.put(C_oid, this.oid);
			values.put(C_CREATED, this.created);
			values.put(C_TYPE,    this.type);
			values.put(C_FoodID,  this.foodID);
			values.put(C_USERID,  this.userID);
			values.put(C_NAME,    this.name);
			values.put(C_PROTEIN, this.protein);
			values.put(C_CARB,    this.carb);
			values.put(C_FAT,     this.fat);
			values.put(C_CAL,     this.cal);
			values.put(C_SIZE,    this.size);
			values.put(C_QTY,     this.qty);
			
			return values;
		} 
		
		public void setInfo(Cursor c){ 		
	 		 this.oid         =  c.getInt(c.getColumnIndex(C_oid));
	 		 this.id          =  c.getInt(c.getColumnIndex(C_ID));
			 this.created     =  c.getString(c.getColumnIndex(C_CREATED));
			 this.type        =  c.getString(c.getColumnIndex(C_TYPE));
			 this.foodID      =  c.getInt(c.getColumnIndex(C_FoodID));
			 this.userID      =  c.getInt(c.getColumnIndex(C_USERID));			 			 
			 this.name        =  c.getString(c.getColumnIndex(C_NAME));			 			 			 
			 this.protein     =  c.getDouble(c.getColumnIndex(C_PROTEIN));
			 this.carb        =  c.getDouble(c.getColumnIndex(C_CARB));
			 this.fat         =  c.getDouble(c.getColumnIndex(C_FAT));
			 this.cal         =  c.getDouble(c.getColumnIndex(C_CAL));			 
			 this.size        =  c.getString(c.getColumnIndex(C_SIZE));
			 this.qty         =  c.getInt(c.getColumnIndex(C_QTY));			 
		}
		
		public void setLastId(){	
			if(this.id > 0){				
			}else{
				Cursor cursor = MYAPP.static_ds.rawQuery("SELECT *FROM " + TABLE
						+ " ORDER BY " + C_ID +" DESC LIMIT 1 ", null);					
				if(cursor.getCount() > 0){  
					cursor.moveToFirst(); 				
					   this.id =  cursor.getInt(cursor.getColumnIndex(C_ID));
				}
			}
		}
		
		
		
		public void update() { 
			setLastId();
			MYAPP.static_ds.update(TABLE, getValues(), C_ID, String.valueOf( this.id ) );
		} 

	}
  
  
 
//this record contains our list of foods
 class Foods{  
	public int oid;
    public static final String C_oid = "oid";
 	public int id;
 	public int foodID; // actual foodID online
 	public String created;
 	public String NDB_No; // alphanumeric id
 	public String name;
 	public String FdGrp_Cd;
 	public String description;
 	public String company;
 	public String size;
 	public double serving;
 	public double protein;
 	public double carbs;
 	public double fats;
 	public double cal;
 	public double grams;
 	public String search_keywords;
	public int search_order;

 	public static final String TABLE = "foods_fts";
 	//public static final String TABLE = "foods";
 	public static final String C_id              = BaseColumns._ID; 	
 	public static final String C_foodID          = "foodID";
 	public static final String C_created         = "created";
 	public static final String C_NDB_No          = "NDB_No";
 	public static final String C_FdGrp_Cd        = "FdGrp_Cd";
 	public static final String C_name            = "name";
 	public static final String C_description     = "description";
 	public static final String C_company         = "company";
 	public static final String C_serving         = "serving";
 	public static final String C_protein         = "protein";
 	public static final String C_carbs           = "carbs";
 	public static final String C_fats            = "fats";
 	public static final String C_cal             = "cal";
 	public static final String C_grams           = "grams";
 	public static final String C_size            = "size"; 	
 	public static final String C_search_keywords = "search_keywords";
 	public static final String C_search_order    = "search_order";
 	

 	public static final String CREATE_TABLE = String
		.format("create VIRTUAL TABLE  %s "
				+ " USING fts3 (%s integer primary key autoincrement,%s int,%s int,%s text, %s text, %s text,%s text,%s text,%s text,%s text,"
				+ "   %s double, %s double,%s double, %s double, %s double, %s double,%s text,%s int )",
				TABLE, C_id,C_oid, C_foodID, C_created, C_NDB_No, C_FdGrp_Cd,
				C_name, C_description, C_company, C_size, C_protein,
				C_carbs, C_fats, C_cal, C_grams, C_serving,C_search_keywords,C_search_order);
 	
 	public static final String CREATE_TABLE_OLD = String
 			.format("create table %s "
 					+ "(%s integer primary key autoincrement,%s int,%s int,%s text, %s text, %s text,%s text,%s text,%s text,%s text,"
 					+ "   %s double, %s double,%s double, %s double, %s double, %s double )",
 					TABLE, C_id,C_oid, C_foodID, C_created, C_NDB_No, C_FdGrp_Cd,
 					C_name, C_description, C_company, C_size, C_protein,
 					C_carbs, C_fats, C_cal, C_grams, C_serving);

 	
 	public void setInfo(Cursor c){
 		 this.id          =  c.getInt(c.getColumnIndex(C_id));
 		 this.oid         =  c.getInt(c.getColumnIndex(C_oid));
		 this.created     =  c.getString(c.getColumnIndex(C_created)) ;
		 this.foodID      =  c.getInt(c.getColumnIndex(C_foodID)) ;
		 this.NDB_No      =  c.getString(c.getColumnIndex(C_NDB_No)) ;
		 this.FdGrp_Cd    =  c.getString(c.getColumnIndex(C_FdGrp_Cd)) ;
		 this.name        =  c.getString(c.getColumnIndex(C_name)) ;
		 this.description =  c.getString(c.getColumnIndex(C_description)) ;
		 this.company     =  c.getString(c.getColumnIndex(C_company)) ;
		 this.serving     =  c.getDouble(c.getColumnIndex(C_serving)) ;
		 this.protein     =  c.getDouble(c.getColumnIndex(C_protein)) ;
		 this.carbs       =  c.getDouble(c.getColumnIndex(C_carbs)) ;
		 this.fats        =  c.getDouble(c.getColumnIndex(C_fats)) ;
		 this.cal         =  c.getDouble(c.getColumnIndex(C_cal)) ;
		 this.grams       =  c.getDouble(c.getColumnIndex(C_grams)) ;
		 this.size        =  c.getString(c.getColumnIndex(C_size)) ;
		 this.search_keywords  =  c.getString(c.getColumnIndex(C_search_keywords)) ;
		 this.search_order     =  c.getInt(c.getColumnIndex(C_search_order)) ;
	}
 	
 	public int insert() {
 		if (MYAPP.static_ds.Exists(C_foodID, Integer.toString(this.foodID))) {
 			Log.d("Foods TABLE", "Duplicate food id " + this.foodID + " found!");
 			return 0;
 		} else {
 			ContentValues values = new ContentValues();
 			values.put(C_oid, this.oid);
 			values.put(C_created, this.created);
 			values.put(C_foodID, this.foodID);
 			values.put(C_NDB_No, this.NDB_No);
 			values.put(C_FdGrp_Cd, this.FdGrp_Cd);
 			values.put(C_name, this.name);
 			values.put(C_description, this.description);
 			values.put(C_company, this.company);
 			values.put(C_serving, this.serving);
 			values.put(C_protein, this.protein);
 			values.put(C_carbs, this.carbs);
 			values.put(C_fats, this.fats);
 			values.put(C_cal, this.cal);
 			values.put(C_grams, this.grams);
 			values.put(C_size, this.size); 			
 			values.put(C_search_keywords, this.search_keywords);
 			values.put(C_search_order, this.search_order); 			 					 
 			return MYAPP.static_ds.add(TABLE, values);
 		}
 	}

 	public void loadJson(Context context, int page, int count) {
 		new Json(context, page, count, this).execute();
 	}

 	class Json extends AsyncTask<String, Void, String> {
 		private String api_url;
 		String TAG = "Load food API";
 		Context context;
 		public int page;
 		public int count;
 		public int expected_total_size = 50000;
 		Foods food; 

 		public Json(Context context,  int page, int count, Foods f) { 
 			MYAPP.static_ds._table = Foods.TABLE;
 			MYAPP.static_ds._id = Foods.C_id;
 			this.food = f;
 			this.page = page;
 			this.count = count;
 			this.context = context;
 			this.api_url = MYAPP.API_BASE + "?reload=1&method=get_foods&page="
 					+ page + "&count=" + count;
 			Log.d(TAG, "Loading JSON " + this.api_url);
 		}

 		@Override
 		protected String doInBackground(String... params) {
 			HttpClient httpclient = new DefaultHttpClient();
 			HttpPost httppost = new HttpPost(this.api_url);

 			try {
 				HttpResponse response = httpclient.execute(httppost);
 				InputStream is = response.getEntity().getContent();
 				BufferedReader in = new BufferedReader(new InputStreamReader(is));
 				String line;
 				StringBuilder total = new StringBuilder();

 				while ((line = in.readLine()) != null) {
 					total.append(line);
 				}

 				String output = total.toString();

 				try {
 					JSONObject json = new JSONObject(output);
 					String total_records = json.get("total").toString();
 					String current_rows = json.get("rows").toString();
 					JSONArray array = json.getJSONArray("data");

 					InsertHelper ih = new InsertHelper(MYAPP.static_ds.db, Foods.TABLE);
 					final int col1 = ih.getColumnIndex(Foods.C_foodID);
 					final int col2 = ih.getColumnIndex(Foods.C_name);
 					final int col3 = ih.getColumnIndex(Foods.C_company);
 					final int col4 = ih.getColumnIndex(Foods.C_grams);
 					final int col5 = ih.getColumnIndex(Foods.C_size);
 					final int col6 = ih.getColumnIndex(Foods.C_serving);
 					final int col7 = ih.getColumnIndex(Foods.C_cal);
 					final int col8 = ih.getColumnIndex(Foods.C_fats);
 					final int col9 = ih.getColumnIndex(Foods.C_protein);
 					final int col10 = ih.getColumnIndex(Foods.C_carbs);
 					//final int col11 = ih.getColumnIndex(Foods.C_search_keywords);
 					//final int col12 = ih.getColumnIndex(Foods.C_search_order);
 					final int size = array.length();

 					try {
 						// food.dbHelper.getReadableDatabase().setLockingEnabled(false);
 						for (int i = 0; i < size; i++) {
 							String str = array.get(i).toString();
 							String[] tokens = str.split("\\|"); 
 							Log.d(TAG, "INSERT FOOD::::: > #" + tokens[0]);

 							ih.prepareForInsert();
 							ih.bind(col1, tokens[0]);
 							ih.bind(col2, tokens[1]);
 							ih.bind(col3, tokens[2]);
 							ih.bind(col4, tokens[3]);
 							ih.bind(col5, tokens[4]);
 							ih.bind(col6, tokens[5]);
 							ih.bind(col7, tokens[6]);
 							ih.bind(col8, tokens[7]);
 							ih.bind(col9, tokens[8]);
 							ih.bind(col10, tokens[9]);
                            //ih.bind(col11, tokens[10]);
                            //ih.bind(col12, tokens[11]);
 							ih.execute();
 							// {$row["id"]}|{$row["name"]}|{$row["company"]}|{$row["grams"]}|{$row["size"]}|{$row["serving"]}|{$row["calories"]}|{$row["fat"]}|{$row["protein"]}|{$row["carbs"]}
 						}
 					} finally {
 						// food.dbHelper.getReadableDatabase().setLockingEnabled(true);
 						ih.close(); // See comment below from Stefan Anca
 					}
 					Log.d(TAG, "ONLINE TOTAL RECORDS ::::: >" + total_records);
 					Log.d(TAG,"Total rows of local foods db ::::>" + MYAPP.static_ds.count() );
 				} catch (Exception e) {
 					Log.e(TAG, "Food Json parser error..", e);
 					return "";
 				}

 				return "ok";
 			} catch (ClientProtocolException e) {
 				Log.e(TAG, "::ERROR::", e);
 				e.printStackTrace();
 			} catch (IOException e) {
 				Log.e(TAG, "::ERROR::", e);
 				e.printStackTrace();
 			}
 			return "";
 		}

 		@Override
 		protected void onPostExecute(String result) {
 			super.onPostExecute(result);

 			if (result != "") {
 				if (this.expected_total_size >= (this.count * (this.page + 1)) ) {
 					//&& page + 1 <= 3
 					Log.d(TAG, "Restarting loadJson to " + (this.page + 1) + "........");
 					food.loadJson(context,  page + 1, count);
 				}
 			}
 		}
 	}

 }
 
 
 
 
 
 
 
 
 