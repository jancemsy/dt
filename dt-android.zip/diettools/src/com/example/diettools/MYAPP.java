package com.example.diettools;

 
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.ParseException;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

public class MYAPP extends Application { 
    public static Activity static_activity;
    public static Datasource2 static_ds;
	static final int LOGIN_PTS             = 5;
	static final int INPUT_FOOD_PTS        = 1;
	static final int INPUT_EXERCISE_PTS    = 1; 
	static final int COMMENT_ARTICLE_PTS   = 5;
	static final int RATING_RECIPE_PTS     = 3;
	static final int COMMENT_RECIPE_PTS    = 5;
	static final int ADD_JOURNAL_PTS       = 5;
	static final int SHARE_FB_PTS          = 10; //facebook
	static final int SHARE_SU_PTS          = 10; //stumble upon
	static final int SHARE_TWITTER_PTS     = 10; //twitter
	static final int SHARE_GOOGLE_PTS      = 10; //google plus
	static final int REACH_5_FRIENDS_PTS   = 5;
	static final int REACH_10_FRIENDS_PTS  = 10;
	static final int REACH_20_FRIENDS_PTS  = 20;
	static final int REACH_50_FRIENDS_PTS  = 50;
	static final int REACH_100_FRIENDS_PTS = 100;		
	static final int UNREAD                = -1;
	static final int READ                  = 1;        
	static final int DELETED               = 0;
	static final int SHARE_PRIVATE         = 1;
	static final int SHARE_FRIENDS         = 2;
	static final int SHARE_ALL             = 3; 	
	
	static final String TAG = "Diet Tools APPlication";
	//static final String API_BASE = "http://dt.liquidapogeedev.com/_____api.php";	
    //static final String API_BASE = "http://10.0.2.2/LAD/dpp/_____api.php";    
	static final String API_BASE = "http://diettools.com/_____api.php"; 
    static final String SITE_URL = "http://diettools.com/";
	   
	Intent newIntent;
	Activity newact;
	Activity myactivity;
	Users user;
	Datasource2 ds;
	TabHost tabhost;
	Syncher downloader; 	
	public int    tid           = 0; /*use to delete an item by id*/
	public double today_cal     = 0.0;  
	public double today_burned  = 0.0;
	public double today_eaten   = 0.0; 
	public long daily_cap       = 0; 
	public int currentTab       = 0; //0-exercise 1- food 2-mind 3-body   
	public int userID;
	public int inboxCount       = 0; 
	public String exercise_type = "cardio"; 
	public String dateString;
	public String orig_username;
	public String orig_email;  	
	public String _bmi_result1 = "";
	public String _bmi_result2 = ""; 
	public String _bmr_result1 = "";
	public String _bmr_result2 = "";
	public String _bmr_result3 = "";
	public String _bmr_result4 = "";
	public String _bmr_result5 = "";
	public String _bmr_result6 = "";  
	public String _ibw_result1 = "";
	public String _ibw_result2 = ""; 
	public String _message_id = "";	   
	public Double _exercise_met = 0.0;
	public int    _exercise_id = 0;
	public String _exercise = "";
	public String _exercise_result1 = "";
	public String _exercise_result2 = "";
	public String _exercise_result3 = "";
	public String _exercise_result4 = "";
	public String _exercise_result5 = "";
	public String _exercise_result6 = "";  
	public String _to_add_duration = "";
	public String _to_add_burned = "";  
	public String _food_type = "";
	public String _food_name = "";
	public String _food_id = ""; 
	public String _to_add_food = "";
	public String _to_add_foodID = "";
	public String _to_edit_food_ID = ""; /*actual userfoods.id not userfoods.foodID */	
	public String _to_edit_exercise_ID = ""; /*actual userexercises.id */	
	public String _to_add_foodP = "";
	public String _to_add_foodC = "";
	public String _to_add_foodF = "";
	public String _to_add_foodCAL = "";
	public String _to_add_foodS = ""; 
	public String _current_journal_id = "";  
	public String _to_add_journal_title  = "";
	public String _to_add_journal_text   = "";
	public String _to_add_journal_date   = ""; 
	public String _gallery_item_id     = "";
	public String _profile_tab         = "";	
	public String _otheruserid         = "";
	
	/*
	public String _to_add_journal_height = "";
	public String _to_add_journal_weight = "";
	public String _to_add_journal_arms   = "";
	public String _to_add_journal_chest  = "";
	public String _to_add_journal_waist  = "";
	public String _to_add_journal_hips   = "";
	*/
	
	// SharedPreferences prefs;
	// String time_text; 
	Calendar calendar;
	static String Months[] = {  "", "January", "February", "March", "April",
			"May", "June", "July", "August", "September", "October",
			"November", "December" };
	static String Weeks[] = {  "", "Sunday","Monday", "Tuesday", "Wednesday", "Thursday",
			"Friday", "Saturday"   };

	public void onCreate() {
		  try {
		        Class.forName("android.os.AsyncTask");
		  } catch (ClassNotFoundException e) {
		    	
		  }
		    
		super.onCreate();
		user       = new Users();
		calendar   = Calendar.getInstance();
		dateString = getDateString();	 
		// calendar.setTimeZone(TimeZone.getTimeZone("gmt"));
		// calendar.setTime();
		// .getTime()

		// TimeZone.getTimeZone("gmt")
		// our global prefs
		// prefs = PreferenceManager.getDefaultSharedPreferences(this);
		// prefs.registerOnSharedPreferenceChangeListener(this);
		// time_text = prefs.getString("time_text", ""); 
	}
	
	public void initDs(Datasource2 d){
		static_ds = d;
	}
	
	public void init(Activity act){
		ds =  static_ds;
		myactivity = act;
		static_activity = act;
	}

	public Date getDate(){
		return calendar.getTime();
	}	
	
	public String getDateString(){		
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String newFormat = formatter.format( getDate() );        
		return newFormat;
	}
	
	public static long dateToLong( String str_date)  {
		long longDate = 0; 
		  try {		     
			 SimpleDateFormat formatter; 
		     Date date ; 
		     formatter = new SimpleDateFormat("yyyy-MM-dd"); 
		     try {
				date = formatter.parse(str_date);
				Calendar cal = Calendar.getInstance();
				cal.setTime(date);
				//longDate = date.getTime();
				longDate = cal.getTimeInMillis();
			} catch (java.text.ParseException e) { 
				e.printStackTrace();
			} 
		    	     		 
		  }catch (ParseException e){
		    
		  }  
		  return longDate;		  
    }
	
	
	public double getExerciseTotalDuration(){
		String res1 = ds.getResult("SELECT SUM(" + UserExercises.C_DURATION + ") FROM " + UserExercises.TABLE
	    		+ " WHERE   " + UserExercises.C_USERID + " = '" + userID + "' ");		    
	     
	    return parseDoubleOrNull(res1);
	}
	
	
	public double getExerciseTotalBurned(){
		String res1 = ds.getResult("SELECT SUM(" + UserExercises.C_BURNED + ") FROM " + UserExercises.TABLE
	    		+ " WHERE   " + UserExercises.C_USERID + " = '" + userID + "' ");		    
	     
	    return parseDoubleOrNull(res1);
	}
	
	
	public void updateInboxCount(){ 
		Cursor c = ds.rawQuery("SELECT COUNT(*) as num FROM  " + Messages.TABLE + " WHERE " + Messages.C_recipient + " = " + userID + " AND "+ Messages.C_status + " = " + UNREAD , null);						
		if ( c.getCount() > 0 ) {
			 c.moveToFirst();	        	    
			 inboxCount =  c.getInt(c.getColumnIndex("num"));							 			 
	    } 
		
		if(myactivity.findViewById(R.id.txtinbox_num) != null){				 
		   ((TextView) myactivity.findViewById(R.id.txtinbox_num)).setText(String.valueOf(inboxCount));
		}
		
	}
	
	
	public void updateHeaderValues(){ 		
		((TextView) myactivity.findViewById(R.id.txtinbox_num)).setText(String.valueOf(inboxCount));
		
		String res1 = ds.getResult("SELECT SUM(" + UserFoods.C_CAL + ") FROM " + UserFoods.TABLE
	    		+ " WHERE " + UserFoods.C_CREATED + " = '" + dateString + "'"
	    		+ " AND " + UserFoods.C_USERID + " = '" + userID + "' ");		    
	    
	    String res2 = ds.getResult("SELECT SUM(" + UserExercises.C_BURNED + ") FROM " + UserExercises.TABLE
	    		+ " WHERE " + UserExercises.C_CREATED + " = '" + dateString + "'"
	    		+ " AND " + UserExercises.C_USERID + " = '" + userID + "' ");

	    today_eaten = parseDoubleOrNull(res1);
	    today_burned = parseDoubleOrNull(res2);
	    today_cal = today_eaten - today_burned;	  
	    daily_cap = user.getCAP(today_burned);
	    	    
	    //Header textviews //this will be displayed in all the screens 
	    ((TextView) myactivity.findViewById(R.id.txt_cal_today)).setText( String.valueOf(today_cal)  );	   
	    ((TextView) myactivity.findViewById(R.id.txt_daily_cap)).setText( String.valueOf(daily_cap)  );
	}
	
	/*
	public void changeDateHeader(String msg) {
		TextView txt = (TextView) myactivity.findViewById(R.id.header_date);
		txt.setText(msg);
	}
	*/
	      
	public void updateDateHeader() {
		int month = calendar.get(Calendar.MONTH) + 1; //begins at 0 lol fucking java
		int day   = calendar.get(Calendar.DAY_OF_MONTH);
		int year  = calendar.get(Calendar.YEAR);
		int week  = calendar.get(Calendar.DAY_OF_WEEK);				
		String msg = Weeks[week] + " / " + Months[month] + " " + day + ", " + year; //+ "===" + dateString ;
		TextView txt = (TextView) myactivity.findViewById(R.id.header_date);
		txt.setText(msg);
	}
	
	public void moveNext() {				
		calendar.add(Calendar.DATE, +1); 
		dateString = getDateString();
		updateDateHeader();
		updateHeaderValues(); 
	}

	public void movePrev() {			
		calendar.add(Calendar.DATE, -1);
		dateString = getDateString();
		updateDateHeader(); 
		updateHeaderValues();
	}

	public void setDateButtonListeners() {  		
		updateDateHeader();

		((Button) myactivity.findViewById(R.id.btnArrowLeft))
				.setOnClickListener(new OnClickListener() {
					// @Override
					public void onClick(View view) {
						Log.d(TAG, "clicked arrow left");
						movePrev();
					}
				});

		((Button) myactivity.findViewById(R.id.btnArrowRight))
				.setOnClickListener(new OnClickListener() {
					// @Override
					public void onClick(View view) {
						Log.d(TAG, "clicked arrow right");
						moveNext();
					}
				});
	}

	public void initMenu() {

	}

	public void jumpActivityOnClick(int btnId,   Class<?> cls) {						
		 newIntent = new Intent(myactivity, cls); 
		((Button) myactivity.findViewById(btnId)) .setOnClickListener(new MyClickListener(myactivity,  newIntent));
	}
	
	

	/*
	 * new OnClickListener() {
	 * 
	 * //@Override public void onClick(View view) { newact.startActivity(
	 * newIntent ); } }
	 */

	private class MyClickListener implements OnClickListener {
		private Intent intent;
		private Activity newact;

		public MyClickListener(Activity act, Intent intent) {
			this.intent = intent;
			this.newact = act;
		}

		public void onClick(View v) {
			switch(v.getId()){
			  case R.id.MenuBtn1:
				    currentTab = 0;
				    v.setBackgroundResource(R.drawable.dashboard_btn_0_click);
		      break;
			  case R.id.MenuBtn2:
				    currentTab = 0;
				    v.setBackgroundResource(R.drawable.dashboard_btn_1_click);
		      break;
			  case R.id.MenuBtn3:
				    currentTab = 0;
				    v.setBackgroundResource(R.drawable.dashboard_btn_2_click);
		      break;
			  case R.id.MenuBtn4:
				    currentTab = 0;
				    v.setBackgroundResource(R.drawable.dashboard_btn_3_click);
		      break;
			  case R.id.MenuBtn5:
				    currentTab = 0;
				    v.setBackgroundResource(R.drawable.dashboard_btn_4_click);
		      break;
			}
			
			this.newact.startActivity(this.intent);
		}          
	}

	public void openscreen( Class<?> cls) {
		Intent newIntent = new Intent( myactivity , cls);
		myactivity.startActivity(newIntent);
	}

	public void SetMainMenuListeners() {						
		jumpActivityOnClick(R.id.MenuBtn1, DashboardActivity.class);	 
		jumpActivityOnClick(R.id.MenuBtn2, JournalsActivity.class);
		jumpActivityOnClick(R.id.MenuBtn3, ToolsActivity.class);
		//jumpActivityOnClick(R.id.MenuBtn4, MessagesActivity.class);
		jumpActivityOnClick(R.id.MenuBtn4, MessagesInboxActivity.class);
		jumpActivityOnClick(R.id.MenuBtn5, ProfileActivity.class);
		updateHeaderValues(); 		
	}

	public void changeMainHeader(String msg ) {
		TextView txt = (TextView) myactivity.findViewById(R.id.header_main);
		txt.setText(msg);	 
	}



	public void flash(final String msg) { 
		new Runnable() {
			public void run() {
				Toast.makeText(MYAPP.this, msg, Toast.LENGTH_SHORT).show();
			}
		}.run();
	}
	
	public void alertbox(String msg){
		AlertDialog ad = new AlertDialog.Builder(myactivity).create(); 
		ad.setCancelable(false); // This blocks the 'BACK' button
		ad.setMessage(msg);
		ad.setButton("OK", new DialogInterface.OnClickListener() {
		    @Override
		    public void onClick(DialogInterface dialog, int which) {
		        dialog.dismiss();                    
		    }
		});
		ad.show(); 
	}
	
	

	public static String urlencode(String str) {
		String res = "";		
		try {
			res = java.net.URLEncoder.encode(str, "utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}
	
	public static String urldecode(String str)  {
		String res = "x";		
		try {
			res = java.net.URLDecoder.decode(str, "utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}
	
	
	public static String getWebString(InputStream is) throws IOException {
		String line = "";
		StringBuilder total = new StringBuilder();
		// Wrap a BufferedReader around the InputStream
		BufferedReader rd = new BufferedReader(new InputStreamReader(is));
		// Read response until the end
		while ((line = rd.readLine()) != null) {
			total.append(line);
		}
		// Return full string
		return total.toString();
	}

	public static String formatDateTime(Context context, String timeToFormat) {
		String finalDateTime = "";
		SimpleDateFormat iso8601Format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		Date date = null;
		if (timeToFormat != null) { 
			try {
				date = iso8601Format.parse(timeToFormat);
			} catch (ParseException e) {
				date = null;
			} catch (java.text.ParseException e) {  
				e.printStackTrace();
			}

			if (date != null) {
				long when = date.getTime();
				int flags = 0;
				flags |= android.text.format.DateUtils.FORMAT_SHOW_TIME;
				flags |= android.text.format.DateUtils.FORMAT_SHOW_DATE;
				flags |= android.text.format.DateUtils.FORMAT_ABBREV_MONTH;
				flags |= android.text.format.DateUtils.FORMAT_SHOW_YEAR;

				finalDateTime = android.text.format.DateUtils.formatDateTime(
						context, when + TimeZone.getDefault().getOffset(when),
						flags);
			}
		}
		return finalDateTime;
	}
	
	
	public void goToDashboard(){
		Intent newIntent = new Intent(myactivity,DashboardActivity.class);
		myactivity.startActivity(newIntent);
	}
	
	
	
	
   public void addPoints(int points, String msg, int tid , double min, double burned){	
	    Points p  = new Points(); 
	    p.userID  = this.userID;
	    p.points  = points;
	    p.message = msg;
	    p.tid     = tid;	    
	    p.burned  = burned;
	    p.minutes = min;	    	    	  	    
	    p.insert(); 
	    
	    user.points = user.points + points ;
	    user.update();	     
   }
	
	
    public void removePoints(int points,String msg, int tid){	
	  ds.db.delete(Points.TABLE, Points.C_userid + " = "+  user.id + " AND "  + 
			Points.C_message + "='" + msg + "' AND " + Points.C_tid + " = " + tid  , null);		
	  user.points = user.points - points ;
      user.update();        
    }	   
	
	
	public static String add0(int i){
		if(i > 9) return String.valueOf(i);
		else return "0" + String.valueOf(i);
	}
  
	
	/*parsers ---------------------------------------------*/
	
	public static boolean isNumericOrEmtpy(String str)  
	{  
		if(str.length() == 0) return true;
		else return isNumeric(str);  
	}
	  
	
	public static boolean isNumeric(String str)  
	{  
	  try  
	  {  
	    Double.parseDouble(str);  
	  }  
	  catch(NumberFormatException nfe)  
	  {  
	    return false;  
	  }  
	  return true;  
	} 
	
	public static double parseDoubleOrNull(String str) {
	    return str != null && ! MYAPP.isEmpty(str) ? Double.parseDouble(str) : 0.0;
	}
	
	public static int toInt(String str){
		if(str.length() == 0) return 0;
		else  return Integer.parseInt(str);
	}
	
	public static double toDouble(String str){
		if(str.length() == 0) return 0.0;
		else return Double.parseDouble(str);
	}  
	
	double roundTwoDecimals(double d) {
    	DecimalFormat twoDForm = new DecimalFormat("#.##");
	    return Double.valueOf(twoDForm.format(d));
   }
	
	
	public static String NOW(){
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
		Date date = new Date();		
		return  dateFormat.format(date);		
	}
	
	
	public static String md5(String string) {
	    byte[] hash;

	    try {
	        hash = MessageDigest.getInstance("MD5").digest(string.getBytes("UTF-8"));
	    } catch (NoSuchAlgorithmException e) {
	        throw new RuntimeException("Huh, MD5 should be supported?", e);
	    } catch (UnsupportedEncodingException e) {
	        throw new RuntimeException("Huh, UTF-8 should be supported?", e);
	    }

	    StringBuilder hex = new StringBuilder(hash.length * 2);

	    for (byte b : hash) {
	        int i = (b & 0xFF);
	        if (i < 0x10) hex.append('0');
	        hex.append(Integer.toHexString(i));
	    }

	    return hex.toString();
	}
	
	public static boolean isEmpty(String text) {
		return text == null ? true : text.equals("");
	}
	
	
	public static boolean isConnected(Context context) {
	    ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
	    NetworkInfo netInfo = cm.getActiveNetworkInfo();
	    if (netInfo != null && netInfo.isConnected()) {
	        return true;
	    }
	    return false;
	}
	 

}
