package com.example.diettools;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
  
public class RegistrationStep1Activity extends Activity {
	MYAPP me;
	EditText txtregemail;
	EditText txtregusername;
	EditText txtregpassword;
	EditText txtregpassword2;	 
	String password2;
  
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.registration_step1);
		me              = (MYAPP) getApplication();		
		me.init(this);				
		txtregemail     = (EditText) findViewById(R.id.txtregemail); 
		txtregusername  = (EditText) findViewById(R.id.txtregusername);
		txtregpassword  = (EditText) findViewById(R.id.txtregpassword);
		txtregpassword2 = (EditText) findViewById(R.id.txtregpassword2);
		me.user = new Users();		        		 	
		
		

		Button btnregsubmit = (Button) findViewById(R.id.btnregsubmit); 		 	
		btnregsubmit.setOnClickListener(new OnClickListener() {
            // @Override
			public void onClick(View view) {
				me.user.email    = txtregemail.getText().toString();
				me.user.username = txtregusername.getText().toString();
				me.user.password = txtregpassword.getText().toString();						        
		        password2 = txtregpassword2.getText().toString();
		        
				if( !me.user.password.equals(password2) ){
					  me.alertbox("Confirm password didn't match");		
				}else if( 
						  me.user.email.equals("") ||
						  me.user.username.equals("") ||
						  me.user.password.equals("") ){															
					  me.alertbox("Fields can't be blank!");		
				}else{
					  new RegValidationStep1().execute();	  
				}										
			}   
		});   
		
    }
	
	
	class RegValidationStep1 extends AsyncTask<String, Void, String> { 
		ProgressDialog progress;
		String TAG = "RegValidationStep1";
		
		@Override
	    protected void onPreExecute() {
		        progress = ProgressDialog.show(RegistrationStep1Activity.this , "", "Please wait..."); 
		        super.onPreExecute();
		 }

		
		@Override
		protected String doInBackground(String... params) { 
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(10);		
			nameValuePairs.add(new BasicNameValuePair("method", "validate_email_username"));									
			nameValuePairs.add(new BasicNameValuePair("email", me.user.email));
			nameValuePairs.add(new BasicNameValuePair("username", me.user.username));							
			
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(MYAPP.API_BASE);

			try {
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = httpclient.execute(httppost);
				String output = MYAPP.getWebString(response.getEntity().getContent());
				Log.d(TAG, "API Connection Result: \n" + output); 
				return output;
			} catch (ClientProtocolException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} catch (IOException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} 
			return "";
		}

		
		@Override  
		protected void onPostExecute(String result) {
			super.onPostExecute(result);	 
			if(result.length() == 0){     
				progress.dismiss();  
				me.flash("Error occured, Please try again!");
			}else{			 					
					try{																	
			            JSONObject json = new JSONObject(result);
			            if( MYAPP.isEmpty(json.get("error").toString()) ) {			            				            
			               me.openscreen(RegistrationStep2Activity.class);			             		
			            }else{
			               me.alertbox(json.get("error").toString());  	 
			            }
				    } catch (Exception e) {
				    	Log.e(TAG, "User Json parser error..", e); 
				    } 
				    
				    progress.dismiss();							
			}  
		}
} 
	
	
	

}
