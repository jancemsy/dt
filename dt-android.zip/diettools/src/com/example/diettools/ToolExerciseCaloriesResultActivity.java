package com.example.diettools;


import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class ToolExerciseCaloriesResultActivity extends Activity{
	MYAPP me; 
	TextView txtexercise;
	TextView txtresult;
	TextView txtdetails;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.exercisetracker_result);			
		me = (MYAPP)getApplication(); 
		me.init(this);
		me.SetMainMenuListeners();
				
		txtexercise = (TextView) findViewById(R.id.txtexercise);
		txtresult   = (TextView) findViewById(R.id.txtresult);
		txtdetails  = (TextView) findViewById(R.id.txtdetails);  
				 
		txtexercise.setText(me._exercise);
		String details = "height: " +  me._exercise_result2 + "in , weight: " +me._exercise_result3 + 
		"lbs, age: "+ me._exercise_result4 +", minutes: " +  me._exercise_result5;
		txtdetails.setText(details);
		String cal = String.valueOf( me.roundTwoDecimals(Double.parseDouble(me._exercise_result1)) );
	    txtresult.setText( "calories is " + cal);						    	     
	    me.jumpActivityOnClick(R.id.btnback, ToolsActivity.class);
	}
 
}
