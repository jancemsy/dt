package com.example.diettools;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.database.Cursor;
import android.database.DatabaseUtils.InsertHelper;
import android.util.Log;

public class Syncher {
	public static String TAG = "%%%%%%%%%%%%%%%%%%%%%%%%%%Downloader%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"; 
	public String username;
	public String password;
	int userID;
	MYAPP me;

	public Syncher() { 
		DownloadUserInfo(); 
		DownloadUserPoints();
		DownloadGallery();
		DownloadUserFriendsInfo(); /*get UserFriends Info*/
		DownloadUserFriends(); /*Get UserFriends ID*/
		DownloadUserExercises();
		DownloadUserFoods();		
		DownloadMessages();
		DownloadJournal(); 
	}	
	
	private static String GetOids(String table){
		Cursor c = MYAPP.static_ds.rawQuery("SELECT oid FROM  "+ table, null);
		String oids = "-1";
		if (c.getCount() > 0) {
			c.moveToFirst();
			do {
				oids = oids + "," + c.getString(c.getColumnIndex("oid"));
			} while (c.moveToNext());
		}
		return oids; 
	}
	
	public static void DeleteFood(int oid){ 
		if( oid > 0){
			MYAPP me = (MYAPP) MYAPP.static_activity.getApplication();	   
			me.tid = oid;
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(20);		
			nameValuePairs.add(new BasicNameValuePair("oid",String.valueOf(oid)));
			ApiCaller api = new ApiCaller(nameValuePairs, "deleteFood",1);	  		
		    api.setReadyListener(new ApiCaller.OnReadyListener() {
				@Override
				public void onReady(String result){					
					MYAPP me = (MYAPP) MYAPP.static_activity.getApplication();	 
					MYAPP.static_ds.db.delete(UserFoods.TABLE ,  UserFoods.C_oid + "=" +  me.tid, null);
					me.tid  = 0;
					Log.d(TAG, "DeleteFood Callback Success"); 
				} 
			});
		    api.execute();
		}
	}
	
	
	public static void DownloadJournal(){		
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(20);		
		nameValuePairs.add(new BasicNameValuePair("oids", GetOids(UserJournals.TABLE)));
		ApiCaller api = new ApiCaller(nameValuePairs, "downloadjournal");	  		
	    api.setReadyJsonListener(new ApiCaller.OnReadyJsonListener() {
			@Override
			public void onReadyJson(JSONArray jarray) throws JSONException{ 
				InsertHelper ih = new InsertHelper(MYAPP.static_ds.db,UserJournals.TABLE); 
						final int size = jarray.length();
						for (int i = 0; i < size; i++) {	
							        String str = jarray.get(i).toString();
							        JSONObject jsonarray = new JSONObject(str);
									Log.d(TAG, "INSERT USER JOURNL #" + jsonarray.get("id") ); 
									ih.prepareForInsert();
									ih.bind(ih.getColumnIndex(UserJournals.C_oid),Integer.parseInt(jsonarray.get("id").toString()));
									ih.bind(ih.getColumnIndex(UserJournals.C_userID),Integer.parseInt(jsonarray.get("userID").toString()));
									ih.bind(ih.getColumnIndex(UserJournals.C_created),jsonarray.get("created_at").toString());
									ih.bind(ih.getColumnIndex(UserJournals.C_title),jsonarray.get("title").toString());
									ih.bind(ih.getColumnIndex(UserJournals.C_message),jsonarray.get("message").toString());
									ih.bind(ih.getColumnIndex(UserJournals.C_embed),jsonarray.get("embed").toString());
									ih.bind(ih.getColumnIndex(UserJournals.C_picture),jsonarray.get("picture").toString());
									ih.bind(ih.getColumnIndex(UserJournals.C_video),jsonarray.get("video").toString());
									ih.bind(ih.getColumnIndex(UserJournals.C_weight),jsonarray.get("weight").toString());
									ih.bind(ih.getColumnIndex(UserJournals.C_height),jsonarray.get("height").toString());
									ih.bind(ih.getColumnIndex(UserJournals.C_arms),jsonarray.get("arms").toString());
									ih.bind(ih.getColumnIndex(UserJournals.C_chest),jsonarray.get("chest").toString());
									ih.bind(ih.getColumnIndex(UserJournals.C_waist),jsonarray.get("waist").toString());
									ih.bind(ih.getColumnIndex(UserJournals.C_hips),jsonarray.get("hips").toString());
									ih.bind(ih.getColumnIndex(UserJournals.C_bmr),jsonarray.get("bmr").toString());
									ih.bind(ih.getColumnIndex(UserJournals.C_privacy),jsonarray.get("privacy").toString());
									ih.execute(); 
						} 
						ih.close(); 
				Log.d(TAG, "DownloadJournal Callback Success");
				ih.close();
			}
		});
	    api.execute();
	}
	
	public static void DownloadUserInfo(){
		MYAPP me = (MYAPP) MYAPP.static_activity.getApplication();	   
		List<NameValuePair> nameValuePairs2 = new ArrayList<NameValuePair>(20);
		nameValuePairs2.add(new BasicNameValuePair("last_update",me.user.last_update));
		ApiCaller api = new ApiCaller(nameValuePairs2, "downloaduserinfo");	    
	    api.setReadyJsonListener(new ApiCaller.OnReadyJsonListener() {
			@Override
			public void onReadyJson(JSONArray jarray) throws JSONException{
				MYAPP me = (MYAPP) MYAPP.static_activity.getApplication();	   				
						final int size = jarray.length();
						for (int i = 0; i < size; i++) {
							String str = jarray.get(i).toString();
							JSONObject jsonarray = new JSONObject(str);
							me.user              = me.user.UpdateUserInfo(me.user,jsonarray, "");
							me.userID            = me.user.userID;
							me.orig_username     = me.user.username;
							me.orig_email        = me.user.email;   
						} 						
				Log.d(TAG, "Download Userinfo Callback Success");				
			}
		});
	    api.execute();
	}
	
	
	public static void DownloadMessages(){
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(20);		
		nameValuePairs.add(new BasicNameValuePair("oids", GetOids(Messages.TABLE)));
		ApiCaller api = new ApiCaller(nameValuePairs, "downloadmessages");	  		
	    api.setReadyJsonListener(new ApiCaller.OnReadyJsonListener() {
			@Override
			public void onReadyJson(JSONArray jarray) throws JSONException{
				MYAPP me = (MYAPP) MYAPP.static_activity.getApplication(); 
				InsertHelper ih = new InsertHelper(MYAPP.static_ds.db,Messages.TABLE); 
						final int size = jarray.length();
						for (int i = 0; i < size; i++) {	
							        String str = jarray.get(i).toString();
							        JSONObject jsonarray = new JSONObject(str);
									Log.d(TAG, "INSERT Messages #" + jsonarray.get("id") ); 
									ih.prepareForInsert();
									ih.bind(ih.getColumnIndex(Messages.C_oid),Integer.parseInt(jsonarray.get("id").toString()));
									ih.bind(ih.getColumnIndex(Messages.C_recipient),Integer.parseInt(jsonarray.get("recipient").toString()));
									ih.bind(ih.getColumnIndex(Messages.C_sender),jsonarray.get("sender").toString());
									ih.bind(ih.getColumnIndex(Messages.C_subject),jsonarray.get("subject").toString());
									ih.bind(ih.getColumnIndex(Messages.C_message),jsonarray.get("message").toString());
									ih.bind(ih.getColumnIndex(Messages.C_created),jsonarray.get("created_at").toString());
									ih.bind(ih.getColumnIndex(Messages.C_status),jsonarray.get("status").toString());
									ih.execute(); 
						} 
						ih.close();
						me.updateInboxCount();
				Log.d(TAG, "Download Message Callback Success");
				ih.close();
			}
		});
	    api.execute();
	}
	
	
	public static void DownloadUserFoods(){		
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(20);		
		nameValuePairs.add(new BasicNameValuePair("oids", GetOids(UserFoods.TABLE)));
		ApiCaller api = new ApiCaller(nameValuePairs, "downloaduserfoods");	  		
	    api.setReadyJsonListener(new ApiCaller.OnReadyJsonListener() {
			@Override
			public void onReadyJson(JSONArray jarray) throws JSONException{ 
				InsertHelper ih = new InsertHelper(MYAPP.static_ds.db,UserFoods.TABLE); 
						final int size = jarray.length();
						for (int i = 0; i < size; i++) {	
							        String str = jarray.get(i).toString();
							        JSONObject jsonarray = new JSONObject(str);
									Log.d(TAG, "Insert user foods #" + jsonarray.get("id") ); 
									ih.prepareForInsert();
									ih.bind(ih.getColumnIndex(UserFoods.C_oid),Integer.parseInt(jsonarray.get("id").toString()));
									ih.bind(ih.getColumnIndex(UserFoods.C_USERID),jsonarray.get("userID").toString());
									ih.bind(ih.getColumnIndex(UserFoods.C_CREATED),jsonarray.get("date").toString());
									ih.bind(ih.getColumnIndex(UserFoods.C_NAME),jsonarray.get("food_name").toString());
									ih.bind(ih.getColumnIndex(UserFoods.C_FoodID),jsonarray.get("foodID").toString());
									ih.bind(ih.getColumnIndex(UserFoods.C_SIZE),jsonarray.get("size").toString());
									ih.bind(ih.getColumnIndex(UserFoods.C_QTY),jsonarray.get("qty").toString());
									ih.bind(ih.getColumnIndex(UserFoods.C_CARB),jsonarray.get("carbs").toString());
									ih.bind(ih.getColumnIndex(UserFoods.C_PROTEIN),jsonarray.get("protein").toString());
									ih.bind(ih.getColumnIndex(UserFoods.C_FAT),jsonarray.get("fat").toString());
									ih.bind(ih.getColumnIndex(UserFoods.C_CAL),jsonarray.get("calories").toString());
									ih.execute(); 
						} 
						ih.close(); 
				Log.d(TAG, "Download User Foods Callback Success");
				ih.close();
			}
		});
	    api.execute();
	}
	
	

	public static void DownloadUserExercises(){		
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(20);		
		nameValuePairs.add(new BasicNameValuePair("oids", GetOids(UserExercises.TABLE)));
		ApiCaller api = new ApiCaller(nameValuePairs, "downloaduserexercises");	  		
	    api.setReadyJsonListener(new ApiCaller.OnReadyJsonListener() {
			@Override
			public void onReadyJson(JSONArray jarray) throws JSONException{ 
				InsertHelper ih = new InsertHelper(MYAPP.static_ds.db,UserExercises.TABLE); 
						final int size = jarray.length();
						for (int i = 0; i < size; i++) {	
							        String str = jarray.get(i).toString();
							        JSONObject jsonarray = new JSONObject(str);
									Log.d(TAG, "Insert user exercise #" + jsonarray.get("id") ); 
									ih.prepareForInsert();
									ih.bind(ih.getColumnIndex(UserExercises.C_oid),Integer.parseInt(jsonarray.get("id").toString()));
									ih.bind(ih.getColumnIndex(UserExercises.C_USERID),jsonarray.get("userID").toString());
									ih.bind(ih.getColumnIndex(UserExercises.C_CREATED),jsonarray.get("date").toString());
									ih.bind(ih.getColumnIndex(UserExercises.C_DURATION),jsonarray.get("duration").toString());
									ih.bind(ih.getColumnIndex(UserExercises.C_BURNED),jsonarray.get("burned").toString());
									ih.bind(ih.getColumnIndex(UserExercises.C_EXERCISE),jsonarray.get("exercise").toString());
									ih.bind(ih.getColumnIndex(UserExercises.C_TYPE),jsonarray.get("type").toString());
									ih.bind(ih.getColumnIndex(UserExercises.C_MET),jsonarray.get("met").toString());
									ih.bind(ih.getColumnIndex(UserExercises.C_EXERCISEID),jsonarray.get("exerciseID").toString());
									ih.bind(ih.getColumnIndex(UserExercises.C_BMR),jsonarray.get("bmr").toString());
									ih.execute(); 
						} 
						ih.close(); 
				Log.d(TAG, "DownloadUser Exercises Callback Success");
				ih.close();
			}
		});
	    api.execute();
	}               
	  
	     
	public static void DownloadUserFriendsInfo(){		
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(20);
		String oids = GetOids(UserFriends.TABLE);
		nameValuePairs.add(new BasicNameValuePair("oids", oids));
		Log.d("DownloadUserFriendsInfo","DownloadUserFriendsInfo Debugging......... oids" + oids);
		ApiCaller api = new ApiCaller(nameValuePairs, "downloaduserfriendsinfo");	  		
	    api.setReadyJsonListener(new ApiCaller.OnReadyJsonListener() {
			@Override  
			public void onReadyJson(JSONArray jarray) throws JSONException{ 				 				
				        Users u = new Users();
						final int size = jarray.length();
						for (int i = 0; i < size; i++) {	
							        String str = jarray.get(i).toString();   
							        JSONObject jsonarray = new JSONObject(str);
									Log.d(TAG, "Insert User friends Info #" + jsonarray.get("id") ); 																																				
									u.UpdateUserInfo(u, jsonarray,"");																		
						} 
				Log.d(TAG, "Download User friends INFO Callback Success");
			}
		});
	    api.execute();
	}
	
	
	public static void DownloadUserFriends(){		
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(20);		
		nameValuePairs.add(new BasicNameValuePair("oids", GetOids(UserFriends.TABLE)));
		ApiCaller api = new ApiCaller(nameValuePairs, "downloaduserfriends");	  		
	    api.setReadyJsonListener(new ApiCaller.OnReadyJsonListener() {
			@Override
			public void onReadyJson(JSONArray jarray) throws JSONException{ 
				InsertHelper ih = new InsertHelper(MYAPP.static_ds.db,UserFriends.TABLE); 
						final int size = jarray.length();
						for (int i = 0; i < size; i++) {	
							        String str = jarray.get(i).toString();
							        JSONObject jsonarray = new JSONObject(str);
									Log.d(TAG, "Insert User Friends #" + jsonarray.get("id") ); 
									ih.prepareForInsert();
									ih.bind(ih.getColumnIndex(UserFriends.C_oid),Integer.parseInt(jsonarray.get("id").toString()));
									ih.bind(ih.getColumnIndex(UserFriends.C_userID),jsonarray.get("userID").toString());
									ih.bind(ih.getColumnIndex(UserFriends.C_friendID),jsonarray.get("friendID").toString());
									ih.execute(); 
						} 
						ih.close(); 
				Log.d(TAG, "Download User friends Callback Success");
				ih.close();
			}
		});
	    api.execute();
	}
	
	
	public static void DownloadGallery(){		
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(20);		
		nameValuePairs.add(new BasicNameValuePair("oids", GetOids(UserGalleries.TABLE)));
		ApiCaller api = new ApiCaller(nameValuePairs, "downloadgallery");	  		
	    api.setReadyJsonListener(new ApiCaller.OnReadyJsonListener() {
			@Override
			public void onReadyJson(JSONArray jarray) throws JSONException{ 
				InsertHelper ih = new InsertHelper(MYAPP.static_ds.db,UserGalleries.TABLE); 
						final int size = jarray.length();
						for (int i = 0; i < size; i++) {	
							        String str = jarray.get(i).toString();
							        JSONObject jsonarray = new JSONObject(str);
									Log.d(TAG, "Insert User Gallery #" + jsonarray.get("id") ); 
									ih.prepareForInsert();
									ih.bind(ih.getColumnIndex(UserGalleries.C_oid),Integer.parseInt(jsonarray.get("id").toString()));
									ih.bind(ih.getColumnIndex(UserGalleries.C_created),jsonarray.get("created_at").toString());
									ih.bind(ih.getColumnIndex(UserGalleries.C_albumID),jsonarray.get("albumID").toString());
									ih.bind(ih.getColumnIndex(UserGalleries.C_userID),jsonarray.get("userID").toString());
									ih.bind(ih.getColumnIndex(UserGalleries.C_caption),jsonarray.get("caption").toString());
									ih.bind(ih.getColumnIndex(UserGalleries.C_file),MYAPP.SITE_URL + jsonarray.get("file").toString());
									ih.bind(ih.getColumnIndex(UserGalleries.C_title),jsonarray.get("title").toString());
									ih.execute(); 
						} 
						ih.close(); 
				Log.d(TAG, "Download Gallery Callback Success");
				ih.close();
			}
		});
	    api.execute();
	}
	
	
	public static void DownloadUserPoints(){		
		List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(20);		
		nameValuePairs.add(new BasicNameValuePair("oids", GetOids(Points.TABLE)));
		ApiCaller api = new ApiCaller(nameValuePairs, "downloaduserpoints");	  		
	    api.setReadyJsonListener(new ApiCaller.OnReadyJsonListener() {
			@Override
			public void onReadyJson(JSONArray jarray) throws JSONException{ 
				InsertHelper ih = new InsertHelper(MYAPP.static_ds.db,Points.TABLE); 
						final int size = jarray.length();
						for (int i = 0; i < size; i++) {	
							        String str = jarray.get(i).toString();
							        JSONObject jsonarray = new JSONObject(str);
									Log.d(TAG, "Insert User Points #" + jsonarray.get("id") ); 
									ih.prepareForInsert();
									ih.bind(ih.getColumnIndex(Points.C_oid),Integer.parseInt(jsonarray.get("id").toString()));
									ih.bind(ih.getColumnIndex(Points.C_points),jsonarray.get("points").toString());
									ih.bind(ih.getColumnIndex(Points.C_userid),jsonarray.get("userID").toString());
									ih.bind(ih.getColumnIndex(Points.C_created),jsonarray.get("date").toString());
									ih.bind(ih.getColumnIndex(Points.C_message),jsonarray.get("message").toString());
									ih.bind(ih.getColumnIndex(Points.C_burned),jsonarray.get("burned").toString());
									ih.bind(ih.getColumnIndex(Points.C_minutes),jsonarray.get("min").toString());
									ih.bind(ih.getColumnIndex(Points.C_tid),jsonarray.get("tid").toString());
									ih.execute(); 
						} 
						ih.close(); 
				Log.d(TAG, "Download User Points Callback Success");
				ih.close();
			}
		});
	    api.execute();
	}
	
	

}
