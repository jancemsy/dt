 package com.example.diettools;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends Activity {
	public static String TAG = "::LOGINACTIVY::";	
	MYAPP me;
	EditText username_txt;
	EditText password_txt; 
	Button sign_in_btn; 
	Datasource2 ds; 

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		me = (MYAPP) getApplication(); 
		//open handler to setup the db intially
		ds = new Datasource2(this);
		me.initDs(ds);      
		me.init(this);		 
		setContentView(R.layout.login);    
		username_txt = (EditText) findViewById(R.id.username_txt);
		password_txt = (EditText) findViewById(R.id.password_txt);
		
		//TODO: delete this later
		username_txt.setText("");
		password_txt.setText(""); 
					
		
		me.jumpActivityOnClick(R.id.create_account_btn, RegistrationStep1Activity.class);
		
		sign_in_btn = (Button) findViewById(R.id.sign_in_btn); 
		 
		sign_in_btn.setOnClickListener(new OnClickListener() {
            // @Override
			public void onClick(View view) {
			
			 
				  login(username_txt.getText().toString(), password_txt.getText().toString()  );											
			}   
		});   
		
		
		
		///BELOW LINE SHOULD GO TO LOGINACTIVITY.JAVA
		//Example loading food runtime//DO NOT DELETE FOR REFERENCE
		/*
		Log.d(TAG, "Foods and exercises json executed....");		 
		Foods food = new Foods();
		food.loadJson(this, 1, 1000);	
		*/
		//Exercises ex = new Exercises();
		//ex.loadJson(this);				
        //*/
		//////////////////////////////////////////////////////////////////////////////////////////////
		
		//Cursor cursor = MYAPP.static_ds.rawQuery("SELECT instr(\"james martinez\",\"mart\") ",null);
		
		
	}  
	   
	
	public void login(String username, String password  ){  
		if( username.length() == 0 || password.length() == 0 ) {
			 me.flash("Invalid Username/Password!");
		} else {
			final String SQL_STATEMENT = "SELECT *FROM " + Users.TABLE 
			+ " WHERE (" + Users.C_username + " =? OR " + Users.C_email + " =?  ) ";
			
			Cursor c = ds.rawQuery( SQL_STATEMENT , new String[] { username,username });			
			                                  
			if ( c.moveToFirst() ) { //if something has match in our local db					
				String passmd5  = c.getString(c.getColumnIndex(Users.C_password));
				//String passmd52 = MYAPP.md5(password);		 				
				if(password == null ? false : passmd5.equals(password) ){      
					me.user.setInfo(c);
					me.userID = me.user.userID;
					me.orig_username = me.user.username;
					me.orig_email    = me.user.email;
					StartService();
					me.goToDashboard(); 
				}else{
					new LoginToSite(username, password).execute();
				} 
			}else{
				new LoginToSite(username, password).execute();	
			}						
		}
	}
	
	public void StartService(){
		me.addPoints(MYAPP.LOGIN_PTS, "login", 0 , 0, 0);
		me.updateInboxCount();				
		Intent myIntent = new Intent(this, MyUpdateService.class);
		startService(myIntent);
	}
	  
	
	class LoginToSite extends AsyncTask<String, Void, String> {
		String username;
		String password; 		
		ProgressDialog progress; 
		
		public LoginToSite(String username, String password  ) {			
			this.username   = username;
			this.password   = password; 
		}

		
		@Override
	    protected void onPreExecute() {
		        progress = ProgressDialog.show(LoginActivity.this , "", "Please wait..."); 
		        super.onPreExecute();
		 }

		
		@Override
		protected String doInBackground(String... params) { 
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
			nameValuePairs.add(new BasicNameValuePair("email", username));
			nameValuePairs.add(new BasicNameValuePair("password", password));
			nameValuePairs.add(new BasicNameValuePair("method", "login"));

			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(MYAPP.API_BASE);

			try {
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = httpclient.execute(httppost);
				String output = MYAPP.getWebString(response.getEntity().getContent());
				Log.d("Login Activity", "API Connection Result: \n" + output); 
				return output;
			} catch (ClientProtocolException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} catch (IOException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} 
			return "";
		}

		
		@Override  
		protected void onPostExecute(String result) {
			super.onPostExecute(result);	 
			if(result.length() == 0){     
				progress.dismiss();  
				me.flash("Invalid Username/Password!");
			}else{
				if(result.equals("not found")){
					progress.dismiss();     
					me.flash("Invalid Username/Password!");					    
				}else{//user found here  
					Log.d("Login onPostExecute", "JSON EXECUTED!!!!");
					try{
			            JSONObject json = new JSONObject(result);
			            JSONObject jsonarray = new JSONObject(json.get("data").toString());					            
			            
			            me.user             = me.user.UpdateUserInfo(me.user, jsonarray, password);			            			           
			            me.userID           = me.user.userID;
			            me.orig_username    = me.user.username;
			            me.orig_email       = me.user.email;     
			            //Messages.saveJsonData(result);
						//UserFriends.saveJsonData(result);  						
			            //Users.saveJsonDataFromFriends(result);
						
			            StartService();  
			            Log.d("USER", "user has been saved!"); 
			            me.goToDashboard();
				    } catch (Exception e) {
				    	Log.e(TAG, "User Json parser error..", e); 
				    } 
				    
				    progress.dismiss();
				}				
			}  
		}
} 
	
	
	
	
	
	
	
	
	
	
	
	

}
