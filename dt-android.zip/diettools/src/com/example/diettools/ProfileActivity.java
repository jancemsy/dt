package com.example.diettools;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ContentBody;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreProtocolPNames;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TextView;

public class ProfileActivity extends Activity {
	MYAPP me; 
	TabHost mTabHost;
	TextView txtname;
	TextView txtstats;		       
	TextView txttotalgained; 
	TextView txttotalminutes;
	TextView txttotalcalburned;
	TextView txtbiotitle;
	TextView txtbio;
	File path;
	String base_path = "diettools";	
	String gallery_path  = "diettools/gallery";
	String avatar_path   = "";	
	private Menu menu = null;   
	ImageView imgavatar;
	private static final int CAMERA_REQUEST = 1888; 
	String camera_type = "avatar";
	String [] _mImages;
    Integer [] _mIds; 
    UserGalleries ug;
	 
	
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.profile);		
		
		me = (MYAPP)getApplication(); 
		me.init(this);
		me.SetMainMenuListeners();
		  
		txtname            = (TextView) findViewById(R.id.txtname);
		txtstats           = (TextView) findViewById(R.id.txtstats);
		imgavatar          = (ImageView) findViewById(R.id.imgAvatar); 
		txttotalgained     = (TextView) findViewById(R.id.txttotalgained);
		txttotalminutes    = (TextView) findViewById(R.id.txttotalminutes);
		txttotalcalburned  = (TextView) findViewById(R.id.txttotalcalburned);
		txtbiotitle        = (TextView) findViewById(R.id.txtbiotitle);
		txtbio             = (TextView) findViewById(R.id.txtbio);
		 
		  
		//*
        //---------Init avatar imgavatar out of user.avatar field------------------ 
		if( !MYAPP.isEmpty(me.user.avatar) ){						
	       if(me.user.avatar.contains("http://")){ 
	    	   
	    	   /*
        		LoadOnlineImages lb; 
				lb = new  LoadOnlineImages(me.user.avatar,imgavatar);
				lb.execute();   
				*/
	    	   
	    	   ImageLoader imgLoader = new ImageLoader();
               imgLoader.DisplayImage(me.user.avatar,imgavatar);
               
           }else{
	           File imgFile = new  File(me.user.avatar);
	           if(imgFile.exists()){
	              Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
	              imgavatar.setImageBitmap(myBitmap);
	           } 
          }
		}
		//*/
        
        
		String stats = "Age: "+me.user.age+", Sex: "+me.user.sex+", Weight:"+me.user.weight+
		"lbs, Height: "+me.user.height+"in ";
		
		txtname.setText(me.user.username);
		txtstats.setText(stats);			
		
		imgavatar.setOnClickListener(new View.OnClickListener() { 
            @Override
            public void onClick(View v) {
            	
            	//me.flash("w:"+imgavatar.getWidth()+",h:"+imgavatar.getHeight());
                openCamera("avatar");
            	
            }
        });
		
		
		mTabHost = (TabHost) findViewById(android.R.id.tabhost);
		mTabHost.setup();
		mTabHost.getTabWidget().setDividerDrawable(R.drawable.tab_divider); 
		 
		
        ////////////////////////TABS///////////////////////////////////////////
		TabHost.TabSpec spec1 = mTabHost.newTabSpec("About me");
		View tabview1 = createTabView(mTabHost.getContext(), "About");
		spec1.setIndicator(tabview1);
		spec1.setContent(R.id.profile_about_container); 
		mTabHost.addTab(spec1);

		TabHost.TabSpec spec2 = mTabHost.newTabSpec("Gallery");
		View tabview2 = createTabView(mTabHost.getContext(), "Gallery");
		spec2.setIndicator(tabview2);
		spec2.setContent(R.id.profile_gallery_container);
		mTabHost.addTab(spec2);  

		TabHost.TabSpec spec3 = mTabHost.newTabSpec("Friends");
		View tabview3 = createTabView(mTabHost.getContext(), "Friends");
		spec3.setIndicator(tabview3);
		spec3.setContent(R.id.profile_friends_container);
		mTabHost.addTab(spec3);

		TabHost.TabSpec spec4 = mTabHost.newTabSpec("Activities");
		View tabview4 = createTabView(mTabHost.getContext(), "Activities");
		spec4.setIndicator(tabview4);
        spec4.setContent(R.id.profile_activities_container);
		mTabHost.addTab(spec4);  
		
 
		
		if(me._profile_tab == "gallery"){
			mTabHost.setCurrentTab(1); setGallery();
		}else if(me._profile_tab == "friends"){
			mTabHost.setCurrentTab(2);
			setFriends();
		}else if(me._profile_tab == "activities"){			
			mTabHost.setCurrentTab(3);
			setActivities();
		}else{
			setAboutProfile();	
		}
		 
		
		mTabHost.setOnTabChangedListener(new OnTabChangeListener() {  
			@Override
			public void onTabChanged(String tab) { 	
				setMenuLayout();
				      
				switch(  mTabHost.getCurrentTab() ){		  		  		  
				  case  0:		
					  me._profile_tab = "about";
					  setAboutProfile();					  
					  break;
				  case  1:	
					  me._profile_tab = "gallery";
					  setGallery();
				  break;
                  case  2:        
                	  me._profile_tab = "friends";
                	  setFriends();
					  break;  
				  case  3:
                      setActivities();					  
					  me._profile_tab = "activities"; 
					  break;
				} 
			}
		});
	    ////////////////////////TABS///////////////////////////////////////////
		
		
		
		
		boolean mExternalStorageAvailable = false;
    	boolean mExternalStorageWriteable = false;
    	String state = Environment.getExternalStorageState();
    	

    	if (Environment.MEDIA_MOUNTED.equals(state)) {
    	    // We can read and write the media
    	    mExternalStorageAvailable = mExternalStorageWriteable = true;
    	} else if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
    	    // We can only read the media
    	    mExternalStorageAvailable = true;
    	    mExternalStorageWriteable = false;
    	} else {
    	    // Something else is wrong. It may be one of many other states, but all we need
    	    //  to know is we can neither read nor write
    	    mExternalStorageAvailable = mExternalStorageWriteable = false;
    	}    
    	
    	
        if(mExternalStorageAvailable)
          path = Environment.getExternalStorageDirectory();
        else
          path = Environment.getDataDirectory();
         
        
        base_path = path + "/" + base_path;    
        gallery_path = path + "/" + gallery_path;
        avatar_path = base_path;
	}
	
	
	public void setActivities(){
		Cursor cursor = MYAPP.static_ds.rawQuery("SELECT _id, created, SUM(burned) as burned,  SUM(minutes) as total_min, " +  
	           " SUM(points) as total_points  FROM  points WHERE userId =   "  +  me.userID + 
	           " GROUP BY strftime('%Y-%m-%d',created) " +  
	           " ORDER BY created DESC LIMIT 50"  , null);
		
		
		int[] TO = { R.id.col1 };
		String[] FROM = {  Points.C_created }; 
		
		SimpleCursorAdapter adapter = new ActivityCursorAdapter(this, R.layout._custom_activities_list1, cursor, FROM, TO);		
		ListView output_list = (ListView)findViewById(R.id.output_list);		 
		output_list.setAdapter(adapter);
		output_list.setDivider(null); 			 
	}
	
	public void setFriends(){
		Cursor cursor = MYAPP.static_ds.rawQuery(
			   "SELECT *FROM "+ Users.TABLE+" WHERE  "+Users.C_userID + " IN " +
			   "(SELECT uf."+UserFriends.C_friendID+" FROM "+UserFriends.TABLE+" uf WHERE " +
			   " uf."+UserFriends.C_userID+" = "+me.userID+"  ) ", null);
		
	
		int[] TO = { R.id.col1 };
		String[] FROM = {  Users.C_username }; 
		
		SimpleCursorAdapter adapter = new FriendsCursorAdapter(this, R.layout._custom_friends, cursor, FROM, TO);		
		ListView output_list = (ListView)findViewById(R.id.output_list_friends);		 
		output_list.setAdapter(adapter);
		output_list.setDivider(null); 	
		output_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {  
			@Override
			public void onItemClick(AdapterView<?> arg0, View view, int position, long arg3) {  
				 TextView v  = (TextView) view.findViewById(R.id.colID);				 
				 me._otheruserid  = v.getText().toString();  						
			     me.openscreen(OtherProfileActivity.class); 
			}
       }); 		
	}
	
	public class FriendsCursorAdapter extends SimpleCursorAdapter{ 
	    Cursor c;
	    Context context;
	    Activity activity;

	    public FriendsCursorAdapter(Context context, int layout, Cursor c,
	            String[] from, int[] to) {
	        super(context, layout, c, from, to); 
	        this.c = c;
	        this.context=context;
	        this.activity=(Activity) context; 
	    } 
	    
	    @Override
	    public View getView(int position, View convertView, ViewGroup parent) {
	        if(convertView == null)
	            convertView = View.inflate(context, R.layout._custom_friends, null);
	        View row = convertView; 
	        c.moveToPosition(position); 	  
            ImageView thumb = (ImageView) convertView.findViewById(R.id.imageView1);
            
               
            String avatar  = c.getString(c.getColumnIndex( Users.C_avatar ) ); 
            if( !MYAPP.isEmpty(avatar) ){            	            
              avatar = avatar.contains("http:") ? avatar : MYAPP.SITE_URL + avatar;
              
              ImageLoader imgLoader = new ImageLoader();
              imgLoader.DisplayImage(avatar, thumb);
              
              /*
              LoadOnlineImages lb; 
			  lb = new  LoadOnlineImages(avatar,thumb);
			  lb.execute();
			  */ 
            }
            
            TextView colID = (TextView) convertView.findViewById(R.id.colID);
	        TextView col1 = (TextView) convertView.findViewById(R.id.col1);
	        TextView col2 = (TextView) convertView.findViewById(R.id.col2);
	        
	        colID.setText( c.getString(c.getColumnIndex( Users.C_userID ) ) ); 
	        col2.setText("weight:" + c.getString(c.getColumnIndex( Users.C_weight ) ) +"lbs , height:" +  c.getString(c.getColumnIndex( Users.C_height ) )
	        		 +", points:" + c.getString(c.getColumnIndex( Users.C_points)) );
	        col1.setText( c.getString(c.getColumnIndex( Users.C_username ) )); 
	        return(row);
	    } 
	}
	
	
	 
	public class ActivityCursorAdapter extends SimpleCursorAdapter{ 
	    Cursor c;
	    Context context;
	    Activity activity;

	    public ActivityCursorAdapter(Context context, int layout, Cursor c,
	            String[] from, int[] to) {
	        super(context, layout, c, from, to); 
	        this.c = c;
	        this.context=context;
	        this.activity=(Activity) context; 
	    } 
	    
	    @Override
	    public View getView(int position, View convertView, ViewGroup parent) {
	        if(convertView == null)
	            convertView = View.inflate(context, R.layout._custom_activities_list1, null);
	        View row = convertView; 
	        c.moveToPosition(position); 	  
	        String created   = c.getString(1); 
	        Double burned    = c.getDouble(2);
	        int total_min    = (int) c.getDouble(3);
            int points       = c.getInt(4);    
                                        
            SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            SimpleDateFormat newFormater = new SimpleDateFormat("MM/dd/yyyy");
            SimpleDateFormat timeFormater = new SimpleDateFormat("hh:mm aa");
            
            Date dateObj;
            String date = "";
            String time      = "";
            
			try {
				dateObj = dateFormater.parse(created);
			    date = newFormater.format(dateObj);
			    time = timeFormater.format(dateObj);			    
			} catch (ParseException e) {	
				Log.d("PROFILE ACTIVITY","ERROR profile date convertion..............",e);
				e.printStackTrace();
			}                                      
                    		
            
            String output = me.user.username + " logged at " + time + " on " + date + ".";
            
            if(burned > 0) output = output + "  Logged "+total_min+"minute workout, burned "+burned+" calories and gained " + points;
            else  output = output + " Gained " + points;             	               
                                                   
	        TextView col1 = (TextView) convertView.findViewById(R.id.col1);	 
	        col1.setText(output); 
	        return(row);
	    } 
	}
	
	 
	public void setAboutProfile(){
		    txttotalgained.setText("TOTAL POINTS GAINED: " + String.valueOf(me.user.points));					  					
			txttotalminutes.setText("TOTAL EXERCISE MINUTES: " + String.valueOf(me.getExerciseTotalDuration()));
			txttotalcalburned.setText("TOTAL CALORIES BURNED: " + String.valueOf(me.getExerciseTotalBurned()));
			txtbiotitle.setText( MYAPP.isEmpty(me.user.bio_title) ? "Biography" : String.valueOf(me.user.bio_title) );
			txtbio.setText(me.user.bio); 		
	}
	
	
	
	public void openCamera(String type){
		camera_type = type;
		Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE); 
        startActivityForResult(cameraIntent, CAMERA_REQUEST);
	}
	
	 
	
	
	public void setupDietToolsDIR(){	 
		File folder1 = new File(base_path);        
        if (!folder1.exists()) {
            folder1.mkdir();              
        }
        		
		File folder2 = new File( gallery_path );          
        if (!folder2.exists()) {
        	folder2.mkdir();              
        }
	}
	
	
	
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {  
        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {  
        	//me.flash("after camer capture");
        	
        	setupDietToolsDIR();
        	
        	if(camera_type == "avatar"){        		        	                                     
                String destination = avatar_path + "/avatar.jpg" ;                                                                                
                File dest = new File(destination);                            
                Bitmap photo = (Bitmap) data.getExtras().get("data"); 
                imgavatar.setImageBitmap(photo);            
            
                try {
                   FileOutputStream out = new FileOutputStream(dest);
                   photo.compress(Bitmap.CompressFormat.PNG, 90, out);
                   out.flush();
                   out.close();
                   //save file here                 
                   me.user.avatar  = destination;
	  			   me.user.update();           
	  			  
	  			   new SynchImageUploader(me.user.avatar,"avatarupload").execute();
	  			 
                } catch (Exception e) {
                   e.printStackTrace();
                }
        	}else{ //add gallery         		
        		 long currentTime = System.currentTimeMillis();        		 
        		 String destination = gallery_path + "/"+currentTime+".jpg" ;                                                                                
                 File dest = new File(destination);                            
                 Bitmap photo = (Bitmap) data.getExtras().get("data");                                                       
                 
                 try {
                    FileOutputStream out = new FileOutputStream(dest);
                    photo.compress(Bitmap.CompressFormat.PNG, 90, out);
                    out.flush();
                    out.close();                    
                    ug = new UserGalleries();
                    
                    //save file to gallery   
                    ug.albumID    =  0;
                    ug.file       = destination;
                    ug.title      = "";
                    ug.caption    = "";
                    ug.created    = me.dateString;
					ug.userID     = me.userID;					
 	  			    ug.insert(); 	 
 	  			    new SynchImageUploader(destination,"galleryupload").execute();
 	  			    setGallery();
                 } catch (Exception e) {
                    e.printStackTrace();
                 }
        	}                       
               
        }  
    } 
	
	
	

	private static View createTabView(final Context context, final String text) {
		View view = LayoutInflater.from(context)
				.inflate(R.layout.tabs_bg, null);
		TextView tv = (TextView) view.findViewById(R.id.tabsText);
		tv.setText(text);
		return view;			
	}
		
 

	
	
	
	public void setGallery(){
		    //UserGalleries ug = new UserGalleries
    	    Cursor c = MYAPP.static_ds.rawQuery("SELECT *FROM " + UserGalleries.TABLE
				+ " WHERE ( " + UserGalleries.C_userID + " = ?  )", 
				new String[] { Integer.toString(me.userID) }); 
    	     
    	    	int size;	    
    	    	size = c.getCount();     
    	    	_mImages = new String[size];
    	    	_mIds    = new Integer[size];
    	    	c.moveToFirst(); 
    	    	
    	    	//set images
                for(int i = 0; i < size; i++){            	
                	_mImages[i] = c.getString(c.getColumnIndex(UserGalleries.C_file ) );
                	_mIds[i]    = c.getInt(c.getColumnIndex( UserGalleries.C_id ) );
                	c.moveToNext();            	            	
                }  
    	
		    Gallery g = (Gallery) findViewById(R.id.gallery1);
	        g.setAdapter(new ImageAdapter(this, _mImages,_mIds));
	        
	        g.setFadingEdgeLength(0);
	        g.setHorizontalFadingEdgeEnabled(false);
	         
	 
	        g.setOnItemClickListener(new OnItemClickListener() {
	            public void onItemClick(@SuppressWarnings("rawtypes") AdapterView parent, View v, int position, long id) {
	               me._gallery_item_id  = String.valueOf(_mIds[position]);
	               me.openscreen(  ProfileImageActivity.class);	               
	            } 
	        });
	}
	
	
	
	public class ImageAdapter extends BaseAdapter {
	    int mGalleryItemBackground;
	    private Context mContext; 
	    
	    String [] mImages;
	    Integer [] mIds; 
	 
	    public ImageAdapter(Context con,  String [] _mImages, Integer [] _mIds) {	    		    	     
            mImages = _mImages;
            mIds    = _mIds;                     		   
	        mContext = con;
	        TypedArray a = obtainStyledAttributes(R.styleable.HelloGallery); 
	        mGalleryItemBackground = a.getResourceId(R.styleable.HelloGallery_android_galleryItemBackground, 0);
	        a.recycle();
	    }
	 
	    public int getCount() {
	        return mImages.length;
	    }
	 
	    public Object getItem(int position) {
	        return position;
	    }
	 
	    public long getItemId(int position) {
	        return position;
	    }
	 
	    
	   
	    
	    public View getView(int position, View convertView, ViewGroup parent) {
	        ImageView i = new ImageView(mContext);	    
	        Bitmap myBitmap;  
	        
	        if(mImages[position].contains("http://")){
	        	    /*
	        		LoadOnlineImages lb; 
					lb = new  LoadOnlineImages(mImages[position],i);
					lb.execute();   
					*/					
					ImageLoader imgLoader = new ImageLoader();
		            imgLoader.DisplayImage(mImages[position],i);
	        }else{
		        	File imgFile = new  File(mImages[position]);
			        if(imgFile.exists()){
			              myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());   
			              i.setImageBitmap(myBitmap);
			        } 
	        }
	         
	        i.setLayoutParams(new Gallery.LayoutParams(300, 200)); 
	        i.setBackgroundResource(mGalleryItemBackground);  
	 
	        return i;
	    }	
	}
	

	
	
	public void changeMenu(int menuId){		
		if(this.menu != null){ 			
			this.menu.clear();
            if(menuId == 0)  menuId = R.menu.none;         	
		    getMenuInflater().inflate(menuId, this.menu);
		}
	}
	
	
	public void setMenuLayout(){
		switch(  mTabHost.getCurrentTab() ){		  		  		  
		  case  0:					  
			  changeMenu(R.menu.profile_menu);
			  break;
		  case  1:
			  changeMenu(R.menu.profile_menu_gallery_tab);
		  break;
        case  2:
      	      changeMenu(0);
			  break;  
		  case  3: 	
			  changeMenu(0);
			  break;
		} 
	}
	
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) { 
		this.menu = menu;				
		setMenuLayout();	
		return true;  
	}
	  
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {  
		switch (item.getItemId()) {
		case R.id.item_update_profile: 
			me.openscreen(  ProfileUpdateActivity.class);
			return true;
		case R.id.item_upload_avatar:
			openCamera("avatar");
			return true;
		case R.id.item_update_bio: 
			me.openscreen( ProfileUpdateBioActivity.class);
			return true;
		case R.id.item_add_photo:
			openCamera("gallery"); 
			return true;	
		/*case R.id.item_account_settings:
			me.flash("Account settings clicked.... TODO????");
			return true;*/	 				
		default:
			return false;
		}
	}
	
	
	
	
	class SynchImageUploader extends AsyncTask<String, Void, String> {		
		String method = "";  
		Context context; 
		ProgressDialog progress;
		String TAG = "avatarupload";
		String targetFile = "";
		

		public SynchImageUploader(String f, String m ) { 			         
			this.context =  ProfileActivity.this;
			targetFile = f;
			method = m;
		}

		@Override
		protected void onPreExecute() {
			progress = ProgressDialog.show(context, "", "Please wait...");
			super.onPreExecute();
		}

		@Override
		protected String doInBackground(String... params) {      
				HttpClient httpclient = new DefaultHttpClient();
				HttpPost httppost     = new HttpPost(MYAPP.API_BASE);  
				httpclient.getParams().setParameter(CoreProtocolPNames.PROTOCOL_VERSION, HttpVersion.HTTP_1_1);
				   
                File file = new File(targetFile);

                MultipartEntity mpEntity = new MultipartEntity();
                ContentBody cbFile = new FileBody(file, "image/jpeg");
                mpEntity.addPart("upload", cbFile);             
                try {
					mpEntity.addPart("method", new StringBody(method) );
					mpEntity.addPart("email", new StringBody(me.user.email) );
		            mpEntity.addPart("password", new StringBody(me.user.password) );        
              
			        httppost.setEntity(mpEntity);
                    Log.d( TAG,"executing request " + httppost.getRequestLine());
                    HttpResponse response = httpclient.execute(httppost);
                    HttpEntity resEntity = response.getEntity();                               
                    Log.d( TAG,""+response.getStatusLine());
                
                    String output = MYAPP.getWebString(response.getEntity().getContent());
                    
                    Log.d( TAG,"debugging................01");
                   
                     
                    if (resEntity != null) {
                       resEntity.consumeContent();
                    }
                    Log.d( TAG,"debugging................02");
                    
                    httpclient.getConnectionManager().shutdown(); 
                    
                    return output; 
                } catch (UnsupportedEncodingException e) { 
					e.printStackTrace();
				} catch (ClientProtocolException e) { 
					e.printStackTrace();
				} catch (IOException e) { 
					e.printStackTrace();
				} catch (org.apache.http.ParseException e) { 
					e.printStackTrace();
				}
				
               
				return ""; 
		}

		@Override
		protected void onPostExecute(String result) { 
			super.onPostExecute(result);
			if (result.length() == 0 || result.equals("error") ||  !MYAPP.isNumeric(result) ) {
				progress.dismiss();
				me.flash(result);
			} else {
				if(method == "galleryupload"){
					ug.oid = Integer.parseInt(result);
					ug.update();  
					me.flash("Image has been uploaded!");
				}else{
					me.flash("Avatar has been uploaded!");	
				}
			   	progress.dismiss();	 				 					
               	  									
			}
		}
	}
	
	
	
	
	
	
 
}
