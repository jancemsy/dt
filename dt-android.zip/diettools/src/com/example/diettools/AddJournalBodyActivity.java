package com.example.diettools;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class AddJournalBodyActivity extends Activity {
	MYAPP me; 
	EditText height_txt;
	EditText weight_txt;
	EditText arms_txt;
	EditText chest_txt;
	EditText waist_txt;
	EditText hips_txt;
	UserJournals journal;  
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_journal_body);
		me = (MYAPP) getApplication(); 
		me.init(this);
		me.SetMainMenuListeners();
		height_txt = (EditText) findViewById(R.id.txt_db_height);
		weight_txt = (EditText) findViewById(R.id.txt_db_weight);
		arms_txt   = (EditText) findViewById(R.id.txt_db_arms);
		chest_txt  = (EditText) findViewById(R.id.txt_db_chest);
		waist_txt  = (EditText) findViewById(R.id.txt_db_waist);
		hips_txt   = (EditText) findViewById(R.id.txt_db_hips);
	    journal = new UserJournals();
	    
		if( !MYAPP.isEmpty(me._current_journal_id) ){
			Cursor cursor = MYAPP.static_ds.rawQuery("SELECT *FROM " +  UserJournals.TABLE + " WHERE  " +  
					UserJournals.C_id + " = " + me._current_journal_id + "  " , null);
			
			if(cursor.getCount() > 0){  
				cursor.moveToFirst(); 	
				journal.oid = cursor.getInt(cursor.getColumnIndex(UserJournals.C_oid));
				height_txt.setText(cursor.getString(cursor.getColumnIndex(UserJournals.C_height)) );
				weight_txt.setText(cursor.getString(cursor.getColumnIndex(UserJournals.C_weight))  ); 
				arms_txt.setText(cursor.getString(cursor.getColumnIndex(UserJournals.C_arms)) );
				chest_txt.setText(cursor.getString(cursor.getColumnIndex(UserJournals.C_chest)) );
				waist_txt.setText(cursor.getString(cursor.getColumnIndex(UserJournals.C_waist)) );
				hips_txt.setText(cursor.getString(cursor.getColumnIndex(UserJournals.C_hips)) );				
			}
		}else{
				height_txt.setText( String.valueOf(me.user.height) );
				weight_txt.setText( String.valueOf(me.user.weight) );  
		}
 

		((Button) findViewById(R.id.btn_add))
				.setOnClickListener(new OnClickListener() {
					// @Override
					public void onClick(View view) {

						String height = String.valueOf(height_txt.getText());
						String weight = String.valueOf(weight_txt.getText());
						String arms   = String.valueOf(arms_txt.getText());
						String chest  = String.valueOf(chest_txt.getText());
						String waist  = String.valueOf(waist_txt.getText());
						String hips   = String.valueOf(hips_txt.getText());

						boolean isComplete = MYAPP.isEmpty(height)
								&& MYAPP.isEmpty(weight) && MYAPP.isEmpty(arms)
								&& MYAPP.isEmpty(chest) && MYAPP.isEmpty(waist)
								&& MYAPP.isEmpty(hips) ? false : true; 

						if (!isComplete) {
							me.alertbox("Please complete the fields!");
						} else if (!MYAPP.isNumericOrEmtpy(height)) {
							me.alertbox("Height must be a number!");
							height_txt.requestFocus();
						} else if (!MYAPP.isNumericOrEmtpy(weight)) {
							me.alertbox("Weight must be a number!");
							weight_txt.requestFocus();
						} else if (!MYAPP.isNumericOrEmtpy(arms)) {
							me.alertbox("Arms must be a number!");
							arms_txt.requestFocus();
						} else if (!MYAPP.isNumericOrEmtpy(chest)) {
							me.alertbox("Chest must be a number!");
							chest_txt.requestFocus();
						} else if (!MYAPP.isNumericOrEmtpy(waist)) {
							me.alertbox("Waist must be a number!");
							waist_txt.requestFocus();
						} else if (!MYAPP.isNumericOrEmtpy(hips)) {
							me.alertbox("Hips must be a number!");
							hips_txt.requestFocus();
						} else {
							Log.d("Starting to insert journal","Log.........................1");
						
							journal.height  = MYAPP.parseDoubleOrNull(((EditText) findViewById(R.id.txt_db_height)).getText().toString());
							journal.weight  = MYAPP.parseDoubleOrNull(((EditText) findViewById(R.id.txt_db_weight)).getText().toString());
							journal.arms    = MYAPP.parseDoubleOrNull(((EditText) findViewById(R.id.txt_db_arms)).getText().toString());
							journal.chest   = MYAPP.parseDoubleOrNull(((EditText) findViewById(R.id.txt_db_chest)).getText().toString());
							journal.waist   = MYAPP.parseDoubleOrNull(((EditText) findViewById(R.id.txt_db_waist)).getText().toString());
							journal.hips    = MYAPP.parseDoubleOrNull(((EditText) findViewById(R.id.txt_db_hips)).getText().toString());
							journal.userID  = me.userID;
							journal.title   = me._to_add_journal_title;
							journal.message = me._to_add_journal_text;
							journal.created = me._to_add_journal_date;  
							
							me.user.weight = journal.weight; 
							me.user.height = journal.height;
							me.user.update();
							
							if( !MYAPP.isEmpty(me._current_journal_id) ){								
								journal.id = Integer.parseInt(me._current_journal_id);
								journal.update();		
								me._current_journal_id = "";
								new SynchUploader(AddJournalBodyActivity.this,   "updatejournal" ).execute(); 
							}else{
								//me.flash("Journal has been added!");
								int tid = journal.insert();	
								journal.setLastId();
								me.addPoints( MYAPP.ADD_JOURNAL_PTS,  "user journal", tid ,0,0); 
								new SynchUploader(AddJournalBodyActivity.this,  "addjournal" ).execute(); 								
							}
							
						
						}
					}
				});

  }
	 
	
  class SynchUploader extends AsyncTask<String, Void, String> {		
		Context context;  
		ProgressDialog progress; 
		String TAG = "AddJournal Synch Uploader";		
		String method = "addjournal";
			
		public SynchUploader(Context c,  String method ) { 
			this.context    = c; 			
			this.method     = method;
		}	
		@Override
	    protected void onPreExecute() {
		        progress = ProgressDialog.show(this.context, "", "Please wait..."); 
		        super.onPreExecute();
		 }		
		@Override
		protected String doInBackground(String... params) { 
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(14);
			nameValuePairs.add(new BasicNameValuePair("id",     String.valueOf(journal.oid)));
			nameValuePairs.add(new BasicNameValuePair("height", String.valueOf(journal.height)));
			nameValuePairs.add(new BasicNameValuePair("weight", String.valueOf(journal.weight)));
			nameValuePairs.add(new BasicNameValuePair("arms",   String.valueOf(journal.arms)));
			nameValuePairs.add(new BasicNameValuePair("chest",  String.valueOf(journal.chest)));
			nameValuePairs.add(new BasicNameValuePair("waist",  String.valueOf(journal.waist)));
			nameValuePairs.add(new BasicNameValuePair("hips",   String.valueOf(journal.hips)));
			nameValuePairs.add(new BasicNameValuePair("userID", String.valueOf(journal.userID)));
			nameValuePairs.add(new BasicNameValuePair("title",  journal.title));
			nameValuePairs.add(new BasicNameValuePair("message",journal.message));
			nameValuePairs.add(new BasicNameValuePair("created_at",journal.created)); 
			nameValuePairs.add(new BasicNameValuePair("method", method));
			nameValuePairs.add(new BasicNameValuePair("email", me.user.email));
			nameValuePairs.add(new BasicNameValuePair("password", me.user.password));

			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(MYAPP.API_BASE);

			try {
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = httpclient.execute(httppost);
				String output = MYAPP.getWebString(response.getEntity().getContent());
				Log.d(TAG, "API Connection Result: \n" + output); 
				return output;
			} catch (ClientProtocolException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} catch (IOException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} 
			return "";   
		}  
		
		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);	 
			if(result.length() == 0){
				progress.dismiss(); 
			}else{ 
				if(result.equals("error")){
					 progress.dismiss();
					 me.alertbox("error for some reason"); 
				}else{ //user found here      					    
			         journal.oid = Integer.parseInt(result);
			         me._current_journal_id = String.valueOf(journal.id);
			         journal.update();
			         
			         me.openscreen(AddJournalPictureActivity.class);
				}  		
			} 
		 
       }
	
  }
	
	
	
	

}
