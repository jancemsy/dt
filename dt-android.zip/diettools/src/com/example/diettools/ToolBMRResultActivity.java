package com.example.diettools;


import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class ToolBMRResultActivity extends Activity{
	MYAPP me; 
	  
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.bmr_result);			
		me = (MYAPP)getApplication(); 
		me.init(this);
		me.SetMainMenuListeners(); 			
		TextView result1 = (TextView) findViewById(R.id.txtbmr1);
		TextView result2 = (TextView) findViewById(R.id.txtbmr2);
		TextView result3 = (TextView) findViewById(R.id.txtbmr3);
		TextView result4 = (TextView) findViewById(R.id.txtbmr4);
		TextView result5 = (TextView) findViewById(R.id.txtbmr5);
		TextView result6 = (TextView) findViewById(R.id.txtbmr6);
		
	    result1.setText(me._bmr_result1);
	    result2.setText(me._bmr_result2);
	    result3.setText(me._bmr_result3);
	    result4.setText(me._bmr_result4);
	    result5.setText(me._bmr_result5);
	    result6.setText(me._bmr_result6);
	    	    	   
	    Button back = (Button) findViewById(R.id.Button01);	    	
	    back.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {
				  me.openscreen(ToolBMRActivity.class);
			}
		});		
	}
	
	 
}