package com.example.diettools;


import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.EditText;
import android.widget.TextView;

public class ToolExerciseCaloriesActivity extends Activity{
	MYAPP me; 
	Button btnNext;
	EditText txtSearch;
	AutoCompleteTextView ExerciseTextBox;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.exercisetracker);	  
		me = (MYAPP)getApplication(); 
		me.init(this);
		me.SetMainMenuListeners();  
		
		ExerciseTextBox = (AutoCompleteTextView) findViewById(R.id.txtSearch);
		ItemAutoTextAdapter adapter1 = this.new ItemAutoTextAdapter();		
		ExerciseTextBox.setAdapter(adapter1);
		ExerciseTextBox.setOnItemClickListener(adapter1);
		ExerciseTextBox.addTextChangedListener(new TextWatcher(){
	        public void afterTextChanged(Editable s) {   }
	        public void beforeTextChanged(CharSequence s, int start, int count, int after){}
	        public void onTextChanged(CharSequence s, int start, int before, int count){}
	    });  
		 
		
		btnNext = (Button) findViewById(R.id.btnNext);
		
		btnNext.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {
				 if( !me._exercise.equals("")){					 
					 me.openscreen(ToolExerciseCaloriesForm2Activity.class); 
				 }else{
					 me.alertbox("Please enter a valid exercise!");
				 }
			}
		});	
		
		
	}
	 
	
	
	class ItemAutoTextAdapter extends CursorAdapter implements android.widget.AdapterView.OnItemClickListener {		
		SQLiteDatabase db;
		Activity act;
		MYAPP me;

		public ItemAutoTextAdapter() {
			super(ToolExerciseCaloriesActivity.this, null);			
			db = MYAPP.static_ds.db; 
			me = (MYAPP) getApplication();
		}

		public Cursor getMatches(String constraint) throws SQLException {			
			Log.d("AutoCompleteDbAdapter", " STRING ====> " + constraint);

			String queryString = "SELECT " + Exercises.C_met + ", "
					+ Exercises.C_id + ", " + Exercises.C_exercise + " FROM "
					+ Exercises.TABLE;
			if (constraint != null) {
				constraint = "%" + constraint.trim() + "%";
				queryString += " WHERE " + Exercises.C_exercise + " LIKE ? ";
			}

			String params[] = { constraint };
			if (constraint == null) {
				params = null;
			}

			try {
				Cursor cursor = db.rawQuery(queryString, params);
				Log.d("AutoCompleteDbAdapter", " MATCH COUNT ====> "
						+ queryString + "=" + cursor.getCount()); 
				 
				if(cursor.getCount() == 0){
					me._exercise_met = 0.0;	
				} 
				
				if (cursor != null) {
					cursor.moveToFirst();

					Log.d("AutoCompleteDbAdapter",
							" Returned somthing not sure what...");
					return cursor;
				}
			} catch (SQLException e) {
				Log.e("AutoCompleteDbAdapter", e.toString());
				throw e;
			}
			return null;
		}

		@Override
		public Cursor runQueryOnBackgroundThread(CharSequence constraint) {
			if (getFilterQueryProvider() != null) {
				return getFilterQueryProvider().runQuery(constraint);
			}
			Cursor cursor = getMatches(constraint != null ? constraint.toString() : null);
			return cursor;
		}

		@Override
		public String convertToString(Cursor cursor) {
			final int columnIndex = cursor.getColumnIndexOrThrow(Exercises.C_exercise);
			final String str = cursor.getString(columnIndex);
			return str;
		}

		@Override
		public void bindView(View view, Context context, Cursor cursor) {
			final String text = convertToString(cursor);
			((TextView) view).setText(text);
		}

		@Override
		public View newView(Context context, Cursor cursor, ViewGroup parent) {			
			final LayoutInflater inflater = LayoutInflater.from(context);
			final View view = inflater.inflate(R.layout.add_exercise_custom_completer, parent, false);
			return view;
		}

		
		
		@Override
		public void onItemClick(AdapterView<?> listView, View view, int position, long id) {
			// Get the cursor, positioned to the corresponding row in the result
			// set
			Cursor cursor = (Cursor) listView.getItemAtPosition(position);

			// Get the state's capital from this row in the database.
			String exercise = cursor.getString(cursor.getColumnIndexOrThrow(Exercises.C_exercise));
			me._exercise_met = Double.parseDouble(cursor.getString(cursor.getColumnIndexOrThrow(Exercises.C_met)));
			me._exercise_id  = Integer.parseInt( cursor.getString(cursor.getColumnIndexOrThrow(Exercises.C_id)) );
			me._exercise     = exercise ;						
			ExerciseTextBox.setText(exercise.trim()); 			
		}
	}
	
	
	
	
 
}
