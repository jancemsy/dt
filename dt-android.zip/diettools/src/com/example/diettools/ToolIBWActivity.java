package com.example.diettools;


import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class ToolIBWActivity extends Activity{
	MYAPP me; 
	EditText txtweight;
	EditText txtheight; 
	TextView tvweight;
	TextView tvheight;
	RadioButton radiometric;
	RadioButton radioenglish;
	Button btnclear;
	Button btncalc;
	Boolean isEnglish = true;
	RadioGroup radiomeasurement;
	RadioButton radioselected;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ibw);		 	
		me = (MYAPP)getApplication(); 
		me.init(this);
		me.SetMainMenuListeners(); 
		
		txtweight     = (EditText) findViewById(R.id.editText1);
		txtheight     = (EditText) findViewById(R.id.txtregpassword);		
		tvweight      = (TextView) findViewById(R.id.tvweight);  
		tvheight      = (TextView) findViewById(R.id.tvheight);				
		btnclear      = (Button) findViewById(R.id.btnregsubmit);
		btncalc       = (Button) findViewById(R.id.button2);		
		radioenglish  = (RadioButton) findViewById(R.id.radioEnglish);
		radiometric   = (RadioButton) findViewById(R.id.radioMetric); 
		radiomeasurement  = (RadioGroup) findViewById(R.id.measurement);

        txtweight.setText(String.valueOf(me.user.weight));
		txtheight.setText(String.valueOf(me.user.height));
		
				
		tvweight.setText("Weight (lbs):");
		tvheight.setText("Height (in):");
		
		radioenglish.setChecked(true);		
		radioenglish.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {
				tvweight.setText("Weight (lbs):");
				tvheight.setText("Height (in):");
			}
		}); 
		radiometric.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {
				tvweight.setText("Weight (kg):");
				tvheight.setText("Height (cm):");
			}
		});
		
		
		btnclear.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {
				txtweight.setText("");
				txtheight.setText("");
			}
		});
		
		btncalc.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {
				
				if (MYAPP.isNumeric(txtweight.getText().toString())
						&& MYAPP.isNumeric(txtweight.getText().toString())) {

				        double weight = Double.parseDouble(txtweight.getText().toString());
					    double height = Double.parseDouble(txtheight.getText().toString()); 
						//double bmi = Math.round(weight * 703 / (Math.pow(height, 2)) * 10) / 10;
						 

						String m = getMeasurement();											

						if (m == "Metric") {
							weight = Math.round(weight * 2.20462262);
							height = Math.round(height * 0.393700787);
						}
						
						 				
						  double heightMeters = height * 0.0254; //converts height from inches to meters
						  double ibwLow = Math.round( (19 * (heightMeters * heightMeters)) * 2.2046 * 1.02 );
						  double ibwHigh = Math.round( (25 * (heightMeters * heightMeters)) * 2.2046 * 1.02);
						  
						
						   me.user.weight = weight;
						   me.user.height = height;						   
						   me.user.update();
						   
					      me._ibw_result1 = String.valueOf(ibwLow);
					      me._ibw_result2 = String.valueOf(ibwHigh);
					      me.openscreen(ToolIBWResultActivity.class);						

				} else {
                    me.alertbox("Input must be a number!");
				}

			}// onclick
			 
		});
					
		
	}
	
	
	public String getMeasurement()
	{
		int selectedId = radiomeasurement.getCheckedRadioButtonId();
		radioselected = (RadioButton) findViewById(selectedId);		
		return radioselected.getText().toString();
	}
	
 
}
