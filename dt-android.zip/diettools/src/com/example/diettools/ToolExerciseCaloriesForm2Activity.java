package com.example.diettools;


import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class ToolExerciseCaloriesForm2Activity extends Activity{
	MYAPP me;	
	TextView txtExercise; 
	RadioGroup gender;
	EditText txtWeight;
	EditText txtHeight;
	EditText txtAge;
	EditText txtMin;
	Button btnBack;
    Button btnCalc;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.exercisetracker_form2);	
		
		me = (MYAPP)getApplication(); 
		me.init(this);
		me.SetMainMenuListeners();
		
		RadioButton radiomale = (RadioButton) findViewById(R.id.radioMale);
		radiomale.setChecked(true);	
		
		txtExercise = (TextView) findViewById(R.id.txtExercise); 
		gender      = (RadioGroup) findViewById(R.id.gender);
		txtWeight   = (EditText) findViewById(R.id.txtWeight);
		txtHeight   = (EditText) findViewById(R.id.txtHeight);
		txtAge      = (EditText) findViewById(R.id.txtAge);
		txtMin      = (EditText) findViewById(R.id.txtMin);		
	    btnCalc     = (Button) findViewById(R.id.btnCalc);
	     
        
        txtWeight.setText(String.valueOf(me.user.weight));
		txtHeight.setText(String.valueOf(me.user.height));
		
	    txtExercise.setText(me._exercise);
	    me.jumpActivityOnClick(R.id.btnBack, ToolExerciseCaloriesActivity.class);
	    btnCalc.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {
				String sex = getGender();
				double RMR;  
				double height =  Double.parseDouble(txtHeight.getText().toString());   
				double weight =  Double.parseDouble(txtWeight.getText().toString()); 
				int age       =  Integer.parseInt(txtAge.getText().toString());
				int min       =  Integer.parseInt(txtMin.getText().toString());
				double met = me._exercise_met;
								
				
				if(sex == "Male"){
	                RMR =  66.5 +  5.0 * height  +  13.7 * weight -  6.8 * age ;                 
	                
	           }else{
	                RMR  = 655.1 +  1.8* height  +  9.6 * weight - 4.7 * age;                
	           }
	                     
	           Double RMRCorrected = (RMR * 0.138888889 / weight);                                 
	           Double METCorrected = (met * 3.5 /  RMRCorrected);           
	           Double Calories     = (METCorrected * 3.5 * weight * min) / 200;	            
	           
	           me._exercise_result1 = String.valueOf(Calories); 
	           me._exercise_result2 = String.valueOf(height);
	           me._exercise_result3 = String.valueOf(weight);
	           me._exercise_result4 = String.valueOf(age);
	           me._exercise_result5 = String.valueOf(min);	
	           
	           me.user.weight = weight;
			   me.user.height = height;			   
			   me.user.update();
	   		
	           me.openscreen(ToolExerciseCaloriesResultActivity.class);  	              
			}
		});	 
	    
		
	}
	
	
	
	public String getGender()
	{
		int selectedId = gender.getCheckedRadioButtonId();
		RadioButton radioselected  = (RadioButton) findViewById(selectedId);		
		return radioselected.getText().toString();
	}
	
 
}
