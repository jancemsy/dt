package com.example.diettools;


import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.app.ProgressDialog;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;


public class MessagesReadActivity extends Activity {
	MYAPP me; 
	TextView txtMessage; 
	TextView txtTitle;
	TextView txtTime;  
	TextView txtUser;	  
	Messages msg;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.messages_read);			
		me = (MYAPP)getApplication(); 
		me.init(this);		
		me.SetMainMenuListeners(); 	 		 
		((TextView) findViewById(R.id.header_main)).setText("Read Message");
		
		txtMessage = (TextView) findViewById(R.id.txtMessage);
		txtTitle   = (TextView) findViewById(R.id.txtTitle);
		txtTime    = (TextView) findViewById(R.id.txtTime);
		txtUser    = (TextView) findViewById(R.id.txtUser);
		 
		 
		String query = "SELECT  m.*, u." + Users.C_username + ",u." + Users.C_avatar +  
		" FROM  "+Messages.TABLE+" m " +
		" LEFT JOIN "+Users.TABLE+" u  ON (u."+Users.C_oid+"=m."+Messages.C_sender+") " +
		" WHERE  m."+Messages.C_id + " = " + me._message_id + " " +     
		" ORDER BY m.created DESC LIMIT 50";		
		Cursor c = MYAPP.static_ds.rawQuery(query  , null);		 
		if( c.getCount() > 0 ){
			c.moveToFirst();
			String created   = c.getString(  c.getColumnIndex( Messages.C_created ) ); 
	        String subject   = c.getString(  c.getColumnIndex( Messages.C_subject ) );
	        String message   = c.getString(  c.getColumnIndex( Messages.C_message ) );
	        String from      = c.getString(  c.getColumnIndex( Users.C_username ) );	        
	        SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            SimpleDateFormat newFormater = new SimpleDateFormat("MM/dd/yyyy");
            SimpleDateFormat timeFormater = new SimpleDateFormat("hh:mm aa");
            
            Date dateObj;
            String date = "";
            String time      = "";
            
			try {
				dateObj = dateFormater.parse(created);
			    date = newFormater.format(dateObj);
			    time = timeFormater.format(dateObj);			    
			} catch (ParseException e) {	
				Log.d("PROFILE ACTIVITY","ERROR profile date convertion..............",e);
				e.printStackTrace();
			}   
			
			txtMessage.setText(message);
			txtTitle.setText(subject);
			txtTime.setText(time + " " + date);
			txtUser.setText(from);	 
			
		    msg = new Messages();
			msg.setInfo(c);
			
			if(msg.status  == MYAPP.UNREAD)
			{
				  new SynchAsRead().execute();
				  msg.status     = MYAPP.READ;
			} 
			
			msg.update();		
			me.updateInboxCount();
		} 
	} 
	
	
	 
	class SynchDeleteMessage extends AsyncTask<String, Void, String> {				
		ProgressDialog progress; 
		String TAG = "MarkRead Message Synch Uploader"; 
		String method = "deletemessage";
			
		public SynchDeleteMessage( ) {		 
		}	
		
		@Override
	    protected void onPreExecute() { 
			    progress = ProgressDialog.show(MessagesReadActivity.this , "", "Please wait..."); 
		        super.onPreExecute();
		 }		        
		     
		@Override
		protected String doInBackground(String... params) {     
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(4);	 
			nameValuePairs.add(new BasicNameValuePair("oid",        String.valueOf(msg.oid) ));   
			nameValuePairs.add(new BasicNameValuePair("email",      me.user.email));
			nameValuePairs.add(new BasicNameValuePair("password",   me.user.password));						
			nameValuePairs.add(new BasicNameValuePair("method",     method));	 

			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(MYAPP.API_BASE);

			try {
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = httpclient.execute(httppost);
				String output = MYAPP.getWebString(response.getEntity().getContent());
				Log.d(TAG," MSGID: "+ msg.oid +" - API Connection Result for "+method+": " + output);				
				MYAPP.static_ds.delete(Messages.TABLE, Messages.C_oid, String.valueOf(msg.oid));
				me.openscreen(MessagesInboxActivity.class);
				progress.dismiss();
				return output;
			} catch (ClientProtocolException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} catch (IOException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} 
			return "";   
		}  
		
		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);	  
       }
	
  }
	
	class SynchAsRead extends AsyncTask<String, Void, String> {				
		ProgressDialog progress; 
		String TAG = "MarkRead Message Synch Uploader"; 
		String method = "markread";
			
		public SynchAsRead( ) {		 
		}	 

		@Override
	    protected void onPreExecute() {		        
		        super.onPreExecute();
		 }
		     
		@Override
		protected String doInBackground(String... params) {     
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(4);	 
			nameValuePairs.add(new BasicNameValuePair("oid",        String.valueOf(msg.oid) ));   
			nameValuePairs.add(new BasicNameValuePair("email",      me.user.email));
			nameValuePairs.add(new BasicNameValuePair("password",   me.user.password));						
			nameValuePairs.add(new BasicNameValuePair("method",     method));	 

			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(MYAPP.API_BASE);

			try {
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = httpclient.execute(httppost);
				String output = MYAPP.getWebString(response.getEntity().getContent());
				Log.d(TAG," MSGID: "+ msg.oid +" - API Connection Result for "+method+": " + output);				
				return output;
			} catch (ClientProtocolException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} catch (IOException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} 
			return "";   
		}  
		
		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);	  
       }
	
  }
	 
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) { 
    	getMenuInflater().inflate(R.menu.read_message_menu, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {  
		switch (item.getItemId()) {
		case R.id.item_reply: 		 
		 	me.openscreen(MessagesNewActivity.class); 
			return true;
		case R.id.item_delete: 
			new SynchDeleteMessage().execute();			
			return true;	 			
		default:
			return false;
		}
	}
	
	
	
	
	
	
	
	
 
}
