package com.example.diettools;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;
 
 
  
// /DB
// HELPERS//////////////////////////////////////////////////////////////////////////////////////////////
public class Datasource2 { 
	public static final int DB_VERSION = 26;		
	public static final String DB_NAME = "dt26.db";
	public static final String TAG = "Datasource";	
	private static String DB_PATH = "/data/data/com.example.diettools/databases/";
	
	public static final String ASSET_DB_NAME = "dt_fts.db"; //do not change
	

	DbHelper dbHelper = null;
	SQLiteDatabase db;
	Context context;

	String _table; 
	String _id; 

	public Datasource2(Context con) {
		this.context = con;			
		dbHelper = new DbHelper(con);						
		try {		
			Log.d(TAG, "db here....");
			dbHelper.createDataBase();			
		} catch (IOException ioe) {
			throw new Error("Unable to create database");
		}  
		dbHelper.close(); 
		dbHelper = new DbHelper(con); 		
		db = dbHelper.getWritableDatabase();	
		
		
		////////////////////////////////////////////////////////////
		/*
		Log.d(TAG, "RECREATING TABLES............");
								

		  dbHelper.deleteTable(db,Points.TABLE);
		  db.execSQL(Points.CREATE_TABLE);
		  
		  dbHelper.deleteTable(db,Users.TABLE);
		  db.execSQL(Users.CREATE_TABLE);
		

		  dbHelper.deleteTable(db,UserJournals.TABLE);
		  db.execSQL(UserJournals.CREATE_TABLE);
		  

		  dbHelper.deleteTable(db,UserExercises.TABLE);
		  db.execSQL(UserExercises.CREATE_TABLE);
		  
		  dbHelper.deleteTable(db,UserFoods.TABLE);
		  db.execSQL(UserFoods.CREATE_TABLE);
		  
		  dbHelper.deleteTable(db,UserFriends.TABLE);
		  db.execSQL(UserFriends.CREATE_TABLE);
		  
		  dbHelper.deleteTable(db,UserGalleries.TABLE);
		  db.execSQL(UserGalleries.CREATE_TABLE);
		  
		  dbHelper.deleteTable(db,FriendRequests.TABLE);
		  db.execSQL(FriendRequests.CREATE_TABLE);
		  
		  dbHelper.deleteTable(db,Generator.TABLE);
		  db.execSQL(Generator.CREATE_TABLE);
		  
		  
		  
		  dbHelper.deleteTable(db,MeasurementTracker.TABLE);
		  db.execSQL(MeasurementTracker.CREATE_TABLE);
		  
		  dbHelper.deleteTable(db,Points.TABLE);
		  db.execSQL(Points.CREATE_TABLE);
		  
		  
		  dbHelper.deleteTable(db,Messages.TABLE);
		  db.execSQL(Messages.CREATE_TABLE);
		  
		  
		  dbHelper.deleteTable(db,FriendRequests.TABLE);
		  db.execSQL(FriendRequests.CREATE_TABLE);	
		
		  Log.d(TAG, "Recreate food table");
		  dbHelper.deleteTable(db,Foods.TABLE);
		  db.execSQL(Foods.CREATE_TABLE);
		  Log.d(TAG, "Recreate food table ended..");
		
		  Log.d(TAG, "Recreate exercise table");
		  dbHelper.deleteTable(db,Exercises.TABLE);
		  db.execSQL(Exercises.CREATE_TABLE);
		  Log.d(TAG, "Recreate exercise table ended..");
		
		  
	     Log.d(TAG, "RECREATING TABLES DONE............");
	    
	 
		  		
		//////////////////////////////////////////////////////////////////////////////////////////////
		/*recreate foods table and insert data*/ 	 			
		
		
		
		
		///BELOW LINE SHOULD GO TO LOGINACTIVITY.JAVA
		//Example loading food runtime//DO NOT DELETE FOR REFERENCE
		/*
	     
	     
		Foods food = new Foods();
		food.loadJson(con, 1, 1000);		
		Log.d(TAG, "db startedxxxxxxxxxxxxxx............222");
		
		Exercises ex = new Exercises();
		ex.loadJson(con);		
		Log.d(TAG, "db startedxxxxxxxxxxxxxx............222");
        //*/
		//////////////////////////////////////////////////////////////////////////////////////////////
		
		
		//////////////////////////////////////////////////////////////////////////////////////////////
		/*recreating food example
		  dbHelper.deleteTable(db, UserFoods.TABLE);		 
		  db.execSQL(UserFoods.CREATE_TABLE);
		  Log.d(TAG, "ALTERED TABLE SUCCESSFUL...............");
		  db.execSQL(MeasurementTracker.CREATE_TABLE);
		  Log.d(TAG, "CREATED TABLE SUCCESSFUL...............");
		*////////////////////////////////////////////////////////////////////////////////////////////
		
	
	}

 
	public Datasource2(Context context, String table, String id) {
		this.context = context;
		dbHelper = new DbHelper(context);
		this._table = table;
		this._id = id; 	
		Log.d(TAG, "Datasource 2nd contructor loaded");
		db = dbHelper.getWritableDatabase();
	}
 
	
	public void close() {
		if (dbHelper != null) {
			dbHelper.close();
		}
	}

	public String getWebString(InputStream is) throws IOException {
		String line = "";
		StringBuilder total = new StringBuilder();
		// Wrap a BufferedReader around the InputStream
		BufferedReader rd = new BufferedReader(new InputStreamReader(is));
		// Read response until the end
		while ((line = rd.readLine()) != null) {
			total.append(line);
		}
		// Return full string
		return total.toString();
	}

	public void empty() {
		truncate(this._table);
	}

	public long count() {
		return total_record(this._table);
	}

	public boolean Exists(String field, String search) {		
		Cursor cursor = db.rawQuery("select  " + _id + " from " + this._table
				+ " where  " + field + " = '" + search + "' ", null);
		boolean exists = (cursor.getCount() > 0);
		cursor.close();
		return exists;
	}

	public void truncate(String table) {		
		db.execSQL("DELETE FROM " + table);
	}
	
	public void delete(String table, String id, String value) {		
		db.execSQL("DELETE FROM " + table +" WHERE "+id+" = " + value);
	}

	public int add(String table, ContentValues values) {
		Log.d(table, "Running insert");
		long l = db.insert(table, null, values); 
		return  (int) l;
	}
	
	public void update(String table, ContentValues values, String search, String value){
		String where = search + " =?";
		String[] whereArgs = new String[] {String.valueOf(value)};
		db.update(table, values, where, whereArgs);
	}

	public long total_record(String table) {		
		SQLiteStatement statement = db.compileStatement("SELECT COUNT(*) FROM "
				+ table);
		long count = statement.simpleQueryForLong();
		return count;
	}

	public Cursor getCursor(String table, String id, String OrderBy, String Limit) {
		this._table = table;
		this._id    = id;			
		Limit = "LIMIT " + Limit;
		return this.query(OrderBy, Limit);
	}

	public Cursor query(String OrderBY, String Limit) {		
		Cursor cursor = db.query(this._table, null, null, null, null, null,
				OrderBY + " " + Limit);
		return cursor;
	}
	
	
	
	public Cursor rawQuery(String sql_statement, String[] values){		
	  Cursor cursor = db.rawQuery(sql_statement, values );
      return cursor;
    }
  
	
	public int getSum(String table, String column){
	    Cursor cursor = db.rawQuery("SELECT SUM(" + column + ") FROM " + table, null);
        if(cursor.moveToFirst()) {
		    return cursor.getInt(0);
		}
		
        return 0;
	}
	
	public String getResult(String query){
	    Cursor cursor = db.rawQuery(query, null);
	    String result = null;
        if(cursor.moveToFirst()) {
		    result = cursor.getString(0);
		}
		
        return result;
	}
	
	

	public class DbHelper extends SQLiteOpenHelper {

		public DbHelper(Context context) {
			super(context, DB_NAME, null, DB_VERSION);
			Log.d(TAG, "DBhelper constructor(.............) ");
		}

		public void deleteTable(SQLiteDatabase db, String table) {
			db.execSQL("DROP TABLE IF EXISTS  " + table);
		}

		private boolean checkDataBase() {
			Log.d(TAG,"checking db .........");
			SQLiteDatabase checkDB = null;
			try {
				String myPath = DB_PATH + DB_NAME;
				checkDB = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.OPEN_READONLY);
			} catch (SQLiteException e) {
				return false;
			}

			if (checkDB != null) {
				checkDB.close();
			}
			Log.d(TAG,"checking db  end.........");
			return checkDB != null ? true : false;
		}

		private void copyDataBase() throws IOException {
			InputStream myInput = context.getAssets().open(ASSET_DB_NAME); /*this is a static value in asset*/
			String outFileName = DB_PATH + DB_NAME;
			OutputStream myOutput = new FileOutputStream(outFileName);
			byte[] buffer = new byte[1024];
			int length;
			while ((length = myInput.read(buffer)) > 0) {
				myOutput.write(buffer, 0, length);
			}
			myOutput.flush();
			myOutput.close();
			myInput.close();
		}

		public void openDataBase() throws SQLException {
			// Open the database
			String myPath = DB_PATH + DB_NAME;
			db = SQLiteDatabase.openDatabase(myPath, null,
					SQLiteDatabase.OPEN_READONLY);
		}

		public void createDataBase() throws IOException {
			boolean dbExist = checkDataBase();
			if (dbExist) {
				Log.d(TAG, "DB already created...");
			} else {
				Log.d(TAG, "Creating our DB...");
				this.getWritableDatabase();
				try {
					copyDataBase();
					Log.d(TAG, "DB defaults initialized..........");
				} catch (IOException e) {
					throw new Error("Error copying database");
				}
			}
		}

		
		@Override
		public void onCreate(SQLiteDatabase db) {	 
			/*
			  db.execSQL(Users.CREATE_TABLE);
			  db.execSQL(UserJournals.CREATE_TABLE);
			  db.execSQL(UserExercises.CREATE_TABLE);
			  db.execSQL(UserFoods.CREATE_TABLE);
			  db.execSQL(UserFriends.CREATE_TABLE);
			  db.execSQL(UserGalleries.CREATE_TABLE);
			  db.execSQL(FriendRequests.CREATE_TABLE);
			  db.execSQL(Foods.CREATE_TABLE);
			  db.execSQL(Exercises.CREATE_TABLE);
			  db.execSQL(Generator.CREATE_TABLE);
			 //*/
			//Log.d(TAG, "Tables created");
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {  
			onCreate(db);
		}

		@Override
		public synchronized void close() {
			if (db != null)
				db.close();
			super.close();
		}

	}

}
