package com.example.diettools; 
import java.io.File;
import java.io.FileOutputStream;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

public class AddJournalPictureActivity extends Activity {
	MYAPP me; 
	ImageView image; 
	private static final int CAMERA_REQUEST = 1888; 
	File path;
	String base_path = "diettools";	 
	String picture_path   = "";	
	UserJournals journal; 
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_journal_picture);
		me = (MYAPP) getApplication(); 
		me.init(this);
		me.SetMainMenuListeners(); 
		journal = new UserJournals();
		
		if( !MYAPP.isEmpty(me._current_journal_id) ){
			Cursor cursor = MYAPP.static_ds.rawQuery("SELECT *FROM " +  UserJournals.TABLE + " WHERE  " +  
					UserJournals.C_id + " = " + me._current_journal_id + "  " , null);
			
			if(cursor.getCount() > 0){  
				cursor.moveToFirst(); 	 
				journal.setInfo(cursor); 
			}else{
				 me.openscreen(JournalsActivity.class);			
			}
		}else{
			 me.openscreen(JournalsActivity.class);  
		}
		
		
		
		
		image   = (ImageView) findViewById(R.id.journalImageVIew); 
		image.setOnClickListener(new View.OnClickListener() { 
            @Override
            public void onClick(View v) {  
                openCamera(); 
            }
        });
		
		me.jumpActivityOnClick(R.id.btn_next, AddJournalVideoActivity.class);	 
		boolean mExternalStorageAvailable = false;
    	boolean mExternalStorageWriteable = false;
    	String state = Environment.getExternalStorageState(); 

    	if (Environment.MEDIA_MOUNTED.equals(state)) {
    	    // We can read and write the media
    	    mExternalStorageAvailable = mExternalStorageWriteable = true;
    	} else if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
    	    // We can only read the media
    	    mExternalStorageAvailable = true;
    	    mExternalStorageWriteable = false;
    	} else {
    	    // Something else is wrong. It may be one of many other states, but all we need
    	    //  to know is we can neither read nor write
    	    mExternalStorageAvailable = mExternalStorageWriteable = false;
    	}    
    	
    	
        if(mExternalStorageAvailable)
          path = Environment.getExternalStorageDirectory();
        else
          path = Environment.getDataDirectory();
         
        
        base_path = path + "/" + base_path;     
        picture_path = base_path + "/journal";
        
        
        
        ((Button) findViewById(R.id.btn_skip))
		.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {	
				journal.picture = "";
                journal.update();
				me.openscreen(AddJournalVideoActivity.class);											
			}
		});
		
    }
		
	
	public void openCamera(){ 
		Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE); 
        startActivityForResult(cameraIntent, CAMERA_REQUEST);
	}
	
	 
	
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {  
        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {          	        
        	      File folder1 = new File(picture_path);        
                  if (!folder1.exists()) {
                     folder1.mkdir();              
                 }
                               
                String fn = MYAPP.md5(String.valueOf(journal.id));                  
                String destination = picture_path + "/"+ fn +".jpg" ;                                                                                
                File dest = new File(destination);                            
                Bitmap photo = (Bitmap) data.getExtras().get("data"); 
                image.setImageBitmap(photo);            
            
                try {
                   FileOutputStream out = new FileOutputStream(dest);
                   photo.compress(Bitmap.CompressFormat.PNG, 90, out);
                   out.flush();
                   out.close();                                     
                   journal.picture = destination;
                   journal.update();
                   
                   if(!journal.video.equals(""))
                      me.openscreen(JournalsActivity.class); 
                   else
                	  me.openscreen(AddJournalVideoActivity.class);
                   
                } catch (Exception e) {
                   e.printStackTrace();
                }                        	                  
               
        }  
    } 
	
	  
	
	
	
	

}
