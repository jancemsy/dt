package com.example.diettools;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class ToolsActivity extends Activity{
	MYAPP me; 
	
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tools);	 
		me = (MYAPP)getApplication(); 
		me.init(this);
		me.SetMainMenuListeners();
		((TextView) findViewById(R.id.header_main)).setText("Tools");
	    me.jumpActivityOnClick(R.id.Button01,ToolBMIActivity.class);
	    me.jumpActivityOnClick(R.id.Button02,ToolBMRActivity.class);
	    me.jumpActivityOnClick(R.id.Button03,ToolIBWActivity.class);
	    me.jumpActivityOnClick(R.id.Button04,ToolExerciseCaloriesActivity.class); 
	    me.jumpActivityOnClick(R.id.Button05,ToolBodyMeasurementActivity.class);	    
	}
 
}
