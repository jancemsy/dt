package com.example.diettools;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

public class AddJournalMindActivity extends Activity {
	MYAPP me; 
	static EditText txt_date;
	EditText txt_title;
	EditText txt_text;
	DialogFragment newFragment = null;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_journal_mind);
		me = (MYAPP) getApplication(); 
		me.init(this);
		me.SetMainMenuListeners();
		txt_title = (EditText) findViewById(R.id.editText1);
		txt_text  = (EditText) findViewById(R.id.txtregpassword);
		txt_date  = (EditText) findViewById(R.id.editText3); 
		txt_title.requestFocus();  
		
		if( !MYAPP.isEmpty(me._current_journal_id) ){
			Cursor cursor = MYAPP.static_ds.rawQuery("SELECT *FROM " +  UserJournals.TABLE + " WHERE  " +  
					UserJournals.C_id + " = " + me._current_journal_id + "  " , null);
			
			if(cursor.getCount() > 0){  
				cursor.moveToFirst(); 	 
			    txt_title.setText( cursor.getString(cursor.getColumnIndex(UserJournals.C_title)) );
			    txt_text.setText( cursor.getString(cursor.getColumnIndex(UserJournals.C_message)));  
			    txt_date.setText(cursor.getString(cursor.getColumnIndex(UserJournals.C_created)));
			}
		}else{
			final Calendar c = Calendar.getInstance();
			int year = c.get(Calendar.YEAR);
			int month = c.get(Calendar.MONTH);
			int day = c.get(Calendar.DAY_OF_MONTH); 
			txt_date.setText(year + "-" + month + "-" + day);	
		}
		
		me.jumpActivityOnClick(R.id.btn_cancel, JournalsActivity.class);		
		((Button) findViewById(R.id.btn_next))
				.setOnClickListener(new OnClickListener() {
					// @Override
					public void onClick(View view) {
						me._to_add_journal_title = txt_title.getText().toString();
						me._to_add_journal_text =  txt_text.getText().toString();
						me._to_add_journal_date =  txt_date.getText().toString();
						me.openscreen(  AddJournalBodyActivity.class);
					}
				});
 
			
	    txt_date.setOnClickListener(new OnClickListener() {
					// @Override
					public void onClick(View view) {						
						if( newFragment != null ) newFragment.dismiss(); 
						newFragment = new DatePickerFragment();
						newFragment.show(getFragmentManager(), "datePicker");						
					}
				});
	    }
	

	public static class DatePickerFragment extends DialogFragment 
	   implements DatePickerDialog.OnDateSetListener {   
	    Calendar cal;  
		Date date2 = null;			    

		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {			
            String date = txt_date.getText().toString();
	    	
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); 
			
			try {
				date2 = formatter.parse( date );
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
		    cal = Calendar.getInstance();	
		    if(date2 != null) cal.setTime(date2);
		    
			
			int year  = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH);
			int day   = cal.get(Calendar.DAY_OF_MONTH); 
			return new DatePickerDialog(getActivity(), this, year, month, day);
		}

		public void onDateSet(DatePicker view, int year, int month, int day) {
			txt_date.setText(year + "-" + MYAPP.add0( month + 1 ) + "-" + MYAPP.add0(day) );
		}
	}
 

}
