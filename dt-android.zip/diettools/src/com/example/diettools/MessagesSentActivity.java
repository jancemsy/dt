package com.example.diettools;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

public class MessagesSentActivity extends Activity {
	MYAPP me; 
	
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.messages_sent);	
		
		me = (MYAPP)getApplication(); 
		me.init(this);	
		me.SetMainMenuListeners();
		
		((TextView) findViewById(R.id.header_main)).setText("My Sent Messages");
		
		String query = "SELECT  m.*, u." + Users.C_username + ",u."+Users.C_avatar +  
		" FROM  "+Messages.TABLE+" m " +
		" LEFT JOIN "+Users.TABLE+" u  ON (u."+Users.C_oid+"=m."+Messages.C_recipient+") " +
		" WHERE   m." + Messages.C_sender + " =  "  + me.userID + " " +     
           " ORDER BY m.created DESC LIMIT 50";
		Cursor cursor = MYAPP.static_ds.rawQuery(query  , null);
		
		Log.d("MessagesSentActivity","checking............."+query);
					
			int[] TO = { R.id.col1 };
			String[] FROM = {  Messages.C_created }; 
			
			SimpleCursorAdapter adapter = new ActivityCursorAdapter(this, R.layout._custom_messages_inbox, cursor, FROM, TO);		
			ListView output_list = (ListView)findViewById(R.id.output_list);		 
			output_list.setAdapter(adapter);
			output_list.setDivider(null); 
			output_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {  
				@Override
				public void onItemClick(AdapterView<?> arg0, View view,
						int position, long arg3) {  
					 TextView v  = (TextView) view.findViewById(R.id.colID);					 
					 me._message_id = v.getText().toString();					 									 					
				     me.openscreen(MessagesReadSentActivity.class); 
				}
	      }); 
					 	 
	}
	
	
	public class ActivityCursorAdapter extends SimpleCursorAdapter{ 
	    Cursor c;
	    Context context;
	    Activity activity;

	    public ActivityCursorAdapter(Context context, int layout, Cursor c,
	            String[] from, int[] to) {
	        super(context, layout, c, from, to); 
	        this.c = c;
	        this.context=context;
	        this.activity=(Activity) context; 
	    } 
	                                           
	    @Override
	    public View getView(int position, View convertView, ViewGroup parent) {
	        if(convertView == null)
	            convertView = View.inflate(context, R.layout._custom_messages_inbox, null);
	        View row = convertView; 
	        c.moveToPosition(position); 	        
	        int    id        = c.getInt( c.getColumnIndex( Messages.C_id ) );  
	        String created   = c.getString(  c.getColumnIndex( Messages.C_created ) ); 
	        String subject   = c.getString(  c.getColumnIndex( Messages.C_subject ) );
	        String from      = c.getString(  c.getColumnIndex( Users.C_username ) );
	        	        	                                             
            SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            SimpleDateFormat newFormater = new SimpleDateFormat("MM/dd/yyyy");
            SimpleDateFormat timeFormater = new SimpleDateFormat("hh:mm aa");
            
            if (position % 2 == 0) row.setBackgroundResource(R.color.lightgray1);
			else row.setBackgroundResource(R.color.white);	
            
            Date dateObj;
            String date = "";
            String time      = "";
            
			try {
				dateObj = dateFormater.parse(created);
			    date = newFormater.format(dateObj);
			    time = timeFormater.format(dateObj);			    
			} catch (ParseException e) {	
				Log.d("PROFILE ACTIVITY","ERROR profile date convertion..............",e);
				e.printStackTrace();
			}                           
			                                              	                         
	        TextView col1 = (TextView) convertView.findViewById(R.id.col1);
	        TextView col2 = (TextView) convertView.findViewById(R.id.col2);
	        TextView col3 = (TextView) convertView.findViewById(R.id.col3);
	        TextView colID = (TextView) convertView.findViewById(R.id.colID);
	        
	        colID.setText(String.valueOf(id)); 
	        col1.setText(subject); 
	        col2.setText(from);
	        col3.setText(  time + "  " + date );
	        
	        return(row);
	    } 
	}
 
}
