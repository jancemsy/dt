 package com.example.diettools;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
 
 
public class ToolBodyMeasurementAddActivity extends Activity{
	MYAPP me;  
	EditText txtdate; 
    EditText txtarm;
    EditText txtchest;
    EditText txtwaist;
    EditText txthips;
    Button btnAddMeasurement;
    DialogFragment newFragment = null;
	  
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.bodymeasurement_add);	 
		me = (MYAPP)getApplication(); 
		me.init(this);
		me.SetMainMenuListeners();		
		
		txtdate  = (EditText) findViewById(R.id.txtdate); 
	    txtarm   = (EditText) findViewById(R.id.txtarm);
	    txtchest = (EditText) findViewById(R.id.txtchest);
	    txtwaist = (EditText) findViewById(R.id.txtwaist);
	    txthips  = (EditText) findViewById(R.id.txthips);
	    btnAddMeasurement  = (Button) findViewById(R.id.btnAddMeasurement);
	    
	    btnAddMeasurement.setOnClickListener(new OnClickListener() {
			//@Override
 			public void onClick(View view) {
 				MeasurementTracker mt = new MeasurementTracker();
 				double arm = Double.parseDouble( txtarm.getText().toString() );;
 				double chest     = Double.parseDouble( txtchest.getText().toString() );
 				double waist     = Double.parseDouble( txtwaist.getText().toString() );
 				double hips      = Double.parseDouble( txthips.getText().toString() ); 
 				 		 				
 				if( arm > 0 && chest > 0 && waist > 0 && hips > 0){ 					
 				  mt.created   = txtdate.getText().toString();
 				  mt.userID    = me.userID; 
 				  mt.upper_arm = Double.parseDouble( txtarm.getText().toString() );
 				  mt.chest     = Double.parseDouble( txtchest.getText().toString() );
 				  mt.waist     = Double.parseDouble( txtwaist.getText().toString() );
 				  mt.hips      = Double.parseDouble( txthips.getText().toString() ); 				 				 		
 				  mt.insert(); 	
 				  me.flash("Measurement has been save!");
 				  me.openscreen(ToolBodyMeasurementActivity.class); 
 				}else{
 				  me.alertbox("Please complete the fields!");
 				} 			
			}
	    });	    
	    
	    
	    txtdate.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {						
				if( newFragment != null ) newFragment.dismiss(); 
				newFragment = new DatePickerFragment(txtdate.getText().toString());
				newFragment.show(getFragmentManager(), "datePicker");						
			}
		}); 
		
	}
	
	
	
	
	public class DatePickerFragment extends DialogFragment 
	   implements DatePickerDialog.OnDateSetListener {   
		final Calendar cal;  
		Date date2 = null;
		
		DatePickerFragment( String date ){
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); 
			
			try {
				date2 = formatter.parse( date );
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
		    cal = Calendar.getInstance();	
		    if(date2 != null) cal.setTime(date2);  		        
		}

		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {  
			int year  = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH);
			int day   = cal.get(Calendar.DAY_OF_MONTH); 
			return new DatePickerDialog(getActivity(), this, year, month, day);
		}
		
		 
		public void onDateSet(DatePicker view, int year, int month, int day) {
			txtdate.setText(year + "-" + MYAPP.add0( month + 1 ) + "-" + MYAPP.add0(day) );
		}
	}
 
}
