package com.example.diettools;



import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

import android.app.Activity;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.androidplot.series.XYSeries;
import com.androidplot.xy.LineAndPointFormatter;
import com.androidplot.xy.SimpleXYSeries;
import com.androidplot.xy.XYPlot;



public class ToolBodyMeasurementActivity extends Activity{
	MYAPP me; 
	private XYPlot mySimpleXYPlot = null;
	Button btnnext;
	Button btnprev;
	int thisMonth;
	int thisYear;
	String months[] = {"","January","February","March",
			           "April","May","June","July","August",
			           "September","October","November","December"};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.bodymeasurement);	
		
		me = (MYAPP)getApplication(); 
		me.init(this);
		me.SetMainMenuListeners();
		
		Calendar calendar = Calendar.getInstance();
		Date date = calendar.getTime();

		SimpleDateFormat sdf = new SimpleDateFormat("M");
		thisMonth = Integer.parseInt(sdf.format(date));
		
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy");
		thisYear = Integer.parseInt(sdf2.format(date));  
		 
		me.jumpActivityOnClick(R.id.btnAddMeasurement, ToolBodyMeasurementAddActivity.class);
		
		btnnext = (Button) findViewById(R.id.btnnext);		
		btnprev = (Button) findViewById(R.id.btnprev);
		
		btnnext.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {
				moveMonth(1);
			}
		});
		
		btnprev.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {
				moveMonth(-1);
			}
		});
		 
		
		
		
		

		renderPlot();
	}
	
	public void moveMonth(int i){
		
		if(i > 0){
			thisMonth++;
		}else{			
	        thisMonth--;			
		}
		
		if(thisMonth > 12){
			thisMonth = 1;
			thisYear ++;
		}
		
		if(thisMonth <= 0){
			thisMonth = 12;
			thisYear --;
		}
		
		renderPlot();
	}
	
	
	public void renderPlot(){
		if( mySimpleXYPlot != null){
			mySimpleXYPlot.destroyDrawingCache();
			mySimpleXYPlot.clear();
		}
		mySimpleXYPlot = (XYPlot) findViewById(R.id.mySimpleXYPlot);
		/*
		// Create a couple arrays of y-values to plot:
		Number[] series1Numbers = {1, 8, 5, 2, 7, 4}; //arms
		Number[] series2Numbers = {4, 6, 3, 8, 2, 10};//chest
		Number[] series3Numbers = {3, 4, 7, 4, 4, 9};//waist
		Number[] series4Numbers = {5, 6, 8, 5, 5, 4};//hips		
		Number[] series1NumbersY = {1 , 5 ,10, 15, 20, 25}; //days
		*/ 
		
		String searchMonth =    thisMonth   > 9 ?  thisMonth  + "" : "0" + thisMonth ;  
		
		Cursor c = MYAPP.static_ds.rawQuery("SELECT *FROM " + MeasurementTracker.TABLE
				+ " WHERE  strftime('%Y-%m', `"+MeasurementTracker.C_created+"`) = " +
				"'" + thisYear + "-" + searchMonth + "' " , null); 
		
		
		int size = c.getCount();	
		
	    if(size < 1) size = 1;
		
		int arms, chest, waist, hips, day;
		String date;
		Number[] series1Numbers = new Number[size]; //arms
		Number[] series2Numbers = new Number[size];//chest
		Number[] series3Numbers = new Number[size];//waist
		Number[] series4Numbers = new Number[size];//hips		
		Number[] series1NumbersY = new Number[size]; //days
		
		
		if( c.getCount() > 0){    
		    c.moveToFirst(); 
		    for(int i = 0; i < size; i++){			
              	arms = c.getInt(c.getColumnIndex( MeasurementTracker.C_upper_arm ) );           	
             	chest = c.getInt(c.getColumnIndex( MeasurementTracker.C_chest ) );           	
            	waist = c.getInt(c.getColumnIndex( MeasurementTracker.C_waist ) );           	
             	hips = c.getInt(c.getColumnIndex( MeasurementTracker.C_hips) );           	
             	date = c.getString(c.getColumnIndex( MeasurementTracker.C_created ) );       
            	day  = Integer.parseInt(date.split("-")[2]); 
           	
            	series1Numbers[i] = arms;
             	series2Numbers[i] = chest;
           	    series3Numbers[i] = waist;
           	    series4Numbers[i] = hips;
             	series1NumbersY[i] = day;           	           
                c.moveToNext();            	            	
            }  
		}else{           //defaults
			series1Numbers[0] = 0;
			series2Numbers[0] = 0;
			series3Numbers[0] = 0;
			series4Numbers[0] = 0;
			series1NumbersY[0] = 0;  
		} 
		
			
		//SimpleXYSeries.ArrayFormat.Y_VALS_ONLY
		// Turn the above arrays into XYSeries':
		XYSeries series1 = new SimpleXYSeries(
				Arrays.asList(series1NumbersY),
				Arrays.asList(series1Numbers),  // SimpleXYSeries takes a List so turn our array into a List				
		"Arms");                             // Set the display title of the series
		
		
		XYSeries series2 = new SimpleXYSeries( Arrays.asList(series1NumbersY), Arrays.asList(series2Numbers), "Chest");
		XYSeries series3 = new SimpleXYSeries( Arrays.asList(series1NumbersY) , Arrays.asList(series3Numbers),   "Waist");
		XYSeries series4 = new SimpleXYSeries( Arrays.asList(series1NumbersY), Arrays.asList(series4Numbers), "Hips");
		
		mySimpleXYPlot.setDomainLabel( months[thisMonth] + " " + thisYear);
		mySimpleXYPlot.setRangeLabel("Measurements (inches)");
		mySimpleXYPlot.setDomainValueFormat(new DecimalFormat("0"));
		mySimpleXYPlot.setTitle("Body Measurement Progress");
		
		// Create a formatter to use for drawing a series using LineAndPointRenderer:	        
		LineAndPointFormatter series1Format = new LineAndPointFormatter(
				Color.rgb(0, 200, 0),                   // line color
				Color.rgb(0, 100, 0),                   // point color
				null);                                  // fill color (none)
		// add a new series' to the xyplot:
		mySimpleXYPlot.addSeries(series1, series1Format);
		
		// same as above:
		mySimpleXYPlot.addSeries(series2, new LineAndPointFormatter(Color.rgb(0, 0, 200), Color.rgb(0, 0, 100), null));			
		mySimpleXYPlot.addSeries(series3, new LineAndPointFormatter(Color.rgb(255, 255, 51),Color.rgb(255, 255, 51), null));		
		mySimpleXYPlot.addSeries(series4, new LineAndPointFormatter(Color.rgb(255,4 ,4), Color.rgb(255,4 ,4), null));
		
		// reduce the number of range labels
		mySimpleXYPlot.setTicksPerRangeLabel(3);
		// by default, AndroidPlot displays developer guides to aid in laying out your plot.
		// To get rid of them call disableAllMarkup():
	    mySimpleXYPlot.disableAllMarkup();	
		
		mySimpleXYPlot.redraw();  
	}
 
}
