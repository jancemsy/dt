package com.example.diettools;


import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

public class JournalsActivity extends Activity{
	MYAPP me; 
	ListView output_list;
    private static final int EDIT_ID = Menu.FIRST + 3;
    private static final int DELETE_ID = Menu.FIRST + 4;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.journals);			
		me = (MYAPP)getApplication(); 
		me.init(this);
		me.SetMainMenuListeners();
		output_list = (ListView) findViewById(R.id.output_list); 
		((TextView) findViewById(R.id.header_main)).setText("Journals");
		 
		displayList();
	   
		
	}
	
	
	public void displayList(){
		Cursor cursor = MYAPP.static_ds.getCursor(UserJournals.TABLE, UserJournals.C_id, UserJournals.C_id + " DESC", "100"); 			 
		String[] FROM = { UserJournals.C_title, UserJournals.C_message ,UserJournals.C_created, UserJournals.C_id,UserJournals.C_oid };
		int[] TO = { R.id.col1, R.id.col2, R.id.col3 , R.id.colID,R.id.colOID};			
		SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, R.layout._custom_journal_list1, cursor, FROM, TO) {
			@Override
			public View getView(int position, View convertView, ViewGroup parent) {
				 final View row = super.getView(position, convertView, parent);
				 if (position % 2 == 0) row.setBackgroundResource(R.color.lightgray1);
				 else row.setBackgroundResource(R.color.white);	 
				 return row;
			}  
		};			
		output_list.setAdapter(adapter);			
		output_list.setDivider(null);
		output_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {  
			@Override
			public void onItemClick(AdapterView<?> arg0, View view, int position, long arg3) {  
				 TextView v  = (TextView) view.findViewById(R.id.colID);  
				 me._current_journal_id  = v.getText().toString();  						
			     me.openscreen(  JournalPageActivity.class); 
			}
       }); 
		
		registerForContextMenu(output_list);		 		
	}
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) { 
    	getMenuInflater().inflate(R.menu.journals_menu, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {  
		switch (item.getItemId()) {
		case R.id.item_add: 		 
			me._current_journal_id  = ""; //make sure it empty 						
		    me.openscreen(AddJournalMindActivity.class); 
			return true;		
		default:
			return false;
		}
	} 
	
	
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,ContextMenuInfo menuInfo) {
	super.onCreateContextMenu(menu, v, menuInfo);
        AdapterView.AdapterContextMenuInfo info; 
        info = (AdapterView.AdapterContextMenuInfo) menuInfo; 
	    String title = ((TextView) info.targetView.findViewById(R.id.col1)).getText().toString(); 	   
	    menu.setHeaderTitle(title);
 	    menu.add(0, DELETE_ID, 0, "Delete Journal");
	    menu.add(0, EDIT_ID, 0, "Edit Journal");
	} 
	
	@Override
	public boolean onContextItemSelected(MenuItem item) {
	  AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();	  
	  int id  =  MYAPP.toInt( ((TextView) info.targetView.findViewById(R.id.colID)).getText().toString() );
	  int oid =  MYAPP.toInt( ((TextView) info.targetView.findViewById(R.id.colOID)).getText().toString() );
	  
      switch (item.getItemId()) {    
      case EDIT_ID: 
    	  me._current_journal_id = String.valueOf(id);
    	  me.openscreen(AddJournalMindActivity.class);     	  
          return (true);             
      case DELETE_ID:  
    	  if(oid> 0){    			      						 
				me.tid = oid;
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(6);		
				nameValuePairs.add(new BasicNameValuePair("oid",String.valueOf(oid)));
				ApiCaller api = new ApiCaller(nameValuePairs, "deleteJournal",2);	  		
			    api.setReadyListener(new ApiCaller.OnReadyListener() {
					@Override
					public void onReady(String result){					
						MYAPP me = (MYAPP) MYAPP.static_activity.getApplication();	 
						MYAPP.static_ds.db.delete(UserJournals.TABLE ,  UserJournals.C_oid + "=" +  me.tid, null);
						me.tid  = 0;
						Log.d("calling async", "DeleteJournal Callback Success");
						displayList();  
					} 
				});
			    api.execute();    				
		  }else{
		        MYAPP.static_ds.db.delete(UserJournals.TABLE ,  UserJournals.C_id + " = " +  id, null); 
		        displayList();   
		  }
    	  
          return (true);
      }      
      return true;
	} 
	
	
	
	
	/*
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,ContextMenuInfo menuInfo) {
	super.onCreateContextMenu(menu, v, menuInfo); 	    
	    AdapterView.AdapterContextMenuInfo info; 
	    info = (AdapterView.AdapterContextMenuInfo) menuInfo; 
	    	    
	    int id = MYAPP.toInt( ((TextView) info.targetView.findViewById(R.id.colID)).getText().toString() );	  	 			 	   
	    String title = ((TextView) info.targetView.findViewById(R.id.col1)).getText().toString(); 	   
	    menu.setHeaderTitle(title);	    			   
	    menu.add(id, DELETE_ID, 0, "Delete Journal");
	    menu.add(id, EDIT_ID, 0, "Edit Journal");
	   
	} 
    
	
	@Override
	public boolean onContextItemSelected(MenuItem item) {
	  AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();	  
	  int id  =  MYAPP.toInt( ((TextView) info.targetView.findViewById(R.id.colID)).getText().toString() );
	  int oid =  MYAPP.toInt( ((TextView) info.targetView.findViewById(R.id.colOID)).getText().toString() );
	  
      switch (item.getItemId()) { 
        case EDIT_ID:
   	   
   	    return (true);   
   	   
        case DELETE_ID:
    	   
    	return (true);   
      }
    		  
    	 
      return true;
	}
 */
}
