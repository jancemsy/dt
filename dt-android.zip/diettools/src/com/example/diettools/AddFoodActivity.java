package com.example.diettools;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class AddFoodActivity extends Activity {
	MYAPP me; 
	EditText search_txt;
	Button search_btn; 
	Foods food;
	Button btn_add_food; 
	TextView txt_serving;
	TextView txt_cal;
	TextView txt_size;
	TextView txt_fat;
	TextView txt_carb;
	TextView txt_protein;
	TextView txt_food_name;
	EditText txtqty;
    UserFoods myfood, origmyfood;
    
	
	

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_food);
		me = (MYAPP) getApplication();  
		me.init(this); 
		me.SetMainMenuListeners();
		me.setDateButtonListeners();	
		
		btn_add_food = (Button) findViewById(R.id.btn_add_food);  	 
		txt_serving = (TextView) findViewById(R.id.txt_serving1); 
		txt_cal = (TextView) findViewById(R.id.txt_cal1); 
		txt_size = (TextView) findViewById(R.id.txt_size1); 
		txt_fat = (TextView) findViewById(R.id.txt_fat1); 
		txt_carb = (TextView) findViewById(R.id.txt_carb1); 
		txt_protein = (TextView) findViewById(R.id.txt_protein1); 
		txt_food_name = (TextView) findViewById(R.id.txt_food_name);
		txtqty        = (EditText) findViewById(R.id.txtqty);
		txtqty.addTextChangedListener(new TextWatcher(){
	        public void afterTextChanged(Editable s) {	        	
	        	computeFood();
	        }
	        public void beforeTextChanged(CharSequence s, int start, int count, int after){}
	        public void onTextChanged(CharSequence s, int start, int before, int count){}
	    });   
		
		myfood             =  new UserFoods();	
		origmyfood         =  new UserFoods();	
		
		if(!MYAPP.isEmpty(me._food_id)){
		    prepareAddFood();
		}else if(!MYAPP.isEmpty(me._to_edit_food_ID)){
			prepareEditFood();
		}else{
			me.openscreen(DashboardActivity.class);
		} 		
	}
	
	
	private void prepareEditFood(){
		me.changeMainHeader("Update food");
		Cursor cursor = MYAPP.static_ds.rawQuery("SELECT *FROM " + UserFoods.TABLE
				+ " WHERE (   " + UserFoods.C_ID + " LIKE ? AND " + UserFoods.C_USERID+" LIKE ?  ) ",
				new String[] { me._to_edit_food_ID, String.valueOf(me.userID) });
		 
		if(cursor.getCount() > 0){    
			cursor.moveToFirst();  			
		    myfood.setInfo(cursor);			
			origmyfood.qty             =  myfood.qty;			
			Foods thisFood             =  getFoodById(String.valueOf(myfood.foodID));					
			if( thisFood.id  > 0){  				 						
				origmyfood.protein     =  thisFood.protein; 
				origmyfood.carb        =  thisFood.carbs; 
				origmyfood.fat         =  thisFood.fats; 
				origmyfood.cal         =  thisFood.cal;
			}else{			
			    me.openscreen(DashboardActivity.class);
			    me.alertbox("Updating food error. Coun't access food db");
			}
			
			txtqty.setText(String.valueOf(origmyfood.qty));
			txtqty.setSelection(txtqty.getText().length()); 
			computeFood();			
			txt_food_name.setText( myfood.name );
			txt_size.setText(  myfood.size );
			txt_serving.setText(  String.valueOf(thisFood.serving)  ); 
			btn_add_food.setText("Save Food");
			btn_add_food.setOnClickListener(new OnClickListener() {
			   // @Override
		       	public void onClick(View view) {
		       		me._food_id  = "";  
		       		me._food_type = "";	
		       		me._to_edit_food_ID = "";
		       	    me.currentTab = 0;
		       	    myfood.update(); 		       	     	       	 		       	    	       	
		       		new SynchUploader("adduserfood").execute();  /*add or update works here*/
			    }
	       	});  
			me.jumpActivityOnClick(R.id.btn_cancel,DashboardActivity.class );	 
		}else{
			me.openscreen( DashboardActivity.class );
		}
	}
	
	private Foods getFoodById(String id){
		Foods food = new Foods(); 
		Cursor cursor = MYAPP.static_ds.rawQuery("SELECT *FROM " +  Foods.TABLE
				+ " WHERE (   " + Foods.C_foodID + " LIKE ?  ) ",
				new String[] { id });
		
		if(cursor.getCount() > 0){  
			cursor.moveToFirst();
			food.setInfo(cursor);	   		            
		}
		
		return food;
	}
	
	
	private void prepareAddFood(){ 			
		me.changeMainHeader("Add To " + me._food_type + "");
		Foods thisFood  = getFoodById(me._food_id);					
		if( thisFood.id  > 0){  		 
            myfood.created     =  me.dateString;
            myfood.userID      =  me.userID;
            myfood.type        =  me._food_type;
			myfood.foodID      =  thisFood.foodID; 
			myfood.name        =  thisFood.name; 			
			myfood.protein     =  thisFood.protein; 
			myfood.carb        =  thisFood.carbs; 
			myfood.fat         =  thisFood.fats; 
			myfood.cal         =  thisFood.cal;
			myfood.size        =  thisFood.size; 
			myfood.qty         =  1;
			
			origmyfood.qty         =  1;
			origmyfood.protein     =  thisFood.protein; 
			origmyfood.carb        =  thisFood.carbs; 
			origmyfood.fat         =  thisFood.fats;  
			origmyfood.cal         =  thisFood.cal;  
			txtqty.setText("1");        
			txtqty.setSelection(txtqty.getText().length());
		     
			
			computeFood();			
			txt_food_name.setText( myfood.name );
			txt_size.setText(  myfood.size );
			txt_serving.setText( String.valueOf(thisFood.serving) );   
				
			 
			btn_add_food.setOnClickListener(new OnClickListener() {
			   // @Override
		       	public void onClick(View view) {
		       		me._food_id  = "";  
		       	    me.currentTab = 0;
		       	    int tid = myfood.insert(); 		       	    
		       	    me.addPoints(MYAPP.INPUT_FOOD_PTS, "user food", tid , 0,  0);		       	 
		       	    me._food_type = "";		       		
		       		new SynchUploader("adduserfood").execute(); 
			    }
	       	});  
			me.jumpActivityOnClick(R.id.btn_cancel,AddFoodSearchActivity.class );	 
		}else{
			me.openscreen( AddFoodTypeActivity.class );
		}
	}
	
	
    public void computeFood(){    	
    	if( !MYAPP.isEmpty(txtqty.getText().toString())){
	    	origmyfood.qty = MYAPP.toInt(txtqty.getText().toString());
	    	
	    	Log.d("computeFood","-------------------------------->" + origmyfood.qty);
	    	myfood.qty     = origmyfood.qty;
	    	myfood.cal     = origmyfood.cal * origmyfood.qty; 
	    	myfood.fat     = origmyfood.fat * origmyfood.qty;
	    	myfood.carb    = origmyfood.carb * origmyfood.qty;
	    	myfood.protein = origmyfood.protein * origmyfood.qty;
	    	
			 				
			txt_cal.setText(  Double.toString(myfood.cal) );			
			txt_fat.setText( Double.toString(myfood.fat) + "g");			
			txt_carb.setText( Double.toString(myfood.carb) + "g");			
			txt_protein.setText( Double.toString(myfood.protein) + "g");
    	}
    }
	
	
	
	class SynchUploader extends AsyncTask<String, Void, String> {		
		Context context;  
		ProgressDialog progress; 
		String TAG = "adduserfood Synch Uploader"; 
		String method = "adduserfood";
			
		public SynchUploader(String method) { 
			this.context    = AddFoodActivity.this; 
			this.method     = method;
		}	
		@Override
	    protected void onPreExecute() {
		        progress = ProgressDialog.show(this.context, "", "Please wait..."); 
		        super.onPreExecute();
		 }		
		@Override
		protected String doInBackground(String... params) { 
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(14);	 
			nameValuePairs.add(new BasicNameValuePair("created", myfood.created));						
			nameValuePairs.add(new BasicNameValuePair("oid",     String.valueOf(myfood.oid)));
			nameValuePairs.add(new BasicNameValuePair("userID",  String.valueOf(myfood.userID)));        		
			nameValuePairs.add(new BasicNameValuePair("type",    myfood.type));						
			nameValuePairs.add(new BasicNameValuePair("foodID",  String.valueOf(myfood.foodID)));			
			nameValuePairs.add(new BasicNameValuePair("name",    String.valueOf(myfood.name)));			
			nameValuePairs.add(new BasicNameValuePair("protein", String.valueOf(myfood.protein)));			
			nameValuePairs.add(new BasicNameValuePair("carb",    String.valueOf(myfood.carb)));
			nameValuePairs.add(new BasicNameValuePair("fat",     String.valueOf(myfood.fat)));
			nameValuePairs.add(new BasicNameValuePair("cal",     String.valueOf(myfood.cal)));
			nameValuePairs.add(new BasicNameValuePair("size",    String.valueOf(myfood.size)));
			nameValuePairs.add(new BasicNameValuePair("qty",     String.valueOf(myfood.qty)));	 
			nameValuePairs.add(new BasicNameValuePair("method",    method));
			nameValuePairs.add(new BasicNameValuePair("email",     me.user.email));
			nameValuePairs.add(new BasicNameValuePair("password",  me.user.password));
	 
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(MYAPP.API_BASE);

			try {
				httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				HttpResponse response = httpclient.execute(httppost);
				String output = MYAPP.getWebString(response.getEntity().getContent());
				Log.d(TAG, "API Connection Result for "+method+": " + output); 
				return output;
			} catch (ClientProtocolException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} catch (IOException e) {
				Log.e(TAG, "::ERROR::", e);
				e.printStackTrace();
			} 
			return "";   
		}  
		
		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);	 
			if(result.length() == 0){
				progress.dismiss(); 
			}else{
				if( !MYAPP.isNumeric(result) ){
					 progress.dismiss();
					 me.alertbox("There is an error adding your food online"); 
				}else{ //user found here 
					   myfood.oid = Integer.parseInt(result);
					   myfood.update(); 
				}				
			}			
			me.openscreen(DashboardActivity.class);
       }
	
  }
	
 
}
