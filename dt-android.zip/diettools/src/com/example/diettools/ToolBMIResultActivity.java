package com.example.diettools;


import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class ToolBMIResultActivity extends Activity{
	MYAPP me; 
	
	@Override
	protected void onCreate(Bundle savedInstanceState) { 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.bmi_result);			
		me = (MYAPP)getApplication(); 
		me.init(this);
		me.SetMainMenuListeners(); 			
		TextView result1 = (TextView) findViewById(R.id.textView1);
		TextView result2 = (TextView) findViewById(R.id.textView4);
		
	    result1.setText(me._bmi_result1);
	    result2.setText(me._bmi_result2);
	    
	    Button back = (Button) findViewById(R.id.Button01);	    	
	    back.setOnClickListener(new OnClickListener() {
			// @Override
			public void onClick(View view) {
				  me.openscreen(ToolBMIActivity.class);
			}
		});		
	}
	
	 
}